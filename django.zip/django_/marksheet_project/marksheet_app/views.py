from django.shortcuts import render, redirect
from .forms import SubjectForm
from .models import Subject

def input_marks(request):
    # Subject.objects.all().delete()
    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('marksheet')
    else:
        form = SubjectForm()
    return render(request, 'input_marks.html', {'form': form})

def marksheet(request):
    subjects = Subject.objects.all()
    total_marks = sum(subject.total_marks() for subject in subjects)
    max_marks = len(subjects) * 100  # 80 (theory) + 20 (internal)
    overall_pass = all(subject.pass_status() for subject in subjects)
    
    return render(request, 'marksheet.html', {
        'subjects': subjects,
        'total_marks': total_marks,
        'max_marks': max_marks,
        'overall_pass': overall_pass,
    })
