from django.db import models

class Subject(models.Model):
    name = models.CharField(max_length=100)
    theory_marks = models.PositiveIntegerField()
    internal_marks = models.PositiveIntegerField()

    def total_marks(self):
        return self.theory_marks + self.internal_marks

    def pass_status(self):
        return self.total_marks() >= 35
