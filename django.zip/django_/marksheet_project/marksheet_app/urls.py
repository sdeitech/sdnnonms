from django.urls import path
from .views import input_marks, marksheet

urlpatterns = [
    path('', input_marks, name='input_marks'),
    path('marksheet/', marksheet, name='marksheet'),
]
