from django.apps import AppConfig


class MarksheetAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'marksheet_app'
