from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('marksheet_app.urls')),
]
# python3 manage.py makemigrations
# python manage.py migrate
