import express from "express";
import { verifToken } from "../middleware/verifyToken";
const router = express.Router();
const studentController = require('../controller/student-Controller')

router.post('/add-student',[verifToken], studentController.createStudent)
router.get('/get-student',[verifToken], studentController.getStudents)
// router.get('/get-student', studentController.getStudents)

router.get('/get-student/:id', studentController.getStudentById)

module.exports = router;


