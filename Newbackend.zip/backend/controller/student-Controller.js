const Student = require("../model/studentModel");

// const createStudent = async (req, res) => {
//     try {
//         const { firstName, lastName, email} = req.body;
//         const userId = req.userId

//         const user = new Student({
//             firstName : firstName,
//             lastName : lastName,
//             email : email,
//             userId
//         })

//         await user.save()
//         res.status(200).json(user)
//     } catch (error) {
//         console.log(error);
//         res.status(401).json({ Error: error.message });
//     }
// }





const createStudent = async (req, res) => {
    try {
        const { firstName, lastName, email} = req.body;
        const userId = req.user.userId

        console.log('userId',userId)
        const user = new Student({
            firstName : firstName,
            lastName : lastName,
            email : email,
            userId : userId
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}


export const getUsers = async (req, res) => {
    try {
        const user = await Users.findById(req.params.id)
        if (!user) {
            return res.status(STATUS_CODE.NOT_FOUND).json({ message: MESSAGE.USER_NOT_FOUND })
        }
        const userDetails = await Users.findById(req.params.id).populate("users")
        res.status(STATUS_CODE.SUCCESS).json({ user: userDetails })

    } catch (error) {
        console.log(`Error while getting user ${error.message}`)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}


const getStudents = async (req, res) => {
    try {
        const { searchText } = req.query;
        const userId = req.user.userId
        console.log('userId---------', userId)

        let filter = {};

        filter.userId = userId;

        if (searchText) {
            filter = {
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 4;
        const skip = (page - 1) * limit;

        const students = await Student.find(filter)
            .select('firstName lastName email password maritalStatus dob gender userId')
            .skip(skip)
            .limit(limit);
        const totalCount = await Student.countDocuments(filter);

        const response = {
            students: students,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: "Internal Server Error" });
    }
};

//here using populate
// const getStudents = async (req, res) => {
//     try {
//         const { searchText } = req.query;

//         let filter = {};

//         if (searchText) {
//             filter = {
//                 $or: [
//                     { firstName: { $regex: searchText, $options: 'i' } },
//                     { lastName: { $regex: searchText, $options: 'i' } },
//                 ]
//             };
//         }

//         const page = parseInt(req.query.page) || 1;
//         const limit = parseInt(req.query.limit) || 8;
//         const skip = (page - 1) * limit;

//         const students = await Student.find({filter })
//             .populate('userId', 'firstName lastName email')
//             .select('firstName lastName email password maritalStatus dob gender')
//             .skip(skip)
//             .limit(limit);
//         const totalCount = await Student.countDocuments(filter);

//         const response = {
//             students: students,
//             pagination: {
//                 total_record: totalCount,
//                 per_page: limit,
//                 current_page: page,
//                 total_pages: Math.ceil(totalCount / limit),
//             },
//         };

//         res.status(200).json(response);
//     } catch (error) {
//         console.error(error); 
//         res.status(500).json({ error: "Internal Server Error" });
//     }
// };



const getStudentById = async (req, res) => {
    try {
        const { id } = req.params
        const student = await Student.findById(id)
        res.status(200).json(student)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}




module.exports = {createStudent, getStudents, getStudentById};
