import multer from 'multer';
import path from 'path';

import {messages} from '../config/constant'

const storage = multer.diskStorage({
    destination: function (req ,file , cb){
        cb(null , './images');
    },
    filename:function (req , file , cb){
        cb(null , Date.now() + path.extname(file.originalname));
    }
});

// const filefilter=(req,file ,cb) =>{
//     const allowedTypes = ['image.png' ,'image.jpg','image.jpeg'];
//     if(!allowedTypes.includes(file.mimetype)) {
//         return cb(new Error("this file type not allowed"));
//     }
//     cb(null ,true);
// };

export const uploadMiddleware = multer({
    storage:storage,
    // fileFilter:filefilter,
    limits:{fileSize: 5 * 1024 *1024}

});









