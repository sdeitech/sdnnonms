const Info = require('../model/info.model');
// Create Item 
exports.createUser = async (req, res) => {
    try {
        const newInfo = new Info(req.body);
        await newInfo.save(); res.status(201).json(newInfo);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
exports.getUser = async (req, res) => {
    console.log("getting")
    const{id} = req.params;
    console.log(req.param);


    try {
        const info = await Info.find({});
        res.json(info);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
exports.getOneUser = async (req , res) => {
    // console.log("oneUser",req.params.id)
    try{
        const info = await Info.findOne({id:req.body._id});
        console.log(info ,"dff")
        res.json({info})
    }catch (error) {
        res.status(500).json
    }
};

exports.updateUser = async(req,res) => {
    try{

        const info = await Info.findByIdAndUpdate(req.params.id,req.body,{
            new:true
        });

        if(!info){
            return res.status(404).json({error:'User not found'});
        }
        res.json(info);
    } catch(error){
        res.status(400).json({error:error.message});
    }

};
exports.deleteUser = async (req,res) => {
    try{
        const info = await Info.findByIdAndDelete(req.params.id);
        
        res.json("User Deleted Successfully");
        console.log(info);

    } catch(error){
        res.status(500).json({error:error.message});
    }
};

exports.getUserPagination = async(req,res) =>{
    try{
        const filter ={
            $or:[
                {
                    firstName: {$regex:req.query.searchText || ' ',$options:'i'}
                }
            ]

        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page-1) * limit;

        const info = await Info.find(filter).skip(skip).limit(limit);
        const totalCount = await Info.countDocuments();

        const response = {
            Info:info,
            pagination:{
                total_record:totalCount,
                perPage : limit,
                currentPage: page,
            }
        }
        res.status(200).json(response);

    } catch(error){
        res.status(500).json("error in pagination")
    }
};
