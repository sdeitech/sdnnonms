const User = require('../model/user.model');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

exports.userRegister = async (req,res) =>{
    // const  {userName , password} = req.body;
    //console.log(req.body);
    console.log(req.file);
    try{
    const  {firstName,lastName,email,dob,password,gender,image} = req.body;
    console.log(req.body);

    // processTicksAndRejections

//         const existingUser = await User.findOne(req.body.userName);
// console.log(existingUser,"ghjdghsgd");
        
//         if (existingUser) return res.status(500).send("User already Exist");

        const hashedPass = await bcrypt.hashSync(password , 10);
        console.log(hashedPass);
        

        const newuser = new User({firstName,lastName,email,dob,gender,image:req.file.filename,password:hashedPass});
        console.log(newuser);
        

        await newuser.save();
         res.status(200).json(newuser);
    }catch(err){
        console.log(err);
        res.status(500).send("error registering user");
    }

};


// exports.userRegister = async (req, res) =>{
// console.log("body",req.body);
// // console.log("file",req.file);

// console.log(req.body);
// };
exports.userLogin = async (req ,res) =>{
    // console.log("gayatri")
    try{
        const {email, password} = req.body;
        console.log(req.body)

        const user = await User.findOne({email});
        // console.log(user)

         


        if(!user) return res.status(400).send("User Not Found");
        // console.log(!user)

        const isMatch = await bcrypt.compare(password,user.password);
        // console.log(isMatch)

        if(!isMatch) return res.status(400).send('Credntial Invalid');
        // console.log(!isMatch)

        const token = jwt.sign({userId: user._id},'your_jwt_secret',{expiresIn:'1h'});
        // console.log(token);

        // console.log({token});
         user.tokens=[{token}];

         await user.save();

         console.log(token);

        res.status(200).json({message:'login successfully', token,user});


    } catch(err){

        console.log(err.message);
        res.status(500).send('error loged In')
    }
  
};

exports.getUser = async (req ,res) => {
    try{
    const user = await User.find({})
        res.json(user);
    } catch(err){
        console.log(err);
    }
};


exports.uploadimage = (req, res) => {
    console.log("runnnnn",req.file);
    // return;
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
    }
    res.status(200).json({ message: 'File uploaded successfully', file: req.file});
};







