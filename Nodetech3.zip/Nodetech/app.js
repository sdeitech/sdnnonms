import express from "express";
import bodyParser from "body-parser";
import cors from 'cors';
import db from './config/db.js';
import path from "path"
// import uploadRoute from "./route/pic.route.js";
const userRoutes = require('./route/user.route');
const infoRoutes = require('./route/info.route.js');
// const imageRoutes = require('./route/pic.route.js')
// import imageRoutes from './route/pic.route.js';

 

const app = express();
// app.use(bodyParser.urlencoded({limit:'50mb' , extended:false}));



app.use(cors({origin:'*'}));
app.use(express.json({limit:"50mb"}));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: false }));

app.use('/user',userRoutes);
app.use('/api',infoRoutes);

// app.use("/", express.static("images"));
app.use('/', express.static(path.join('images')));



// app.use('/upload', uploadRoute);




export default app;