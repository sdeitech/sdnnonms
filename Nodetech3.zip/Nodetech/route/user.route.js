const express = require('express');
// import express from 'express';
const router = express.Router();
const userController = require('../controller/user.controller');
import { uploadMiddleware } from '../helper/multer';


// router.post('/register',userController.userRegister);
router.post('/register',uploadMiddleware.single("file"),userController.userRegister);
router.post('/login',userController.userLogin);
// router.post('/image',uploadMiddleware.single('file'),uploadimage);

// router.get('/get-user',userController.getUser);

module.exports = router;