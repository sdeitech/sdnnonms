// // import express from 'express';
// // // const imageRouter = express.Router();
// // import {uploadimage}from '../controller/profile';
// // import { uploadMiddleware } from '../helper/multer';

// // const imageRouter = express.Router();


// // imageRouter.post('/image',uploadMiddleware.single('image'),uploadimage);

// // export default imageRouter;
// import express from 'express';
// // console.log("express",express);
// import {uploadimage}from '../controller/profile';
// import { uploadMiddleware } from '../helper/multer';
// const uploadRoute = express.Router()
// // console.log("router__",uploadRoute);

// // uploadRoute.post('/image',uploadMiddleware.single('image'),uploadimage);
// uploadRoute.post('/image',uploadMiddleware.single('file'),uploadimage);

// export default uploadRoute;