// const express = require('express');
import express from 'express'
// import express from "express";
const router = express.Router();
const infoController = require('../controller/info.controller');

router.get('/get-info',infoController.getUser);
router.get('/user/:id',infoController.getOneUser);
router.post('/add',infoController.createUser);
router.put('/new/:id',infoController.updateUser);
router.delete('/remove/:id',infoController.deleteUser);
router.get('/page',infoController.getUserPagination);

module.exports = router;



