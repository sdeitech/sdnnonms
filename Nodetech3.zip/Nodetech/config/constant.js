require('dotenv/config');


export const messageID = {
"tesrt":"dghd"
}
export const messages = {
    imageType:"dghd"

};