require('dotenv/config');

export const config ={
    "local":{
        DB:{
            HOST:"127.0.0.1",
            PORT:"27017",
            DATABASE:"User",
            USERNAME:" ",
            PASSWORD:" ",
        },
        apiPORT : "5001"
    },
    "staging":{

    },
    "prod":{

    },
};




















