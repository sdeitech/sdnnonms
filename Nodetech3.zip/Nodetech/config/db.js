// import mongoose from 'mongoose';
const mongoose = require('mongoose')

// require('dotenv/config');

// const NODE_ENV = process.env.NODE_ENV || "local"; //local

// const config = require('../config/config.js');

// const configuration=config.config[NODE_ENV];


// const MONGOURI = `mongodb://localhost:27017/User`;
// // console.log(MONGOURI, "MONGOURI");
// const db = async () => {
//     try {
//         console.log(MONGOURI, "MONGOURI");
//         // mongoose.set('strictQuery', true);
//         await mongoose.connect(MONGOURI, options);
//         console.log("Connected to DB", MONGOURI);
//     } catch (e) {
//         console.log(e);
//         throw e;
//     }
// };

// module.exports = db;

// const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/User');

const db = mongoose.connection;
db.on('error',console.error.bind(console,'connection error:'))
db.once('open', () => {
    console.log('connected to mongodb');
});

module.exports=db;



















































