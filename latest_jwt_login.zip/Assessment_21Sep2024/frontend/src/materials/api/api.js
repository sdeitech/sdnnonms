import axios from "axios";
const API_PATH = "http://localhost:4000";

const API_CALL = axios.create({
  basePath: API_PATH,
});

export { API_PATH, API_CALL };
