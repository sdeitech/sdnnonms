import React from "react";
import PrivateLayout from "../Layout/PrivateLayout";
import NotFound from "../../components/NotFound";
import SignUp from "../../materials/modules/SignUp/SignUp";
import SignIn from "../modules/SignIn/SignIn";
import TableView from "../../components/TableView";

const privateRoutes = [
  {
    path: "/users",
    exact: true,
    element: (
      <PrivateLayout>
        <TableView />
      </PrivateLayout>
    ),
  },
  {
    path: "/*",
    element: <NotFound />,
  },
];

export default privateRoutes;
