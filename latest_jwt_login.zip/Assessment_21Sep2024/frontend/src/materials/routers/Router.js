import PrivateRouter from "./PrivateRouter";
import PublicRouter from "./PublicRouter";
import { createBrowserRouter } from "react-router-dom";

const routers = createBrowserRouter([...PrivateRouter, ...PublicRouter]);

export default routers;
