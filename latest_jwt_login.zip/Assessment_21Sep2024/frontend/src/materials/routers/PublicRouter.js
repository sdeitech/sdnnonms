import React from "react";
import SignUp from "../modules/SignUp/SignUp";
import PublicLayout from "../Layout/PublicLayout";

const publicRoutes = [
  {
    path: "/",
    exact: true,
    element: (
      <PublicLayout>
        <SignUp />
      </PublicLayout>
    ),
  },
  {
    path: "/signUp",
    exact: true,
    element: (
      <PublicLayout>
        <div>SignUp</div>
      </PublicLayout>
    ),
  },
];

export default publicRoutes;
