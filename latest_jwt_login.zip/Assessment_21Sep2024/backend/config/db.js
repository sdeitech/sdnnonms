const mongoose = require("mongoose");
const constants = require("./constants");

mongoose.connect(constants.DBURL);
const db = mongoose.connection;

db.on("error", console.error.bind("Conection Failed between DB Server"));
db.once("open", () => {
  console.log("DB Server is connected.....");
});

module.exports = db;
