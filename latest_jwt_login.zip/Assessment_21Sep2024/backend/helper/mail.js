var nodemailer = require("nodemailer");
const { SENDMAIL } = require("../config/constants");

var transport = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  service: "gmail",
  secure: false,
  auth: {
    user: SENDMAIL,
    pass: "livcdbicsdiaacea",
  },
});

// console.log(transport);
const sendRegistrationEmail = (email, firstName, lastName) => {
  const mailConfig = {
    from: `"Student Registery" <${SENDMAIL}>`,
    to: email,
    subject: "This an sample mail for NodeMailer",
    text: `Hello! ${firstName} ${lastName}, \n\nThis is Regarding your Student Report Registration in our organization 'SmartData Pvt. Ltd Welcome to the Team.!!`,
  };
  return transport.sendMail(mailConfig);
};

module.exports = { sendRegistrationEmail };
