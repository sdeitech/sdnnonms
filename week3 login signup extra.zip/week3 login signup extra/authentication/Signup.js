import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import FormControlLabel from '@mui/material/FormControlLabel';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import './signup.css'
import Checkbox from '@mui/material/Checkbox';  


export default function SignUp() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    dateofBirth: '',
    password: '',
    married: '',
    gender: '',
  });
  const [error, setError] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const {name, value} = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    setFormErrors((prevErrors) => ({...prevErrors, [name]: null}));
  };

  const validateForm = () => {
    const errors = {};
    const {firstName, lastName, email, dateofBirth, password, married, gender} = formData;

    if (!firstName) {
      errors.firstName = 'Name is required';
  }

  if (!lastName) {
    errors.lastName = 'Last Name is required';
}

if (!dateofBirth) {
  errors.dateofBirth = 'date of birth is required';
}
if (!gender) {
  errors.gender = 'gender is required';
}
if (!married) {
  errors.married = 'married field is required';
}
  if (!email) {
      errors.email = 'Email is required';
  } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email address is invalid';
  }

  if (!password) {
      errors.password = 'Password is required';
  } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
  }

  return errors;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if(Object.keys(validationErrors). length > 0){
      setFormErrors(validationErrors);
      return;
    }
    try{
      const response = await axios.post(`http://localhost:5000/api/register`, formData);
      localStorage.setItem('token', response.data.token);
      navigate('/dashboard');

    } catch(err){
      setError("registration failed")
    }
  };

  return (
    <form onSubmit={handleSubmit}>
    <Box
    direction="col"
      component="form"
      sx={{ '& .MuiTextField-root': { m: 1, width: '25ch' } }}
      noValidate
      autoComplete="off"
    >
    <h1>
      Sign Up
    </h1>
      <div>
        <TextField
          required
          id="outlined-required"
          label="First Name"
          defaultValue=""
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
        />
        {formErrors.firstName && <p style={{ color: 'red' }}>{formErrors.firstName}</p>}

        </div>
        <div>
        <TextField
        required
        id="outlined-required"
        label="Last Name"
        defaultValue=""
        type="text"
        name="lastName"
        value={formData.lastName}
        onChange={handleChange}
      />
        {formErrors.lastName && <p style={{ color: 'red' }}>{formErrors.lastName}</p>}

      </div>
      <div>
       <TextField
          required
          id="outlined-required"
          label="Email"
          defaultValue=""
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
        />
        {formErrors.email && <p style={{ color: 'red' }}>{formErrors.email}</p>}

        </div>
        <div>
         <TextField
          required
          id="outlined-required"
          label="Date of Birth"
          defaultValue=""
          type="date"
          name="dateofBirth"
          value={formData.dateofBirth}
          onChange={handleChange}
        />
        {formErrors.dateofBirth && <p style={{ color: 'red' }}>{formErrors.dateofBirth}</p>}

        <div>
        <TextField
          id="outlined-password-input"
          label="Password"
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
        {formErrors.password && <p style={{ color: 'red' }}>{formErrors.password}</p>}
        </div>
        <div>
      
    <FormControl>
      <FormControlLabel control={<Checkbox defaultChecked />} type="married" value={formData.married} onChange={handleChange} label="Married" />
      <hr></hr>

      <FormLabel type="gender" value={formData.gender} onChange={handleChange} id="demo-radio-buttons-group-label">Gender</FormLabel>
      <RadioGroup
        aria-labelledby="demo-radio-buttons-group-label"
        defaultValue="female"
        name="radio-buttons-group"
      >
        <FormControlLabel value="female" control={<Radio />} label="Female" />
        <FormControlLabel value="male" control={<Radio />} label="Male" />
        <FormControlLabel value="other" control={<Radio />} label="Other" />
      </RadioGroup>
    </FormControl>
    </div>
    <div>
      <div className="container">
      <Stack spacing={5} direction="row" className="center">
      <Button variant="contained">Sign Up</Button>
    </Stack>
      </div>
    
    </div>
      </div>  
    </Box>
    </form>
  );
}
