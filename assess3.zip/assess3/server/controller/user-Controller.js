const Joi = require('joi')

// Joi validation schema for registration
const registrationSchema = Joi.object({
    userName: Joi.string().min(3).max(30).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required()
});

// Joi validation schema for login
const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required()
});

const registerUser = async (req, res) => {
    try {
        console.log(req.body);
        const { userName, password, email } = req.body;

        // Validate registration data
        const { error } = registrationSchema.validate({ userName, email, password });
        if (error) {
            return res.status(400).json({ Error: error.details[0].message });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            userName,
            email,
            password: hashedPassword,
        });

        await user.save();
        res.status(201).json(user);
    } catch (error) {
        console.log(error);
        res.status(500).json({ Error: error.message });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate login data
        const { error } = loginSchema.validate({ email, password });
        if (error) {
            return res.status(400).json({ Error: error.details[0].message });
        }

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (isMatch) {
            const token = jwt.sign({ email }, "an123idjk", { expiresIn: "2h" });

            return res.status(200).json({ message: "Logged In", token });
        } else {
            return res.status(401).json({ message: "Invalid Credentials" });
        }
    } catch (error) {
        res.status(500).json({ Error: error.message });
    }
};

module.exports = { registerUser, loginUser };