// routes/patientRoutes.js
const express = require('express');
const Patient = require('../model/patientModel');
const router = express.Router();

// Create a new patient
router.get('/patients', async (req, res) => {
    const { page = 1, limit = 10, searchText = '' } = req.query; // Set default values

    try {
        // Create the filter for searching by firstName and lastName
        const filter = {
            $or: [
                { firstName: { $regex: searchText, $options: 'i' } },
                { lastName: { $regex: searchText, $options: 'i' } },
            ],
        };

        // Fetch the data with pagination and searching
        const patients = await Patient.find(filter)
            .limit(parseInt(limit))
            .skip((page - 1) * limit)
            .sort({ createdAt: -1 });

        const totalPatients = await Patient.countDocuments(filter); // Get total count for pagination

        Responses._200(res, {
            status: true,
            message: messages.listSuccess,
            body: {
                patients,
                totalPages: Math.ceil(totalPatients / limit),
                currentPage: parseInt(page),
            },
        });
    } catch (error) {
        Responses._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
});

// Get all patients
router.get('/patient', async (req, res) => {
    try {
        const patients = await Patient.find();
        res.status(200).json(patients);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get a patient by ID
router.get('/patient/:id', async (req, res) => {
    try {
        const patient = await Patient.findById(req.params.id);
        if (!patient) return res.status(404).json({ message: 'Patient not found' });
        res.status(200).json(patient);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update a patient by ID
router.put('/patient/:id', async (req, res) => {
    try {
        const updatedPatient = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedPatient) return res.status(404).json({ message: 'Patient not found' });
        res.status(200).json(updatedPatient);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete a patient by ID
router.delete('/patient/:id', async (req, res) => {
    try {
        const deletedPatient = await Patient.findByIdAndDelete(req.params.id);
        if (!deletedPatient) return res.status(404).json({ message: 'Patient not found' });
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
