// models/Patient.js
const mongoose = require('mongoose');


const PatientSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
    },
    lastName: {
        type: String,
        required: true,
    },
    age: {
        type: Number,
        required: true,
    },
    gender: {
        type: String,
        required: true,
    },
    condition: {
        type: String,
        required: true,
    },
}, { timestamps: true });

module.exports = mongoose.model('Patient', PatientSchema);
