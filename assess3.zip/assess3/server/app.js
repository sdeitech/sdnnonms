const express = require('express');
const cors = require('cors')
const { initiateMongoConnection } = require('./config/db');
const bodyParser = require('body-parser');
const { errorHandler, notFound } = require('./middleware/errorMiddleware');
const fileUpload = require('express-fileupload');
const userRouter = require('./routes/user-Route')
const patientRoutes = require('./routes/patientRoute');

const app = express();
/**
 * @returns
 */
initiateMongoConnection();

/**

 * @param {Object} options
 * @param {string} options.origin 
 * @returns 
 */

app.use(cors({ origin: "*" }));

/**

 * @returns 
app.use(fileUpload());

/**

 * @param {object} options
 * @param {string} options.limit 
 */
app.use(express.json({ limit: "50mb" }));

/**
 * @param {object} bodyParser.urlencoded 
 * @param {string} limit 
 * @param {boolean} extended 
 */
app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));

/**
 * @param {object} options 
 * @param {string} options.limit 
 * @returns None
 */
app.use(bodyParser.json({ limit: "50mb" }));

/**
 * @param {string} path
 * @param {Router} routes
 */

app.use('/api', userRouter)
app.use('/api', patientRoutes);

/**
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next 
 * @returns None
 */
app.use(notFound);

/**
 * @param {Function} errorHandler 
 * @returns
 */
app.use(errorHandler);

export default app;
