import {React} from "react";
import PrivateLayout from "../layout/PrivateLayout";
import PatientForm from "../component/list/PatientForm";

const privateRoutes = [
	{
		path: "/patient",
		exact: true,
		element: <PrivateLayout><PatientForm/></PrivateLayout>
	},
	
];
export default privateRoutes;
