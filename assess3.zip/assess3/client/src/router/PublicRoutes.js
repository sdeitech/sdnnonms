import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Login from "../authentication/Login";
import SignUp from "../authentication/SignUp";

const publicRoutes = [
    {
        path: "/login",
        exact: true,
        element: <PublicLayout><Login /></PublicLayout>
    },
    {
    	path: "/",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    }
];
export default publicRoutes;
