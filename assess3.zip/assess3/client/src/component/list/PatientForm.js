import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input, FormGroup, Row, Col } from 'reactstrap';
import axios from "axios";

// Form component for adding/updating patient details
function PatientForm({ setPatient, fetchPatient }) {

    const [editPatient, setEditPatient] = useState(null);
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        age: '',
        gender: '',
        condition: ''
    });

    // Fetch patients dynamically
    // const fetchPatients = async () => {
    //     try {
    //         const response = await axios.get(`http://localhost:8080/api/patients`);
    //         // Use the fetched patients if needed (e.g., display in a list)
    //     } catch (error) {
    //         console.error("Error fetching patients:", error);
    //     }
    // };

    // Update patient details
    const updatePatient = async (patientId, updatedData) => {
        try {
            const response = await axios.put(`http://localhost:8080/api/patients/${patientId}`, updatedData);
            // Handle updating patient details in the state if needed
            setEditPatient(null); // Reset edit state after updating
            console.log("Updated patient details:", response.data);
        } catch (error) {
            console.error('Error updating patient details:', error);
        }
    };

    useEffect(() => {
        if (editPatient) {
            setFormData({
                firstName: editPatient.firstName,
                lastName: editPatient.lastName,
                age: editPatient.age,
                gender: editPatient.gender,
                condition: editPatient.condition
            });
        } else {
            setFormData({
                firstName: '',
                lastName: '',
                age: '',
                gender: '',
                condition: ''
            });
        }
    }, [editPatient]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (editPatient) {
            // Update existing patient
            updatePatient(editPatient._id, formData);
        } else {
            // Add new patient detail
            try {
                const response = await axios.post(`http://localhost:8080/api/createpatient`, formData);
                setPatient(prevPatient => [...prevPatient, response.data]);
                fetchPatient();
            } catch (error) {
                console.error("Error adding detail", error);
            }
        }

        // Clear the form and edit state
        setFormData({
            firstName: '',
            lastName: '',
            age: '',
            gender: '',
            condition: ''
        });
        setEditPatient(null);
    };

    // Reset button function
    const handleReset = () => {
        setFormData({
            firstName: '',
            lastName: '',
            age: '',
            gender: '',
            condition: ''
        });
    };

    return (
        <div>
            <h1>{editPatient ? 'Edit Patient Detail' : 'Add Patient Detail'}</h1>
            <Form onSubmit={handleSubmit}>
                <Row>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="firstName">First Name</Label>
                            <Input
                                id="firstName"
                                name="firstName"
                                value={formData.firstName}
                                onChange={handleInputChange}
                                type="text"
                                required
                            />
                        </FormGroup>
                    </Col>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="lastName">Last Name</Label>
                            <Input
                                id="lastName"
                                name="lastName"
                                value={formData.lastName}
                                onChange={handleInputChange}
                                type="text"
                            />
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="age">Age</Label>
                            <Input
                                id="age"
                                name="age"
                                value={formData.age}
                                onChange={handleInputChange}
                                type="number"
                            />
                        </FormGroup>
                        <FormGroup>
                            <Label for="gender">Gender</Label>
                            <Input
                                id="gender"
                                name="gender"
                                value={formData.gender}
                                onChange={handleInputChange}
                                type="text"
                            />
                        </FormGroup>
                    </Col>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="condition">Medical Condition</Label>
                            <Input
                                id="condition"
                                name="condition"
                                value={formData.condition}
                                onChange={handleInputChange}
                                type="text"
                            />
                        </FormGroup>
                    </Col>
                </Row>
                <Button className="me-2" type="submit">{editPatient ? 'Update Detail' : 'Add Detail'}</Button>
                <Button type="reset" onClick={handleReset}>Reset</Button>
            </Form>
        </div>
    );
}

export default PatientForm;
