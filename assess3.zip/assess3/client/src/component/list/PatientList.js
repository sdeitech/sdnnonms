import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import { Button } from "react-bootstrap";
import ReactPaginate from 'react-paginate';
import axios from 'axios';

const PatientList = ({ viewPatient, updatePatient }) => {
    const [patients, setPatients] = useState([]);
    const [totalPages, setTotalPages] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const itemsPerPage = 10; // Set your desired items per page

    // Fetch patients from the backend
    const fetchPatients = async (page, searchText = '') => {
        try {
            const response = await axios.get(`http://localhost:8080/api/patients`, {
                params: { page, limit: itemsPerPage, searchText }
            });
            setPatients(response.data.body.patients);
            setTotalPages(response.data.body.totalPages);
            setCurrentPage(response.data.body.currentPage);
        } catch (error) {
            console.error("Error fetching patients:", error);
        }
    };

    // Effect to fetch patients on component mount and when the current page or searchQuery changes
    useEffect(() => {
        fetchPatients(currentPage, searchQuery);
    }, [currentPage, searchQuery]);

    // Function to handle page change
    const handlePageChange = (selectedPage) => {
        setCurrentPage(selectedPage + 1); // +1 because page index starts from 0 in ReactPaginate
    };

    // Function to handle search input change
    const handleSearchInputChange = (event) => {
        const query = event.target.value;
        setSearchQuery(query);
        setCurrentPage(1); // Reset to the first page on new search
    };

    return (
        <div>
            <h2>Patient List</h2>
            <input
                type="text"
                placeholder="Search by first or last name..."
                value={searchQuery}
                onChange={handleSearchInputChange}
                style={{ marginBottom: '20px', padding: '10px', width: '100%' }}
            />
            <Table striped>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Condition</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {patients.length > 0 ? (
                        patients.map(patient => (
                            <tr key={patient._id}>
                                <td>{patient.firstName}</td>
                                <td>{patient.lastName}</td>
                                <td>{patient.age}</td>
                                <td>{patient.gender}</td>
                                <td>{patient.condition}</td>
                                <td>
                                    <Button className="me-2" onClick={() => viewPatient(patient)}>View</Button>
                                    <Button className="me-2" onClick={() => updatePatient(patient)}>Edit</Button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="6" className="text-center">No patients found.</td>
                        </tr>
                    )}
                </tbody>
            </Table>

            <ReactPaginate
                breakLabel="..."
                nextLabel="next >"
                onPageChange={(event) => handlePageChange(event.selected)}
                pageRangeDisplayed={5}
                pageCount={totalPages}
                previousLabel="< previous"
                renderOnZeroPageCount={null}
                className="pagination"
            />
        </div>
    );
};

export default PatientList;
