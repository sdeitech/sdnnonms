import React from 'react';

// This component outputs details of a patient
const PatientDetail = ({ patient }) => {
    return (
        <div>
            <h2>Patient Detail</h2>
            <p>First Name: {patient.firstName}</p>
            <p>Last Name: {patient.lastName}</p>
            <p>Age: {patient.age}</p>
            <p>Gender: {patient.gender}</p>
            <p>Condition: {patient.condition}</p>
        </div>
    );
};

export default PatientDetail;
