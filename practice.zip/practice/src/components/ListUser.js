import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteUser } from '../features/user/crud'

export default function ListUser() {
    const user = useSelector(state => state.user.user)
const dispatch =  useDispatch()
    const deleteUserById = (id)=>{
        // dispatch deleteUser action
        console.log("vsdasvh" , id)
        dispatch(deleteUser(id))
    }

  return (
    <>
    <div>ListUser</div>
     
     {/* display user data here */}
     {user?.map(user=>(
         <li key={user.id}> {user.id} {user.name} <button onClick={()=>deleteUserById(user.id)}> delete</button></li>
     ))}
    
    </>
  )
}
