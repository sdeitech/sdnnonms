import React ,{useState} from 'react'
import {addProduct} from '../features/product/cardSclice'
import {useDispatch} from'react-redux'
import { useNavigate } from 'react-router-dom'
export default function AddProduct() {
    const [formData, setFormData] = useState({
        "productName":"",
        "price":0,
        "description":""
    })
    const dispatch = useDispatch()
    const navigate = useNavigate()
const  onChangeEventHandler= (e) => { 
    // your code here
    setFormData({...formData, [e.target.name]: e.target.value})
}

const formSubmit = (e) =>{
    e.preventDefault()
    console.log("submited" , formData)
    const result = dispatch(addProduct(formData))
    console.log(result, "result")
    navigate('/')
}

  return (
    <div className='container mt-3'>
    <form className="row g-3" onSubmit={formSubmit}>
  <div className="col-md-6">
    <label htmlFor="inputEmail4" className="form-label">
      product name
    </label>
    <input type="text" name="productName"  onChange={onChangeEventHandler}   value={formData.productName} className="form-control" id="inputEmail4" />
  </div>
  <div className="col-md-6">
    <label htmlFor="inputPassword4" className="form-label">
      price
    </label>
    <input type="Number" name='price'  onChange={onChangeEventHandler}  value={formData.price}className="form-control" id="inputPassword4" />
  </div>

  <div className="col-md-12">
    <label htmlFor="inputCity" className="form-label">
      Description
    </label>
    <input type="text" className="form-control"  onChange={onChangeEventHandler} value={formData.description} name = "description" id="inputCity" />
  </div>

  <div className="col-12">
    <button type="submit" className="btn btn-primary">
     Add Product
    </button>
  </div>
</form>
</div>

  )
}
