import React from 'react'
import {useDispatch , useSelector} from 'react-redux'
import { deleteCard } from '../features/product/cardSclice'
export default function ViewCard() {
    const cards = useSelector(state => state.cards.cardsList.cards)
    const total = useSelector(state => state.cards.cardsList.totalCard)

    const dispatch = useDispatch()
    return (
        <>
        <div class="row gap-3  d-flex justify-content-center mt-3">
        {
            cards?.map(product => (
                <div class="col-sm-5"> {total}
                <div class="card">
                    <div class="card-header">
                        {product?.productName}
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">
                        {product?.price}

                        </h5>
                        <p class="card-text"> 
                            {product?.description}
                        </p>
                        <button onClick={()=>dispatch(deleteCard(product))} class="btn btn-primary">Add to card</button>
                    </div>
                </div>
                </div>
            ))  // end of map()  //  end of return statement  //</div>
  
        }
        </div>
        </>
  )
}
