import React , {useState} from 'react'
import { useDispatch  } from 'react-redux'
import { createUser } from '../features/user/crud'
export default function AddUser() {
    const [formData,setFormData] = useState({
        id:'',
        name:''
    })

    const dispatch = useDispatch()

    const handleChange = (e) => {
        setFormData({...formData,[e.target.name]:e.target.value})
    }

    const submitForm = (e) => {
        e.preventDefault()
        // dispatch createUser action
        console.log("firstSubmit",  formData)
        dispatch(createUser(formData))
    }

  return (
  <>
    <div>AddUser</div>
    <form onSubmit={submitForm}>
    <input type="text"  onChange={handleChange}  name='id'/>
    <input type="text"  onChange={handleChange} name='name'/>
    <input type="submit" />

    </form>


  </>
  )
}
