import React from 'react'
import Navbar from '../components/Navbar'
import Card from '../components/Card'
import { BrowserRouter ,Route ,Routes } from 'react-router-dom';
import AddProduct from '../components/AddProduct';
import ViewCard from '../components/ViewCard';

export default function HomePage() {
  return (
    <>
    <BrowserRouter>
    <Navbar/>
    <Routes>  
        <Route path="/" element={<Card />} />
        <Route path="/addProduct" element={<AddProduct />} />
        <Route path="/viewCart" element={<ViewCard />} />


    </Routes>
 
    </BrowserRouter>
    </>
  )
}
