import { configureStore } from "@reduxjs/toolkit";
import counterSclice from "../features/counter/counterSclice";
import UserManagment from "../features/user/crud";
import cardSlice from "../features/product/cardSclice";
export default configureStore({
    reducer: {
        counter :counterSclice,
        user:UserManagment,
        cards :cardSlice
    }
})