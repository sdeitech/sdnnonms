import  {createSlice} from '@reduxjs/toolkit'


const cardSlice = createSlice({
    name: 'cards',
    initialState: {
        products:[],
        cardsList: { cards :[], totalCard : 0 }
    },
    reducers: {
        addProduct: (state, action) => {
            state.products.push(action.payload)
        },
        addCard: (state, action) => {
            console.log(action.payload, "added card");
        
            const existingCard = state.cardsList.cards.find(card => 
                card.id === action.payload.id 
            );
        
            console.log(existingCard ? "Card exists" : "Card does not exist");
        
            if (!existingCard) {
                state.cardsList.cards.push(action.payload);
                state.cardsList.totalCard++;
            } else {
                console.log("already added");
                state.cardsList.totalCard++;
            }
        
            
      
        },
        deleteCard: (state, action) => {
            state.cardsList = state.cardsList.cards.filter(card => card.id!==action.payload)
            state.cardsList.totalCard--
            
        },
        updateCard: (state, action) => {
            state.cardsList = state.cardsList.cards.map(card => 
                card.id === action.payload.id? {...card,...action.payload}:card
            )
        },
    }
})

export const { addCard, deleteCard, updateCard , addProduct} = cardSlice.actions 

export default cardSlice.reducer