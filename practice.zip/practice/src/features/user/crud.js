import { createSlice } from "@reduxjs/toolkit";

const UserManagment = createSlice({
    initialState: {
        user:[],
        loading: false,
        error: null,
    },
    name: 'user',
    reducers: { 
        createUser: (state, action)=>{
            return {...state, user: [...state.user, action.payload]}
        },
        deleteUser: (state, action)=>{ 
            console.log(action.payload , 'delete')
            // state.loading = true
            state.error = null
            return {...state, user: state.user.filter(user=>user.id!==action.payload)}
        },
        updateUser: (state, action)=>{ 
            state.error = null
            return {...state, user: state.user.map(user=>user.id===action.payload.id? action.payload:user)}
        }

    }
})

export const { createUser, deleteUser, updateUser } = UserManagment.actions

export default UserManagment.reducer