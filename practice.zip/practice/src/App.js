import logo from './logo.svg';
import './App.css';
import Counter from './components/Counter';
import AddUser from './components/AddUser';
import ListUser from './components/ListUser';
import HomePage from './pages/HomePage';
function App() {
  return (
  <>
{/* <Counter/>
<AddUser/>
<ListUser/> */}


<HomePage/>


  </>
  );
}

export default App;
