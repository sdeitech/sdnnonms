const express = require("express");
const route = express.Router();
const routeController = require("../controller/controller");


route.get("/api/report", routeController.getReportDetails);
route.get("/api/report/:id", routeController.getReportDetailsById);
route.post("/api/report", routeController.createReportDetails);


route.post("/api/mail", routeController.mail);

module.exports = route;   