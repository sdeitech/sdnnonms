const mongoose = require("mongoose");
// Define student Schema
const reportSchema = new mongoose.Schema({
  FirstName: { type: String, required: true },
  LastName: { type: String, required: true },
  Email: { type: String, required: true },
  MarksInEnglish: { type: Number, required: true },
  MarksInScience: { type: Number, required: true },
  MarksInMath: { type: Number, required: true },
  AboutYou:{type: String,require:true}
});
// Create report Model
const report= mongoose.model("ReportDetails", reportSchema);
module.exports=report;
