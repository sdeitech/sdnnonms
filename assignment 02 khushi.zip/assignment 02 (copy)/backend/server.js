const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors')
const reportRoutes = require('./routes/routes');
const db = require('./config/db'); 
const app = express();
// const productRouter=require("./router/product.router")
 
app.use(cors())
app.use(bodyParser.json());
app.use('/reportDetails', reportRoutes);

app.listen(4000, () => {
console.log(`connected to server: http://localhost:4000`);
});