const { OK, CREATED, BAD_REQUEST, NOT_FOUND, EMAIL_SENT } = require("../config/constants");
const reportModel = require("../model/model");
const mongoose = require("mongoose");
const { sendRegistrationEmail } = require("../helper/mail");

exports.getReportDetails = async (req, res) => {
  try {
    const getReport = await reportModel.find();
    res.status(OK).json({ message: "Report data Fetched", item: getReport });
  } catch (error) {
    res.status(201).json({ error: error.message });
  }
};

exports.getReportDetailsById = async (req, res) => {
  try {
    const getReportById = await reportModel.findById({ _id: req.params.id });
    res
      .status(OK)
      .json({ message: "Report data Fetched", item: getReportById });
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};

exports.createReportDetails = async (req, res) => {
  try {
    const newReportDetail = new reportModel(req.body);
    await newReportDetail.save();

    await sendRegistrationEmail(
      newReportDetail.FirstName,
      newReportDetail.LastName,
      newReportDetail.Email
    );

    res.status(CREATED).json(newReportDetail);
  } catch (error) {
    res.status(BAD_REQUEST).json({ error: error.message });
  }
};

exports.updateReportDetails = async (req, res) => {
  try {
    const updateReport = await reportModel.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
      }
    );
    if (!updateReport) {
      return res.status(NOT_FOUND).json({ error: "report Unavailable" });
    }
    res.status(OK).json(updateReport);
  } catch (error) {
    res.status(BAD_REQUEST).json({ error: error.message });
  }
};

exports.mail = async (req, res) => {
  try {
    const { Email, FirstName, LastName } = req.body;
    await sendRegistrationEmail(Email, FirstName, LastName);
    res.status(OK).json({ message: EMAIL_SENT });
  } catch (error) {
    console.error("Error in sending email:", error);
    res.status(BAD_REQUEST).json({ error: error.message });
  }
};
