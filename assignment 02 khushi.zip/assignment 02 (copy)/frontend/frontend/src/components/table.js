import { Table, Button } from "react-bootstrap";
import { useEffect, useState } from "react";
import axios from "axios";

function TableView() {
  const [data, setData] = useState([]);
  
  const recordHandle = async () => {
    try {
      const result = await axios.get(
        "http://localhost:4000/reportDetails/api/report"
      );
      console.log(result.data,".....")
        setData(result.data.item);
    } catch (error) {
      console.error(error);
    }
    
  };

  useEffect(() => {
    recordHandle();
  }, []);

  const viewHandle = (x) => {
    alert(`First Name: ${x.FirstName}\nLast Name: ${x.LastName}\nEmail: ${x.Email}\nMarks English: ${x.MarksInEnglish}\nMarks Science: ${x.MarksInScience}\nMarks Maths: ${x.MarksInMath}`);
  };

  console.log(data);
  return (
    <Table striped bordered hover variant="dark">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {data?.map((x) => {
          return (
            <tr key={x._id}>
              <td>{x.FirstName}</td>
              <td>{x.LastName}</td>
              <td>{x.Email}</td>  
              <td>
                <Button variant="info" onClick={() => viewHandle(x)}>VIEW</Button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );      
}

export default TableView;

