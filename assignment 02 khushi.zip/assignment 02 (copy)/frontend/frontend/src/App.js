// import logo from './logo.svg';
import './App.css';
import TableView from "./components/table";
import RegisterForm from"./components/RegistrationForm"

function App() {
  return (
    <div className="App">
      <div className='App-header'>
    <h2>Report Card Management</h2>
      </div>
      <div className='Table-body'>
      <TableView/>
      </div>
      <div/>
      <div className='Form-body'>
      <RegisterForm/>
      </div>
    </div>
  );
}

export default App;
