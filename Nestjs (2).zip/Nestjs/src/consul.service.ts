import { Injectable, Logger } from '@nestjs/common';
import Consul from 'consul';

@Injectable()
export class ConsulService {
  private consul: Consul;
  private readonly logger = new Logger(ConsulService.name);

  constructor() {
    // Initialize the Consul client without the promisify option
    this.consul = new Consul({
      host: '127.0.0.1', // Consul server host (localhost)
      port: 8500,        // Consul server port (default)
    });
  }

  // Register the service with Consul
  async registerService() {
    const service = {
      name: 'nest-service',                 // Name of your service
      id: 'nest-service-id',                // Unique ID for the service
      address: '127.0.0.1',                 // Service address (localhost)
      port: 3000,                           // Port where your NestJS app is running
      tags: ['nestjs', 'microservice'],     // Tags to identify the service
      check: {
        http: 'http://127.0.0.1:3000/health', // Health check endpoint
        interval: '10s',                      // Health check interval
        name: 'HTTP Health Check',            // Name for the check
        timeout: '5s',                        // Timeout for the check
      },
    };

    try {
      // Register the service with Consul
      await this.consul.agent.service.register(service);
      this.logger.log('Service registered with Consul');
    } catch (error) {
      this.logger.error('Error registering service with Consul', error);
    }
  }

  // Deregister the service from Consul
  async deregisterService() {
    try {
      // Deregister the service with Consul by its ID
      await this.consul.agent.service.deregister('nest-service-id');
      this.logger.log('Service deregistered from Consul');
    } catch (error) {
      this.logger.error('Error deregistering service from Consul', error);
    }
  }
}
