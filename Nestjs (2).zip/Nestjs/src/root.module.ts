import { Module, OnModuleInit } from '@nestjs/common';
import { BookController } from './app.controller';
import { ConsulService } from './consul.service';

@Module({
  imports: [],
  controllers: [BookController],
  providers: [ConsulService],
})
export class AppModule implements OnModuleInit {
  constructor(private readonly consulService: ConsulService) {}

  // Register the service when the app starts
  async onModuleInit() {
    await this.consulService.registerService();
  }

  // Deregister service on shutdown (optional)
  async onModuleDestroy() {
    await this.consulService.deregisterService();
  }
}
