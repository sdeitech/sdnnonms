import axios from "axios";
import React, { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import toast, { Toaster } from "react-hot-toast";
function AddUser() {
  const navigate = useNavigate();

  const token = useSelector((state) => state.users?.authUser?.token);
  const userId = useSelector((state) => state.users?.authUser?.userId);

  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    email: "",
    createdBy: userId,
  });
  const [toastShown, setToastShown] = useState(false);
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        `http://localhost:3217/api/postdata/${userId}`,
        user,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      setToastShown(true);
      setTimeout(() => {
        console.log(response.data);
        console.log("user data submitted :", response.data);
        navigate("/dashboard");
      }, 1000);
    
    } catch (err) {
      console.error("Error in submitting form:", err.message);
    }
  };
  useEffect(() => {
    if (toastShown) {
      toast.success("User Added !");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "#f7f9fc",
      }}
    >
      <div
        style={{
          border: "1px solid #ddd",
          padding: "30px",
          borderRadius: "10px",
          boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#fff",
          width: "400px",
        }}
      >
        <h2 style={{ textAlign: "center", color: "#333", marginBottom: "20px" }}>
          Add User
        </h2>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "15px" }}>
            <label
              style={{
                display: "block",
                fontWeight: "bold",
                marginBottom: "5px",
                color: "#555",
              }}
            >
              First Name:
            </label>
            <input
              type="text"
              name="firstname"
              value={user.firstname}
              onChange={handleInputChange}
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
                fontSize: "16px",
              }}
            />
          </div>
  
          <div style={{ marginBottom: "15px" }}>
            <label
              style={{
                display: "block",
                fontWeight: "bold",
                marginBottom: "5px",
                color: "#555",
              }}
            >
              Last Name:
            </label>
            <input
              type="text"
              name="lastname"
              value={user.lastname}
              onChange={handleInputChange}
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
                fontSize: "16px",
              }}
            />
          </div>
  
          <div style={{ marginBottom: "20px" }}>
            <label
              style={{
                display: "block",
                fontWeight: "bold",
                marginBottom: "5px",
                color: "#555",
              }}
            >
              Email:
            </label>
            <input
              type="email"
              name="email"
              value={user.email}
              onChange={handleInputChange}
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
                fontSize: "16px",
              }}
            />
          </div>
  
          <button
            type="submit"
            style={{
              width: "100%",
              padding: "12px",
              backgroundColor: "#007BFF",
              color: "white",
              fontSize: "16px",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              transition: "background-color 0.3s",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#007BFF")}
          >
            Submit
          </button>
        </form>
        <Toaster />
      </div>
    </div>
  );
}

export default AddUser;
