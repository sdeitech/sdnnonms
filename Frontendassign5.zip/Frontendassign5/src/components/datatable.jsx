import React, { useEffect, useState } from "react";
import axios from "axios";
import { CSVLink, CSVDownload } from "react-csv";
// import UploadCsv from "./Uploadcsv";
import Papa from "papaparse";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";

import View from "./adduserviewlist";
import { useSelector } from "react-redux";

const DataTable = () => {
  const [searchtext, setSearchText] = useState("");
  console.log(searchtext);
  const [data, setData] = useState([]);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");

  const [totalPage, setTotalPage] = useState(1);
  const [pageNo, setPageNo] = useState(1);

  const chnagePage = (event, page) => {
    setPageNo(page);
  };

  const searchname = (e) => {
    setSearch(e.target.value);
  };
  console.log(pageNo);

  const token = useSelector((state) => state.users?.authUser?.token);
  const userId = useSelector((state) => state.users?.authUser?.userId);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        `http://localhost:3217/api/getdataInList/${userId}?page=${pageNo}&search=${search}&limit=2`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      setTotalPage(response.data.totalPages);
      setPageNo(response.data.currentPage);
      console.log(response.data);
      console.log(response.data.users, "hhhgghhghh");

      setData(response.data.users);
    } catch (error) {
      console.log("error fetching data");
    }
  };

  useEffect(() => {
    fetchData();
  }, [pageNo, search]);

  const [curruntUser, setcurruntUser] = useState(null);

  const [showview, setshowview] = useState(false);

  const Handleview = (data) => {
    setshowview(!showview);
    setcurruntUser(data);
  };

  const uploadCsv = (e) => {
    const file = e.target.files[0];
    console.log(file);
    if (file) {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: async (res) => {
          console.log(res.data , "file data");
          setUsers(res.data);
          try {
            const resp = await axios.post(
              `http://localhost:3217/api/uploadcsv/${userId}`,
              {
                user: res.data,
              }
            );
            console.log(resp.data);
          } catch (error) {
            console.log(error.message);
          }
        },
      });
    }
  };

  return (
    <div
      style={{
        padding: "20px",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        backgroundColor: "#f8f9fa",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: "20px",
        }}
      >
        <CSVLink
          data={data}
          style={{
            padding: "10px 20px",
            backgroundColor: "green",
            color: "white",
            textDecoration: "none",
            borderRadius: "5px",
            fontWeight: "bold",
          }}
        >
          Export Files
        </CSVLink>
        <input type="text" placeholder="search" onChange={searchname} />
        <input
          type="file"
          accept=".csv"
          onChange={uploadCsv}
          style={{
            padding: "5px",
            border: "1px solid #ddd",
            borderRadius: "5px",
          }}
        />
      </div>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginBottom: "20px",
        }}
      >
        <thead>
          <tr style={{ backgroundColor: "#007BFF", color: "white" }}>
            <th
              style={{
                padding: "10px",
                textAlign: "left",
                borderBottom: "2px solid #ddd",
              }}
            >
              Sr No
            </th>
            <th
              style={{
                padding: "10px",
                textAlign: "left",
                borderBottom: "2px solid #ddd",
              }}
            >
              First Name
            </th>
            <th
              style={{
                padding: "10px",
                textAlign: "left",
                borderBottom: "2px solid #ddd",
              }}
            >
              Last Name
            </th>
            <th
              style={{
                padding: "10px",
                textAlign: "left",
                borderBottom: "2px solid #ddd",
              }}
            >
              Email
            </th>
            <th
              style={{
                padding: "10px",
                textAlign: "left",
                borderBottom: "2px solid #ddd",
              }}
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {data?.map((item, i) => {
            return (
              <tr key={i}>
                <td style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                  {i + 1}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                  {item.firstname}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                  {item.lastname}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                  {item.email}
                </td>
                <td style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                  <button
                    onClick={() => Handleview(item)}
                    style={{
                      padding: "8px 12px",
                      backgroundColor: "#17a2b8",
                      color: "white",
                      border: "none",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    View
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {showview && (
        <View
          curruntUser={curruntUser}
          showview={showview}
          setshowview={setshowview}
        />
      )}

      <Pagination
        count={totalPage}
        page={pageNo}
        onChange={chnagePage}
        color="primary"
      />
    </div>
  );
};
export default DataTable;
