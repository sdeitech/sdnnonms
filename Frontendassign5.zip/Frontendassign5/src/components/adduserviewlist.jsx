import React from "react";
const View = ({ curruntUser, showview, setshowview }) => {
  return (
    <div
      style={{
        border: "2px solid #28a745", // A subtle border with a green theme
        backgroundColor: "white", // White background for better readability
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "400px",
        borderRadius: "10px", // Rounded corners for a modern look
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)", // Soft shadow for depth
        padding: "20px", // Add padding inside the box for spacing
        color: "#333", // Neutral text color
        textAlign: "center",
      }}
    >
      <h2 style={{ color: "#28a745", marginBottom: "20px" }}>User Details</h2>
  
      <p><strong>First Name:</strong> {curruntUser?.firstname}</p>
      <p><strong>Last Name:</strong> {curruntUser?.lastname}</p>
      <p><strong>Email:</strong> {curruntUser?.email}</p>
      {/* Add more details if needed */}
      
      {/* Close Button */}
      <button
        onClick={() => {
          setshowview(!showview);
        }}
        style={{
          padding: "10px 20px",
          backgroundColor: "#007BFF",
          color: "white",
          border: "none",
          borderRadius: "5px",
          fontSize: "16px",
          cursor: "pointer",
          marginTop: "20px",
          transition: "background-color 0.3s",
        }}
        onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
        onMouseOut={(e) => (e.target.style.backgroundColor = "#007BFF")}
      >
        Close
      </button>
    </div>
  );
};

export default View;
