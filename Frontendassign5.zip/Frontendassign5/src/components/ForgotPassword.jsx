import axios from 'axios'
import React, { useState,useEffect } from 'react'
import toast, { Toaster } from "react-hot-toast";
import { useNavigate } from 'react-router-dom';

const ForgetPassword = () => {
    const [email, setEmail] = useState("")
    const navigate = useNavigate()
    const [toastShown, setToastShown] = useState(false);

    const handleChange = (e) => {
        setEmail(e.target.value)
    }

    // console.log(email)

    
    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            const res = await axios.put("http://localhost:3217/api/forgotpass/password", {
                email: email
            })
            setToastShown(true);

            setTimeout(() => {
                navigate("/login")
              }, 1000);

           
            console.log(res.data)
            setEmail("")
          
        } catch (error) {
            console.log(error.message)
        }
    }
    useEffect(() => {
        if (toastShown) {
            toast.success("Password sent to email")
          setToastShown(false);
        }
      }, [toastShown]);


    return (
        <div className='order border-gray-300 py-10 px-6 rounded-2xl shadow-xl w-96 flex flex-col items-center  mx-auto mt-20 color-green'>
            <p className='text-xl mb-6 '>forgot password by entering email </p>
            <form onSubmit={handleSubmit} className='flex flex-col items-center align-center' >
                <div className="border border-gray-400 rounded-md ">
                    <input
                        type="email"
                        name="email"
                        value={email}
                        onChange={handleChange}
                        placeholder="Enter your Email"
                        className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
                    />
                </div >
                <div className='mt-6 '>
                    <button type='submit' className=' background-black bg-black text-black px-3 py-1 rounded-md '>Submit</button>
                </div>
            </form>
            <Toaster />
        </div>
    )
}

export default ForgetPassword