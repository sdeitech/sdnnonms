import { useState } from 'react';
import Papa from "papaparse";
import axios from 'axios';
import { useSelector } from 'react-redux';

const UploadCsv = () => {
    const uid = useSelector((state) => state.loginUser?.userId);

    const [users, setUsers] = useState([])

    const handleFile = (e) => {
        const file = e.target.files[0];
        console.log(file)
        if (file) {
            Papa.parse(file, {
                header: true,
                skipEmptyLines: true,
                complete: async (res) => {
                    console.log(res.data)
                    setUsers(res.data)
                    try {
                        const resp = await axios.post(`http://localhost:3217/api/uploadcsv/${uid}`, {
                            users: res.data
                        })
                        console.log(resp.data)
                    } catch (error) {
                        console.log(error.message)
                    }
                }
            })
        }
    }
    return { handleFile, users }
}

export default UploadCsv