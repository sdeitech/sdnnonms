const express = require('express');
const bodyParser = require('body-parser');
const UserRoutes = require('./router/Userroutes');
const cors = require('cors')
const db = require("./db/Userdb");

const app = express();
const PORT = 3006;
app.use (cors())
app.use (bodyParser.json());
app.use ('',UserRoutes);
app.listen (PORT,() => {
    console.log(`Server is running on http://localhost:${PORT}`);
}
); 