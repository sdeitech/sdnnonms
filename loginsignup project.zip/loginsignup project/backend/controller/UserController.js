const bcrypt = require("bcrypt");
const user = require('../models/Usermodels');
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
    const { username, email, password } = req.body;
    if (!(username && email && password)) {
        return res
            .status(400)
            .json({ status: 400, message: "all field are mandatoy" });
    }
    try {
        const olduser = await user.findOne({ email: email });
    
        if (olduser) {
            return res
                .status(409)
                .json({ status: 409, message: "user allready registered" });
        }

        const hashPassword = await bcrypt.hash(password, 10);
        req.body.password = hashPassword;
        const newUser = new user(req.body);

         await newUser.save();
         console.log("new user created:",req.body);
         
        return res
            .status(201)
            .json({
                status: 201,
                message: "user inserted succussfully",
                user: newUser,
            });


    } catch (error) {
        console.log(error.message);
        res
            .status(400)
            .json({
                status: 201,
                message: "faild to register user",
                error: error.message
            });
    }
};


exports.logIn = async (req, res) => {
    const { email, password } = req.body
    if (!(email && password)) {
        return res
            .status(400)
            .json({
                message: "all fields are mandatory",
                status: 400
            })
    }
    try {
        const User = await user.findOne({ email: email })
        console.log(User);
        if (!user) {
            return res.status(400).json({ message: "user not exists" })
        }
        const isCorrect = await bcrypt.compare(password, User.password)
        console.log(isCorrect);

        if (isCorrect) {
            const token = jwt.sign({ email }, "user token created");
            User.token = token
            await User.save()
            return res
                .status(200)
                .json({ message: "token gentrated succusssfully", token })
        }
        return res.status(400).json({ message: "incorrect password,login faild", status: 400 }
        )
    } catch (error) {
        res.status(400).json({ message: "loginfaield", error: error.message })
    }
}