const user = require('../models/Usermodels');
exports.createUser = async (req, res) => {
    console.log("user create user function is ready");
    try {
        console.log("function for creating User")
        console.log(user);
        
        const newUser = new user(req.body)
        console.log(newUser)
        await newUser.save();
        res.status(200).json(newUser);
        console.log("user  added successfully");
    } catch (error) {
        
        console.log(error.message );
        res.status(400).json({ error: error.message });
        
        console.log("user is wrong");
    }
};
exports.getUser = async (req, res) => {
    try {
        const User01= await user.find();
        res.json(User01);
        console.log("your products in a database are:");
        
    } catch (error) {
        res.status(400).json({ error: error.message });
    }}