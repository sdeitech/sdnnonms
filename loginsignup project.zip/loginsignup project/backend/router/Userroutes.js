const express = require('express');
const router = express.Router();
const UserController = require('../controller/UserController');
console.log("your router file is getting ready");

router.post('/toPostUser',UserController.createUser);
router.get('/togetUser',UserController.getUser); 


module.exports = router;