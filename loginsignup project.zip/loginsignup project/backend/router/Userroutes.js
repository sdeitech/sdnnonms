const express = require('express');
const router = express.Router();
const UserController = require('../controller/UserController');
console.log("your router file is getting ready");

router.post('/toregister',UserController.register);
router.post('/tologin',UserController.logIn); 

// router.get('/togetUser',UserController.logIn); 


module.exports = router;