const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
    UserName: { type: String, required: true },
    EmailId: { type: String, required: true },
    Password: { type: String , required: true},
    }
);
console.log("your model is ready");

const user = mongoose.model('Users', UserSchema);
module.exports = user;