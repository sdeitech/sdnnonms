import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

export default  function  Routersforuse() {
    return (
        <h1></h1>
    )
}