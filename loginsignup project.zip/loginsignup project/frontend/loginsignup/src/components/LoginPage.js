import { useState } from 'react';
import axios from 'axios';

function LoginPage() {

    const [user, setuser] = useState({
        email: "",
        password: ""
    })
    const handlechange = (e) => {
        setuser({ ...user, [e.target.name]: e.target.value })

    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await axios.post("http://localhost:3006/tologin", user);
            localStorage.setItem("token",result.data.token)
            console.log("you logined in succsusfully", result.data.user);
            console.log(result.data.token);

        } catch (error) {
            console.log("error", error);
        }
    }
    return (
        <>

            <div>
                <form onSubmit={handleSubmit}>
                    <input type="email" name='email' placeholder="Enter email" onChange={handlechange} />
                    <input type="password" name='password' placeholder="Password" onChange={handlechange} />
                    <button type="submit">
                        Submit</button></form>
            </div>
        </>
    )
}
export default LoginPage;