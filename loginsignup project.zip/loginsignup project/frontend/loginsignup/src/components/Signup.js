import { useState } from 'react';
import axios from 'axios';

function SignupPage() {

    const [user1, setuser1] = useState({
        username:"",
        email: "",
        password: ""
    })
    const handlechange = (e) => {
        setuser1({ ...user1, [e.target.name]: e.target.value })

    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await axios.post("http://localhost:3006/toregister", user1);
            console.log("you sign up  in succsusfully", result.data.user1);

        } catch (error) {
            console.log("error", error);
        }
    }
    return (
        <>
            <div>
                <form onSubmit={handleSubmit}>
                     <input type="text" name='username' placeholder="username" onChange={handlechange} />
                    <input type="email" name='email' placeholder="Enter email" onChange={handlechange} />
                    <input type="password" name='password' placeholder="Password" onChange={handlechange} />
                    <button type="submit">
                        Submit</button></form>
            </div>
        </>
    )
}
export default SignupPage;