import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { useState} from 'react';
import axios from 'axios'
function SignupPage() {
  const [userc, setuserc] = useState({
    UserName:"",
    EmailId:"",
    Password:""
})

  const handleChange = (e) => {
  setuserc({ ...userc, [e.target.name]: e.target.value });

  }
  const handleSubmit =  async (e) =>{
    e.preventDefault();
    try {
      console.log("you are in the posting phase");
      const response = await axios.post('http://localhost:3006/toPostUser',userc);
      console.log("your data is :", response?.data);
      setuserc(response.data)
      
      
    } catch (error) {

      console.log(error);
      console.log("error in posting data")
        
    }
  }

return (
    <Form onSubmit={handleSubmit}>
    <Form.Group className="mb-3" controlId="formBasicEmail">
      <Form.Label>UserName</Form.Label>
      <Form.Control type="text" placeholder="Enter username"  onChange={handleChange}
      name ='UserName'
      value={userc.UserName}/>
    </Form.Group>

    <Form.Group className="mb-3" controlId="formBasicEmail">
      <Form.Label>Email address</Form.Label>
      <Form.Control type="email" placeholder="Enter email"  onChange={handleChange}
       name ='EmailId'
       value={userc.EmailId}/>
    </Form.Group>

    <Form.Group className="mb-3" controlId="formBasicPassword">
      <Form.Label>Password</Form.Label>
      <Form.Control type="text" placeholder="Password"  onChange={handleChange} 
      name ='Password'
      value={userc.Password}
      />

    </Form.Group>
    <Form.Group className="mb-3" controlId="formBasicCheckbox">
    </Form.Group>
    <Button variant="primary" type="submit">
      Submit
    </Button>
  </Form>
)
}
export default  SignupPage;