import './App.css';
import RegisterNavbar from './components/RegNavbars';
import Routersforuse from './components/Routers';
// import LoginPage from './components/LoginPage';
import SignupPage from './components/Signup';

function App() {
  return (
    <div className="App">
      <RegisterNavbar />
      <Routersforuse/>
      <SignupPage />
      {/* <LoginPage /> */}
    </div>
  );
}

export default App;
