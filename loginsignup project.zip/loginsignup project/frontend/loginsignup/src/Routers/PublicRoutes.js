import { React } from "react";
import PublicLayout from "../components/layout/Publiclayout";
import LoginPage from "../components/LoginPage";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><LoginPage /></PublicLayout>
    },
];
export default publicRoutes;