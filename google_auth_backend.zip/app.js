import express from "express"
import cors from "cors"
import userRouter from "./routes/user"

const app = express()

// routes

app.use(express.json())
app.use(cors({ origin: "*" }))
app.use("/api", userRouter)



export default app