import express from "express";
const userRouter = express.Router()
import { googleAuth } from "../controllers/googleAuth";


userRouter.post("/login", googleAuth)

export default userRouter