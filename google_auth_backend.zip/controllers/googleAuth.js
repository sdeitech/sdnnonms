import { OAuth2Client } from "google-auth-library"
const client_id = "622058714679-05h88k55a394tmarmmutuq49orq51r8m.apps.googleusercontent.com"
const client = new OAuth2Client(client_id)

import Users from "../models/users"


export const googleAuth = async (req, res) => {
    try {
        const { token } = req.body

        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: client_id
        })

        const payload = ticket?.payload
        const email = payload?.email
        const pass = payload?.sub
        console.log(email, pass)
        // console.log(ticket)

        const user = new Users({
            username: email,
            password: pass
        })

        const data = await user.save()
        console.log(data)

    } catch (error) {
        console.log(error.message)
    }
}