from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout


# Create your views here.
class Index(View):
    def get(self, request):
        return render(request, "index.html")


class Login(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):
        username = request.POST.get("username")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            user = authenticate(username=username, password=password)
            if user != None:
                login(request, user)
                return redirect("index/")
            else:
                print("Invalid Credentials!!")
        else:
            print("Username Not Found!!")

        return render(request, "login.html")


class Register(View):
    def get(self, request):
        return render(request, "signup.html")

    def post(self, request):
        firstName = request.POST.get("firstName")
        lastName = request.POST.get("lastName")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password")
        phone = request.POST.get("phoneNo")

        if User.objects.filter(email=email).exists():
            print("Email Already Exist!!")
        elif User.objects.filter(username=username).exists():
            print("Username Already Exists!!")
        else:
            User.objects.create_user(
                first_name=firstName,
                last_name=lastName,
                email=email,
                username=username,
                password=password,
            )
            request.session["phone"] = phone

            print("REGISTERED!")
            print(f"Phone = {phone}")
            return redirect("/")

        return render(request, "signup.html")
