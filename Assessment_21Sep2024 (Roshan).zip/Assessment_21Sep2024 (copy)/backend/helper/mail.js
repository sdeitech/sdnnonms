var nodemailer = require("nodemailer");
const { SENDMAIL } = require("../config/constants");

var transport = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  service: "gmail",
  secure: false,
  auth: {
    user: SENDMAIL,
    pass: "livcdbicsdiaacea",
  },
});

// console.log(transport);
const mailConfig = {
  from: SENDMAIL,
  to: "shivamraj123@yopmail.com",
  subject: "This an sample mail for NodeMailer",
  text: "Hello! Mr. Roshan is an sample!!",
};
exports.mail = () => {
  transport.sendMail(mailConfig);
  console.log("Email Send Successfully");
};
