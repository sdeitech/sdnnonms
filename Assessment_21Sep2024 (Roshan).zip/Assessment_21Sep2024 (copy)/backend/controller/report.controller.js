const mongoose = require("mongoose");
const modelReport = require("../models/report.model");
const constants = require("../config/constants");

/**
 * To get User Report
 */
exports.getReportDetails = async (req, res) => {
  try {
    const reportFound = await modelReport.find();
    res
      .status(constants.OK)
      .json({ message: constants.RECORD_FOUND, report: reportFound });
  } catch (error) {
    res.status(constants.NOT_FOUND).json({ error: constants.RECORD_NOT_FOUND });
  }
};

/**
 * To get Record by ID
 */
exports.getReportDetailById = async (req, res) => {
  try {
    const reportFoundById = await modelReport.findById({ _id: req.params.id });
    res
      .status(constants.OK)
      .json({ message: constants.RECORD_FOUND, report: reportFoundById });
  } catch (error) {
    res.status(constants.NOT_FOUND).json({ error: constants.RECORD_NOT_FOUND });
  }
};

/**
 * To create Record
 */
exports.createReportDetails = async (req, res) => {
  try {
    const newReport = new modelReport(req.body);
    await newReport.save();
    res
      .status(constants.CREATED)
      .json({ message: constants.REGISTERED, report: newReport });
  } catch (error) {
    res
      .status(constants.BAD_REQUEST)
      .json({ error: constants.REGISTER_FAILED });
  }
};

/**
 * To update Record by ID
 */
exports.updateReportDetails = async (req, res) => {
  try {
    const updateReport = await modelReport.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
      }
    );
    if (!updateReport) {
      return res
        .status(constants.NOT_FOUND)
        .json({ error: constants.RECORD_NOT_FOUND });
    }
    res
      .status(constants.OK)
      .json({ message: constants.UPDATED, item: updateReport });
  } catch (error) {
    console.log(error);
    res.status(constants.NOT_FOUND).json({ error: constants.UPDATE_FAILED });
  }
};

/**
 * To delete Record by ID
 */
exports.deleteReportDetails = async (req, res) => {
  try {
    const deleteReport = await modelReport.findByIdAndDelete(req.params.id);
    if (!deleteReport) {
      return res
        .status(constants.NOT_FOUND)
        .json({ error: constants.REMOVE_FAIL });
    }
    res
      .status(constants.OK)
      .json({ message: constants.REMOVED, report: deleteReport });
  } catch (error) {
    res.status(constants.BAD_REQUEST).json({ error: constants.REMOVE_FAIL });
  }
};

/**
 * To send MAIL
 */
exports.mail = async (req, res) => {
  let mailOptions = {
    from: "test@gmail.com",
    to: constants.SENDMAIL,
    subject: "Nodemailer API",
    text: "Hi from your nodemailer API",
  };
  console.log(mailOptions);
  transporter.sendMail(mailOptions);
};
