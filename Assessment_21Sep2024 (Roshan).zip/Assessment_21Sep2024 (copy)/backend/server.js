const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const db = require("./config/db");
const constants = require("./config/constants");
const routerPath = require("./routers/report.router");
const { mail } = require("./helper/mail");
const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use("/reportDetails", routerPath);

mail();
console.log(PORTNO);
app.listen(PORTNO, () => {
  console.log(`Server started on http://localhost:${PORTNO}`);
});
