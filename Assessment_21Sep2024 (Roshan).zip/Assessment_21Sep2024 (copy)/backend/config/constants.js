/**
 * The Following files contains the unchangable code of variable
 */
PORTNO = 4000;
exports.DBURL = `mongodb://localhost:27017/ReportAssessmentDB`;

// MAIL DETAILS
exports.SENDMAIL = "roshankhandagale08@gmail.com";

// DATA STATUS
exports.OK = 200;
exports.CREATED = 201;
exports.ACCEPTED = 202;
exports.BAD_REQUEST = 400;
exports.NOT_FOUND = 404;

// MESSAGES
exports.RECORD_FOUND = "REPORT DATA FOUND!!";
exports.RECORD_NOT_FOUND = "REPORT DATA NOT FOUND!!";
exports.REGISTERED = "REPORT REGISTERED SUCCESSFULLY!!";
exports.REGISTER_FAILED = "REPORT REGISTRATION FAILED..";
exports.UPDATED = "REPORT DATA UPDATED!!";
exports.UPDATE_FAILED = "REPORT UPDATION FAILED!!";
exports.REMOVED = "REPORT REMOVED SUCCESSFULLY!!";
exports.REMOVE_FAIL = "REPORT NOT DELETED!!";
