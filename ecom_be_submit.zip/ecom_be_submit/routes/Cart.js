const express = require('express');
const router = express.Router();
const { addToCart, fetchCartByUser, updateCart, deleteFromCart } = require('../controller/Cart-controller');

// /cart is already added in base path
router.post('/',addToCart);
router.get('/',fetchCartByUser);
router.delete('/:id', deleteFromCart)
router.patch('/:id', updateCart)


exports.router = router;