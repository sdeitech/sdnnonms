
const nodemailer = require("nodemailer") 
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: 'harshgadekar02@gmail.com',
        pass: 'umyoleyzxhadulht'
    }
})

const sendMailAtOrderConfirm = async (to, subject, text) => {
    const mailOptions = {
        from: "harshgadekar02@gmail.com",
        to: to,
        subject: subject,
        text: text
    }
    try {
        const info = await transporter.sendMail(mailOptions)
        return { status: true }
    } catch (error) {
        return { status: false }
    }
}

console.log("mail------------------", sendMailAtOrderConfirm);


module.exports = sendMailAtOrderConfirm