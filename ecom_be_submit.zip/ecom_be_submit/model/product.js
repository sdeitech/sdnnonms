const mongoose = require('mongoose');
const {Schema} = mongoose;

const productSchema = new Schema({                  //this object inside schema which gives the structure of product
    title: {type: String, required: true, unique: true},        //unique: true coz same nam ke 2 product add na ho
    description: {type: String, required: true},
    price: {type: Number, min:[1, 'wrong min Price'], max:[10000, 'wrong max price']},
    discountPercentage: {type: Number, min:[1, 'wrong min discount'], max:[99, 'wrong max discount']},
    rating: {type: Number, min:[0, 'wrong min rating'], max:[99, 'wrong max rating'], default:0},
    stock: {type: Number, min:[0, 'wrong min stock'],default:0},
    brand: {type: String, required: true},
    category: {type: String, required: true},
    thumbnail: {type: String, required: true},
    images: {type: [String], required: true},
    deleted: {type: Boolean, default: false},
})

//the bellow code is for to convert _id into id 

const virtual = productSchema.virtual('id');        //virtual helps in they create virtual data field
virtual.get(function(){         //jaise ab hum yaha productSchema me virtual id bana rhe hai //aur abhi isme getter, setter function hote hai
    return this._id;            //yaha .get ke callback function me bataya ke apko _id ko he as a id return krna hai coz we are using only id in frontend instead of _id 
})
productSchema.set('toJSON',{   //and is .set se he virtual enable hote hai and jab bhi hum res.json send karenge to automatically virtual id create hoke add ho jaege hamare data ke response me
    virtuals: true,
    versionKey: false,
    transform: function(doc, ret) {delete ret._id}
})

exports.Product = mongoose.model('Product',productSchema);