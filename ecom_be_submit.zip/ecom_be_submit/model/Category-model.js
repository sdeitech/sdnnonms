const mongoose = require('mongoose');
const {Schema} = mongoose;

const categorySchema = new Schema({                  //this object inside schema which gives the structure of product
    label: {type: String, required: true, unique: true},        //unique: true coz same nam ke 2 product add na ho
    value: {type: String, required: true, unique: true},
    
})

//the bellow code is for to convert _id into id 

const virtual = categorySchema.virtual('id');        //virtual helps in they create virtual data field
virtual.get(function(){         //jaise ab hum yaha productSchema me virtual id bana rhe hai //aur abhi isme getter, setter function hote hai
    return this._id;            //yaha .get ke callback function me bataya ke apko _id ko he as a id return krna hai coz we are using only id in frontend instead of _id 
})
categorySchema.set('toJSON',{   //and is .set se he virtual enable hote hai and jab bhi hum res.json send karenge to automatically virtual id create hoke add ho jaege hamare data ke response me
    virtuals: true,
    versionKey: false,
    transform: function(doc, ret) {delete ret._id}
})

exports.Category = mongoose.model('Category',categorySchema);