const mongoose = require('mongoose');
const {Schema} = mongoose;

const cartSchema = new Schema({                  //this object inside schema which gives the structure of cart
    quantity: {type: Number, required: true},
    product: {type: Schema.Types.ObjectId, ref: 'Product', required: true},   //using this we can fetch all the info from Product 
    user: {type: Schema.Types.ObjectId, ref: 'User', required: true}
})

//the bellow code is for to convert _id into id 

const virtual = cartSchema.virtual('id');        //virtual helps in they create virtual data field
virtual.get(function(){         //jaise ab hum yaha productSchema me virtual id bana rhe hai //aur abhi isme getter, setter function hote hai
    return this._id;            //yaha .get ke callback function me bataya ke apko _id ko he as a id return krna hai coz we are using only id in frontend instead of _id 
})
cartSchema.set('toJSON',{   //and is .set se he virtual enable hote hai and jab bhi hum res.json send karenge to automatically virtual id create hoke add ho jaege hamare data ke response me
    virtuals: true,
    versionKey: false,
    transform: function(doc, ret) {delete ret._id}
})

exports.Cart = mongoose.model('Cart',cartSchema);