const { Product } = require('../model/product');

exports.createProduct = async (req,res)=>{            //req,res hum yha iseleye de rhe hai kyuki ye jp exact controller function hai ye hum route me put karenge
    //this product we have to get from API body
    const product = new Product(req.body)   //ye req.body ye aaege api call se frontend se
    try{
        const doc = await product.save();
        res.status(201).json(doc);          //otherwise res.status 201 which show resource has created
    }catch(err) {
        res.status(400).json(err);      //if there is a err in database or err in server then this will execute (status 400 which means bad req)
    }
};

exports.fetchAllProducts = async (req,res)=>{            
    //here we need all query string
    // filter = {"category":"smartphone", "laptops"}
    //sort = {_sort : "price",_order = "desc"}
    //pagination = {_page:1,_limit=10}
    //TODO: we have to try with multiple category and brands after chage in front-end

    let condition = {}
    if(!req.query.admin){
        condition.deleted = {$ne:true};
    };

    //same query will not work for get product list and for count of total products thats why we create 2 diff queries
    let query = Product.find(condition); 
    let totalProductsQuery = Product.find(condition);        //{deleted:{$ne:true}} means deleated not equals to true |isse deleted products user ko show nhi honge

    if(req.query.category) {
        query = query.find({ category: req.query.category });
        totalProductsQuery = totalProductsQuery.find({category: req.query.category});
    }
    if(req.query.brand) {
        query = query.find({ brand: req.query.brand });
        totalProductsQuery = totalProductsQuery.find({ brand: req.query.brand });
    }
    //TODO: How to get sort on discounted Price not on actuall price.
    if(req.query._sort && req.query._order){            //here _sort and _order frontend me hai it means sorting ki request aai hue hai
        query = query.sort({[req.query._sort]:req.query._order})   //sort me hme generally field dena hota jo object format me dena hota hai eg{"title":"desc"or"asc"} so by default title ko hmm [req.query._sort] likhenge and order jo "desc"or"asc" hai use hmm req.query._order likhenge
    }
    
    //in frontend we use 'X-Total-Count' to check totalItems and to execute that part we wrote this
    const totalDocs = await totalProductsQuery.countDocuments().exec();
    console.log({totalDocs});

    if(req.query._page && req.query._limit) {
        const pageSize = req.query._limit;   //pageSize basically is page limit =>ITEMS_PER_PAGE jo 30 hmne constant me likha tha 
        const page = req.query._page;
        query = query.skip(pageSize*(page-1)).limit(pageSize);      //.skip() query hoti hai ki hme itne documents skip krne hai | logic: basically 1st page hai to kuch bhi skip nhi karenge 2nd page hai to 30 skip kaege agar 30 limit hai toand .limit means 31 to 60 hume itni limit bhejni hai
    }

    try{
        const docs = await query.exec(); //isse execute hoga and humm results bhej dege
        res.set('X-Total-Count',totalDocs)         //from express re.set | res.set('Content-Type', 'text/plain')
        res.status(200).json(docs);          
    }catch(err) {
        res.status(400).json(err);     
    }
};

exports.fetchProductById = async (req,res) =>{
    const {id} = req.params;
    try{
        const product = await Product.findById(id);
        res.status(200).json(product);          
    }catch(err) {
        res.status(400).json(err);      
    }
};

exports.updateProduct = async (req,res) =>{
    const {id} = req.params;
    try{
        const product = await Product.findByIdAndUpdate(id, req.body, {new:true}); //this {new:true} option is provided coz hme return me latest document mile aur latest doument he hmm frontend me replace krr rhr the iseleye
        res.status(200).json(product);          
    }catch(err) {
        res.status(400).json(err);      
    }
};

