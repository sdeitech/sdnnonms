const sendMailAtOrderConfirm = require("../helper/mail");
const { Order } = require("../model/Order-model");


exports.fetchOrderByUser = async(req,res) =>{
    const {userId} = req.params;
    try{
        const cartItems = await Order.find({user: userId})

        res.status(200).json(cartItems);
    }catch(err) {
        res.status(400).json(err);
    }
}

// exports.createOrder = async (req,res)=>{           
//     const order = Order(req.body);  
//     try{
//         const doc = await order.save();
//         res.status(201).json(doc);         
//     }catch(err) {
//         res.status(400).json(err);      
//     }
// };


exports.createOrder = async (req, res) => {
    const order = new Order(req.body);  
    try {
        const doc = await order.save();
        console.log('doc-------',doc);
        

        // Prepare email content
        const to = req.body.email;  // Assuming the email is part of the request body
        console.log('to-----------',to);
        
        const productNames = doc.items.map(item => item.title || item.brand).join(', ');
        console.log("product Name--------",productNames);
        

        const subject = `Order Confirmation - Order ID: ${doc._id}`;
        const text = `Thank you for your order!\n\nOrder Details:\nOrder ID: ${doc._id}\nProduct Name(s): ${doc.items.title}\nQuantity: ${doc.totalItems}\nTotal Amount: ${doc.totalAmount}\n\nWe will notify you when your order is shipped.`;

        // Send the email
        await sendMailAtOrderConfirm(to, subject, text);

        // Respond to the frontend
        res.status(201).json(doc);
    } catch (err) {
        res.status(400).json(err);
    }
};


exports.deleteOrder = async (req,res)=>{           
    const {id} = req.params;
    try{
        const order = await Order.findByIdAndDelete(id);
        res.status(200).json(order);         
    }catch(err) {
        res.status(400).json(err);      
    }
};

exports.updateOrder = async (req,res) =>{
    const {id} = req.params;
    try{
        const order = await Order.findByIdAndUpdate(id, req.body, {new:true}); //this {new:true} option is provided coz hme return me latest document mile aur latest doument he hmm frontend me replace krr rhr the iseleye
        res.status(200).json(order);          
    }catch(err) {
        res.status(400).json(err);      
    }
}

exports.fetchAllOrders = async (req,res)=>{            
    //here we need all query string
    //sort = {_sort : "price",_order = "desc"}
    //pagination = {_page:1,_limit=10}

    //same query will not work for get product list and for count of total products thats why we create 2 diff queries
    let query = Order.find({deleted:{$ne:true}}); 
    let totalOrdersQuery = Order.find({deleted:{$ne:true}});        //{deleted:{$ne:true}} means deleated not equals to true |isse deleted products user ko show nhi honge

    if(req.query._sort && req.query._order){            //here _sort and _order frontend me hai it means sorting ki request aai hue hai
        query = query.sort({[req.query._sort]:req.query._order})   //sort me hme generally field dena hota jo object format me dena hota hai eg{"title":"desc"or"asc"} so by default title ko hmm [req.query._sort] likhenge and order jo "desc"or"asc" hai use hmm req.query._order likhenge
    }

    //in frontend we use 'X-Total-Count' to check totalItems and to execute that part we wrote this
    const totalDocs = await totalOrdersQuery.countDocuments().exec();
    console.log({totalDocs});

    if(req.query._page && req.query._limit) {
        const pageSize = req.query._limit;   //pageSize basically is page limit =>ITEMS_PER_PAGE jo 30 hmne constant me likha tha 
        const page = req.query._page;
        query = query.skip(pageSize*(page-1)).limit(pageSize);      //.skip() query hoti hai ki hme itne documents skip krne hai | logic: basically 1st page hai to kuch bhi skip nhi karenge 2nd page hai to 30 skip kaege agar 30 limit hai toand .limit means 31 to 60 hume itni limit bhejni hai
    }

    try{
        const docs = await query.exec(); //isse execute hoga and humm results bhej dege
        res.set('X-Total-Count',totalDocs)         //from express re.set | res.set('Content-Type', 'text/plain')
        res.status(200).json(docs);          
    }catch(err) {
        res.status(400).json(err);     
    }
};