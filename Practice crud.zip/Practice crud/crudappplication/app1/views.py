from django.shortcuts import render, redirect
from . models import User, Registartion

# Create your views here.

def input(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        mobileno = int(request.POST.get('mobileno'))
        dob = request.POST.get('dob')
        gender = request.POST.get('gender')
        marritialstatus = request.POST.get('marritialstatus')
        profile = request.POST.get('profile')
        if marritialstatus:
            newObj = User(
                username = username,
                mobileno = mobileno,
                dob = dob,
                gender = gender,
                profile = profile,
                marritialstatus = True
            )
            newObj.save()

        else:
            User.objects.create(
                username = username,
                mobileno = mobileno,
                dob = dob,
                gender = gender,
                profile = profile,
                marritialstatus = False
            )
           
        return redirect('details/')
   
    return render(request, 'input.html')

def details(request):
    result = User.objects.all()
    context = {'result' : result}

    return render(request, 'details.html', context)



def delete(request, id):
    result = User.objects.get(id = id)
    result.delete()
    return redirect('details/')


def update(request, id):
    if request.method == 'GET':
        result = User.objects.get(id=id)
        context = {'result': result}
        return render(request, 'update.html', context)
    else:
        username = request.POST.get('username')
        mobileno = request.POST.get('mobileno')
        dob = request.POST.get('dob')
        gender = request.POST.get('gender')
        marritialstatus = request.POST.get('marritialstatus')
        profile = request.POST.get('profile')

        result = User.objects.get(id=id)

        if username:
            result.username  = username
        
        if mobileno:
            result.mobileno  = mobileno

        if dob:
            result.dob  = dob

        if gender:
            result.gender  = gender

        if marritialstatus:
            result.marritialstatus  = marritialstatus

        if profile:
            result.profile  = profile

        if marritialstatus == 'on':
            result.marritialstatus  = True
        else:
            result.marritialstatus = False
        
        result.save()
        return redirect('details/')
    

def view(request, id):
    result = User.objects.get(id=id)
    context = {'result': result}
    return render(request, 'view.html', context)


# def registration(request):
#     if request.method == 'POST':
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         resultregistration = email, password
#         resultregistration.save()
#     return redirect('/')


# def login(request):

#     if request.method == 'POST':
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         resultlogin = email, password
#         resultlogin.save()
#     return redirect('input/')