from django.db import models

# Create your models here.
GENDER_CHOICES = (
   ('M', 'Male'),
   ('F', 'Female'),
   ('O', 'Other')

)
class User(models.Model):
    username = models.CharField(max_length=50)
    mobileno = models.IntegerField()
    gender = models.CharField(choices=GENDER_CHOICES, max_length=128)
    marritialstatus = models.BooleanField(null=True, blank=True)
    dob = models.DateField()
    profile = models.FileField(upload_to="images/", default=True)

class Registartion(models.Model):
    email = models.EmailField(max_length=50)
    password = models.CharField(max_length=128)