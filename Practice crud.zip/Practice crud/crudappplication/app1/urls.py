from django.urls import path
from . import views

urlpatterns = [
    # path('/', views.login, name='login'),
    path('', views.input, name='input'),
    path('details/', views.details, name='details'),
    path('delete/<int:id>' ,views.delete, name='delete'),
    path('update/<int:id>' ,views.update, name='update'),
    path('view/<int:id>', views.view, name='view' )
]