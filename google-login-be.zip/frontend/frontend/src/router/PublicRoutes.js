import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Loginform from "../Login SignUp/loginform";
import SignUp from "../Login SignUp/SignUpForm";
import UserProfile from "../component/UserProfile";
import Login from "../Goggle-O-Auth/login";
import Logout from "../Goggle-O-Auth/logout";


const publicRoutes = [
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Loginform /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    },
    {
    	path: "/login",
    	exact: true,
    	element: <PublicLayout><Login/></PublicLayout>
    },
    {
    	path: "/logout",
    	exact: true,
    	element: <PublicLayout><Logout/></PublicLayout>
    }
    
    
];
export default publicRoutes;
