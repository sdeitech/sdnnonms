import { useState } from "react";
import { TextField, Button, Box } from "@mui/material";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const ChangePassword = () => {
    const navigate = useNavigate();
    const user = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    const [passwordData, setPasswordData] = useState({
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
    });

    // Handle input changes
    const handlePasswordChange = (e) => {
        const { name, value } = e.target;
        setPasswordData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    // Submit password change
    const handlePasswordSubmit = async (e) => {
        e.preventDefault();
        if (passwordData.newPassword !== passwordData.confirmPassword) {
            Swal.fire('Error', 'Passwords do not match!', 'error');
            return;
        }

        try {
            await axios.put(`http://localhost:5000/api/change-password/${user}`, {
                oldPassword: passwordData.oldPassword,
                newPassword: passwordData.newPassword
            }, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            Swal.fire('Success', 'Password updated successfully', 'success');
            navigate('/students'); // Navigate back after success
        } catch (error) {
            Swal.fire('Error', 'Old password is incorrect or update failed', 'error');
        }
    };

    // Handle forget password functionality
    const handleForgetPassword = async () => {
        const { value: email } = await Swal.fire({
            title: 'Enter your email address',
            input: 'email',
            inputLabel: 'Email',
            inputPlaceholder: 'Enter your email address',
            showCancelButton: true,
            confirmButtonText: 'Send Temporary Password',
            preConfirm: (email) => {
                if (!email) {
                    Swal.showValidationMessage('Please enter a valid email');
                }
                return email;
            }
        });

        if (email) {
            try {
                await axios.post(`http://localhost:5000/api/forget-password`, { email });
                Swal.fire('Success', 'Temporary password sent to your email!', 'success');
            } catch (error) {
                Swal.fire('Error', 'Failed to send temporary password. Please try again.', 'error');
            }
        }
    };

    return (
        <Box component="form" onSubmit={handlePasswordSubmit} sx={{ mt: 2 }}>
            <h2>Change Password</h2>
            <TextField
                label="Old Password"
                name="oldPassword"
                type="password"
                value={passwordData.oldPassword}
                onChange={handlePasswordChange}
                fullWidth
                sx={{ mb: 2 }}
            />
            <TextField
                label="New Password"
                name="newPassword"
                type="password"
                value={passwordData.newPassword}
                onChange={handlePasswordChange}
                fullWidth
                sx={{ mb: 2 }}
            />
            <TextField
                label="Confirm New Password"
                name="confirmPassword"
                type="password"
                value={passwordData.confirmPassword}
                onChange={handlePasswordChange}
                fullWidth
                sx={{ mb: 2 }}
            />
            <Button variant="contained" color="primary" type="submit">
                Submit Password Change
            </Button>

            <Box sx={{ mt: 2 }}>
                <Button variant="outlined" color="secondary" onClick={handleForgetPassword}>
                    Forget Password?
                </Button>
            </Box>
        </Box>
    );
};

export default ChangePassword;
