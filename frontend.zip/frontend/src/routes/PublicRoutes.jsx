import SignIn from "../components/Login";
import SignUp from "../components/SignUp";
import PublicLayout from "../layout/PublicLayout";
import ForgetPassword from "../components/Forgot";
// import Register from "../components/Register";

const PublicRoutes = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignIn />
        {/* <SignUp/> */}
      </PublicLayout>
    ),
  },
  {
    path: "/signup",
    // path: "/login",
    element: (
      <PublicLayout>
        <SignUp />
        {/* <SignIn/> */}
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />

        {/* <SignUp/> */}
      </PublicLayout>
    ),
  },
  {
    path: "/forget",
    element: (
      <PublicLayout>
        {/* <SignIn /> */}
        <ForgetPassword />
      </PublicLayout>
    ),
  },
];
export default PublicRoutes;
