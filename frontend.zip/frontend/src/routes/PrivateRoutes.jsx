import AddUser from "../components/AddUser";
import DataTable from "../components/DataTable";
// import SignUp from "../components/SignUp";
import UpdateUser from "../components/UpdateUser";
import PrivateLayout from "../layout/PrivateLayout";
import ChangePassword from "../components/ChangePassword";

const PrivateRoutes = [
  {
    // path: "/dashboard",
    path:"/datatable",
    element: (
      <PrivateLayout>
        <DataTable/>
      </PrivateLayout>
    ),
  },
  {
    path:"/adduser",
    element: (
      <PrivateLayout>
        <AddUser/>
      </PrivateLayout>
    ),
  },
  {
    path:"/myprofile",
    element: (
      <PrivateLayout>
        <UpdateUser/>
      </PrivateLayout>
    ),
  },
  {
    // path: "/dashboard",
    path:"/changepassword",
    element: (
      <PrivateLayout>
        <ChangePassword/>
      </PrivateLayout>
    ),
  },
];


export default PrivateRoutes;
