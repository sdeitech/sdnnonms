// import React, { useState } from "react";
// import axios from "axios";
// // import { Link } from "react-router-dom";
// import { useNavigate } from "react-router-dom";
// // import validateUser from "./validate";
// import './Register.css'
// import {
//   MDBBtn,
//   MDBContainer,
//   MDBCard,
//   MDBCardBody,
//   MDBInput,
//   MDBCheckbox
// }
// from 'mdb-react-ui-kit';

// function Register() {
    

//   const [image,setImage] = useState("")

//   const navigate = useNavigate();
//   const [formData, setFormData] = useState({
//     firstname: "",
//     lastname: "",
//     email: "",
//     DOB: "",
//     password: "",
//     profile: null,
//   });

//   const [errors,setErrors] = useState("")
//   const apiUrl = "http://localhost:8000/api";

//   console.log(formData);
//   const handleChnage = (e) => {
//     const { name, value, type, files } = e.target;
//     if (type === "file") {
//       setFormData({
//         ...formData,
//         [name]: files[0],
        
//       },
//     setImage(URL.createObjectURL(files[0])));
//     } else {
//       setFormData({
//         ...formData,
//         [name]: value,
//       });
//     }
//   };


//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     // const validationErrors = validateUser(formData);
//     // if (Object.keys(validationErrors).length === 0) 
//     {


//     try {
//       const res = await axios.post(`${apiUrl}/signup`, formData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
//       navigate("/login");
//       console.log(res.data);
//     } catch (error) {
//       console.log(error.message);
//     }
//   }};

//   return (
//     <MDBContainer fluid className='d-flex align-items-center justify-content-center bg-image' style={{backgroundImage: 'url(https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp)'}}>
//       <div className='mask gradient-custom-3'></div>
//       <MDBCard className='m-5' style={{maxWidth: '600px'}}>
//         <MDBCardBody className='px-5'>
//           <h2 className="text-uppercase text-center mb-5">Create an account</h2>
//           <MDBInput wrapperClass='mb-4' label='First Name' size='lg' id='form1' type='text'/>
//           <MDBInput wrapperClass='mb-4' label='Last Name' size='lg' id='form1' type='text'/>
//           <MDBInput wrapperClass='mb-4' label='Your Email' size='lg' id='form2' type='email'/>
//           <MDBInput wrapperClass='mb-4' label='DOB' size='lg'  type='date'/>
//           <MDBInput wrapperClass='mb-4' label='password' size='lg' id='form4' type='password'/>
//           {/* <MDBInput label='married'/> */}
//           <label>
//           <input type="checkbox" />
//           Married
//         </label>
//         <div
//           style={{
//             marginBottom: "10px",
//             display: "flex",
//             justifyContent: "space-around",
//           }}
//         >
//           <label>
//             Male
//             <input
//               type="radio"
//               name="gender"
//               value="male"
//             //   checked={formData.gender === "male"}
//             //   onChange={handleChnage}
//               style={{ marginLeft: "5px" }}
//             />
//           </label>
//           <label>
//             Female
//             <input
//               type="radio"
//               name="gender"
//               value="female"
//             //   checked={formData.gender === "female"}
//             //   onChange={handleChnage}
//               style={{ marginLeft: "5px" }}
//             />
//           </label>
//         </div>
//           <div className='d-flex flex-row justify-content-center mb-4'>
//             <MDBCheckbox name='flexCheck' id='flexCheckDefault' label='I agree all statements in Terms of service' />
//           </div>
//   {/* onClick={() => navigate("/login")} */}
//   <MDBBtn className='mb-4 w-100 gradient-custom-4' size='lg' >Register</MDBBtn>
//         </MDBCardBody>
//       </MDBCard>
//     </MDBContainer>
//   );
// }
// export default Register;