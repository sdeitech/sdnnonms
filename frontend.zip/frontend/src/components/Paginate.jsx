import React, { useEffect, useState } from "react";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import axios from "axios";
import View from "./View";
import { useSelector } from "react-redux";
import { CSVLink, CSVDownload } from "react-csv";

const Paginate = () => {
  const [curruntUser, setcurruntUser] = useState(null);
  const [showview, setshowview] = useState(false);


  const token = useSelector(state => state.loginUser.userToken)
  console.log(token,"dhjfbvkjdsbgfkjsghkdfjhbgvkjs")

  const [userdata, setUserdata] = useState([]);
  const [totalpage, setTotalpage] = useState(1);
  const [currentpage, setCurrentpage] = useState(1);
  const [search, setSearch] = useState("");
  console.log(userdata, "hkjsahdd");
  console.log(totalpage, currentpage);
  const handlepage = (event, page) => {
    setCurrentpage(page);
  };
  const Handleview = (data) => {
    setshowview(!showview);
    setcurruntUser(data);
  };
  const id = localStorage.getItem("id")

  const fetchData = async () => {
    try {
      const res = await axios.get(
        `http://localhost:8001/api/users/${id}?search=${search}&page=${currentpage}&limit=5`,
        {
          headers: {
            Authorization: localStorage.getItem("usertoken"),
          },
        }
      );
      console.log(res.data, "aryan");
      setUserdata(res.data.user);
      setTotalpage(res.data.totalPages);
      setCurrentpage(res.data.pageNo);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchData();
  }, [currentpage, search]);

  const handleSearch = (e) => {
    setSearch(e.target.value);
  };

  return (
    <div>


      <input type="text" placeholder="search" onChange={handleSearch} />
      <button style={{backgroundColor:"#3b5998",marginRight:"16px",marginLeft:"16px"}}>Import User</button>
      {/* <button style={{backgroundColor:"#3b5998",marginRight:"16px"}}>Export User</button> */}
      <CSVLink data={userdata}  style={{backgroundColor:"#3b5998",marginRight:"16px",color:"white"}} >Export User</CSVLink>
      <div>
        <table
          style={{
            border: "5px solid",
            marginLeft: "auto",
            marginRight: "auto",
            // marginTop: "10px",
            width: "100%",
            height: "50%",
            alignItems: "center",
            textAlign: "center",
          }}
        >
          <thead style={{ border: "1px solid" }}>
            <tr style={{ border: "1px solid" }}>
              <th>firstname</th>
              <th>lastname</th>
              <th>email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody style={{ border: "1px solid" }}>
            {userdata.map((item) => {
              return (
                <tr key={item._id}>
                  <td>{item.firstname}</td>
                  <td>{item.lastname}</td>
                  <td>{item.email}</td>
                  <td>
                    <button onClick={() => Handleview(item)}>View</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div>
        <div
          style={{ width: "100%", display: "flex", justifyItems: "center" }}
        ></div>
        {showview && (
          <View
            curruntUser={curruntUser}
            showview={showview}
            setshowview={setshowview}
          />
        )}
      </div>

      <Stack spacing={2}>
        <Pagination
          count={totalpage}
          page={currentpage}
          onChange={handlepage}
          variant="outlined"
        />
      </Stack>
    </div>
  );
};

export default Paginate;
