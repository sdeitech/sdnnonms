import React, { useEffect, useState } from "react";
import axios from "axios";
import View from "./View";
import { Link } from "react-router-dom";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { MDBInputGroup, MDBInput, MDBIcon, MDBBtn } from "mdb-react-ui-kit";
import Paginate from "./Paginate";
import ChangePassword from "./ChangePassword";
// import AddUser from "./AddUser";

const DataTable = () => {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const myToken = JSON.parse(localStorage.getItem("token"));

      const response = await axios.get(
        // `http://localhost:8001/add/getdata/userid/${myToken.id}`,
        {
          headers: {
            Authorization: localStorage.getItem("usertoken"),
          },
        }
      );
      console.log(response.data, "heyy");
      console.log("jhgjghjghyhgb", response.data.newUser);

      setData(response.data.newUser);
      console.log(response.data.newUser, "hey");
    } catch (error) {
      console.log("error fetching data");
    }
  };

  // export const getregisterbyid = async (id) => {
  //   try{
  //     const response = await axios.get()
  //   }
  // }
  // const [updatedata,setupdatedata] = useState(null);

  // useEffect(() => {
  //   fetchData();
  // }, []);

  const [curruntUser, setcurruntUser] = useState(null);
  const [showview, setshowview] = useState(false);

  // const update = (user) => {
  //   setshowupdate(!showupdate);
  //   console.log(update);
  //   setcurruntUser(user)
  // };


  const Handleview = (data) => {
    setshowview(!showview);
    setcurruntUser(data);
  };
  const handleLogout = () => {
    localStorage.clear();
  };

  //Pagination

  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(5);

  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;

  const currentRecords = data.slice(indexOfFirstRecord, indexOfLastRecord);
  console.log(currentPage);
  const nPages = Math.ceil(data.length / recordsPerPage);

  const pageNumbers = [...Array(nPages + 1).keys()].slice(1);

  const goToNextPage = () => {
    if (currentPage !== nPages) setCurrentPage(currentPage + 1);
  };

  const goToPrevPage = () => {
    if (currentPage !== 1) setCurrentPage(currentPage - 1);
  };

  return (
    <>
      <h1 style={{ textAlign: "center" }}>Dashboard</h1>
     
      <div>
        
        <div
          style={{ width: "100%", display: "flex", justifyItems: "center" }}
        ></div>
        {showview && (
          <View
            curruntUser={curruntUser}
            showview={showview}
            setshowview={setshowview}
          />
        )}
      </div>
      <Paginate/>
    </>
  );
};

export default DataTable;
