import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

// const apiUrl = process.env.REACT_APP_API_URL;

const UpdateUser = () => {
  const navigate = useNavigate();

  const data = localStorage.getItem("token");

  const userData = JSON.parse(data);
  console.log(userData,"dhole")

  const [formData, setFormData] = useState({
    firstname: userData?.firstname,
    lastname: userData?.lastname,
    email: userData?.email,
    DOB: userData?.DOB,
    profile: null,
  });

  const apiUrl = "http://localhost:8001/api";

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  // console.log(formData,"he")
  const [userdata, setUserdata] = useState({});

  const fetchProfile = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put(
        `http://localhost:8001/api/getuser/${localStorage.getItem("id")}`,
        formData,{
          headers:{
            "Content-Type":"multipart/form-data"
          }
        }
      );
      localStorage.setItem("token", JSON.stringify(res.data));
      console.log(res.data, "dholeeeeee");
      setFormData(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div
      style={{
        justifyContent: "center",
        display: "flex",
        alignItems: "center",
        border: "solid 3px",
        padding: "20px",
        flexDirection: "column",
        width: "500px",
        margin: "auto",
        marginTop: "50px",
        borderRadius: "10px",
      }}
    >
      <h1>My Profile</h1>
      <div>
        <img
          src={`http://localhost:8001/getimage/${userData?.profile}`}
          height={70}
          width={70}
          alt=""
          style={{ borderRadius: "50%", border: "1px solid black" }}
        />
      </div>
      <form
        onSubmit={fetchProfile}
        style={{ display: "flex", flexDirection: "column", width: "100%" }}
      >
        <input
          type="text"
          name="firstname"
          value={formData?.firstname}
          placeholder="Enter firstname"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="tel"
          name="lastname"
          value={formData?.lastname}
          placeholder="Enter lastname"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="text"
          name="email"
          value={formData?.email}
          placeholder="Enter email"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="date"
          name="DOB"
          value={formData?.DOB}
          placeholder="Enter DOB"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        {/* <input
          type="password"
          name="password"
          value={formData.password}
          placeholder="Enter password"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
          /> */}
        <label>
          <input type="checkbox" />
          Married
        </label>
        <div
          style={{
            marginBottom: "10px",
            display: "flex",
            justifyContent: "space-around",
          }}
        >
          <label>
            Male
            <input
              type="radio"
              name="gender"
              value={formData.gender}
              checked={formData.gender === "male"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
          <label>
            Female
            <input
              type="radio"
              name="gender"
              value={formData.gender}
              checked={formData.gender === "female"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
        </div>
        <input
          type="file"
          name="profile"
          onChange={handleChnage}
          style={{ marginBottom: "10px", border: "none" }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            borderRadius: "5px",
            backgroundColor: "#007bff",
            color: "#fff",
            border: "none",
            cursor: "pointer",
          }}
          // onClick={() => navigate("/login")}
        >
          Update
        </button>
      </form>
      {/* <p style={{ marginTop: "10px" }}>
        Already have an account?{" "}
        <Link
          to={"/login"}
          style={{ color: "#007bff", textDecoration: "none" }}
        >
          <span>click here</span>
        </Link> */}
    </div>
  );
};

export default UpdateUser;
