import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';


const ChangePassword = () => {
  const id = localStorage.getItem("id");
    const navigate = useNavigate();


  const [currentPassword, setcurrentPassword] = useState("");
  const [newPassword, setnewPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (newPassword === confirmPassword) {
      //api
      const response = await axios.put(
        `http://localhost:8001/api/changepassword/${id}`,
        {
          oldPassword: currentPassword,
          newPassword: newPassword,
        }
      );
      console.log(response.data);
      toast.success('Successfully password changed..!')

      setTimeout(() => {
        
      navigate("/login");
      }, 2000);
      
    } else {
      alert("Passwords do not match");
    }
  };

  return (
    <div>
    <form
    onSubmit={handleSubmit}
      style={{
        display: "flex",
        justifyContent: "space-around",
        textAlign: "center",
        height: "97vh",
        position: "relative",
        alignItems: "center",
        display: "grid",
        border: "3px solid",
        gap: "1px",
      }}
    >
      <label for="html" style={{ fontWeight: "bold" }}>
        Current Password
      </label>
      <input
        type="password"
        placeholder="current Password"
        value={currentPassword}
        onChange={(e) => setcurrentPassword(e.target.value)}
      />
      <label for="html" style={{ fontWeight: "bold" }}>
        New Password
      </label>

      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={(e) => setnewPassword(e.target.value)}
      />

      <label for="html" style={{ fontWeight: "bold" }}>
        Confirm Password
      </label>

      <input
        type="password"
        placeholder="confirm new Password"
        value={confirmPassword}
        onChange={(e) => setconfirmPassword(e.target.value)}
      />

      <button type="submit">Change Password</button>
    </form>
    <Toaster/>
    </div>
  );
};

export default ChangePassword;
