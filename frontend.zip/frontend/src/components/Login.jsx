import React, { useState } from "react";
// import SignUp from "./SignUp";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import {
  MDBContainer,
  MDBCol,
  MDBRow,
  MDBBtn,
  MDBIcon,
  MDBInput,
  MDBCheckbox,
} from "mdb-react-ui-kit";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Googlebutton from "./Googlebutton";
import validation from "./validation";
import toast, { Toaster } from 'react-hot-toast';
import { loginSuccess } from "../Reducers/LoginUser";
import {useDispatch,useSelector} from "react-redux"
import ForgetPassword from "./Forgot";
const clientId =
  "368841272750-bsgr39djulkqk32p6utco69sqsjj83mc.apps.googleusercontent.com";

const SignIn = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState({});

  const apiUrl = "http://localhost:8001/api";

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${apiUrl}/login`, formData);
      console.log(res.data.token, "heybghujb ");
      console.log(res.data,"ahkjsha")
      dispatch(loginSuccess(res.data))
      localStorage.setItem("id", res.data.id);
      localStorage.setItem("token", JSON.stringify(res.data.token));
      localStorage.setItem("usertoken", res.data.usertoken);

      toast.success('Successfully logged in..!')

      setTimeout(() => {
        
      navigate("/datatable");
      }, 2000);
      
    } catch (error) {
      console.log(error.message);
    }
  };

  // const handleSubmitt = async (response) => {
  //   const { credential } = response;
  //   console.log(response);
    
  // };
  // const handleErrro = (error) => {
  //   console.log(error.message);
  // };

  const handleRegister = () => {
    navigate("/signup");
  };
  return (
   <div>

<MDBContainer fluid className="p-3 my-5">
      <MDBRow>
        <MDBCol col="10" md="6">
          <img
            src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg"
            class="img-fluid"
            alt="Phone image"
          />
        </MDBCol>

        <MDBCol col="4" md="6">
          <form onSubmit={handleSubmit}>
            <MDBInput
              wrapperClass="mb-4"
              label="Email address"
              type="email"
              name="email"
              placeholder="Enter email"
              onChange={handleChnage}
              size="lg"
            />
            {error.email && (
              <p style={{ color: "red" }}>{error.email}</p>
            )}

            <MDBInput
              wrapperClass="mb-4"
              label="Password"
              type="password"
              name="password"
              placeholder="Enter password"
              onChange={handleChnage}
              size="lg"
            />
          {error.password && (
              <p style={{ color: "red" }}>{error.password}</p>
            )}
            <div className="d-flex justify-content-between mx-4 mb-4">
              <MDBCheckbox
                name="flexCheck"
                value=""
                id="flexCheckDefault"
                label="Remember me"
              />
              <a href="/forget">Forgot password?</a>
            </div>

            <MDBBtn className="mb-4 w-100" size="lg" type="submit">
              Sign in
            </MDBBtn>

            <div className="divider d-flex align-items-center my-4">
              <p className="text-center fw-bold mx-3 mb-0">OR</p>
            </div>

            <MDBBtn
              className="mb-4 w-100"
              size="lg"
              style={{ backgroundColor: "#3b5998" }}
              // onClick={() => navigate("/register")}
              onClick={handleRegister}
            >
              <MDBIcon
                className="mx-2"
                // onClick={handleRegister}
              />
              Sign Up
            </MDBBtn>

            {/* <div>
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={handleSubmitt}
                    onError={handleErrro} />
            </GoogleOAuthProvider>
        </div> */}

            <Googlebutton />
            {/* <MDBBtn
              className="mb-4 w-100"
              size="lg"
              style={{ backgroundColor: "#55acee" }}
            >
              login with Google
            </MDBBtn> */}
          </form>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
    <Toaster/>


   </div>
  );
};

export default SignIn;
// {
//   headers:{
//     Authorization:loacastorage.getIt
//   }
// }
