import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from "react-router-dom";
import ChangePassword from './ChangePassword';


function NavBar() {
  const navigate = useNavigate();
  const handleLogout = () => {
    toast.error("Logged Out ")
    setTimeout(() => {
      navigate("/login")
    }, 2000);
    localStorage.clear();
  };

  const user = localStorage.getItem("token")
  const data = JSON.parse(user)
  return (
    <div>
   <div>
   <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        {/* <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand> */}
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
          <Nav.Link href="/adduser" style={{fontWeight:"bold"}}>Hello {data?.firstname}...!!</Nav.Link>

            <Nav.Link href="/adduser" style={{fontWeight:"bold"}}>Add User</Nav.Link>
            <Nav.Link href="/myprofile" style={{fontWeight:"bold"}}>My Profile</Nav.Link>
            
            
            <button onClick={handleLogout}style={{backgroundColor:"Red", fontWeight:"bold"}}>logout</button>
            
            {/* <Nav.Link href="/myprofile" style={{fontWeight:"bold",display:"flex",alignItems:"center",backgroundColor:"#3b5998",gap:"3px",marginRight:"16px",marginLeft:"16px"}}>Import User</Nav.Link> */}
          
            <Nav.Link href="/changepassword" style={{backgroundColor:"#3b5998",fontWeight:"bold",marginLeft:"16px"}}>Change Password</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
   </div>
   <Toaster/>
    </div>
  );
}

export default NavBar;