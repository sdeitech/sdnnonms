import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import toast, { Toaster } from 'react-hot-toast';

const clientId =
  "469359144145-0su1kkfikabj3tqbsvognfte227j3uot.apps.googleusercontent.com";

const Googlebutton = () => {

const navigate = useNavigate()
const handleLoginSuccess = async (response) => {
    const { credential } = response;
    console.log(credential , "kjbhkj")
    try {
    const res = await axios.post('http://localhost:8001/api/login-with-google', { token: credential });

    toast.success('Successfully logged in..!')

      setTimeout(() => {
        
      navigate("/datatable");
      }, 2000);



 console.log(res.data,"hegjgagdua")
 localStorage.setItem("id", res.data.id);
 localStorage.setItem("token", JSON.stringify(res.data.token)[0]);
 localStorage.setItem("usertoken", res.data.usertoken);
    } catch (error) {
        console.error('Error during login:', error);
    }
};

const handleLoginFailure = (error) => {
    console.log('Login failed', error);
}


  return (
    <div>
      <div>
        <GoogleOAuthProvider clientId={clientId}>
          <GoogleLogin
            onSuccess={handleLoginSuccess}
            onError={handleLoginFailure}
          />
        </GoogleOAuthProvider>
      </div>
      <Toaster/>
    </div>
  );
}

export default Googlebutton;
