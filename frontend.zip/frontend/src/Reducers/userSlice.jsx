import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "userData",
  initialState: {
    userData: null,
  },
  reducers: {
    saveUserData: (state, action) => {
      console.log(action.payload);
      state.userData = action.payload;
    },
    clearUsers: (state) => {
      state.userData = null;
    },
  },
});

export const { saveUserData } = userSlice.actions;
export default userSlice.reducer;
