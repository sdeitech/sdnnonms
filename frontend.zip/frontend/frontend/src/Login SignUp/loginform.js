import React, { useState } from "react";
import { TextField, Button, InputAdornment } from "@mui/material";
import { Link } from "react-router-dom";
import AccountCircle from "@mui/icons-material/AccountCircle";
import LockIcon from "@mui/icons-material/Lock";
import "./loginform.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Loginform() {
  const navigate = useNavigate();

  const [state, setState] = useState({
    emailError: "",
    passwordError: "",
  });

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState(null); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { email, password } = formData;

    setState({
      ...state,
      emailError: email === "" ? "Please enter your email" : "",
      passwordError: password === "" ? "Please enter your password" : "",
    });

    if (email === "" || password === "") {
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/login", formData);
      localStorage.setItem("token", response.data.token);
      navigate("/students");
      console.log("Login successful");
    } catch (err) {
      if (err.response && err.response.data && err.response.data.message) {
        setError(err.response.data.message); 
      } else {
        setError("Login failed. Please check your credentials."); 
      }
    }
  };

  return (
    <React.Fragment>
      <form autoComplete="off" onSubmit={handleSubmit} className="form-container">
        <h1>SIGN IN</h1>
        <TextField
          id="email"
          name="email"
          label="Email"
          value={formData.email}
          onChange={handleChange}
          fullWidth
          sx={{ mb: 3 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <AccountCircle />
              </InputAdornment>
            ),
          }}
        />
        <span className="error-message">{state.emailError}</span>

        <TextField
          id="password"
          name="password"
          label="Password"
          type="password" 
          value={formData.password}
          onChange={handleChange}
          fullWidth
          sx={{ mb: 3 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
        />
        <span className="error-message">{state.passwordError}</span>

        {error && <span className="error-message">{error}</span>} 

        <Button variant="outlined" color="secondary" type="submit">
          Login
        </Button>
      </form>

      <small>
        Need an account? <Link to="/signUp">Register here</Link>
      </small>
    </React.Fragment>
  );
}

export default Loginform;
