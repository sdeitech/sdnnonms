
import React, { useState } from "react";
import {
  TextField,
  Button,
} from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddStudent() {

  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });

  const [error, setError] = useState({
    firstNameError: "",
    lastNameError: "",
    emailError: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { firstName, lastName, email } = formData;

    setError({
      firstNameError: firstName === "" ? "Please enter firstName" : "",
      lastNameError: lastName === "" ? "Please enter last Name" : "",
      emailError: email === "" ? "Please enter email" : "",
    });

    if (firstName && lastName && email) {
      console.log("Student Data:", formData);
    }

    try {
      const response = await axios.post('http://localhost:5000/apis/add-student', formData);
      navigate('/students');
      console.log('SignUp successful:');
    } catch (err) {
      setError('Login failed. Please check your credentials.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <h1>Add Student</h1>

      <TextField
        id="firstName"
        name="firstName"
        label="First Name"
        value={formData.firstName}
        onChange={handleChange}
        defaultValue=""
        fullWidth
        sx={{ mb: 3 }}

      />
      <span className="error-message">{error.firstNameError}</span>

      <TextField
        id="lastName"
        name="lastName"
        label="Last Name"
        value={formData.lastName}
        onChange={handleChange}
        defaultValue=""
        fullWidth
        sx={{ mb: 3 }}

      />
      <span className="error-message">{error.lastNameError}</span>

      <TextField
        id="email"
        name="email"
        label="Email"
        value={formData.email}
        onChange={handleChange}
        defaultValue=""
        fullWidth
        sx={{ mb: 3 }}

      />
      <span className="error-message">{error.emailError}</span>

      <Button variant="contained" color="primary" type="submit">
        Submit
      </Button>
    </form>
  );
}

export default AddStudent;
