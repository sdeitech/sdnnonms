import jwt from "jsonwebtoken";

const verifyToken = async (req, res, next) => {
  try {
    const token = req.header("Authorization")?.split(" ")[1];
    if (!token) {
      return res.status(500).json({ message: "assess deny" });
    }
    const verifiedToken = jwt.verify(token, "secret key");
    if (!verifiedToken) {
      return res.status(500).json({ message: "ACCESS_DENIED" });
    }
    next();
  } catch (error) {
    res.status(500).json({ error: error.message, message: "invalid" });
  }
};

export default verifyToken;