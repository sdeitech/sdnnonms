const config = {
  local: {
    DB: {
      HOST: "",
      DB_PORT: "27017",
      DB_NAME: "userManagementSystem",
    },
    API_PORT: 4444,
    emailUser:'dikshaladke12@gmail.com',
    emailPassword:"jkch gbof naao peqo"
  },

  prod: {
    DB: {
      HOST: "",
      DB_PORT: "27017",
      DB_NAME: "userManagementSystem",
    },
    API_PORT: 4000,
  },

  testing: {
    DB: {
      HOST: "",
      DB_PORT: "27017",
      DB_NAME: "userManagementSystem",
    },
    API_PORT: 4000,
  },
};
export default config;