import UserAuth from "../model/authUser";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { OAuth2Client } from "google-auth-library";
import nodemailer from "nodemailer";
import randomstring from "randomstring";
import config from "../config/config";

const CLIENT_ID =
  "598813302719-b6jeo85np0pnma5qasggi0qre5mfpe2l.apps.googleusercontent.com";
const client = new OAuth2Client(CLIENT_ID);

export const RegisterUser = async (req, res) => {
  try {
    const profile = req.file?.filename;
    const { firstName, lastName, email, DOB, password, isMarried, gender } =
      req.body;
    const hashPass = await bcrypt.hash(password, 10);

    const newAuthuser = new UserAuth({
      firstName,
      lastName,
      email,
      DOB,
      password: hashPass,
      isMarried,
      gender,
      profile: profile,
    });

    await newAuthuser.save();
    res.status(200).json(newAuthuser);
  } catch (error) {
    res.status(500).json({ message: "error while registering user" });
  }
};

export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const newuser = await UserAuth.findOne({ email });
    if (!newuser) {
      return res.status(500).json({ message: "email not match" });
    }

    const ismatch = await bcrypt.compare(password, newuser.password);
    if (!ismatch) {
      return res.status(500).json("Invalid credentials");
    }

    const token = jwt.sign(
      { email: newuser.email, id: newuser._id },
      "secret key",
      { expiresIn: "6hr" }
    );

    await newuser.save();
    res.status(200).json({ message: "login successfull", token, newuser });
  } catch (error) {
    res.status(500).json({ message: "error while login " });
  }
};

export const googleLogin = async (req, res) => {
  const { token } = req.body;
  try {
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: CLIENT_ID,
    });
    const payload = ticket.getPayload();

    const googleId = payload["sub"];
    const email = payload["email"];

    const username = email.split("@")[0];
    let user = await UserAuth.findOne({ email });

    if (!user) {
      user = new UserAuth({
        firstName: username,
        lastName,
        email,
        DOB: "",
        password: googleId,
        isMarried,
        gender: "",
        profile: "",
      });
      await user.save();
    }
    const token = jwt.sign({ userId: user._id }, "secret key", {
      expiresIn: "6hr",
    });
    res.json({ message: "login success with google", token: token });
  } catch (error) {
    console.log("error while login with google");
    res.status(500).json({ message: "error while login with google" });
  }
};


export const updateAuthUser = async (req, res) => {
  try {

    const user = await UserAuth.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const {
      firstName = user.firstName,
      lastName = user.lastName,
      email = user.email,
      DOB = user.DOB,
      password = user.password,
      isMarried = user.isMarried,
      gender = user.gender,
    } = req.body;

    const profile = req.file ? `/profiles/${req.file.filename}` : user.profile;

    const updatedData = {
      firstName,
      lastName,
      email,
      DOB,
      isMarried,
      gender,
      profile,
    };

    if (password !== user.password) {
      const salt = await bcrypt.genSalt(10);
      updatedData.password = await bcrypt.hash(password, salt);
    }

    const updateduser = await UserAuth.findByIdAndUpdate(
      req.params.id,
      updatedData,
      { new: true }
    );

    if (!updateduser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ message: "Profile updated", user: updateduser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error while updating user profile" });
  }
};

export const changePassword = async (req, res) => {
  try {
    const { email, oldPassword, newPassword } = req.body;
    const user = await UserAuth.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Old password is incorrect" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedNewPassword = await bcrypt.hash(newPassword, salt);

    user.password = hashedNewPassword;
    await user.save();

    res.status(200).json({ message: "Password changed successfully", user });
  } catch (error) {
    // console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

const sendResetPasswordMail = async (firstName, email, token) => {
  try {
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587, 
      secure: false,
      requireTLS: true,
      auth: {
        user: "dikshaladke12@gmail.com",
        pass: "xczk fixe jynw iupg",
      },
    });

    const mailOptions = {
      from: config.emailUser,
      to: email,
      subject: "Password Reset Request",
      html: `<p>Hi ${firstName},</p>
             <p>Please click the following link to reset your password:</p>
             <p><a href="http://localhost:3001/reset-password?token=${token}">
             Reset Password</a></p>`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log("Error while sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });
  } catch (error) {
    console.error("Error in sending email:", error.message);
  }
};

export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const userdata = await UserAuth.findOne({ email: email });

    if (userdata) {
      const randomString = randomstring.generate();

      await UserAuth.updateOne(
        { email: email },
        { $set: { token: randomString } }
      );

      sendResetPasswordMail(userdata.firstName, userdata.email, randomString);
      console.log("token",randomString)
      res.status(200).json({
        status: 200,
        message: "Please check your email inbox and reset your password.",
        token:randomString
      });

    } else {
      return res.status(404).json({ message: "Email does not exist." });
    }
  } catch (error) {
    res
      .status(500)
      .json({ message: "An error occurred while processing your request." });
  }
};

export const resetPassword = async (req, res) => {
  try {
    const token = req.query.token;
    const tokenData = await UserAuth.findOne({ token: token });

    if (tokenData) {
      const password = req.body.password;
      const newPass = await bcrypt.hashSync(password, 10);
      const userData = await UserAuth.findByIdAndUpdate(
        { _id: tokenData._id },
        { $set: { password: newPass, token: "" } },
        { new: true }
      );
      res.status(200).send({ message: "user password has been reset", data: userData });

    } else {
      res.status(500).send({ message: "this link has been expired" });
    }
  } catch (error) {
    res.status(500).json({ message: "error while reset password" });
  }
};
