import adduser from "../model/AddUser";

export const AddUser = async (req, res) => {
    try {
        const newUser = await adduser(req.body);
        await newUser.save();
        res.status(200).json(newUser)
    }
    catch (error) {
        res.status(500).json({ message: "error while adding new users" });
    }
}

export const getUser = async (req, res) => {
    try {
        const filter = {
            $or: [
                {
                    firstName: { $regex: req.query.searchText || "", option: "i" }
                },
                {
                    lastName: { $regex: req.query.searchText || "", option: 'i' }
                }
            ]
        }
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query?.limit)
        const skip = (page - 1) * limit;

        const user = await adduser.find({ createdBy: req.params.id }).skip(skip).limit(limit);
        const total = await adduser.countDocuments();

        const response = {
            Users: user,
            pagination: {
                total_record: total,
                perPage: limit,
                currentPage: page,

            }
        }
        res.status(200).json(response);
    }
    catch (error) {
        res.json({ message: "error while doing pagination and searching" })
    }

}