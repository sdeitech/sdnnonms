import { Register } from "../Component/Register";
import { Login } from "../Component/Login";
import Publiclayout from "../layouts/Publiclayout";
// import { Forgotpassword } from "../Component/Forgotpassword";
import  Forgotpassword from '../Component/Forgotpassword'
import Resetpassword from "../Component/Resetpassword";
const Publicroute = [
    {
        path: '/',
        exact: true,
        element: <Publiclayout><Login /></Publiclayout>
    },
    {
        path: '/register',
        exact: true,
        element: <Publiclayout><Register /></Publiclayout>
    },
    {
        path: "/forgotPassword",
        exact: true,
        element: <Publiclayout><Forgotpassword /></Publiclayout>
    },
    {
        path: "/reset-password",
        exact: true,
        element: <Publiclayout><Resetpassword /></Publiclayout>
    }
]

export default Publicroute;