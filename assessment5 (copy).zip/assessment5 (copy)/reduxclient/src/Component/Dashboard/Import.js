import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import '../../styles/Register.css'

const Import = () => {
    const navigate= useNavigate()
    const [file, setFile] = useState(null)

    const handleFileChange = async (e) => {
        setFile(e.target.files[0]);
    }

    const formData = new FormData();
    formData.append("csv", file); // csv is the key

    const handleSubmit = async () => {
        try {
            const response = await axios.post("http://localhost:4444/uploadfile", formData, {
                headers: {
                    "Content-Type": "application/form-data"
                }
            })
            console.log(response, "response")
            console.log('file uploaded successfully')
            navigate('/maindashboard')

        } catch (error) {
            console.log("error while uploading csv file ")
        }
    }
    return (
        <div className='conatainer form-data'>
            <div className='container login-container' >
                <form onSubmit={handleSubmit} className='login-form'>
                    <div className='form-group'>
                        <lable>Add file</lable>
                        <br></br>
                        <input
                            className='form-control'
                            placeholder='enter csv file'
                            type="file"
                            accept='.csv'
                            onChange={handleFileChange}
                        />
                    </div>
                    <br></br>
                    <button type="submit">
                        Import File
                    </button>
                    <span onClick={()=>navigate('/maindashboard')}>back to dashBoards</span>
                </form>
            </div>
        </div>
    )
}

export default Import;