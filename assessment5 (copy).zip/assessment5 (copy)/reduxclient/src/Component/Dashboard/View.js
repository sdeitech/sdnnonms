import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const View = () => {
  const location = useLocation();
  const { user } = location.state || {};
  const navigate = useNavigate();

  return (
    <div>
      {user ? (
        <div className="container">
          <div class="card text-center">
            <div class="card-header">
              User details
              <button
                style={{ float: "right" }}
                onClick={() => navigate("/maindashboard")}
              >
                back to Dashboard
              </button>
            </div>
            <div class="card-body">
              <h5 class="card-title">
                {user.firstName} {user.lastName}
              </h5>
              <p class="card-text">{user.email}</p>
            </div>
          </div>
        </div>
      ) : (
        <p>no user available</p>
      )}
    </div>
  );
};

export default View;
