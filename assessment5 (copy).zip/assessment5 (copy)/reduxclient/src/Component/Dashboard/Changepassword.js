import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { ChangePassword } from '../../features/Authuser'

export const ChangePasswordOfUser = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    //   const { isLoading, error, errorMessage } = useSelector((state) => state.authUser);

    const [formData, setFromData] = useState({
        email: "",
        oldPassword: "",
        newPassword: "",
    });

    const [formErrors, setFormErrors] = useState({});

    const validateForm = () => {
        const errors = {};
        if (!formData.email) {
            errors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            errors.email = "Email is invalid";
        }

        if (!formData.oldPassword) {
            errors.oldPassword = "Old password is required";
        }

        if (!formData.newPassword) {
            errors.newPassword = "New password is required";
        } else if (formData.newPassword.length < 5) {
            errors.newPassword = "New password must be at least 6 characters long";
        }

        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handlesubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        dispatch(ChangePassword(formData));
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFromData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    return (
        <div className="container form-data">
            <div className="container login-container">
                <form className="login-form" onSubmit={handlesubmit}>
                    <h3> Change Password</h3>

                    <div className="form-group">
                        <input
                            className="form-control"
                            type="email"
                            name="email"
                            placeholder="EMAIL"
                            onChange={handleChange}
                            value={formData.email}
                        />
                        {formErrors.email && <p style={{ color: "red" }}>{formErrors.email}</p>}
                    </div>
                    <br />

                    <div className="form-group">
                        <input
                            className="form-control"
                            type="password"
                            name="oldPassword"
                            placeholder="OLD PASSWORD"
                            onChange={handleChange}
                            value={formData.oldPassword}
                        />
                        {formErrors.oldPassword && <p style={{ color: "red" }}>{formErrors.oldPassword}</p>}
                    </div>
                    <br />

                    <div className="form-group">
                        <input
                            className="form-control"
                            type="password"
                            name="newPassword"
                            placeholder="NEW PASSWORD"
                            onChange={handleChange}
                            value={formData.newPassword}
                        />
                        {formErrors.newPassword && <p style={{ color: "red" }}>{formErrors.newPassword}</p>}
                    </div>
                    <br />

                    <div>
                        <button
                            type="submit"
                            className="btn btn-primary btn-block"
                        >
                            change password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
