import React from 'react'


const Pagination = ({
    postPerPage,
    totalposts,
    setCurrentpage,
    currentPage
}) => {

    const pageNumber = [];
    for (let i = 0; i <= Math.ceil(totalposts / postPerPage); i++) {
        pageNumber.push(i);
    }

    const Paginate = (number, e) => {
        e.target.value;
        setCurrentpage(number+1)

    }
    return (
        <nav>
            <ul className='pagination'>
                {pageNumber.map((number,index) => {
                    const page=index+1;
                    <li
                        key={number}
                        className={`page-item ${currentPage === number ? 'active' : ''}`}>
                        <a
                            onClick={(e) => Paginate(page, e)}
                            href="#"
                            className='page-link'
                        >
                            {number}
                        </a>

                    </li>
                })}
            </ul>
        </nav>
    )
}
export default Pagination;