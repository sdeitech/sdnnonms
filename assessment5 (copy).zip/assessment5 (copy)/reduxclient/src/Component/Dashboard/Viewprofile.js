import React from 'react'
import { useNavigate } from 'react-router';

export const Viewprofile = () => {
    const userData = localStorage.getItem("userData");
    const newUserData = JSON.parse(userData);
    // console.log(newUserData.profile, "newuser")

    const navigate = useNavigate()

    return (
        <div className='container' style={{ backgroundColor: 'skyblue' }}>
            <h3>My Profile</h3>
            <div className='container'>
                <img
                    src={`http://localhost:4444/${newUserData.profile}`}
                    alt={"profile"}
                    style={{ width: "20%", height: "20%" }}
                />
                <div><strong>First Name: </strong> {newUserData.firstName}</div>
                <div><strong>Last Name: </strong> {newUserData.lastName}</div>
                <div><strong>Email: </strong>{newUserData.email}</div>
                <div><strong>isMarried: </strong>{newUserData.isMarried}</div>
                <div><strong>Gender: </strong>{newUserData.gender}</div>
                <div><strong>DOB: </strong> {newUserData.DOB.split('T')[0]}</div>
            </div>
            <span onClick={(e) => navigate('/maindashboard')}><b>back to dashboard</b></span>

        </div >
    )
}
