import axios from 'axios';
import React, { useState } from 'react'
import { LoginAuthUser } from '../features/Authuser';

const Forgotpassword = () => {
  const [formData, setFromData] = useState({
    email: ''
  })
  // console.log(formData);
  const [formErrors, setFormErrors] = useState({});

  const validateForm = () => {
    const errors = {};
    if (!formData.email) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid";
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFromData({ ...formData, [name]: value })
  }

  const handlesubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await axios.post("http://localhost:4444/forgotPassword", formData,{
        headers:{
          "Content-Type":"application/json"
        }
      });
      console.log("reset link send successfully")  
      alert("Reset Link sent!! please check email")
      const token=localStorage.setItem("newtoken",data?.data?.token);
      
    } catch (error) {
      console.log("email not matched",error)

    }
  }
  return (
    <div className='conatainer form-data'>
      <div className='container login-container'>
        <form className='login-form'>
          <h3 > Forgot Password</h3>
          <div className='form-group'>
            <input
              className='form-control'
              type="email"
              name="email"
              placeholder='enter the register email'
              onChange={handleChange}
              value={formData.email}
            />
            {formErrors.email && <p style={{ color: "red" }}>{formErrors.email}</p>}
          </div>
          <br></br>
          <div>
            <button
              type="submit"
              className="btn btn-primary btn-block"
              onClick={handlesubmit}
            >
              send Reset Link
            </button>
          </div>
          <br></br>
        </form>
      </div>
    </div>
  )
}

export default Forgotpassword;