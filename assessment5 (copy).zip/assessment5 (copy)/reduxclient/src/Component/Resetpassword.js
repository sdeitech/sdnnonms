import React, { useState } from 'react'
import '../styles/Register.css'
import axios from 'axios'
import { parse } from 'papaparse'

const Resetpassword = () => {
    const [formData,setFormData]=useState({
        password:''
    })

    const token = localStorage.getItem("newtoken");
    const handleChange=(e)=>
    {
        const {name,value}=e.target;
        setFormData({...formData,[name]:value})
    }
    const handlesubmit=async(e)=>
    {
        e.preventDefault();
        try {
            axios.post(`http://localhost:4444/reset-password?token=${token}`,formData)
            console.log("password reset ")
            alert("password reset")
            
        } catch (error) {
            console.log("error while reseting password")
        }
    }

    return (
        <div className='conatainer form-data'>
            <div className='container login-container'>
                <form className='login-form'>
                    <h3 > Reset Password</h3>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="password"
                            name="password"
                            placeholder='enter the new password'
                            onChange={handleChange}
                            value={formData.password}
                        />
    
                    </div>
                    <br></br>
                    <div>
                        <button
                            type="submit"
                            className="btn btn-primary btn-block"
                            onClick={handlesubmit}
                        >
                            Reset Password
                        </button>
                    </div>
                    <br></br>
                </form>
            </div>
        </div>
    )
}

export default Resetpassword