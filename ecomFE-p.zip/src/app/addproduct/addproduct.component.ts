// add-product.component.ts
import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css'],
})
export class AddProductComponent {
  pageTitle: string = 'Add New Product';
  name: string = '';
  desc: string = '';
  price: number = 0;
  image: File | null = null;

  constructor(private productService: ProductService, private router: Router) {}

  onImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.image = input.files[0];
    }
  }

  onSubmit(): void {
    if (!this.name || !this.desc || !this.price) {
      Swal.fire({
        title: 'Missing Fields',
        text: 'Please fill in all required fields.',
        icon: 'error',
        confirmButtonText: 'Try Again'
      });
      return;
    }

    this.productService.addProduct(this.name, this.desc, this.price, this.image).subscribe(
      (response) => {
        Swal.fire({
          title: 'Product Added Successfully!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Go to Product List'
        }).then(() => {
          this.router.navigate(['/products']); // Redirect to products list or wherever necessary
        });
      },
      (error) => {
        Swal.fire({
          title: 'Error Adding Product',
          text: error.error?.message || 'An error occurred. Please try again.',
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }
}
