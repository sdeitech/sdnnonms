import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  pageTitle: string = 'Welcome to Our Website!';
  heroImage: string =
    'https://colorlib.com/wp/wp-content/uploads/sites/2/coloshop-free-bootstrap-ecommerce-website-template.jpg';
  isAdmin: boolean = false;

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit(): void {
    // Fetch user details from the server
    this.authService.getUserDetailsFromServer().subscribe({
      next: (user: any) => {
        this.isAdmin = user.is_admin; // Update isAdmin based on backend data
        console.log('Admin status:', this.isAdmin); // Debugging
      },
      error: (err) => {
        console.error('Error fetching user details:', err);
      },
    });
  }

  onAddProduct(): void {
    this.router.navigate(['/addproduct']);
  }

  onAddCoupon(): void {
    // Redirect to Add Coupon page
    this.router.navigate(['/addcoupon']);
  }
}
