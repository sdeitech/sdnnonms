import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lo-gin',
  templateUrl: './lo-gin.component.html',
  styleUrls: ['./lo-gin.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    this.authService.login(this.email, this.password).subscribe(
      (response) => {
        Swal.fire({
          title: 'Login Successful!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Proceed'
        }).then(() => {
          // Token is already saved in localStorage by AuthService
          this.router.navigate(['/home']); // Redirect to home page
        });
      },
      (error) => {
        Swal.fire({
          title: 'Login Failed',
          text: error.error.error || 'Invalid credentials',
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }
}
