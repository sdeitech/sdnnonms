// product.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private baseUrl = 'http://127.0.0.1:8000/api'; // Replace with your Django API URL

  constructor(private http: HttpClient) {}

  // Method to send POST request to add a product
  addProduct(
    name: string,
    desc: string,
    price: number,
    image: File | null // Image is optional
  ): Observable<any> {
    const formData = new FormData();
    formData.append('name', name);
    formData.append('desc', desc);
    formData.append('price', price.toString());

    if (image) {
      formData.append('image', image); // Append image if provided
    }

    return this.http.post(`${this.baseUrl}/products/`, formData); // Assuming your API has a POST route at '/add/'
  }
}
