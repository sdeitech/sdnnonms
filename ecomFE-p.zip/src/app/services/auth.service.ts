import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  loginStatusChanged = new Subject<void>(); // Emits events when login/logout occurs

  private baseUrl = 'http://127.0.0.1:8000/api'; // Replace with your Django API URL

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: Object) {}

  signup(
    first_name: string,
    last_name: string,
    address: string,
    postal_code: number,
    contact_number: number,
    email: string,
    username: string,
    password: string,
    is_admin: boolean,
    is_user: boolean
  ): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/`, {
      first_name,
      last_name,
      address,
      postal_code,
      contact_number,
      email,
      username,
      password,
      is_admin,
      is_user
    });
  }
  
  login(email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/login/`, { email, password }).pipe(
      tap((response: any) => {
        localStorage.setItem('token', response.token); // Save token in localStorage
        localStorage.setItem('email', email); // Store email in localStorage
        this.loginStatusChanged.next(); // Notify login state change
      })
    );
  }
  

  logout(): void {
    localStorage.removeItem('token'); // Remove the token from localStorage
    this.loginStatusChanged.next(); // Notify login state change
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('token'); // Check if token exists in localStorage
  }

  getUserDetailsFromServer(): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('No token found. Please login.');
    }
  
    const headers = { Authorization: `Token ${token}` }; // Use `Bearer` if using JWT instead of Token
    return this.http.get(`${this.baseUrl}/getsuser/`, { headers });
  }
  


 // This is just an example; implement proper authentication and role management.
 isAdmin(): boolean {
  // Fetch user data from localStorage or API
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  console.log('User object:', user); // Debugging to confirm user object
  return user?.is_admin === true; // Return true if is_admin is true
}

}

