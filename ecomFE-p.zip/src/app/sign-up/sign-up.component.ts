import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignupComponent {
  first_name: string = '';
  last_name: string = '';
  address: string = '';
  email: string = '';
  postal_code: number = 123456;
  password: string = '';
  confirm_password: string = '';
  contact_number: number = 0;
  username: string = '';
  is_admin: boolean = false; // Checkbox for admin
  is_user: boolean = true;  // Default to regular user

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    if (this.password !== this.confirm_password) {
      Swal.fire({
        title: 'Password Mismatch',
        text: 'Your passwords do not match.',
        icon: 'error',
        confirmButtonText: 'Try Again'
      });
      return;
    }
  
    this.authService.signup(
      this.first_name,
      this.last_name,
      this.address,
      this.postal_code,
      this.contact_number,
      this.email,
      this.username,
      this.password,
      this.is_admin, // Pass is_admin
      this.is_user   // Pass is_user
    ).subscribe(
      (response) => {
        Swal.fire({
          title: 'Registration Successful!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Proceed to Login'
        }).then(() => {
          this.router.navigate(['/login']); // Redirect to login page
        });
      },
      (error) => {
        Swal.fire({
          title: 'Registration Failed',
          text: error.error.error,
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }
}  