import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  discountPrice: number = 0;
  discountPercentage: number = 0;
  couponcode: string = '';
  couponMessage: string = '';
  availableCoupons: any[] = [];

  constructor(private cartService: CartService, private router: Router) {}

  ngOnInit(): void {
    this.cartService.cart$.subscribe((cart: any[]) => {
      this.cart = cart;
      this.calculateTotal();
    });

    this.cartService.getAvailableCoupons().subscribe(
      (coupons) => {
        this.availableCoupons = coupons;
      },
      (error) => {
        console.error('Error fetching available coupons:', error);
      }
    );
  }

  removeFromCart(product: any): void {
    this.cartService.removeFromCart(product.id);
    this.calculateTotal();
  }

  clearCart(): void {
    this.cartService.clearCart();
    this.calculateTotal();
  }

  increaseQuantity(product: any): void {
    product.quantity += 1;
    this.cartService.updateCart(this.cart);
    this.calculateTotal();
  }

  decreaseQuantity(product: any): void {
    if (product.quantity > 1) {
      product.quantity -= 1;
      this.cartService.updateCart(this.cart);
    } else {
      this.removeFromCart(product);
    }
    this.calculateTotal();
  }

  checkout(): void {
    this.router.navigate(['/orders']);
  }

  redeemCoupon(): void {
    if (!this.couponcode) {
      Swal.fire('Error', 'Please enter a coupon code!', 'error');
      return;
    }

    const coupon = this.availableCoupons.find(coupon => coupon.coupon_code === this.couponcode);

    if (!coupon) {
      Swal.fire('Error', 'Coupon code does not exist or has already been redeemed.', 'error');
      return;
    }

    // Update the request body to match the backend expected structure
    this.cartService.redeemCoupon({ coupon_code: this.couponcode }).subscribe(
      (response: any) => {
        if (response.success) {
          this.discountPercentage = response.discount; // Update discount percentage
          this.couponMessage = 'Coupon redeemed successfully!';
          
          // SweetAlert with success message
          Swal.fire('Success', 'Coupon redeemed successfully!', 'success');
          
          this.calculateTotal(); // Recalculate the total with the discount
    
          // Remove the coupon from available list after it has been redeemed
          this.availableCoupons = this.availableCoupons.filter(
            (coupon) => coupon.coupon_code !== this.couponcode
          );
        } else {
          this.couponMessage = response.message || 'Invalid or expired coupon!';
        }
      },
      (error) => {
        Swal.fire('Error', 'Failed to redeem coupon. Please try again.', 'error');
      }
    );
  }

  applyCouponFromList(coupon: any): void {
    this.couponcode = coupon.coupon_code;
  }

  calculateTotal(): void {
    this.totalPrice = this.cart.reduce(
      (total, product) => total + product.price * product.quantity,
      0
    );

    this.discountPrice = this.totalPrice;

    if (this.discountPercentage > 0) {
      // Apply discount if percentage is valid
      this.discountPrice = this.totalPrice * (1 - this.discountPercentage / 100);
    }
  }
}
