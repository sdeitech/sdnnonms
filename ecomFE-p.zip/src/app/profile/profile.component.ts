import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'; // Import Swal for the alert

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user: any = null;
  error: string | null = null;
  isAdmin: boolean = false; // Flag to check if the user is admin
  username: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Check if user is authenticated
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/login']); // Redirect to login page if not authenticated
    } else {
      // Fetch user details on initialization if the user is authenticated
      this.authService.getUserDetailsFromServer().subscribe(
        (data) => {
          console.log('User details fetched:', data); // Debugging
          if (data && data.length > 0) {
            this.user = data[0]; // Extract the first object from the array
            // Check if the user is an admin or a regular user
            this.isAdmin = this.user.is_admin;
            this.username = this.isAdmin ? `Hello Admin, ${this.user.username}` : `Hello User, ${this.user.username}`;
          } else {
            this.error = 'No user details available.';
          }
        },
        (err) => {
          console.error('Error fetching user details:', err); // Debugging
          this.error = 'Failed to fetch user details. Please try again.';
        }
      );
    }
  }

  logout(): void {
    this.authService.logout(); // Log the user out
    Swal.fire({
      title: 'Logout Successful!',
      text: 'You have been logged out successfully.',
      icon: 'success',
      confirmButtonText: 'Proceed',
    }).then(() => {
      this.router.navigate(['/home']); // Redirect to home page after logout
    });
  }
}
