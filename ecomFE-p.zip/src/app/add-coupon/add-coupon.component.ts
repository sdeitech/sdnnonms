import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { CouponService } from '../services/coupon.service';

@Component({
  selector: 'app-add-coupon',
  templateUrl: './add-coupon.component.html',
  styleUrls: ['./add-coupon.component.css']
})
export class AddCouponComponent implements OnInit {
  coupon_name: string = '';
  coupon_code: string = '';
  percentage: number = 0;
  expiryDate: string = '';
  nonExpiredCoupons: any[] = [];

  constructor(private couponService: CouponService, private router: Router) {}

  ngOnInit() {
    this.loadNonExpiredCoupons();
  }

  onSubmit() {
    if (!this.coupon_name || !this.coupon_code || !this.percentage || !this.expiryDate) {
      Swal.fire({
        title: 'Missing Fields',
        text: 'Please fill in all required fields.',
        icon: 'error',
        confirmButtonText: 'Try Again'
      });
      return;
    }

    const couponData = {
      coupon_name: this.coupon_name,
      coupon_code: this.coupon_code,
      percentage: this.percentage,
      expiry_date: this.expiryDate
    };

    this.couponService.addCoupon(couponData).subscribe(
      (response) => {
        Swal.fire({
          title: 'Coupon Added Successfully!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Okay'
        });
        this.loadNonExpiredCoupons(); // Refresh the list of coupons
        this.resetForm();
      },
      (error) => {
        Swal.fire({
          title: 'Error Adding Coupon',
          text: error.error?.message || 'An error occurred. Please try again.',
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }

  deleteCoupon(couponId: number) {
    this.couponService.deleteCoupon(couponId).subscribe(
      (response) => {
        Swal.fire({
          title: 'Coupon Deleted Successfully!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Okay'
        });
        this.loadNonExpiredCoupons(); // Refresh the list
      },
      (error) => {
        Swal.fire({
          title: 'Error Deleting Coupon',
          text: error.error?.message || 'An error occurred. Please try again.',
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }

  loadNonExpiredCoupons() {
    this.couponService.getNonExpiredCoupons().subscribe(
      (data) => {
        this.nonExpiredCoupons = data;
      },
      (error) => {
        console.error('Error loading coupons:', error);
      }
    );
  }

  resetForm() {
    this.coupon_name = '';
    this.coupon_code = '';
    this.percentage = 0;
    this.expiryDate = '';
  }

  
}
