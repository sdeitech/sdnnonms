import express from "express";
import { registerUser, userLogin ,getAllUsers, getPeginatedData} from "../controllers/authController";
import { uploadMiddleware } from "../helpers/multer";
const userRouter = express.Router();

userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);
userRouter.post("/login", userLogin);
userRouter.get("/users", getAllUsers); // Add this line to fetch all users
userRouter.get("/pagination", getPeginatedData);

export default userRouter;
