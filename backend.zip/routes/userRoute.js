const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.get('/fetchusers', userController.getUsers);       
router.post('/createusers', userController.createUser);      

module.exports = router;
