export const config = {
  local: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "AUTH",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 3002,
  },
  stagg: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "AUTH",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 3002,
  },
  prod: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "AUTH",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 3002,
  },
};
