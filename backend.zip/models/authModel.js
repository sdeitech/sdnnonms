import mongoose from "mongoose";
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },
  maritialstatus: {
    type: Boolean,
  },
  gender: {
    type: String,
    enum: ["male", "female"],
  },
  profile: {
    type: String,
  },
  password: {
    type: String,
  },

  
});

const Users = mongoose.model("AuthUser", UserSchema);
export default Users;
