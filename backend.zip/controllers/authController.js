import Users from "../models/authModel.js";
import { STATUS_CODE, MESSAGE } from "../config/constants.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const registerUser = async (req, res) => {
  try {
    const { firstname, lastname, email, gender, maritialstatus,  password } = req.body;
    const profile = req.file?.filename;
    if (!firstname || !lastname || !email ||!gender || !maritialstatus || !profile || !password) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ message: MESSAGE.ALL_FILEDS_REQ });
    }

    const pass = await bcrypt.hash(password, 10);
    const user = new Users({
      firstname,
      lastname,
      email,
      gender,
      maritialstatus,
      profile: profile,
      password: pass,
    });

    console.log(req.body, "=======", req.file, "=========")

    await user.save();
    res.status(STATUS_CODE.NEW_CREATED).json({ msg: MESSAGE.USER_REGISTER });
  } catch (error) {
    res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ msg: error.message });
  }
};



export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ message: MESSAGE.ALL_FILEDS_REQ });
    }
    const existUser = await Users.findOne({ email: email });
    // console.log(existUser);

    if (!existUser) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ msg: MESSAGE.USER_NOT_FOUND });
    }

    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "com[are");

    if (isMatch) {
      const token = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
      return res
        .status(STATUS_CODE.SUCCESS)
        .json({ msg: MESSAGE.LOGIN, token: token , id: _id});
    } else {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ msg: MESSAGE.INVALID_CREDENTIALS });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.INTERNAL_SERVER_ERR)
      .json({ msg: error.message });
  }
};

export const getAllUsers = async (req, res) => {
  try {
    const users = await Users.find(); // Fetch all users
    res.status(STATUS_CODE.SUCCESS).json(users); // Send users as a response
  } catch (error) {
    console.error(error);
    res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ msg: error.message });
  }
};


export const getPeginatedData = async (req, res) => {
  console.log("getting peginated data")
  try {
    const { search = "", page = 1, limit = 4 } = req.query
    const pageNo = Number(page)
    const pageLimit = Number(limit)

    const skip = (pageNo - 1) * pageLimit

    const query = { firstname: { $regex: search, $options: "i" } }

    const user = await Users.find(query).skip(skip).limit(pageLimit)

    if (!user) {
      return res.status(404).json({
        msg: "UnSuccessfull"
      })
    }

    const totalRecord = await Users.countDocuments()
    const totalPages = Math.ceil(totalRecord / pageLimit)
    console.log(pageNo, "hgfjh")


    res.status(200).json({ user, totalRecord, totalPages, pageNo })

  } catch (error) {
    console.log("error for pegination")
    res.status(500).json({ msg: error.message })
  }
}