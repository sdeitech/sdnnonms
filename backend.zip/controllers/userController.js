const User = require('../models/userModel');
const { MESSAGE, STATUS_CODE } = require('../config/constants'); 
// Get all users
exports.getUsers = async (req, res) => {
    const { page = 1, limit = 2 } = req.query; 
    try {
      const users = await User.find()
        .limit(parseInt(limit)) 
        .skip((page - 1) * limit)
        .exec();
  
      const count = await User.countDocuments();
  
      res.json({
        users,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
      });
    } catch (err) {
      res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: err.message });
    }
};

// Create a new user
exports.createUser = async (req, res) => {
  const { firstname, lastname, email } = req.body;
  if (!firstname || !lastname || !email) {
    return res.status(STATUS_CODE.BAD_REQ).json({ message: MESSAGE.ALL_FILEDS_REQ });
  }

  const user = new User({
    firstname,
    lastname,
    email
  });

  try {
    const newUser = await user.save();
    res.status(STATUS_CODE.NEW_CREATED).json(newUser);
  } catch (err) {
    res.status(STATUS_CODE.BAD_REQ).json({ message: err.message });
  }
};

exports.getUsersbyid = async (req, res) => {
  const { page = 1, limit = 2 } = req.query; 
  try {
    const users = await User.find()
      .limit(parseInt(limit)) 
      .skip((page - 1) * limit)
      .exec();

    const count = await User.countDocuments();

    res.json({
      users,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
    });
  } catch (err) {
    res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: err.message });
  }
};
