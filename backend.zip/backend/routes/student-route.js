import express from "express";
const router = express.Router();
const studentController = require('../controller/student-Controller')

router.post('/add-student', studentController.createStudent)
router.get('/get-student', studentController.getStudents)
router.get('/get-student/:id', studentController.getStudentById)

module.exports = router;


