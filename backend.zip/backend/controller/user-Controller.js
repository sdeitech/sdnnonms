const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const User = require('../model/user-Model');

const registerUser = async (req, res) => {
    try {
        const { firstName, lastName, email, password, dob, maritalStatus, gender,} = req.body;
        let hashed = await bcrypt.hash(password, 10)

        const user = new User({
            firstName : firstName,
            lastName : lastName,
            email : email,
            password : hashed,
            dob : dob,
            maritalStatus : maritalStatus,
            gender : gender
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

const loginUser = async (req, res) => {

    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email })

        if (!user) {
            return res.status(400).json({ message: "User not found" })
        }

        const isMatch = await bcrypt.compare(password, user.password)

        if (isMatch) {
            const token = jwt.sign({ email, password , userId: user._id}, "an123idjk", { "expiresIn": "2h" })
            console.log('token-----', token)

            return res.status(201).json({ message: "Logged In", "token": token })
        } else {
            return res.status(401).json({ message: "Invalid Credentials" })

        }
    } catch (error) {
        res.status(401).json({ Error: error.message })
    }
}

const getUser = async (req, res) => {
    try {
        const { searchText } = req.query;

        let filter = {};

        if (searchText) {
            filter = {
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        const users = await User.find(filter)
            .select('firstName lastName email password maritalStatus dob gender')
            .skip(skip)
            .limit(limit);
        const totalCount = await User.countDocuments(filter);

        const response = {
            users: users,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getUserById = async (req, res) => {
    try {
        const { id } = req.params
        const user = await User.findById(id)
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}



module.exports = { registerUser, loginUser, getUser, getUserById}