const jwt = require('jsonwebtoken')

const verifToken = (req, res, next) => {
    try {
        const token = req.header("Authorization")
        const verified = jwt.verify(token, "an123idjk")
        console.log(verified)

        if (!verified) {
            return res.status(404).json({ "message": "Access Denied" })
        }
        next()
    } catch (error) {
        res.status(401).json({ "error": error.message })
    }
}

module.exports = { verifToken }


// const jwt = require('jsonwebtoken')
// const { messages } = require('../config/constants')

// const verifToken = (req, res, next) => {
//     try {
//         const token = req.header("Authorization")
//         const verified = jwt.verify(token, "an123idjk",(err, decode) => {
//             if(err) return res.status(401).json({messages : 'Invalid Token'})

//                 req.userId = decode.userId;
//                 next()
//         })
//         console.log(verified)

//         if (!verified) {
//             return res.status(404).json({ "message": "Access Denied" })
//         }
//         next()
//     } catch (error) {
//         res.status(401).json({ "error": error.message })
//     }
// }

// module.exports = { verifToken }