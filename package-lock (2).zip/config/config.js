export const config = {
    local: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT:3217,
    },
    stagg: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3217,
    },
    prod: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3217,
    },
  };
  