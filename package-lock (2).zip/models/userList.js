import mongoose from "mongoose";
const Schema = mongoose.Schema;

//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },

  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
});

const Userlist = mongoose.model("userlist", UserSchema);
export default Userlist;
