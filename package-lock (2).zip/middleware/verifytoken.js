import jwt from 'jsonwebtoken'

exports.verifyToken = (req, res, next) => {
    const token = req.headers["authorization"]?.split(" ")[1];
  console.log(token , "chjvznj")
    if (!token) {
        return res.status(403).json({ message: "USER IS NOT AUTHORIZED" })
    }
  
    try {
        const verifiedToken = jwt.verify(token, "KEY")
        console.log(verifiedToken , "verifyToken ")
        if (verifiedToken) {
            next()
  
            // return res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.AUTHORIZED })
        }
    } catch (error) {
        console.log(error.message)
        res.status(500).json({ message: "INTERNAL SERVER ERROR"})
  
    }
  }