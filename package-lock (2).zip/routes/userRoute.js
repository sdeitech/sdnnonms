import express from "express";
import {
  importCsv,
  forgetPassword,
  changePassword,
  getRegisterUserById,
  registerUser,
  userLogin,
  getUsers,
  getdatabyemail,
  addUserInList,
  getUserInList,
  updateUserInList,
  updateUser,
  googleAuth,
  importData,
} from "../controllers/userController";
//  import {addUserInList,getUserInList,updateUserInList,updateUser} from "../controllers/usercontrollerforlist";
import { uploadMiddleware } from "../helper/multer";
import { verifyToken } from "../middleware/verifytoken";
const userRouter = express.Router();

//signup api call
userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);

//login api call
userRouter.post("/login", userLogin);

userRouter.get("/getdata", verifyToken, getUsers);

userRouter.post("/postdata/:id", addUserInList);

userRouter.get("/getdataInList/:id", verifyToken, getUserInList);

userRouter.put("/updateUserInList/:id", updateUserInList);
userRouter.put(
  "/updateUser/:id",
  uploadMiddleware.single("profile"),
  updateUser
);
// userRouter.put("/updateUserInList",updateUserInList)

userRouter.get("/getdatausingemail/:email", verifyToken, getdatabyemail);
userRouter.get("/getRegisterUserById", verifyToken, getRegisterUserById);

userRouter.post("/googlelogin", googleAuth);

userRouter.post("/createUser/v1", verifyToken);

userRouter.put("/changepass/:id", changePassword);

userRouter.put("/forgotpass/password", forgetPassword);
// userRouter.put("/forget/password", forgetPassword)

userRouter.post("/uploadcsv/:id", importData);

export default userRouter;
