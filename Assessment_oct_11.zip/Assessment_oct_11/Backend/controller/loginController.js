import jwt from 'jsonwebtoken';
import { OAuth2Client } from 'google-auth-library';

import User from '../../models/user.js';

const CLIENT_ID = "1027531810358-u8hiqbickkf84q88ndcj3q3d06t829pm.apps.googleusercontent.com ";
const client = new OAuth2Client(CLIENT_ID);

export const loginWithGoogle = async (req, res) => {
    const { token } = req.body;
    try {
        // Verify the ID token
        const ticket = await client.verifyIdToken({
            idToken: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFqaW5reWFAZ21haWwuY29tIiwiaWF0IjoxNzI4MTE5NDIwLCJleHAiOjE3MjgxMjMwMjB9.llKIM6Tz4cVEHtvwnqVR4h89nd7hn2a2zSAxktlgxg4,  // Token from frontend
            audience: CLIENT_ID,  // Should match CLIENT_ID
        });

        const payload = ticket.getPayload();

        // Extract user details from the token payload
        const googleId = payload['sub']; // Google user ID
        const email_id = payload['email']; // User email from Google

        // Check if email_id is defined
        if (!email_id) {
            throw new Error('Email ID is missing from the token payload');
        }

        const username = email_id.split('@')[0]; // Assign default username

        // Check if the user exists in the database
        let user = await User.findOne({ email_id });
        if (!user) {
            user = new User({
                email_id,
                googleId,
                username,
                role: 'user',
                password: googleId,
                tokens: [],
            });
            await user.save();
        }

        // Generate a JWT token
        const jwtToken = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '6h' });

        // Store the token in the user object
        user.tokens = [{ token: jwtToken }];
        await user.save();

        res.status(200).json({ message: "Login with Google Successful", user, token: jwtToken });
    } catch (error) {
        console.error('Error during Google login:', error);
        res.status(401).json({ message: 'Unauthorized', error: error.message });
    }
};

