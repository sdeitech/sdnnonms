import mongoose from 'mongoose';

// Define Item Schema
const itemSchema = new mongoose.Schema({
  SrNo: { type: Number, required: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }  // Reference to the User model
});

// Create Item Model
const Item = mongoose.model('Item', itemSchema);

module.exports = Item;