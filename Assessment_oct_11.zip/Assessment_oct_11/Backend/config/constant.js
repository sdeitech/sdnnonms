require('dotenv/config');


export const messageID = {
"test":"newmessage"
}
export const messages = {
    imageType:"jpeg"

} 