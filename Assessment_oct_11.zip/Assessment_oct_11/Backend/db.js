import mongoose from 'mongoose';
import UserModel from './model/user.model'
import ItemModel from './model/item.model'

mongoose.connect('mongodb://localhost:27017/UserDetails',{
 useNewUrlParser: true,
 useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB'))
 .catch(err => console.error('Could not connect to MongoDB', err));