const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  host: "smtp.gmail.com",
  secure: false,
  port : 587,
  auth: {
    user: 'ajinkyabhise100@gmail.com',
    pass: 'xkjgvlcbtkdxpaey'
  }
});


const sendRegistrationEmail = (Email) =>{
  return new Promise(async(resolve, reject)=>{
    try{
      console.log(Email, 'Email');

      const mailOptions = {
        from: 'ajinkyabhise100@gmail.com',
        to: Email,
        subject: 'hello',
        text: 'hello From my Side!'
      };

const result = await transporter.sendMail(mailOptions);
console.log("send Successfully",result);
resolve(result)
}catch(error){
  reject(error)
}
  })}
  module.exports = sendRegistrationEmail;