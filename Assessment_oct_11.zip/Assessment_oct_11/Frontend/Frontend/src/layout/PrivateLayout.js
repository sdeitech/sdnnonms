import React, { useEffect } from "react";
import { useNavigate } from "react-router";


const PrivateLayout = ({ children }) => {
    //   let token = useSelector(state=> state.userReducer.token);
    let token = localStorage.getItem('token');
    let navigate = useNavigate();
    useEffect(() => {
        if (!token) {
            navigate("/");
        }
    }, [token, navigate]);

    return (
        <div className="layout">
            <div className="content">
               
                {children}
            
            </div>
        </div>
    );
};

export default PrivateLayout;
