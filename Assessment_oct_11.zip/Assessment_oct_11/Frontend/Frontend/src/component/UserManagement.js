import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { CSVLink, CSVDownload } from "react-csv";
import Button from 'react-bootstrap/Button';


function App() {
  const [SrNo, setSrNo] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [item, setItem] = useState([]);
  const [viewItem, setViewItem] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const navigate = useNavigate();


  const fetchData = async () => {
    try {
      // Get the user details from localStorage
      const user = JSON.parse(localStorage.getItem("user"));

      if (user && user.id) {
        // Make the API call with the user ID in the request body
        const response = await axios.post(
          "http://localhost:5000/item/getItem",
          {
            userId: user.id, // Pass the user ID in the request body
          },
          {
            headers: {
              Authorization: localStorage.getItem("token"),
            },
          }
        );

        setItem(response.data); // Set the fetched items in your state
        console.log("Data fetched successfully:", response.data);
      } else {
        console.error("User ID not found in localStorage");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const filteredData = item.filter(
    (item) =>
      item.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredData.slice(indexOfFirstItem, indexOfLastItem);

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  const postData = async () => {
    try {
      // Get the user details from localStorage
      const user = JSON.parse(localStorage.getItem("user"));

      if (user && user.id) {
        // Make the API call and pass the user ID along with other item details
        const response = await axios.post(
          "http://localhost:5000/item/add",
          {
            SrNo,
            firstName,
            lastName,
            email,
            userId: user.id, // Pass the user ID in the request body
          },
          {
            headers: {
              Authorization: localStorage.getItem("token"),
            },
          }
        );

        setItem((prevItem) => [...prevItem, response.data]); // Update the item list
        resetForm(); // Reset the form
        console.log("Data posted successfully:", response.data);
      } else {
        console.error("User ID not found in localStorage");
        alert("User not logged in");
      }
    } catch (error) {
      console.error("Error posting data:", error);
      alert("Error posting data");
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
  };

  const clearViewItem = () => {
    setViewItem(null);
  };

  const viewItemDetails = (item) => {
    setViewItem(item);
  };

  const resetForm = () => {
    setSrNo("");
    setFirstName("");
    setLastName("");
    setEmail("");
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="container">
      <div className="d-flex justify-content-between">
        {/* Placeholder for left space, could be a logo or title */}
        <div></div>
       

        {/* Change Password link/button */}
        <div>
          <button
            className="btn btn-link"
            style={{
              position: "absolute",
              right: "20px",
              top: "20px",
              textDecoration: "none",
              color: "#007bff",
              fontWeight: "bold",
            }}
            onClick={() => navigate("/chnage-password")} // Use navigate here
          >
            Change Password
          </button>
        </div>
      </div>
      <h2> DashBoard </h2>
      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div style={{ textAlign: "right" }}>
        <button
          className="btn btn-secondary"
          onClick={() => navigate("/Profile")}
          style={{}}
        >
          My Profile
        </button>
      </div>
      <br />
      {/* <div style={{textAlign : 'right'}}>
            <button className="btn btn-secondary" onClick={() => navigate('/signUp')}>
                logOut
            </button>
            </div> */}
      <div style={{ textAlign: "right" }}>
        <button className="btn btn-secondary" onClick={handleLogout}>
          logOut
        </button>
      </div>

      {/* <div style={{textAlign: 'right'}}>
                    <a href="#" onClick={this.logout()}><button className="btn btn-secondary">Logout</button></a>
            </div> */}
             {/* <div style={{ textAlign: "right" }}>
            <CsvImportExport />
        </div> */}
       <button>
        <CSVLink data={currentItems}>ExportData</CSVLink><br/></button>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>SrNo</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {item.length > 0 ? (
            currentItems.map((item) => (
              <tr key={item._id}>
                <td>{item.SrNo}</td>
                <td>{item.firstName}</td>
                <td>{item.lastName}</td>
                <td>{item.email}</td>
                <td>
                  <button
                    type="submit"
                    className="btn btn-warning"
                    onClick={() => viewItemDetails(item)}
                  >
                    View
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5">Loading...</td>
            </tr>
          )}
        </tbody>
      </table>

      <h3>Add User</h3>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          postData();
        }}
      >
        <button type="submit" className="btn btn-primary">
          Add{" "}
        </button>
        <br />
        <br />
        <div>
          <label>SrNo</label>
          <input
            type="text"
            className="form-control"
            value={SrNo}
            placeholder="SrNo"
            onChange={(e) => setSrNo(e.target.value)}
          />
          <br />

          <label>FirstName</label>
          <input
            type="text"
            className="form-control"
            value={firstName}
            placeholder="Enter first Name"
            onChange={(e) => setFirstName(e.target.value)}
          />
          <br />

          <label>LastName</label>
          <input
            type="text"
            className="form-control"
            value={lastName}
            placeholder="Enter Last name"
            onChange={(e) => setLastName(e.target.value)}
          />
          <br />

          <label>Email</label>
          <input
            type="text"
            className="form-control"
            value={email}
            placeholder="Enter your Email"
            onChange={(e) => setEmail(e.target.value)}
          />
          <br />
        </div>
      </form>
      {viewItem && (
        <div>
          <h2>User Details</h2>
          <p>SrNo: {viewItem.SrNo}</p>
          <p>First Name: {viewItem.firstName}</p>
          <p>Last Name: {viewItem.lastName}</p>
          <p>Email: {viewItem.email}</p>

          <button onClick={clearViewItem}>Close</button>
        </div>
      )}
      <div style={{ marginTop: "10px" }}>
        {Array.from({ length: totalPages }, (_, index) => (
          <button
            key={index + 1}
            className={`btn ${
              currentPage === index + 1
                ? "btn-secondary"
                : "btn-outline-primary"
            }`}
            onClick={() => setCurrentPage(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

export default App;
