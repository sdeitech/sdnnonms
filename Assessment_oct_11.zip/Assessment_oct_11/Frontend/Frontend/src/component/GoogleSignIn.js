import React from 'react';
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';
import {jwtDecode} from "jwt-decode";


const GoogleSignIn = ()=>{

    const handleSucess =(credentialResponse)=>{
        console.log("Google Sign In Sucess",credentialResponse);
        const decode = jwtDecode(credentialResponse?.credential)
        console.log(decode);
    }
    const handleError=()=>{
         console.log("Google Sign In Error");
    }
    return(
        <div>
        <GoogleOAuthProvider clientId='232045054338-0ktemp8l0dm7vg0fkg6rii6c7ketslor.apps.googleusercontent.com'>
            <GoogleLogin>
                onSucess = {handleSucess}
                onError = {handleError}

            </GoogleLogin>
        </GoogleOAuthProvider>
        </div>
    )
}

export default GoogleSignIn;
