import React, { useState } from 'react';
import { Form, Input, Button, message } from 'antd';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import Password from 'antd/es/input/Password';

const ResetPassword = () => {
  const navigate = useNavigate();
  const[formdata, setFormData]=useState({email:"", password:""});
  const[errorMessage, setErrorMessage]=useState("");
  const[IsForgotPassword, setIsForgotPassword] = useState("");
  const[forgotEmail, setForgotEmail] = useState("");
  const { email } = useParams(); 
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);


const handleForgotPassword= async()=>{
    try{
        const result = await axios.post('http://localhost:5000/user/forgot-password', {email: forgotEmail})
        if(result.data.success){
        alert("Temporary Password send to your mail");
        }else{
            setErrorMessage("Email not register");
        }
        setIsForgotPassword(false);
    }
catch(error)
{
    setErrorMessage("Error Sending temporary Password");
}  };


  return (
    

   
    <div className="container mt-5" style={{width: '800px',
        height: '400px',
        borderRadius: '10px', // Rounded corners
        border: '2px solid #ccc', margin: 'auto'}}>
             <p onClick={()=>setIsForgotPassword(true)}>Forgot Password</p>
            {IsForgotPassword  && (
        <Form layout="vertical">
        <h1>Reset Password</h1>
        <Form.Item label="Email" name="Email">
          <Input type="email"
          placeholder='Enter your email'
           value={forgotEmail} 
           onChange={(e)=>setIsForgotPassword(e.target.value)}
           />
          </Form.Item>
          <button onClick={handleForgotPassword}>send Temporary Password</button>
          <button onClick={()=> setIsForgotPassword(false)}>Cancel</button>
          </Form>
            )}
        {/* <Button type="primary" htmlType="submit" loading={loading}>
          Update Password
        </Button> */}
    </div>
  );
};

export default ResetPassword;