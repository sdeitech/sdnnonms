// import React from 'react'

// const Changepassword = () => {
//   return (
//     <div>
//       <h3>hello Changepassword</h3>
//     </div>
//   )
// }

// export default Changepassword

import React, { useState } from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Changepassword = () => {
    // Get email from localStorage
    const storedUser = JSON.parse(localStorage.getItem('user'));
    const email = storedUser ? storedUser.email : '';
    const navigate = useNavigate();

    // State for the form inputs
    const [formData, setFormData] = useState({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
    });

    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    // Handle form input change
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Combine form data with email from localStorage
            const requestData = { 
                ...formData, 
                email 
            };

            // Send request to update password
            const response = await axios.post('http://localhost:5000/user/chnage-password', requestData);

            // Handle success
            if (response.status === 200) {
                setMessage('Password updated successfully!');
                setError('');  // Clear error message
                setTimeout(() => {
                  navigate('/');  // Redirect to the home page or desired page
              }, 2000);
            }
        } catch (err) {
            // Handle errors
            if (err.response && err.response.data) {
                setError(err.response.data.message);
            } else {
                setError('An error occurred. Please try again.');
            }
            setMessage('');  // Clear success message
        }
    };

    return (
        <div className="container mt-5" style={{width: '600px'}}>
            <h3>Change Password</h3>
            {message && <p style={{ color: 'green' }}>{message}</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Current Password:</label>
                    <input
                        type="password"
                        name="currentPassword"
                        value={formData.currentPassword}
                        onChange={handleChange}
                        required
                        className="form-control"
                    />
                </div><br/>
                <div className="form-group">
                    <label>New Password:</label>
                    <input
                        type="password"
                        name="newPassword"
                        value={formData.newPassword}
                        onChange={handleChange}
                        required
                        className="form-control"
                    />
                </div><br/>
                <div className="form-group">
                    <label>Confirm Password:</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                        className="form-control"
                    />
                </div><br/>
                <Button type="submit" variant="primary">Change Password</Button>
            </form>
        </div>
    );
};

export default Changepassword;
