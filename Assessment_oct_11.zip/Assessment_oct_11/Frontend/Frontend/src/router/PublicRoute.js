import { React } from "react";
import Form from "../form/Form";
import PublicLayout from "../layout/PublicLayout";
import Signup from "../form/signUp";
import Profile from "../component/Profile";
import Changepassword from "../form/Changepassword";
import ResetPassword from "../component/forgetPassword";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><Form /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><div><Signup/></div></PublicLayout>
    },

    {
    	path: "/Profile",
    	exact: true,
    	element: <PublicLayout><div><Profile/></div></PublicLayout>
    },
    {
    	path: "/chnage-password",
    	exact: true,
    	element: <PublicLayout><div><Changepassword/></div></PublicLayout>
    },
    {
    	path: "/ResetPassword",
    	exact: true,
    	element: <PublicLayout><div><ResetPassword/></div></PublicLayout>
    },
];
export default publicRoutes;
