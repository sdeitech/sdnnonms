import React from "react";

const PublicLayout = ({ children }) => {
  return <div>{children}</div>;
};

export default PublicLayout;
