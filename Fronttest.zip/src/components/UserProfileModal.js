import React, { useState } from "react";
import './UserProfileModal.css'; 
import { updateUser} from "../api"; 
import {  useNavigate } from "react-router-dom";
import { useEffect } from "react";

const UserProfileModal = ({ userData, setUserData, show, onClose, onSaveProfile }) => {
  console.log(userData, "hujds=================")


  const navigate = useNavigate()


  const [isEditing, setIsEditing] = useState(false); 

  const [updatedData, setUpdatedData] = useState({
    firstname: userData?.firstname || "",
    lastname: userData?.lastname || "",
    email: userData?.email || "",
    gender: userData?.gender || "",
    maritialstatus: userData?.maritialstatus ,
    profile: userData?.profile || "",
  });
console.log(updatedData, "jskahkajd")
  const UpdateProfile = async (e) => {
    e.preventDefault()
    try {
      const userId = localStorage.getItem('id'); 
      if (!userId) {
        throw new Error("No user ID found, please log in again.");
      }
      // const response = await updateUser(userId , data); 
      const response = await updateUser(userId , updatedData); 

      console.log(response ,"responseresponse") 
      //setUserData(response)
      // userData(response);
    } catch (error) {
      console.error("Error fetching user data:", error.message);
      //setError("Failed to load user profile");
      navigate("/dashboard"); 
    }
  };

  useEffect(() => {
  if (userData) {
    setUpdatedData({
      firstname: userData?.firstname,
      lastname: userData?.lastname,
      email: userData?.email,
      gender: userData?.gender,
      maritialstatus: userData?.maritialstatus ,
      profile: userData?.profile 
    });
  }
    // UpdateProfile(); 
  }, [userData]);
console.log(userData?.maritialstatus, "===============hjjhkj"
)
  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === "file") {
      setUpdatedData({ ...updatedData, [name]: files[0] });
    }
    else if (type== "checked"){
      setUpdatedData({ ...updatedData, [name]: checked });

    }
    
    else if (type === "checkbox") {  
      setUpdatedData({ ...updatedData, [name]: checked });
    } else {
      setUpdatedData({ ...updatedData, [name]: value });
    }

    // setUpdtedData((prevData) => ({
    //   ...prevData,
    //   [name]: type === 'checkbox' ? checked : (value),
    // }));
  };

  const handleFileChange = (e) => {
    setUpdatedData((prevData) => ({
      ...prevData,
      profile: e.target.files[0],
    }));
  };

  const handleSubmit = () => {
    const formData = new FormData();
    formData.append("firstname", updatedData.firstname);
    formData.append("lastname", updatedData.lastname);
    formData.append("email", updatedData.email);
    formData.append("gender", updatedData.gender);
    formData.append("maritialstatus", updatedData.maritialstatus);
      formData.append("profile", updatedData.profile);
    
    UpdateProfile(formData);
    setIsEditing(false); 
  };

  if (!show) return null;

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>&times;</span>
        {isEditing ? (
          <form onSubmit={UpdateProfile}>
            <div>
            <h3>Edit Your Profile</h3>
            <div>
              <label>Profile Picture:</label>
              <input type="file" name="profile" onChange={handleFileChange} />
              {updatedData.profile && typeof updatedData.profile === 'string' && (
                <img
                  src={`http://localhost:3002/profiles/${updatedData.profile}`} 
                  alt="Profile"
                  className="profile-pic"
                />
              )}
            </div>
            <div>
              <label>First Name:</label>
              <input
                type="text"
                name="firstname"
                value={updatedData.firstname}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>Last Name:</label>
              <input
                type="text"
                name="lastname"
                value={updatedData.lastname}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>Email:</label>
              <input
                type="email"
                name="email"
                value={updatedData.email}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>Gender:</label>
              <select
                name="gender"
                value={updatedData.gender}
                onChange={handleChange}
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div>
              <label>Marital Status:</label>
              <input
                type="checkbox"
                name="maritialstatus"
                defaultChecked={updatedData.maritialstatus}
                // checked={updatedData.maritialstatus}

                onChange={handleChange}
              /> Married
            </div>

            {/* <button className="button" onClick={handleSubmit}>Save Profile</button> */}
            <button className="button" type="submit" >Save Profile</button>

            <button className="button" onClick={() => setIsEditing(false)}>Cancel</button>
          </div>
          </form>
        ) : (
          <div>
            <h3>Welcome, {userData.firstname}!</h3>
            {userData.profile && (
              <div>
                <p>Profile Picture:</p>
                <img
                  src={`http://localhost:3002/profiles/${userData.profile}`} 
                  alt="Profile"
                  className="profile-pic"
                />
              </div>
            )}
            <p>First Name: {userData.firstname}</p>
            <p>Last Name: {userData.lastname}</p>
            <p>Email: {userData.email}</p>
            <p>Gender: {userData.gender}</p>
            <p>Marital Status: {userData.maritialstatus ? "Married" : "Unmarried"}</p>
            <button className="button" onClick={() => setIsEditing(true)}  >Update Profile</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserProfileModal;