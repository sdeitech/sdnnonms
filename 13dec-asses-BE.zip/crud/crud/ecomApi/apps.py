from django.apps import AppConfig


class ecomApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ecomApi'
