from django.urls import path
from . import views

urlpatterns = [
    path('products/', views.get_products, name='getProduct'),  
    path('products/<int:pk>/', views.get_productById, name='getProductById'),  
    path('products/create/', views.create_product, name='creatrProduct'), 
    path('products/<int:pk>/update/', views.update_product, name='updateProduct'),  
    path('products/<int:pk>/delete/', views.delete_product, name='deleteProduct'),  
]
