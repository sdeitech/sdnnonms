from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import NotFound
from .models import CustomUser, Product
from .serializers import CouponSerializer, ProductSerializer,CustomUserSerializer
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

class ProductListCreate(APIView):
    def get(self, request):
        # List all products
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Create a new product
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProductRetrieveUpdateDelete(APIView):
    def get(self, request, pk):
        # Retrieve a single product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product)
        return Response(serializer.data)

    def put(self, request, pk):
        # Update a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        # Delete a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        product.delete()
        return Response({"detail": "Product deleted successfully."}, status=status.HTTP_204_NO_CONTENT)


from rest_framework.permissions import IsAuthenticated

class RegisterUserView(APIView):

    def get(self, request):
        user = request.user  # The user is fetched from the request, thanks to authentication
        serializer = CustomUserSerializer(user)
        return Response(serializer.data)


    def post(self, request):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User registered successfully!"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class CustomLoginView(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({"error": "Email and password are required."}, status=status.HTTP_400_BAD_REQUEST)

        # Authenticate user with email and password
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # Generate token for the user
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                "message": "Login successful.",
                "token": token.key  # Return the authentication token
            }, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.exceptions import NotAuthenticated

from .serializers import CustomUserSerializer

class GetUserView(APIView):
    authentication_classes = [TokenAuthentication]  # Ensure token-based authentication
    permission_classes = [IsAuthenticated]          # Restrict to authenticated users

    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            raise NotAuthenticated("User is not authenticated.")

        serializer = CustomUserSerializer(request.user)
        return Response(serializer.data)
    
from django.utils.timezone import now
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Coupon
from .serializers import CouponSerializer


class CouponListCreate(APIView):
    def get(self, request):
        # Fetch all non-expired coupons
        non_expired_coupons = Coupon.objects.filter(expiry_date__gte=now())
        serializer = CouponSerializer(non_expired_coupons, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        # Create a new coupon
        serializer = CouponSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg": "Coupon added successfully!"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CouponDelete(APIView):
    def delete(self, request, pk):
        try:
            coupon = Coupon.objects.get(pk=pk)
            coupon.delete()
            return Response({"msg": "Coupon deleted successfully!"}, status=status.HTTP_200_OK)
        except Coupon.DoesNotExist:
            return Response({"msg": "Coupon not found."}, status=status.HTTP_404_NOT_FOUND)

from django.utils.timezone import now
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Coupon


class RedeemCoupon(APIView):
    def post(self, request):
        coupon_code = request.data.get("coupon_code")
        
        try:
            # Check if the coupon exists and is not expired
            coupon = Coupon.objects.get(coupon_code=coupon_code, expiry_date__gte=now())
            
            # Simulate coupon redemption (e.g., apply discount logic here)
            discount_percentage = coupon.percentage
            
            # Delete the coupon after successful usage
            coupon.delete()

            return Response(
                {"msg": "Coupon redeemed successfully!", "discount": discount_percentage},
                status=status.HTTP_200_OK,
            )
        except Coupon.DoesNotExist:
            return Response(
                {"msg": "Invalid or expired coupon."},
                status=status.HTTP_400_BAD_REQUEST,
            )
