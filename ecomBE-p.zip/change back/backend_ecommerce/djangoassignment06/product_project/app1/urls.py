from django.urls import path

from product_project import settings
from .views import *
from django.conf.urls.static import static
urlpatterns = [
    path('products/', ProductListCreate.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductRetrieveUpdateDelete.as_view(), name='product-retrieve-update-delete'),
    path('register/', RegisterUserView.as_view(), name='register'),
     path('getuser/', RegisterUserView.as_view(), name='getuser'),
    path('login/', CustomLoginView.as_view(), name='custom-login'),
    path('getsuser/', GetUserView.as_view(), name='get_user'),
    path('coupons/', CouponListCreate.as_view(), name='coupon-list-create'),
    path('coupons/<int:pk>/', CouponDelete.as_view(), name='coupon-delete'),
     path('coupons/redeem/', RedeemCoupon.as_view(), name='coupon-redeem'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)