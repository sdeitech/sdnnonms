from rest_framework import serializers
from .models import Coupon, Product
from django.contrib.auth import get_user_model

class ProductSerializer(serializers.ModelSerializer):
    image = serializers.ImageField(use_url=True)  # Ensure the image URL is returned

    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'image', 'desc']


User = get_user_model()

from rest_framework import serializers
from .models import CustomUser

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'email', 'username', 'first_name', 'last_name', 'address',
            'postal_code', 'contact_number', 'profile', 'password',
            'is_admin', 'is_user'
        ]
        extra_kwargs = {
            'password': {'write_only': True},
        }

    def create(self, validated_data):
        profile = validated_data.pop('profile', None)  # Optional field
        is_admin = validated_data.pop('is_admin', False)
        is_user = validated_data.pop('is_user', False)

        # Automatically adjust is_admin and is_user fields
        if is_admin:
            is_user = False  # Ensure is_user is False when is_admin is True
        elif is_user:
            is_admin = False  # Ensure is_admin is False when is_user is True
        else:
            # Default case: If neither is selected, raise an error
            raise serializers.ValidationError(
                {"error": "A user must be either an admin or a regular user."}
            )

        # Create the user with validated data
        user = CustomUser.objects.create_user(**validated_data)

        # Assign the adjusted fields
        user.is_admin = is_admin
        user.is_user = is_user

        if profile:
            user.profile = profile

        user.save()
        return user


class CouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = Coupon
        fields = '__all__'