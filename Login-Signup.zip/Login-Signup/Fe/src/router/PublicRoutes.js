import { React } from "react";
import Form from "../material/form/Form";
import PublicLayout from "../layout/PublicLayout";
import Loginform from "../material/form/loginform";
import SignUp from "../material/form/SignUpForm";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><Loginform /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp></SignUp></PublicLayout>
    }
];
export default publicRoutes;
