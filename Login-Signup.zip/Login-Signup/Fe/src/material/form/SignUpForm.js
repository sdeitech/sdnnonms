import React, { useState } from "react";
import { TextField, Button, InputAdornment } from "@mui/material";
import { Link } from "react-router-dom";
import AccountCircle from '@mui/icons-material/AccountCircle';
import LockIcon from '@mui/icons-material/Lock';
import "./loginform.css"; // Import the CSS file
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function SignUp() {
    const navigate = useNavigate();

    const [state, setState] = useState({
        userNameError: "",
        passwordError: "",
    });


    const [formData, setFormData] = useState({
        userName: '',
        password: '',
    });

    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const userName = e.target.userName.value;
        const password = e.target.password.value;

        setState({
            ...state,
            userNameError: userName === "" ? "Please enter your userName" : "",
            passwordError: password === "" ? "Please enter your password" : "",
        });
        try {
            // Example of making a login request
            const response = await axios.post('http://localhost:5000/api/register', formData);
            // Handle successful login (e.g., store user info, redirect)
            navigate('/users');
            console.log('SignUp successful:');
        } catch (err) {
            setError('Login failed. Please check your credentials.');
        }
    };


    return (
        <React.Fragment>
            <form autoComplete="off" onSubmit={handleSubmit} className="form-container">
                <h1>SIGN UP</h1>
                <TextField
                    id="userName"
                    name="userName"
                    label="userName"
                    value={formData.userName}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <AccountCircle />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.userNameError}</span>

                <TextField
                    id="password"
                    name="password"
                    label="Password"
                    value={formData.password}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <LockIcon />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.passwordError}</span>

                <Button variant="outlined" color="secondary" type="submit">
                    Register

                </Button>
            </form>

            <small>
                Already have Account <Link to="/">Login here</Link>
            </small>
        </React.Fragment>
    );
}

export default SignUp;