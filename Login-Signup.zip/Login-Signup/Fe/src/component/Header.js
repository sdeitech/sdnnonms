import React from "react";

function Header() {
    return (
        <>
            <h2>Header</h2>
        </>
    );
}

export default Header;
