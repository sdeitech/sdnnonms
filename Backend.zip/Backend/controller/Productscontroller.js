const product = require('../models/Productsmodel');
exports.createProduct = async (req, res) => {
    console.log("user create user function is ready");
    try {
        console.log("function for creating product");
        
        const newProduct = new product(req.body)
        await newProduct.save();
        res.status(200).json(newProduct);
        console.log("product added successfully");
    } catch (error) {
        
        res.status(400).json({ error: error });
        console.log("user is wrong");

    }
};
    console.log("product added successfully");
    
exports.getProduct = async (req, res) => {
    try {
        const product01= await product.find();
        res.json(product01);
        console.log("your products in a database are:");
        
    } catch (error) {
        res.status(400).json({ error: error.message });
    }}

exports.getProductbyid = async (req, res) => {
    try {
        const product0= await product.find();
        res.json(product0);
        console.log("your products in a database are:");
        
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
exports.updateProduct= async (req, res) => {
    try {
        const newProduct = await product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        console.log("i am here to update your product by id ");
        
        if (!product) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(newProduct);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
exports.updateProductbyid = async (req, res) => {
    try {
        const user = await user.findById(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'user not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
exports.deleteProduct = async (req, res) => {
    try {
        const user = await user.deleteuserbyid(req.params.id, req.body,);
        if (!user)
            return res.status(402).json({ error: 'user not find to delete' });
    }
    catch (error) {
        res.status(400).json({ error: error.messsage });
    }
}