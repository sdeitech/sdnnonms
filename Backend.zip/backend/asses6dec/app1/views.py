from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import ProductSerializer
from .models import Products
# Create your views here.

class GetAllProduct(APIView):
    def get(self,request):
        try:   
            products = Products.objects.all()
            serializer = ProductSerializer(products,many =True)
            return Response(serializer.data)
        except:
            context = {'error':'No Data Found'}
            return Response(context)
        
    def post(self,request):
        try:
            data = request.data
            title = data.get('title')
            desc = data.get('desc')
            price = data.get('price')
            image = data.get('img')
            print(data)
            Products.objects.create(title=title,description = desc,price =price,image =image)
            context ={ 'msg': 'Product Added Succesfully'}
            return Response (context)
        except:
            context = {'error':'Error Something is Wrong'}
            return Response(context)