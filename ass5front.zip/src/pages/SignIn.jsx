import React, { useEffect, useState } from "react";
import useForm from "../costomHooks/useForm";
import toast, { Toaster } from "react-hot-toast";
import axios from "axios";
import { loginSuccess } from "../context/Reducers/LoginUser";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  
  const dispatch = useDispatch();

  const navigate = useNavigate();
  const [toastShown, setToastShown] = useState(false);

  const data = useSelector((state) => state.loginUser);

  console.log(data, "userdata");

  const signInData = {
    email: "",
    password: "",
  };

  const { formData, handleChange } = useForm(signInData);

  const handleSignIn = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/signin`,
        formData
      );
      setToastShown(true);

      dispatch(loginSuccess(res.data));

      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Login successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-green-400 via-blue-500 to-purple-600">
  {/* <!-- Login Card --> */}
  <div className="bg-white border border-gray-300 py-10 px-6 rounded-2xl shadow-xl w-96 flex flex-col items-center">
    {/* <!-- Login Title --> */}
    <div className="text-3xl font-bold text-gray-800 mb-6">
      <p>Login</p>
    </div>
    
    {/* <!-- Form --> */}
    <form onSubmit={handleSignIn} className="flex flex-col gap-6 w-full">
      {/* <!-- Email Input --> */}
      <div className="relative border border-gray-300 rounded-md focus-within:border-indigo-500">
        <input
          type="email"
          name="email"
          onChange={handleChange}
          placeholder="Enter your email"
          className="w-full h-12 pl-10 pr-4 rounded-md focus:outline-none text-gray-700"
        />
        {/* <!-- Icon --> */}
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400 absolute left-3 top-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14v7m-6 0h12" />
        </svg>
      </div>

      {/* <!-- Password Input --> */}
      <div className="relative border border-gray-300 rounded-md focus-within:border-indigo-500">
        <input
          type="password"
          name="password"
          onChange={handleChange}
          placeholder="Enter your password"
          className="w-full h-12 pl-10 pr-4 rounded-md focus:outline-none text-gray-700"
        />
        {/* <!-- Icon --> */}
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400 absolute left-3 top-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11c1.5 0 2.5 1 3 3m1.15 4.16a1 1 0 01-.35.84m-6-2.84a1 1 0 00.35-.84m4.24 0a1 1 0 00-.35.84m1.15-4.16a4 4 0 00-7.6 0m6.45 3.84h-4.7m4.7 0a1 1 0 01-.35-.84m0 0h-4.7" />
        </svg>
      </div>

      {/* <!-- Login Button --> */}
      <div className="text-center">
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-3 rounded-md font-semibold hover:bg-indigo-700 transition duration-300"
        >
          Login
        </button>
      </div>
    </form>

    {/* <!-- Notifications --> */}
    <Toaster />
  </div>
</div>

  );
};

export default SignIn;
