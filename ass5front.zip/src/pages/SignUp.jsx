import React, { useEffect, useState } from "react";
import { Radio } from "@material-tailwind/react";
import { Link } from "react-router-dom";
import useForm from "../costomHooks/useForm";
import Icons from "../assets/assets";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";

const SignUp = () => {
  const SignUpData = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    gender: "",
    isMarried: false,
    DOB: "",
    profile: null,
  };

  const [toastShown, setToastShown] = useState(false);

  const { formData, previewImg, handleChange, resetForm } = useForm(SignUpData);
  
  console.log(formData);
  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);

    const formDataToSend = new FormData();

    formDataToSend.append("firstName", formData.firstName);
    formDataToSend.append("lastName", formData.lastName);
    formDataToSend.append("email", formData.email);
    formDataToSend.append("password", formData.password);
    formDataToSend.append("gender", formData.gender);
    formDataToSend.append("isMarried", formData.isMarried);
    formDataToSend.append("DOB", formData.DOB);

    if (formData.profile) {
      formDataToSend.append("profile", formData.profile);
    }

    try {
      const res = await axios.post(
        `http://localhost:3002/api/signup`,
        formDataToSend
      );
      setToastShown(true);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Registration successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="bg-gradient-to-r from-green-400 to-blue-400 py-12 px-8 rounded-3xl shadow-2xl w-full max-w-lg mx-auto mt-10">
      <div className="text-3xl font-bold text-white mb-8 text-center">
        <p>Sign Up Here</p>
      </div>
  
      <div className="mb-8">
        {previewImg ? (
          <div className="rounded-full h-24 w-24 border-4 border-white p-1 mx-auto">
            <img
              src={previewImg}
              alt="Profile Preview"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        ) : (
          <div className="rounded-full h-24 w-24 border-4 border-white p-1 mx-auto">
            <img
              src="https://cdn-icons-png.flaticon.com/512/1946/1946429.png" // New profile icon URL
              alt="Default Profile"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        )}
      </div>
  
      <form onSubmit={handleLoginSubmit} className="space-y-6">
        <div className="lg:grid lg:grid-cols-2 lg:gap-4">
          <div className="col-span-1">
            <input
              type="text"
              name="firstName"
              onChange={handleChange}
              placeholder="First Name"
              className="h-12 w-full px-4 text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
  
          <div className="col-span-1">
            <input
              type="text"
              name="lastName"
              onChange={handleChange}
              placeholder="Last Name"
              className="h-12 w-full px-4 text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
  
          <div className="col-span-2">
            <input
              type="email"
              name="email"
              onChange={handleChange}
              placeholder="Email"
              className="h-12 w-full px-4 text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
  
          <div className="col-span-2">
            <input
              type="password"
              name="password"
              onChange={handleChange}
              placeholder="Password"
              className="h-12 w-full px-4 text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
  
          <div className="flex items-center justify-center gap-8 col-span-2">
            <label className="text-white">Gender:</label>
            <div className="text-white flex items-center space-x-4">
              <Radio
                name="gender"
                label="Male"
                value="male"
                checked={formData.gender === "male"}
                onChange={handleChange}
              />
              <Radio
                name="gender"
                label="Female"
                value="female"
                checked={formData.gender === "female"}
                onChange={handleChange}
              />
            </div>
          </div>
  
          <div className="col-span-2">
            <input
              type="date"
              name="DOB"
              onChange={handleChange}
              className="h-12 w-full px-4 text-gray-700 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
  
          <div className="col-span-2 flex items-center gap-6">
            <label className="text-white">Married?</label>
            <input
              type="checkbox"
              name="isMarried"
              checked={FormData.isMarried}
              onChange={handleChange}
              className="w-5 h-5 text-blue-500 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
            />
          </div>
  
          <div className="col-span-2">
            <label
              htmlFor="profile"
              className="cursor-pointer bg-blue-600 text-white px-4 py-2 rounded-lg text-center block w-full"
            >
              Upload Profile
            </label>
            <input
              type="file"
              id="profile"
              name="profile"
              onChange={handleChange}
              style={{ display: "none" }}
            />
          </div>
  
          {previewImg && (
            <div className="col-span-2 text-center">
              <a href={previewImg} target="_blank" className="text-blue-200 underline">
                View Profile
              </a>
            </div>
          )}
        </div>
  
        <div className="flex flex-col items-center mt-6 gap-4">
          <button
            type="submit"
            className="bg-blue-600 text-white py-3 w-full rounded-lg text-center"
          >
            Sign Up
          </button>
  
          <p className="text-white">
            Already have an account?{" "}
            <Link to={"/login"} className="text-yellow-300 underline">
              Click here
            </Link>
          </p>
        </div>
      </form>
  
      <Toaster />
    </div>
  );
  
};

export default SignUp;
