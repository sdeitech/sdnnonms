import axios from "axios";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveUserData } from "../context/Reducers/userSlice";
import { Card, Typography } from "@material-tailwind/react";
import Icons from "../assets/assets";
// import fetchUser from "../costomHooks/fetchUser";

const TABLE_HEAD = ["Profile", "First Name", "LastName", "Email", "Action"];

const Dashboard = () => {

  const uid = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);


  console.log(uid, token)




  const userData = useSelector((state) => state.userData.subUsers);
  console.log(userData, "demoooooooooooooooooooooooooooooooooo");

  const dispatch = useDispatch();

  const fetchUser = async () => {
    try {
      const res = await axios.get(`http://localhost:3002/api/user/${uid}`, {
        headers: {
          Authorization: token,
        },
      });
      dispatch(saveUserData(res.data));
      console.log(res.data, "from call");
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    console.log("calling api")
    fetchUser();
  }, []);
  return (
    <div className="w-11/12 mx-auto mt-10">
      <Card className="h-full w-full overflow-hidden shadow-2xl rounded-2xl border border-gray-200">
        <table className="w-full min-w-max table-auto text-left">
          {/* Header with gradient and uppercase text */}
          <thead className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
            <tr>
              {TABLE_HEAD.map((head) => (
                <th key={head} className="p-4 text-center">
                  <Typography
                    variant="small"
                    color="white"
                    className="font-semibold uppercase tracking-wide"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
  
          {/* Table body with alternating row colors, hover effects, and smooth transitions */}
          <tbody>
            {userData?.map(({ _id, firstName, lastName, email }, index) => (
              <tr
                key={_id}
                className={`transition-all duration-300 ${
                  index % 2 === 0
                    ? 'bg-white hover:bg-pink-50'
                    : 'bg-gray-50 hover:bg-purple-50'
                }`}
              >
                {/* Profile Image */}
                <td className="p-4 text-center">
                  <img
                    src={Icons.profile}
                    alt="Profile"
                    className="rounded-full h-12 w-12 object-cover shadow-md border-2 border-gray-200"
                  />
                </td>
  
                {/* First Name */}
                <td className="p-4 text-center">
                  <Typography
                    variant="small"
                    className="font-semibold text-purple-800"
                  >
                    {firstName}
                  </Typography>
                </td>
  
                {/* Last Name */}
                <td className="p-4 text-center">
                  <Typography
                    variant="small"
                    className="font-semibold text-purple-800"
                  >
                    {lastName}
                  </Typography>
                </td>
  
                {/* Email */}
                <td className="p-4 text-center">
                  <Typography
                    variant="small"
                    className="font-semibold text-blue-600"
                  >
                    {email}
                  </Typography>
                </td>
  
                {/* View Button */}
                <td className="p-4 text-center">
                  <a
                    href="#"
                    className="text-indigo-600 font-semibold hover:underline hover:text-indigo-800 transition-all duration-200"
                  >
                    View
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default Dashboard;
