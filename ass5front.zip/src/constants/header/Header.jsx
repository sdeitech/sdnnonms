import React from "react";
import Icons from "../../assets/assets";
import { useDispatch, useSelector } from "react-redux";
import { logoutUser } from "../../context/Reducers/LoginUser";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import { clearUsers } from "../../context/Reducers/userSlice";

const Header = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const userData = useSelector((state) => state.userData?.userData?.user);


  const handleLogout = () => {
    toast.success("Logged Out");
    setTimeout(() => {
      dispatch(logoutUser());
      dispatch(clearUsers())
      navigate("/");
    }, 1000);
  };
  return (
    <div className="bg-gradient-to-r from-blue-400 to-purple-400 flex justify-between items-center px-6 py-4 shadow-lg">
      <div className="flex items-center gap-3">
        <p className="text-white font-bold text-lg">{userData?.firstName}</p>
        <div className="relative">
          <input
            type="text"
            placeholder="Search user"
            className="h-10 rounded-md w-60 px-4 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-300 transition duration-200"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <Link to="/adduser">
          <button className="bg-white text-blue-600 px-4 py-2 rounded-md shadow-lg hover:bg-blue-50 transition duration-200">
            Add User
          </button>
        </Link>
        <Link to="/profile" className="relative">
          <div className="rounded-full border-2 border-gray-900 p-1 transition-transform transform hover:scale-110">
            <img
              src={Icons.profile}
              alt="Profile"
              height={30}
              width={30}
              className="rounded-full"
            />
          </div>
        </Link>
        <button
          className="bg-red-600 text-white px-4 py-2 rounded-md font-medium transition duration-200 hover:bg-red-700"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>
      
      <Toaster />
    </div>
  );
  
};

export default Header;
