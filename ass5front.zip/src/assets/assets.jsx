import { CgProfile } from "react-icons/cg";
import { RxCross2 } from "react-icons/rx";
import profile from "../assets/images/default-profile.webp";
const Icons = {
  profile,
  crossIcon: RxCross2,
  profileIcon: CgProfile,
};

export default Icons;
