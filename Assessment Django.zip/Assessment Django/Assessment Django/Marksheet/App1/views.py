# from django.shortcuts import render,redirect
# # from .forms import SubjectForm
# from .models import Subject,User

# # Create your views here.

# def input_marks(request):
#     if request.method=='POST':
#       Subject.objects.all().delete()
      
#       sName=request.POST.get('Student_Name')
#       sLast=request.POST.get('Student_LastName')
#       rollno=request.POST.get('Roll_No')      
#       collegeName=request.POST.get('College_Name')      
#       mobile=request.POST.get('Mobile_No')    
      
      
#       user=User.objects.create(
#           sName=sName,
#           sLast=sLast,
#           rollno=rollno,
#           collegeName=collegeName,
#           mobile=mobile
#       )  
      
#       subject_names = request.POST.getlist("name")
#       theory_marks = request.POST.getlist("theory")
#       internal_marks = request.POST.getlist("internal")

#       for name,theory,internal in zip(subject_names,theory_marks,internal_marks):
#             std_data = Subject.objects.create(
#                 name = name,
#                 theory_marks = theory,
#                 internal_marks = internal,
#                 # total = int(th)+int(inter)
#             )
            
#             user.subjects.add(std_data)
         
#       return redirect('marksheet')
#     else:
#          return render(request,"input_marks.html")

# def generate_marksheet(request):
#     subjects=User.objects.last()
    
#     if not subjects:
#         return render(request, "marksheet.html", {
#             'students': [],
#             'subjects': [],
#             'total_marks': 0,
#             'max_marks': 0,
#             'overall_pass': False,
#             "percentage": 0
#         })
        
        
#     # print(subjects)
#     students=subjects.subjects.all()
#     total_marks=sum(std_data.total_marks() for std_data in students)
#     max_marks=len(students)*100
#     percentage = (total_marks/400)*100
#     # print(total_marks)
#     # print(total_marks , "total_marks")
   
#     overall_pass=all(std_data.is_pass() for std_data in students)
#     # print(overall_pass , "overall_pass")
    
    
    
#     return render(request,"marksheet.html",{
#         'students':students,
        
#         'subjects':subjects,
#         'total_marks':total_marks,
#         'max_marks':max_marks,
#         'overall_pass':overall_pass,
#         'percentage':percentage
#     })
    # return render(request,'displaymarksheet.html' , context={"subjects":subjects})  
    
    
    
    
    # subject = request.POST.getlist("subject")
    #     theory = request.POST.getlist("theory")
    #     internal = request.POST.getlist("internal")

    #     print("subject",subject)
    #     print("theory",theory)
    #     print("internal",internal)

    #     for sub,th,inter in zip(subject,theory,internal):
    #         std_data = studentMarks(
    #             subject = sub,
    #             theory = th,
    #             internal = inter,
    #             total = int(th)+int(inter)
    #         )
    #         std_data.save()
    
    
    
from django.shortcuts import render, redirect
from .models import Subject, User  # Keeping User as per your request

def input_marks(request):
    if request.method == 'POST':
        # Optionally clear existing subjects if needed, but be cautious about this logic.
        # Subject.objects.all().delete()  # Remove this line if you want to retain existing subjects

        # Capture student information from POST data
        sName = request.POST.get('Student_Name')
        sLast = request.POST.get('Student_LastName')
        rollno = request.POST.get('Roll_No')
        collegeName = request.POST.get('College_Name')
        mobile = request.POST.get('Mobile_No')

        # Create the User instance
        user = User.objects.create(
            sName=sName,
            sLast=sLast,
            rollno=rollno,
            collegeName=collegeName,
            mobile=mobile
        )

        # Get the subjects, theory marks, and internal marks from the POST data
        subject_names = [
            request.POST.get('subject1'),
            request.POST.get('subject2'),
            request.POST.get('subject3'),
            request.POST.get('subject4')
        ]
        
        theory_marks = [
            request.POST.get('theory1'),
            request.POST.get('theory2'),
            request.POST.get('theory3'),
            request.POST.get('theory4')
        ]
        
        internal_marks = [
            request.POST.get('internal1'),
            request.POST.get('internal2'),
            request.POST.get('internal3'),
            request.POST.get('internal4')
        ]

        # Iterate through subjects and marks, creating Subject instances and associating them with the user
        for name, theory, internal in zip(subject_names, theory_marks, internal_marks):
            std_data = Subject.objects.create(
                name=name,
                theory_marks=int(theory),   # Ensure these are integers
                internal_marks=int(internal)
            )
            
            # After saving the subject, associate it with the user
            user.subjects.add(std_data)

        # Redirect to the marksheet view after submission
        return redirect('marksheet')
    else:
        # Render the input form if GET request
        return render(request, "input_marks.html")


def generate_marksheet(request):
    # Fetch the last User instance (student)
    user = User.objects.last()

    # If there are no users, render an empty marksheet
    if not user:
        return render(request, "marksheet.html", {
            'students': [],  # Empty student list
            'subjects': [],  # Empty subject list
            'total_marks': 0,
            'max_marks': 0,
            'overall_pass': False,
            "percentage": 0
        })

    # Fetch all subjects associated with the last user
    subjects = user.subjects.all()
    
    # Calculate the total marks, max marks, and percentage
    total_marks = sum(subject.total_marks() for subject in subjects)
    max_marks = len(subjects) * 100
    percentage = (total_marks / max_marks) * 100 if max_marks > 0 else 0

    # Check if the student has passed all subjects
    overall_pass = all(subject.is_pass() for subject in subjects)

    # Render the marksheet with the calculated data
    return render(request, "marksheet.html", {
        'students': user,  # The last user (student)
        'subjects': subjects,  # The user's associated subjects
        'total_marks': total_marks,
        'max_marks': max_marks,
        'overall_pass': overall_pass,
        'percentage': percentage
    })

