from django.urls import path
from . import views

urlpatterns = [
  path('',views.input_marks,name='input_marks'),
  path('marksheet/',views.generate_marksheet,name='marksheet'),
]