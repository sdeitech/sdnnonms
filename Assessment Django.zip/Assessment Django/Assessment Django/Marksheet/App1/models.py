

from django.db import models
from django import forms

# Create your models here.
class Subject(models.Model):
    name = models.CharField(max_length=100)
    theory_marks = models.IntegerField(default=0)
    internal_marks = models.IntegerField(default=0)

    def total_marks(self):
        return self.theory_marks + self.internal_marks

    def is_pass(self):
        return self.total_marks() >= 35

    def __str__(self):
        return self.name

class User(models.Model):
    sName = models.CharField(max_length=50)    
    sLast = models.CharField(max_length=50)
    rollno = models.IntegerField()
    collegeName = models.CharField(max_length=50)
    mobile = models.IntegerField()  # Consider using a CharField for mobile if you want to store leading zeros.
    # for linking with multiple subjects or linking with subject model
    subjects = models.ManyToManyField(Subject)

    def __str__(self):
        return f"{self.sName} {self.sLast} (Roll No: {self.rollno}) {self.collegeName} {self.mobile}"

class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject  # Fixed the syntax error here
        fields = ['name', 'theory_marks', 'internal_marks'] 

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['sName', 'sLast', 'rollno', 'collegeName', 'mobile', 'subjects']
         