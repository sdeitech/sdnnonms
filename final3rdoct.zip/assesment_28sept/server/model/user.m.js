import mongoose from "mongoose";




const userSchema = mongoose.Schema({
    firstName: {
        type: String,
        requied: true,
    },
    lastName: {
        type: String,
        requied: true,
    },
    email: {
        type: String,
        required: true,
    },
    pass: {
        type: String,
        required: true,
    },
    dob: {
        type: String,
        requied: true,
    },
    age: {
        type: Number,
    },
    gender: {
        type: String,
    },
    isMarried: {
        type: Boolean,
        default: false,
    },
    token: {
        type: String,
        default: null
    },
    file:{
        type:String
    },

})

const User = mongoose.model("User", userSchema);

module.exports = User;