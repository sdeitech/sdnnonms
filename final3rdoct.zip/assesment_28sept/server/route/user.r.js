import express from "express";
import {registerUser, loginUser, getUserbyId, updateUser} from '../controller/user.c'
import {createUserdata, getUserdata} from '../controller/userdata.c'
import { uploadMiddleware } from "../middleware/multer";
const authrouter = express.Router();

authrouter.post('/image', uploadMiddleware.single('file'), registerUser);
authrouter.post('/login', loginUser); 
authrouter.put('/update/:id',uploadMiddleware.single('file'),updateUser)
authrouter.get('/view/:id', getUserbyId);
authrouter.post('/userdata',createUserdata);
authrouter.get('/userview',getUserdata);





module.exports = authrouter;