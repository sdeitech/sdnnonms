import User from '../model/user.m';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { messages } from '../config/constant';
import { Response } from '../middleware/response';
import 'dotenv/config';
const config = require('../config/config');
const { TOKENS } = config.config;

const registerUser = async (req, res) => {
    try {
        const { firstName, lastName, email, pass, dob, gender, isMarried } = req.body;

        console.log(req.body);

        const file = req.file ? req.file.path : null;

        console.log(req.body);
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return Response._400(res, {
                status: false,
                message: messages.userExist,
                body: null,
            });
        }

        const hashPassword = await bcrypt.hash(pass, 10);


        const newUser = new User({
            firstName,
            lastName,
            email,
            pass: hashPassword,
            dob,
            gender,
            isMarried,
            file
        });
        console.log(newUser);

        await newUser.save();

        return Response._201(res, {
            status: true,
            message: messages.userRegistered,
            body: null,
        });

    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, pass } = req.body;
        const user = await User.findOne({ email });

        if (!user) {
            return (
                Response._401(res, {
                    status: false,
                    message: messages.userNotfound,
                    body: null,
                })
            )
        }

        console.log(user)

        const isMatch = await bcrypt.compare(pass, user.pass);

        if (isMatch) {
            const token = jwt.sign({ email, pass }, TOKENS.JWT_SECRET, {
                expiresIn: TOKENS.JWT_EXPIRATION_IN_MINUTES,
            });
            console.log(user);

            user.token = token;
            await user.save();

            return (
                Response._200(res, {
                    status: false,
                    message: messages.logIn,
                    token: token,
                    user: user,
                })
            )
        } else {
            return (
                Response._401(res, {
                    status: false,
                    message: messages.userNotfound,
                    body: null,
                })
            )
        }
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}

const getUserbyId = async (req, res) => {
    try {
        const { id } = req.params
        const user = await User.findById(id)
        return (
            Response._200(res, {
                status: false,
                message: messages.datfetched,
                body: user,
                // username: username,
            })
        )
    } catch (error) {
        console.log(error);

        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}

const updateUser = async (req, res) => {
    try {

        const updateUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });

        if (!User) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(updateUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
module.exports = {
    registerUser,
    loginUser,
    getUserbyId,
    updateUser

}