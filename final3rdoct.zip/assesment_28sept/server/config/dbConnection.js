import mongoose from "mongoose";
import 'dotenv/config'
const config =require("./config")
const {DB} = config.config 


const DBURL = `mongodb://${DB.HOST}:${DB.PORT}/${DB.DATABASE}`

export const startConnection =async () => {
    try {
        await mongoose.connect(DBURL);
        console.log("Connected to MONGODB"); 
    } catch (e) {
        throw e
    }
}