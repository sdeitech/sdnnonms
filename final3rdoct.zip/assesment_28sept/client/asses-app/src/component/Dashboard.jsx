import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../style/table.css';
import View from './View';

function Dashboard() {

    const [userData, setuserData] = useState([]);



    useEffect(() => {


        const fetchData = async () => {
            let userId = localStorage.getItem('user')
            try {
                const res = await axios.get(`http://localhost:5000/user/userview?userid=${userId}`)

                setuserData(res.data);
            } catch (error) {
                console.error(error);
            }
        };

        fetchData();
    }, []);

    const [curruntUser, setcurruntUser] = useState(null);

    // const update = (user) => {
    //   setshowupdate(!showupdate);
    //   console.log(update);
    //   setcurruntUser(user)
    // };

    const [showview, setshowview] = useState(false);
    const Handleview = (userDat) => {
        setshowview(!showview);
        setcurruntUser(userDat);
    };
    return (
        <>
            <table>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Gender </th>
                        <th>Actions </th>
                    </tr>
                </thead>
                <tbody>
                    {userData.map((userDat) => (
                        <tr key={userDat._id}>
                            <td>{userDat.firstName}</td>
                            <td>{userDat.lastName}</td>
                            <td>{userDat.age}</td>
                            <td>{userDat.gender}</td>
                            <td>
                                <button onClick={() => Handleview(userDat)}>View</button>
                            </td>
                        </tr>
                    ))}

                </tbody>
            </table >
            {showview && (
                <View
                    curruntUser={curruntUser}
                    showview={showview}
                    setshowview={setshowview}
                />
            )}
        </>
    )
}


export default Dashboard;