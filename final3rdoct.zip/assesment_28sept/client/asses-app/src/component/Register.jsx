import React, { useState } from 'react';
import axios from 'axios';
import {
    MDBBtn,
    MDBContainer,
    MDBCard,
    MDBCardBody,
    MDBCol,
    MDBRow,
    MDBInput,
    MDBCheckbox,
    MDBRadio
} from 'mdb-react-ui-kit';
import Form from 'react-bootstrap/Form';

function Register() {
    const [userReg, setUserReg] = useState({
        firstName: '',
        lastName: '',
        email: '',
        pass: '',
        dob: '',
        gender: '',
        isMarried: false,
        file: null,
    });
    const [useresponse, setUseresponse] = useState('');

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setUserReg({
            ...userReg,
            [name]: type === 'checkbox' ? checked : value,
        });
    };

    const handleFileChange = (e) => {
        setUserReg({
            ...userReg,
            file: e.target.files[0],
        });
    };

    const handleRadioChange = (e) => {
        setUserReg({
            ...userReg,
            gender: e.currentTarget.value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();


        const formData = new FormData();
        formData.append('firstName', userReg.firstName);
        formData.append('lastName', userReg.lastName);
        formData.append('email', userReg.email);
        formData.append('pass', userReg.pass);
        formData.append('dob', userReg.dob);
        formData.append('gender', userReg.gender);
        formData.append('isMarried', userReg.isMarried);
        formData.append('file', userReg.file);

        try {
            const response = await axios.post('http://localhost:5000/user/image', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            console.log('User data submitted:', response.data);
            setUseresponse('User data submitted', response.data)
        } catch (err) {
            console.error('Error submitting data:', err.message);
            console.log(err);

        }
    };

    const clearuserData =async () => {
        setUserReg({
            firstName: '',
            lastName: '',
            email: '',
            pass: '',
            dob: '',
            gender: '',
            isMarried: false,
            file: null,
        });
    }

    return (
        <MDBContainer fluid>
            <form onSubmit={handleSubmit}>
                <MDBCard className='mx-5 mb-5 p-5 shadow-5'>
                    {useresponse && <div className="alert alert-success">{useresponse}</div>}
                    <MDBCardBody className='p-5 text-center'>
                        <h2 className="fw-bold mb-5">Sign up now</h2>
                        <MDBRow>
                            <MDBCol col='6'>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='First name'
                                    name='firstName'
                                    value={userReg.firstName}
                                    onChange={handleChange}
                                    type='text'
                                />
                            </MDBCol>
                            <MDBCol col='6'>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Last name'
                                    name='lastName'
                                    value={userReg.lastName}
                                    onChange={handleChange}
                                    type='text'
                                />
                            </MDBCol>
                        </MDBRow>
                        <MDBRow>
                            <MDBCol>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Email'
                                    name='email'
                                    value={userReg.email}
                                    onChange={handleChange}
                                    type='email'
                                />
                            </MDBCol>
                            <MDBCol>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Date of Birth'
                                    name='dob'
                                    value={userReg.dob}
                                    onChange={handleChange}
                                    type='date'
                                />
                            </MDBCol>
                        </MDBRow>
                        <MDBInput
                            wrapperClass='mb-4'
                            label='Password'
                            name='pass'
                            value={userReg.pass}
                            onChange={handleChange}
                            type='password'
                        />
                        <div className='d-flex justify-content-center mb-4'>
                            <MDBCheckbox
                                name='isMarried'
                                id='flexCheckDefault'
                                checked={userReg.isMarried}
                                onChange={handleChange}
                                label='Married'
                            />
                        </div>
                        <div className='mb-4'>
                            <label>Gender</label>
                            <MDBRadio
                                name='gender'
                                id='inlineRadio1'
                                value='Male'
                                label='Male'
                                inline
                                onChange={handleRadioChange}
                            />
                            <MDBRadio
                                name='gender'
                                id='inlineRadio2'
                                value='Female'
                                label='Female'
                                inline
                                onChange={handleRadioChange}
                            />
                        </div>
                        <Form.Group controlId="formFile" className="mb-3">
                            <Form.Label>Upload Profile Picture</Form.Label>
                            <Form.Control type="file" name='file' onChange={handleFileChange} />
                        </Form.Group>
                        <div className='d-flex'>
                            <MDBBtn className='w-100 mb-4' size='md' type='submit'>
                                Register
                            </MDBBtn>
                            <MDBBtn className='w-100 mb-4' size='md' type='reset' onClick={clearuserData}>
                                Reset
                            </MDBBtn>
                        </div>

                        <MDBBtn className='w-100 mb-4' size='md' href='/'>
                            Login Page
                        </MDBBtn>
                    </MDBCardBody>
                </MDBCard>
            </form>
        </MDBContainer>
    );
}

export default Register;