import React, { useState, useEffect } from "react";
import axios from "axios";
import {
    MDBBtn,
    MDBContainer,
    MDBCard,
    MDBCardBody,
    MDBCol,
    MDBRow,
    MDBInput,
    MDBCheckbox,
    MDBRadio,
    MDBCardImage
} from 'mdb-react-ui-kit';

import { Form } from "react-bootstrap";


function Profile() {

    const [profile, setProfile] = useState('');

    console.log("profile data", profile);


    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setProfile((prevData) => ({
            ...prevData,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleFileChange = (e) => {
        setProfile((prevData) => ({
            ...profile,
            file: e.target.files[0],
        }));
    };

    const handleRadioChange = (e) => {
        setProfile({
            ...profile,
            gender: e.currentTarget.value,
        });
    };


    useEffect(() => {


        const fetchDatabyID = async () => {
            try {
                let userId = localStorage.getItem('user')
                const res = await axios.get(`http://localhost:5000/user/view/${userId}`)

                setProfile(res.data.body);
                console.log("resopnse", res.data.body);

            } catch (error) {
                console.error(error);
            }
        };

        fetchDatabyID();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            let userId = localStorage.getItem('user')
            const response = await axios.put(`http://localhost:5000/user/update/${userId}`, profile, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            console.log('User data submitted:', response.data);
        } catch (err) {
            console.error('Error submitting data:', err.message);
            console.log(err);

        }
    }

    return (
        <>
            <MDBContainer fluid>
                <form onSubmit={handleSubmit}>
                <MDBCard className='mx-5 mb-5 p-5 shadow-5'>
                    <MDBCardBody className='p-5 text-center'>
                        <h2 className="fw-bold mb-5">Update Details</h2>

                        <MDBRow>
                            <MDBCol lg="4">
                                <MDBCard className="mb-4">
                                    <MDBCardBody className="text-center">
                                        <MDBCardImage
                                            src={`http://localhost:5000/${profile.file}`}
                                            alt="avatar"
                                            className="rounded-circle"
                                            style={{ width: '150px' }}
                                            fluid />
                                    </MDBCardBody>
                                </MDBCard>
                            </MDBCol>
                        </MDBRow>

                        <MDBRow>
                            <MDBCol col='6'>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='First name'
                                    name='firstName'
                                    value={profile.firstName}
                                    onChange={handleChange}
                                    type='text'
                                />
                            </MDBCol>
                            <MDBCol col='6'>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Last name'
                                    name='lastName'
                                    value={profile.lastName}
                                    onChange={handleChange}
                                    type='text'
                                />
                            </MDBCol>
                        </MDBRow>
                        <MDBRow>
                            <MDBCol>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Email'
                                    name='email'
                                    value={profile.email}
                                    onChange={handleChange}
                                    type='email'
                                />
                            </MDBCol>
                            <MDBCol>
                                <MDBInput
                                    wrapperClass='mb-4'
                                    label='Date of Birth'
                                    name='dob'
                                    value={profile.dob}
                                    onChange={handleChange}
                                    type='date'
                                />
                            </MDBCol>
                        </MDBRow>
                        <div className='d-flex justify-content-center mb-4'>
                            <MDBCheckbox
                                name='isMarried'
                                id='flexCheckDefault'
                                checked={profile.isMarried}
                                onChange={handleChange}
                                label='Married'
                            />
                        </div>
                        <div className='mb-4'>
                            <label>Gender</label>
                            <MDBRadio
                                name='gender'
                                id='inlineRadio1'
                                value='Male'
                                label='Male'
                                inline
                                onChange={handleRadioChange}
                            />
                            <MDBRadio
                                name='gender'
                                id='inlineRadio2'
                                value='Female'
                                label='Female'
                                inline
                                onChange={handleRadioChange}
                            />
                            <Form.Group controlId="formFile" className="mb-3">
                                <Form.Label>Default file input example</Form.Label>
                                <Form.Control type="file" name='file'  onChange={handleFileChange} />
                            </Form.Group>
                        </div>
                        <MDBBtn className='w-100 mb-4' size='md' type='submit' >Update</MDBBtn>
                    </MDBCardBody>
                </MDBCard>
                </form>
            </MDBContainer>




        </>

    );

}

export default Profile;

