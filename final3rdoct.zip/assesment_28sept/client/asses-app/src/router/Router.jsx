import { createBrowserRouter} from "react-router-dom";
import publicRoute from "./PublicRoute";
import PrivateRoute from "./PrivateRoute";

const routers = createBrowserRouter([
    ...publicRoute,
    ...PrivateRoute
]);

export default routers;