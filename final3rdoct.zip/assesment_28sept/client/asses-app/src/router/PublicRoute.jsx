import { React } from "react";
import PublicLay from "../layout/PublicLay";
import Login from "../component/Login";
import Register from "../component/Register";

const publicRoute = [
    {
        path: "/",
        exact: true,
        element: <PublicLay><Login/></PublicLay>
    },
    {
        path: "/register",
        exact: true,
        element: <PublicLay><Register/></PublicLay>
    },

];
export default publicRoute;