const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const itemRoute =require('./routes/item.route');
const db = require('./db'); // Connect to the database
const router = require('./routes/item.route');
const app = express();
const PORT = 4000; //manual port


app.use(cors());
app.use(bodyParser.json());

app.use('/items',itemRoute);



app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
})

module.exports=router;