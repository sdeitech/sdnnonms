
import './App.css';
import ProductCrud from './components/itemCrud';
import ItemCrud from './components/itemCrud';




function App() {
  return (
    <div className="App">
            <ProductCrud></ProductCrud>
    </div>
  );
}

export default App ;
