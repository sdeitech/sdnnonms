import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from 'axios'
import { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { TextField } from '@mui/material';







//css styling 
const style = {
  py: 0,
  width: '100%',
  maxWidth: 360,
  borderRadius: 2,
  border: '1px solid',
  borderColor: 'divider',
  backgroundColor: 'background.paper',
};


export default function ProductCrud() {

  const [data, setData] = useState([])
  const [error, setError] = useState(null)

  const [itemInput, setitemInput] = useState({
    itemName: '',
    details: '',
    quantity: '',
    price: ''
  })

  const [items, setItems] = useState([])
  const [isEditing, setIsEditing] = useState(false)
  const [editItemId, seteditItemId] = useState(null)
  const [editError, setEditError] = useState(null)

  const [deleteError, setDeleteError] = useState(null)

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:4000/items/');
      console.log('------response---------', response.data)
      setData(response.data);
      setError(null);
    } catch (error) {
      setData([]);
      setError('Failed to fetch data.');
    } finally {
    }
  };

  console.log("fetchData ----------", fetchData)

  useEffect(() => {
    fetchData();
  }, []);


  const handleSubmit = async (event) => {
    event.preventDefault();
    console.log('-----itemInput-----', itemInput);

    if (isEditing) {

      try {
        const response = await axios.put(`http://localhost:4000/items/${editItemId}`, itemInput)
        setItems(items.map(product => (product._id === editItemId ? response.data : product)))
        setIsEditing(false)
        seteditItemId(null)
        setitemInput({ itemName: '', details: '', price: '', quantity: '' })
      } catch (error) {
        setEditError('Failed to update data')
      }
      window.location.reload()
    } else {
      event.preventDefault()
      console.log(itemInput)

      axios({
        method: 'post',
        url: `http://localhost:4000/items`,
        data: itemInput,
      }).then(function (response) {
        console.log(response)
        console.log("added Sucessfully")
        window.location.reload()


      }).catch(function (error) {
        console.log(error)
      })
    }
  }

  const onDeleteHandler = async (deleteId) => {
    try {
      await axios.delete(`http://localhost:4000/items/${deleteId}`)
      setData(prevData => prevData.filter(item => item._id !== deleteId))
      setDeleteError(null)
    } catch (error) {
      setDeleteError('Failed to delete data')
    }
  }

  const onUpdateHandler = async (productId) => {
    try {
      setIsEditing(true)
      const response = await axios.get(`http://localhost:4000/items/${productId}`,)
      const productData = response.data
      seteditItemId(productData._id)
      setitemInput({
        itemName: productData.itemName,
        details: productData.details,
        price: productData.price,
        quantity: productData.quantity
      })
    } catch (error) {
      console.log('error fetching product details', error)
    }
  }

  console.log('----isEditing-----', isEditing)

  return (
    <>
      <h1>Product Management</h1>

      <br></br>
      <form onSubmit={handleSubmit}>

        <TextField
          id='itemName'
         
          label='Item Name'
          value={itemInput.itemName}
          onChange={event => { setitemInput({ ...itemInput, itemName: event.target.value }) }}
          required
        />
        &nbsp;

        <TextField
          id='details'
          label='Details'
          value={itemInput.details}
          onChange={event => { setitemInput({ ...itemInput, details: event.target.value }) }}
          required
        />
        &nbsp;
        <TextField
          id='quantity'
          label='Quantity'
          value={itemInput.quantity}
          onChange={event => { setitemInput({ ...itemInput, quantity: event.target.value }) }}
          required
        />
     &nbsp;
        <TextField
          id='price'
          label='Price'
          value={itemInput.price}
          onChange={event => { setitemInput({ ...itemInput, price: event.target.value }); }}
          required
        />
      
        <br/>
        <Button variant='contained' color='primary' type='submit'>
          {isEditing ? 'Edit Item' : "Add Item"}
        </Button>
      </form>

    <h1>Product List </h1>


      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <TableCell>Product Name</TableCell>
              <TableCell align="center">Product Description</TableCell>
              <TableCell align="center">Price&nbsp;</TableCell>
              <TableCell align="center">Quantity&nbsp;</TableCell>
              <TableCell align="center">Action&nbsp;</TableCell>

            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row) => (
              <TableRow
                key={row._id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {row.itemName}
                </TableCell>
                <TableCell align="center">{row.details}</TableCell>
                <TableCell align="center">{row.price}</TableCell>
                <TableCell align="center">{row.quantity}</TableCell>
                <TableCell align="center">
                  <Button variant="contained" color="secondary" onClick={(e) => onUpdateHandler(row._id)}>Edit</Button>
                
 &nbsp;
               
                  <Button   variant="contained" color="error" onClick={(e) => onDeleteHandler(row._id)}>Delete</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

    </>
  );
}

