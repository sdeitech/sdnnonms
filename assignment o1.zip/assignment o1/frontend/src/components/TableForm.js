import { useEffect, useState } from "react";
import axios from "axios";

function TableForm() {
  const [data, setData] = useState([]);
  const [name, setName] = useState("");
  const [type, setType] = useState("");
  const [company, setCompany] = useState("");
  const [price, setPrice] = useState("");

  const getChangeHandle = async () => {
    try {
      const result = await axios.get(
        "http://localhost:4000/product/api/product"
      );
      setData(result.data.item);
      
    } catch (error) {
      console.error(error);
    }
  };

  const deleteDataHandle = async (id) => {
    try {
      await axios.delete(
        `http://localhost:4000/product/api/product/${id}`
        
        
      );
      setData()
      
    } catch (error) {
      console.log(error);
    }

  };

  useEffect(() => {
    getChangeHandle();
  }, [setData]);

  const submitHandle = (e) => {
    e.preventDefault();
    axios.post("http://localhost:4000/product/api/product", {
      name,
      type,
      company,
      price,
    });
  };

  return (
    <div>
      <form onSubmit={submitHandle}>
        <div>
          <input
            type="text"
            name=""
            placeholder="Enter Product Name"
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
          <input
            type="text"
            name=""
            placeholder="Enter Category"
            onChange={(e) => {
              setType(e.target.value);
            }}
          />
          <input
            type="text"
            name=""
            placeholder="Enter Company"
            onChange={(e) => {
              setCompany(e.target.value);
            }}
          />
          <input
            type="number"
            min={0}
            name=""
            placeholder="Enter Price(RS)"
            onChange={(e) => {
              setPrice(e.target.value);
            }}
          />
          <button>Add</button>
        </div>
      </form>
      <div>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {data.map((ele, index) => {
              return (
                <tr key={index}>
                  <td>{ele.productName}</td>
                  <td>{ele.productType}</td>
                  <td>{ele.productPrice}</td>
                  <td>
                    <button>edit</button>
                    <button
                      onClick={() => {
                        deleteDataHandle(ele._id);
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default TableForm;
