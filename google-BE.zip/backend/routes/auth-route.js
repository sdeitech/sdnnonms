
import express from 'express'
import loginWithGoogle from '../controller/auth-Controller'
const router = express.Router();

router.post('/login' ,loginWithGoogle )

export default router;