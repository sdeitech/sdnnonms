import mongoose from 'mongoose';

const authSchema = new mongoose.Schema({
    googleId:{
        type:String,
        required:true,
        unique:true
    },
    email:{
        type:String,
        required:true
    },
    
    userName:{
        type:String,
    
    },
    tokens:[
        {
            token:{
                type:String,
            }
        }
    ]
    
});

const Auth = mongoose.model('Auth' ,authSchema);

module.exports =  Auth;