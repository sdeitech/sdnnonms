import express from "express";
import cors from 'cors'
import bodyParser from "body-parser";
const { initiateMongoConnection } = require('./config/db');
const { errorHandler, notFound } = require('./middleware/errorMiddleware');
import path from "path";

const routes = require('./routes/user-Route');
const studentRouter = require('./routes/student-route')
const authRouter = require('./routes/auth-route')


const app = express();

initiateMongoConnection();


app.use(cors({ origin: "*" }));

app.use(express.json({ limit: "50mb" }));

app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));

app.use(bodyParser.json({ limit: "50mb" }));

app.use("/api/", routes);
app.use("/apis/", studentRouter);
app.use("/api/", authRouter);

// app.use('/profile_photos', express.static(path.join(__dirname, 'profile_photos')))
app.use("/getimg", express.static("profile_photos"));


app.use(notFound);

app.use(errorHandler);

export default app;
