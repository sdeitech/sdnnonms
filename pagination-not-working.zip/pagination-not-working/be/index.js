const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();
const PORT = 3002;
const studentRoute = require('./Route/student-route')
const cors = require('cors')

app.use(bodyParser.json());

app.use(cors())


app.use('/api', studentRoute)

app.listen(PORT, () => {
    console.log(`Student app listining on port ${PORT}`);
});

