const Student = require("../Model/student-model")

const sendMailToStdudents = require('../helper/mail')


const createStudent = async (req, res) => {

    try {

        const { firstName, lastName, email, maths, science, english } = req.body;
        const percentage = (Number(maths) + Number(science) + Number(english)) / 300 * 100
        req.body.percentage = percentage
        if (percentage >= 90) {
            req.body.grade = "A";
        } else if (percentage >= 60 && percentage < 90) {
            req.body.grade = "B";
        } else {
            req.body.grade = "C";
        }

        const student = new Student(req.body);

        const subject = "Your Test Result";
        const text = `Your Final Result is : ${percentage} % with grade  ${req.body.grade}`;

        const emailSend = await sendMailToStdudents(email, subject, text);

        await student.save();
        res.status(200).json(student);
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}


 const fetchStudent = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        const students = await Student.find().skip(skip).limit(limit);
        const totalCount = await Student.countDocuments();

        const response = {
            students: students,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit)
            }
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};


//BE working but FE error
// const fetchStudent = async (req, res) => {
//     // console.log(`getting paginated data student`)

//     const { page = 1, limit = 5 } = req.query
//     const pageNo = Number(page)

//     const pageLimit = Number(limit)
//     const skip = (pageNo - 1) * pageLimit

//     try {
//         const students = await Student.find({}).skip(skip).limit(pageLimit)
//         const totalRecord = await Student.countDocuments()
//         const totalPages = Math.ceil(totalRecord / pageLimit)
//         return res.status(200).json({
//             students,
//             totalRecord,
//             totalPages,
//             pageNo
//         })

//     } catch (error) {
//         // console.log(`Error ${error.message}`)
//         return res.status(500).json({ msg: error.message })
//     }
// }


//with static data 
// const fetchStudent = async (req, res) => {

//     // let query = Student.find(condition); 
//     let totalProductsQuery = Student.find(); 

//     const totalDocs = await totalProductsQuery.countDocuments().exec();
//     console.log({totalDocs});

//     const { page, limit } = req.query
//     try {
//         const student = await Student.find()
//             .limit(limit)
//             .skip((page - 1) * limit)
//         res.json(student);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };



//to be corrected
// const fetchStudent = async (req, res) => {

//     let totalProductsQuery = Student.find(); 

//     const { page, limit } = req.query
//     try {
//         const student = await Student.find()
//             .limit(limit)
//             .skip((page - 1) * limit)
//             const totalDocs = await totalProductsQuery.countDocuments().exec();
//             const totalPages = Math.ceil(totalRecord / pageLimit)

//         res.json({student,
//             totalDocs,
//             totalPages
//         });
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

const fetchStudentById = async (req, res) => {
    try {
        const { id } = req.params
        const student = await Student.findById(id)
        res.status(200).json(student)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

module.exports = { createStudent, fetchStudent, fetchStudentById }