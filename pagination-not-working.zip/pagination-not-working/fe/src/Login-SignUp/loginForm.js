import React, { useState } from "react";
import { TextField, Button, InputAdornment } from "@mui/material";
import { Link } from "react-router-dom";
import AccountCircle from '@mui/icons-material/AccountCircle';
import LockIcon from '@mui/icons-material/Lock';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import './loginForm.css'

function Loginform() {
  const navigate = useNavigate();
  const [state, setState] = useState({
    userName: "",
    password: "",
    userNameError: "",
    passwordError: "",
  });

  const handleSubmit = async (event) => {
    event.preventDefault();
    const userName = event.target.userName.value;
    const password = event.target.password.value;


    setState({
      ...state,
      userNameError: userName === "" ? "Please enter your userName" : "",
      passwordError: password === "" ? "Please enter your password" : "",
    });
    console.log("formdat",userName)
   let results =  await axios({
        method: 'post',
        url: 'http://localhost:6000/user/login',
        data: {
          userName,
          password
        }
     })
      .then(function (response) {
        // handle success
        console.log("results",results);
        localStorage.setItem("token", response.data[0].token);   //storing the token in localstorage
        navigate('/')
      // console.log(userData.data[0].title);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  };

  return (
    <React.Fragment>
      <form autoComplete="off" onSubmit={handleSubmit} className="form-container">
        <h1>Signin</h1>
        <TextField
          id="userName"
          name="userName"
          label="userName"
          defaultValue=""
          fullWidth
          sx={{ mb: 3 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <AccountCircle />
              </InputAdornment>
            ),
          }}
        />
        <span className="error-message">{state.userNameError}</span>

        <TextField
          id="password"
          name="password"
          label="Password"
          type="password"
          defaultValue=""
          fullWidth
          sx={{ mb: 3 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
        />
        <span className="error-message">{state.passwordError}</span>

        <Button variant="outlined" color="secondary" type="submit">
          Login
        </Button>

        <small>
        Need an account? <Link to="/home">Register here</Link>
      </small>
      </form>

      
    </React.Fragment>
  );
}

export default Loginform;