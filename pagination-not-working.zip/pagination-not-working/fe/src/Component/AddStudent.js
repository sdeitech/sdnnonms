import { useForm } from 'react-hook-form';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import { useState } from 'react';
import { TextField } from '@mui/material';
import Button from '@mui/material/Button';
import axios from 'axios';
import validateUser from '../helper /validation';

const AddStudentDetails = () => {

    const [studentInput, setStudentInput] = useState({
        firstName: '',
        lastName: '',
        email: '',
        english: '',
        science: '',
        maths: ''
    })

    const [errors, setErrors] = useState({});

    const handleSubmit = async (e) => {
        e.preventDefault()

        const validationErrors = validateUser(studentInput);
        if (Object.keys(validationErrors).length === 0) {
            console.log('Form data submitted:', studentInput);

            // Perform form submission or API call here
            if (!isNaN(English) && !isNaN(Science) && !isNaN(Maths)) {
                const total = English + Science + Maths
                const percentage = (total / 3).toFixed(2)

                let grade;
                if (percentage >= 90 && percentage <= 100) {
                    grade = 'A'
                } else if (percentage >= 80 && percentage <= 90) {
                    grade = 'B'
                } else {
                    grade = 'C'
                }

                const updatedStudentInput = {
                    ...studentInput,
                    percentage,
                    grade
                }

                axios({
                    method: 'post',
                    url: `http://localhost:3002/api/student`,
                    data: updatedStudentInput,
                }).then(function (response) {
                    console.log(response)
                    console.log("added Sucessfully")
                    Swal.fire('Success' ,'Data Added SucessFully', 'success')

                }).catch(function (error) {
                    console.log(error)
                })
            }


        } else {
            setErrors(validationErrors);
        }

        const English = parseFloat(studentInput.english)
        const Science = parseFloat(studentInput.science)
        const Maths = parseFloat(studentInput.maths)


    }


    return (
        <form onSubmit={handleSubmit}>
            <div>
                <TextField
                    id="firstName"
                    name='firstName'
                    label="First Name"
                    variant="outlined"
                    onChange={event => { setStudentInput({ ...studentInput, firstName: event.target.value }) }}
                />
                {errors.firstName && <p className="error">{errors.firstName}</p>}

                <TextField
                    id='lastName'
                    name=''
                    label='Last Name'
                    onChange={event => { setStudentInput({ ...studentInput, lastName: event.target.value }) }}
                />
                {errors.lastName && <p className="error">{errors.lastName}</p>}


                <TextField
                    id='email'
                    label='Email'
                    onChange={event => { setStudentInput({ ...studentInput, email: event.target.value }) }}

                />
                {errors.email && <p className="error">{errors.email}</p>}


                <TextField
                    id='english'
                    label='English'
                    onChange={event => { setStudentInput({ ...studentInput, english: event.target.value }); }}

                />
                {errors.english && <p className="error">{errors.english}</p>}


                <TextField
                    id='science'
                    label='Science'
                    onChange={event => { setStudentInput({ ...studentInput, science: event.target.value }); }}

                />
                {errors.science && <p className="error">{errors.science}</p>}


                <TextField
                    id='maths'
                    label='Maths'
                    onChange={event => { setStudentInput({ ...studentInput, maths: event.target.value }); }}

                />
                {errors.maths && <p className="error">{errors.maths}</p>}

            </div>

            <Button variant='outlined' color='secondary' type='submit'>
                Save
            </Button>
        </form>
    );
};

export default AddStudentDetails;