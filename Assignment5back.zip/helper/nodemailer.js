
//export default sendMailToUser;
import nodemailer from  "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "tarundakhore@gmail.com",
    pass: "tgsmdnyvfdxpicjg"
  },
  secure:false
});

export const sendMailToUser = async (to, text) => {
  const mailOptions = {
    from:"tarundakhore@gmail.com",
    to: to,
    subject: "your credential",
    text: text,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("mail sent");
    return { status: true };
  } catch (error) {
    console.log(error.message);
    console.log({ status: false });
  }
};





