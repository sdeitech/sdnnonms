
def addMarkSub(subs):
  marks=[]
  for sub in subs:
    while True : 
        add = int(input(f"Enter mark for {sub}"))
        if(0<add <=80):
            marks.append(add)
            break
  print(marks)
  return marks

def addInternalMark(subs):
  marks=[]
  for sub in subs:
    while True : 
        add = int(input(f"Enter INternal mark for {sub}"))
        if(0<add <=20):
            marks.append(add)
            break
  print(marks)
  return marks


def Grade(subject_marks,internal_mark):
  grade=[]
  for a,b in zip(subject_marks,internal_mark):
    if(a+b >= 90):
        grade.append('A')
    elif(a+b>=80 and a+b <90):
        grade.append('B')
        
    elif(a+b>=60 and a+b <80):
        grade.append('c')
    else: 
        grade.append('f')

  print("grade",grade)
  return grade

  


def calculate_result(marks,internal_mark):
  total_marks_subject = sum(marks)
  total_marks_internal = sum(internal_mark)
  total_marks = total_marks_internal+total_marks_subject
  overall_grade=[]

  print(total_marks ,len(marks))
  percentage = (total_marks/(len(marks)*100))*100

  for mark in marks:
    if(mark < 50):
      result_status = "failed"
    else:
      result_status="passed"
  if(percentage>90):
    overall_grade.append('A')
  elif(percentage>=80 and percentage <90):
    overall_grade.append('B')
  elif(percentage>=70 and percentage <80):
    overall_grade.append('C')

  else :
    overall_grade.append('F')
      
     
  return percentage,result_status ,overall_grade ,total_marks


def displayResult(subName , sub_mark,internal_mark,percentage,result_status,total_marks,overall_grade,grade):
   print(subName , sub_mark,internal_mark,percentage,result_status,total_marks,overall_grade,grade)
   print("===========================================================================================")
   print("===========================================================================================")
    #    print(sub , "|" , thmark ,"|" , inmark , "|" , grade,"|"  )
   for sub , thmark , inmark , grade in zip(subName ,sub_mark, internal_mark , grade):
      print(sub , "|" , thmark ,"|" , inmark , "|" , grade,"|"  )

def main():
  semester=[1,2,3]
  sub =[
        ["marathi","eng","hin"],
        ["marathi","eng","hin","sci"],
        ["marathi","eng","hin","sci","chem"],
      ]
  sem = int(input("enter sem"))
  if 0 < sem < 9:
   print(sub , "usesemr")
  else: 
    print("error")

  add =sub[sem-1]
  print(add ,"add")
  sub_mark=addMarkSub(add)
  internal_mark=addInternalMark(add)
  grade = Grade(sub_mark,internal_mark)
  percentage ,result_status ,overall_grade ,total_marks = calculate_result(sub_mark,internal_mark) 
  print(percentage ,result_status)
  displayResult(add ,sub_mark,internal_mark,percentage,result_status,total_marks,overall_grade,grade)



main()