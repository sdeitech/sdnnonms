import express from 'express';

import {Register} from '../controller/userController';
import { middlewareUpload } from '../middleware/multer';

const route=express.Router();

route.post("/user/register",middlewareUpload,Register);

export default route;