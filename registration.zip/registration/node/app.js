import express from "express";
import cors from 'cors'
import bodyParser from 'body-parser';
import path from 'path'
import route from './router/userRoute.js'

const app=express();

app.use(express.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit:'50mb ' ,extended:false}));
app.use("",express.static(path.join("profiles")))

app.use(cors({origin:"*"}))
app.use('/',route);

export default app;