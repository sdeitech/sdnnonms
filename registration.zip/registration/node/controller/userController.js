import bcrypt from 'bcrypt';
import user from '../model/userModel.js'

export const Register=async(req,res)=>
{
    try {
        const profile=req.file?.filename;
        const {email,password}=req.body;
        const hashPassword=await bcrypt.hash(password,10);
        const newuser=new user({
            email,
            password:hashPassword,
            profile:profile
        })

        console.log("newUser",newuser);
        await newuser.save();
        res.status(200).json(newuser);
        
    } catch (error) {
        res.status(500).json({message:"error while registration"});
    }
}