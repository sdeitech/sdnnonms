import { Publiclayout } from "../layout/Publiclayout";
import { Signup } from "../component.js/Signup";
const publicroute=[
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Signup/></Publiclayout>
    }
]
export default publicroute;
