import publicroute from "./publicroute";
import { createBrowserRouter } from "react-router-dom";
const routers = createBrowserRouter(
    [...publicroute,]
)

export default routers;