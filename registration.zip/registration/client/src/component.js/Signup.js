import React, { useState } from 'react';
import axios from 'axios';

export const Signup = () => {

  const [formData, setFormData] = useState({
    email: '',
    password: '',

  })
  const [profile, setProfile] = useState(null)

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

  };

  const handleFileChange = (e) => {
    setProfile(e.target.files[0]);
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userData = new FormData();
    userData.append("email", formData.email);
    userData.append("password", formData.password);
    userData.append("profile", profile);

    try {
      console.log("gggg")
      const result = await axios.post('http://localhost:4000/user/register', userData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          }
        }
      );
      console.log(result, "result")
    } catch (error) {
      console.log("error while registering ")
    }
  }
  return (
    <div>
      <h2>register users</h2>
      <form onSubmit={handleSubmit} encType='multipart/form-data'>
        <input
          type="email"
          name="email"
          value={formData.email}
          placeholder='email'
          onChange={handleChange}
        />
        <br />
        <input
          type='password'
          name="password"
          value={formData.password}
          placeholder='password'
          onChange={handleChange}
        />
        <br />
        <input
          type="file"
          name="profile"
          accept='profiles/*'
          onChange={handleFileChange}></input>
        <br />

        <button type="submit">register</button>
      </form>
    </div>
  )
}
