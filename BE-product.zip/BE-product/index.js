const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();
const PORT = 3007;
const productRoute = require('./Route/product-route')
const cors = require('cors')

app.use(bodyParser.json());

app.use(cors())

app.use('/api', productRoute)

app.listen(PORT, () => {
    console.log(`Product app listining on port ${PORT}`);
});

