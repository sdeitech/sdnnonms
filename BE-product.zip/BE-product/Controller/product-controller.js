const Product = require("../Model/product-model")

const createProduct = async (req, res) => {
    try {
        const product = new Product(req.body)
        await product.save()
        res.status(201).json(product)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const fetchproduct = async (req, res) => {

    try {
        const { page, limit, search } = req.query

        const Searching = {
            $or: [
                { productName: { $regex: search || '', $options: 'i' }, },
                { productDesc: { $regex: search || '', $options: 'i' }, },
            ]
        }

        const product = await Product.find(Searching).select()
            .limit(limit)
            .skip((page - 1) * limit)
            .sort({ createdAt: -1 })
        res.status(201).json(product)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const fetchProductById = async (req, res) => {
    try {
        const { id } = req.params
        const product = await Product.findById(id)
        res.status(200).json(product)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const updateProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};




module.exports = {createProduct, fetchproduct, fetchProductById, updateProduct, deleteProduct}