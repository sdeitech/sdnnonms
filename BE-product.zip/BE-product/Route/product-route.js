const express = require('express')
const router = express() 
const productController = require('../Controller/product-controller')

router.post('/product', productController.createProduct)
router.get('/product', productController.fetchproduct)
router.get('/product/:id', productController.fetchProductById)
router.put('/product/:id', productController.updateProduct)
router.delete('/product/:id', productController.deleteProduct)




module.exports = router