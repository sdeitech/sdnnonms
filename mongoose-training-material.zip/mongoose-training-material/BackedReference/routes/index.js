import express from "express";

const testRouter = require('./testRouter')
const routes = express.Router();

routes.use('/users', testRouter)


module.exports = routes