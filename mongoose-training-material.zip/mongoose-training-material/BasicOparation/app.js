const { MongoClient, ObjectId } = require("mongodb");

// Connection URL
const url = "mongodb://localhost:27017";
const client = new MongoClient(url);

// Database Name
const dbName = "training";
let collection; // Declare collection globally

const createConnection = () => {
  return new Promise(async (resolve, reject) => {
    await client.connect();
    const db = client.db(dbName);
    collection = db.collection("users");
    console.log('Connected successfully');
    resolve(true);
  })
}

async function insertUser(user) {
    try {
      // Ensure the collection is initialized
      if (!collection) {
        throw new Error("Collection is not initialized.");
      }
  
      // Insert the user document
      const result = await collection.insertOne(user);
      console.log("User inserted:", result);
    } catch (error) {
      console.error("Error inserting user:", error);
    }
}
async function findUser() {
    try {
      // Ensure the collection is initialized
      if (!collection) {
        throw new Error("Collection is not initialized.");
      }
  
      // Insert the user document
      const notFound = await collection.findOne({ name: "ask" });
      const found = await collection.findOne({ name: "Akshay" });
      console.log("User not found:", notFound);
      console.log("User found:", found);
    } catch (error) {
      console.error("Error while finding user:", error);
    }
  }
(async () => {
   await createConnection()
  //Insert records
  const data = {
    name: 'Akshay Dev'
  }
  insertUser(data)

  //Find user
//   findUser()
})()