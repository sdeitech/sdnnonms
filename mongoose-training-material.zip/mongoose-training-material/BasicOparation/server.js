const { MongoClient, ObjectId } = require("mongodb");

// Connection URL
const url = "mongodb://localhost:27017";
const client = new MongoClient(url);

// Database Name
const dbName = "training";
let collection; // Declare collection globally

async function main() {
  // Use connect method to connect to the server
  await client.connect();
  console.log("Connected successfully to server");

  const db = client.db(dbName);
  collection = db.collection("users"); // Initialize the collection
  console.log("Collection initialized");

  return "done.";
}

// Example: Use the collection in another function
async function insertUser(user) {
  try {
    // Ensure the collection is initialized
    if (!collection) {
      throw new Error("Collection is not initialized.");
    }

    // Insert the user document
    const result = await collection.insertOne(user);
    console.log("User inserted:", result);
  } catch (error) {
    console.error("Error inserting user:", error);
  }
}
async function findUser() {
  try {
    // Ensure the collection is initialized
    if (!collection) {
      throw new Error("Collection is not initialized.");
    }

    // Insert the user document
    const notFound = await collection.findOne({ name: "ask" });
    const found = await collection.findOne({ name: "John Choi" });
    console.log("User not found:", notFound);
    console.log("User found:", found);
  } catch (error) {
    console.error("Error while finding user:", error);
  }
}
async function findAllUser() {
  try {
    // Ensure the collection is initialized
    if (!collection) {
      throw new Error("Collection is not initialized.");
    }

    // Insert the user document
    const found = await collection.find({name: "John Choi"}).toArray();
    console.log(" All User found:", found);

    //Without toArray ,method
    const foundwithCursor = await collection.find({name: "John Choi"}).toArray();
    await foundwithCursor.forEach(doc => {
      console.log(doc, 'doc');
    });
  } catch (error) {
    console.error("Error while finding user:", error);
  }
}
async function deleteUser(id) {
  try {
    // Ensure the collection is initialized
    if (!collection) {
      throw new Error("Collection is not initialized.");
    }

    // Insert the user document
    const deleted = await collection.deleteOne({ _id: new ObjectId(id) });
    console.log("user deleted:", deleted);
  } catch (error) {
    console.error("Error while deleting user:", error);
  }
}
async function countUser(name) {
  try {
    // Ensure the collection is initialized
    if (!collection) {
      throw new Error("Collection is not initialized.");
    }

    // Insert the user document
    const count = await collection.countDocuments({ name });
    console.log("user count:", count);
  } catch (error) {
    console.error("Error while user count:", error);
  }
}

// Run main first, and then use the insertUser function once the collection is ready
main()
  .then(() => {
    // Now you can safely use insertUser after the main has initialized the collection
    // return insertUser({ name: "John Doe", age: 39 });
    return findAllUser();
    // return findUser();
    // return deleteUser("66dad46719b592bb49db20a4");
    return countUser("John Choi");
  })
  .catch(console.error)
  .finally(() => client.close());
