const { MongoClient, ObjectId } = require("mongodb");

// Connection URL
const url = "mongodb://localhost:27017";
const client = new MongoClient(url);

// Database Name
const dbName = "training";
let collection; // Declare collection globally

const createConnection = () => {
    return new Promise(async (resolve, reject) => {
      await client.connect();
      const db = client.db(dbName);
      collection = db.collection("users");
      console.log('Connected successfully');
      resolve(collection);
    })
  }
  module.exports = createConnection