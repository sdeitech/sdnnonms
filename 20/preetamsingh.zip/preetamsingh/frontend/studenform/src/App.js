import './App.css';
import React, { useState, useEffect } from 'react';
import axios from "axios";
import Form from "react-bootstrap/Form";
import Snavbar from './Snavbar';

function Createstudent() {
    const [formData, setFormData] = useState({
        FirstName: "",
        LastName: "",
        Gmail: "",
        Marksinenglish: "",
        MarksinScience: "",
        MarksinMaths: ""
    });

    const [students, setStudents] = useState([]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault(); 
        try {
            await axios.post("http://localhost:4000/topost/students", formData);
            console.log("Your data has been posted:", formData);
            fetchData(); 
            handleReset(); 
        } catch (error) {
            console.error("Error posting data:", error);
        }
    };

    const handleReset = () => {
        setFormData({
            FirstName: "",
            LastName: "",
            Email: "",
            Marksinenglish: "",
            MarksinScience: "",
            MarksinMaths: ""
        });
    };

    const fetchData = async () => {
        try {
            const res = await axios.get("http://localhost:4000/toget/students");
            setStudents(res.data); 
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleview = (FirstName, LastName, Email, Marksinenglish, MarksinScience, MarksinMaths, percentage) => {
        alert(`Firstname: ${FirstName} ${LastName}\nEmail: ${Email}\nMarks in English: ${Marksinenglish}\nMarks in Science: ${MarksinScience}\nMarks in Maths: ${MarksinMaths}\nPercentage: ${percentage}%`);
    };

    const calculatePercentage = () => {
      const obtainlMarks = Number(formData.Marksinenglish) + Number(formData.MarksinScience) + Number(formData.MarksinMaths);
      console.log(obtainlMarks);
      let average = (obtainlMarks/300)*100;
      console.log(obtainlMarks);
      
      // average.toFixed(2);
      return average;
      
      return (obtainlMarks)
  };
  
  const gradeCalculate = function (percentage) {
    const a = "A";
    const b = "B";
    const c = "C";
    if (percentage >= 90 && percentage <= 100) {
      return a;
    } else if (percentage >= 60 && percentage <= 90) {
      return b;
    } else {
      return c;
    }
  };
    return (
        <div className="App">
            <Snavbar />
            <Form onSubmit={handleSubmit}>
                <Form.Group>
                    <Form.Label>First Name</Form.Label>
                    <Form.Control
                        type="text"
                        name="FirstName"
                        value={formData.FirstName}
                        placeholder="Enter first name"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control
                        type="text"
                        name="LastName"
                        value={formData.LastName}
                        placeholder="Enter last name"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="text"
                        name="Email"
                        value={formData.Email}
                        placeholder="Enter Email"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Marks in English</Form.Label>
                    <Form.Control
                        type="number"
                        name="Marksinenglish"
                        value={formData.Marksinenglish}
                        placeholder="Enter marks in English"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Marks in Science</Form.Label>
                    <Form.Control
                        type="number"
                        name="MarksinScience"
                        value={formData.MarksinScience}
                        placeholder="Enter marks in Science"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Marks in Maths</Form.Label>
                    <Form.Control
                        type="number"
                        name="MarksinMaths"
                        value={formData.MarksinMaths}
                        placeholder="Enter marks in Maths"
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <button type="submit" className="btn btn-primary">Submit</button>
                <button type="button" className="btn btn-secondary" onClick={handleReset}>Reset</button>
            </Form>

            <div className='table'>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Marks in English</th>
                            <th>Marks in Science</th>
                            <th>Marks in Maths</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {students.map((student, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{student.FirstName}</td>
                                <td>{student.LastName}</td>
                                <td>{student.Email}</td>
                                <td>{student.Marksinenglish}</td>
                                <td>{student.MarksinScience}</td>
                                <td>{student.MarksinMaths}</td>
                                <td>
                                    <button onClick={() => handleview(student.FirstName, student.LastName, student.Gmail, student.Marksinenglish, student.MarksinScience, student.MarksinMaths, calculatePercentage,gradeCalculate)}>View</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default Createstudent;
