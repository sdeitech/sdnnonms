const Student = require('../models/Form.Models');

exports.CreateStudents = async (req, res) => {
    try {
        console.log("you are creating user",req.body);
        const newStudent = new Student(req.body)
        await newStudent.save();
        // form email
        const percentage = () =>{
            const totalMarks = Number(req.body.Marksinenglish)+Number(req.body.MarksinScience)+Number(req.body.MarksinMaths);
            const average = (totalMarks/300)*100;
            average.toFixed(2);
            return average;
        }
        const result =percentage();
        console.log(result);
        sendmail(req.body.Email,results);
        

        console.log("you are created user");
        res.status(200).json(newStudent);
    } catch (error) {
        res.status(400).json({ error: error });

    }
};
// this is for form get function
exports.getStudents = async (req, res) => {
    try {
        console.log("we are in get section");
        const students = await Student.find();
        res.json(students);
        console.log("your students are:");
        
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};