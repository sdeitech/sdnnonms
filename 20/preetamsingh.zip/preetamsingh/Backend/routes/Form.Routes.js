const express = require('express');
const router = express.Router();
const FormController = require('../controller/Form.Controller');

router.get('/toget/students',FormController.getStudents); 
router.post('/topost/students',FormController.CreateStudents);
console.log("your router is ready");

module.exports = router;