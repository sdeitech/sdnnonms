const Nodemailer = require("nodemailer");
const transporter = Nodemailer.createTransport({
    host:'smtp.gmail.com',
    port : 587,
    secure:false ,
    auth :{
    user: 'singhpreetam134@gmail.com',
    pass:dnfqsbrjclqeoiof
}});
const mailoptions ={
   

};
function sendmail(email,percentage){
    transporter.sendMail({
        from:'singhpreetam134@gmail.com',
        to:`${email}`,
        subject:'result ',
        text:`you percentage is ${percentage}`,
    })
}