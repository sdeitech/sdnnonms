const express = require('express');
const bodyParser = require('body-parser')
const FormRoutes = require('./routes/Form.Routes');
const db = require('./db/Form.db');
const cors = require("cors");
const router = require('./routes/Form.Routes');
const app = express();
const PORT = 4000;

app.use(cors());
app.use (bodyParser.json());
app.use ('/',FormRoutes);
console.log("server is starting");

app.listen (PORT,() => {
    console.log(`Server is running on http://localhost:${PORT}`);
}
);