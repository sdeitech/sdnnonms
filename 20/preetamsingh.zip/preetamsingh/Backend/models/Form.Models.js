const mongoose = require('mongoose');
const FormSchema = new mongoose.Schema({
    FirstName : { type: String, required: true },
    LastName: { type: String, required: true },
    Email: { type: String , required: true},
    Marksinenglish : { type: String , required: true},
    MarksinScience : { type: String , required: true},
    MarksinMaths : { type: String , required: true},
    }
);
const Form = mongoose.model('Form', FormSchema);
module.exports = Form