import express from 'express';
const router = express.Router();
import  LogController from '../controllers/LoginandRegister.controller';
import uploadMiddleware from '../helper/multer';

router.post('/register', uploadMiddleware.single('image'), LogController.register);
router.post('/login', LogController.login);
router.get('/getdata/:id',LogController.getRegisterData);

module.exports = router;