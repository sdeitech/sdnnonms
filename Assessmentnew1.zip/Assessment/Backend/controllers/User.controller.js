import Profile from '../model/User.model';

// Create User 
const createUser = async (req, res) => {
    try {
        const newUser = new Profile(req.body);
        await newUser.save(); res.status(201).json(newUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get All User 
const getUser = async (req, res) => {
    console.log('getting');
    try {
        const users = await Profile.find();
        res.json({ users });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


//for getting paginated user
const paginateUser = async (req, res) => {
    const { page = 1, limit = 3, search = '' } = req.query;
    try {
        const query = {
            name: { $regex: search, $options: 'i' }, // Case-insensitive search
        };

        // Fetch users with pagination and search
        const user = await Profile.find()
            .skip((page - 1) * limit) // Skip users for pagination
            .limit(parseInt(limit)); // Limit users per pag

        const count = await Profile.countDocuments();
        console.log(count);
        // Respond with JSON data
        res.json({
            user,
            currentPage: parseInt(page),
            totalPages: Math.ceil(count / limit),
            totalRecords: count,
            search,
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Update user
const updateUser = async (req, res) => {
    try {
        const user = await Profile.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const viewData = async (req, res) => {
    try {
        const data = await Profile.findById({ _id: req.params.id });
        console.log("get by id");
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

module.exports = { createUser, getUser, paginateUser, updateUser , viewData}