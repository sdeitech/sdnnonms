import LogReg from '../model/login.model';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const register = async (req, res) => {
    try {
        console.log(req.file.path);


        const { firstname, lastname, email, password, DOB, gender, profile } = req.body;

        const hashedPassword = await bcrypt.hash(password, 10);

        const newuser = new LogReg({
            firstname, lastname,
            email, DOB, gender, profile: req.file.path,
            password: hashedPassword

        })

        console.log(newuser);
        await newuser.save();
        res.status(201).json(newuser);

    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getRegisterData = async (req, res) => {
    try {
        const user = await LogReg.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
}


const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await LogReg.findOne({ email });
        console.log(user);
        if (!user) {
            return res.status(400).json({ message: 'User not found' })
        }

        const isMatch = await bcrypt.compare(password, user.password);
        console.log(isMatch);
        if (!isMatch) {
            return res.status(401).json('Invalid credentials')
        }

        const token = jwt.sign({ email, password }, 'SecretKey', { expiresIn: '6h' });

        user.tokens = [{ token }];
        await user.save();

        res.status(200).json({ message: "Login Successfully", user, token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


module.exports = { register, getRegisterData, login }