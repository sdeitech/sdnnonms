require('dotenv/config');


export const messageID = {
"test":"abc"
}
export const messages = {
    imageType:"png"

} 