import mongoose from 'mongoose'

require('dotenv/config');

const NODE_ENV = process.env.NODE_ENV || "local"; //local

const config = require('../config/config.js');

const configuration=config.get(process.env.NODE_ENV);
console.log(configuration)
var options={
    user:configuration.DB.USERNAME,
    pass:configuration.DB.PASSWORD
}

const MONGOURI = `mongodb://${configuration.DB.HOST}:${configuration.DB.PORT}/${configuration.DB.DATABASE}`;
console.log(MONGOURI, "MONGOURI");
const InitiateMongoServer = async () => {
    try {
     console.log(">>>>>.");
     
        await mongoose.connect(MONGOURI, options);
        console.log("Connected to MongoDB Successfully !!", MONGOURI);
    } catch (e) {
        console.log(e);
        throw e;
    }
};

module.exports = InitiateMongoServer;





