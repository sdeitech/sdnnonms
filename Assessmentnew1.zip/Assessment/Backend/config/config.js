

const config = {
    local:{
        DB: {
            HOST:  "127.0.0.1",
            PORT:  "27017",
            DATABASE: "authenticationDB",
            USERNAME: "",
            PASSWORD:  "",
          },
        apiPort:4000
    },
    // "staging":{

    // },
    // "prod":{

    // },

}

export const get =function get(env){
    return config[env]
}

