import mongoose from 'mongoose';
// Define Item Schema
const userSchema = new mongoose.Schema({
    firstname: { 
        type: String, 
        required: true 
    },
    lastname: { 
        type: String, 
        required: true 
    },
    email: {
        type:String,
        required:true
    },
    tokens:[
        {
            token:{
                type:String,
                required: true
            }
        }

    ]
});

const Profile = mongoose.model('Profile', userSchema);
module.exports = Profile;
