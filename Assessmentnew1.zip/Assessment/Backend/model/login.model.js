import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    firstname: { type: String },
    lastname: { type: String },
    email: { type: String, required: true },
    password: { type: String, required: true },
    DOB: { type: Date },
    gender: { type: String },
    profile: { type: String }

});

const LogReg = mongoose.model('LogReg', userSchema);
module.exports = LogReg;