import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, } from 'react-router-dom';
import './login.css';

const Login = () => {
    const navigate = useNavigate();
    const [loginData, setLoginData] = useState({
        email: '',
        password: '',
    });
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setLoginData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            console.log("getting");
            const response = await axios.post('http://localhost:4000/auth/login', loginData);
            console.log(response);
            const { status, data } = response;

            console.log("login successfully", data);


            localStorage.setItem('userdata',JSON.stringify(response.data.user));

            console.log(response.data)
            navigate('/user');
        } catch (err) {
            console.log(err)
            setError('Login failed. Please check your credentials.');
        }
       
    };

    const GotoSignUp = () => {
        navigate("/register");
    };

    return (
        <div>
            <h2>Login</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form className="form-container" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="text"
                        name="email"
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        onChange={handleChange}
                        required
                    /></div>
                <div className="form-group">
                    <button type="submit" className='submit-button' >Login</button>
                </div>
                <p>Don't have account? <button type="submit" onClick={GotoSignUp}>Sign Up</button></p>
            </form>
        </div>
    );
};

export default Login;


