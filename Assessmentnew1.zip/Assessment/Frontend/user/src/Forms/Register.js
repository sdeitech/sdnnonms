
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
    const navigate = useNavigate();
    const [data, setdata] = useState([]);
    const [regformData, setRegFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        DOB: '',
        password: '',
        gender: '',
        profile: '',
        married: ''

    });

    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setRegFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const fileonchange = (e) => {
        const file = e.target.file[0];
        setRegFormData({ ...regformData, profile: file });
    }



    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const formdata = new FormData();
            Object.keys(regformData).forEach(key => {
                if (key === 'firstname') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);
                }
                if (key === 'lastname') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);}
                if (key === 'email') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);}
                    if (key === 'DOB') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);}
                if (key === 'password') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);
                if (key === 'gender') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);}
                 if (key === 'profile') {
                    formdata.append(key, regformData[key]);
                } else {
                    formdata.append(key, regformData[key]);
                }
             }
        });
            const response = await axios.post('http://localhost:4000/auth/register', FormData);
            setdata([...data, response.data]);
            setRegFormData({
                firstname: '',
                lastname: '',
                email: '',
                DOB: '',
                password: '',
                gender: '',
                profile: '',
                married: ''

            })

            localStorage.setItem('userdata', JSON.stringify(response.data.newuser))
            setError('You Registered Successfully! Now please click on Login');
            console.log("Registered successfully!");
        } catch (err) {
            setError('Registration Failed!');
        }

    };
    const GotoLogin = () => {
        navigate("/")
    }
    return (
        <div>
            <h2>Registration</h2>

            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form className="form-container" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>First Name:</label>
                    <input
                        type="text"
                        name="firstname"
                        value={regformData.firstname}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lastname"
                        value={regformData.lastname}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={regformData.email}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>DOB:</label>
                    <input
                        type="date"
                        name="DOB"
                        value={regformData.DOB}
                        onChange={handleChange}
                        required
                    /></div>


                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={regformData.password}
                        onChange={handleChange}
                        required
                    /></div>
                <div className='form-group'>
                    <label>Gender:</label>
                    <div>
                        <input
                            type="radio"
                            name='gender'
                            value="male"
                            checked={regformData.gender === 'male'}
                            onChange={handleChange} />Male
                        <input
                            type='radio'
                            name='gender'
                            value="female"
                            checked={regformData.gender === 'female'}
                            onChange={handleChange} />Female
                    </div>
                </div>

                <input
                    type="checkbox"
                    name='Married'
                    value="Married"
                    onChange={handleChange} />
                <label>Married</label>

                <label>Select Profile Picture: </label>
                <input
                    type="file"
                    value={regformData.profile}
                    onChange={fileonchange} />

                <div className="form-group">
                    <button type="submit" className='submit-button' >Register </button>
                </div>
                <div className="form-group">
                    <button type="submit" className='submit-button' onClick={GotoLogin}>Login Now</button>
                </div>
            </form>
        </div>
    );
};
export default Register;










