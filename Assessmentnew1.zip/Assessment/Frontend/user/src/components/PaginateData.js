import React,{useState,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import Pagination from "./Pagination";
import axios from 'axios';

import React from 'react'

function PaginateData() {
    const[data,setData]=useState([]);
    const[search,setSearch]=useState('');
    const[currentPage,setCurrentPage]=useState(1);
    const[perPage,setPerpage]=useState(3);

    const indexoflastrecord=currentPage*perPage;
    const indexoffirstrecord=indexoflastrecord-perPage;
    const currentRecords=data.slice(indexoffirstrecord,indexoflastrecord);
    const nPages=Math.ceil(data.length/perPage);

    const handleSearch=(data)=>{
        setSearch(data);
    };
    const filteredRecords = currentRecords.filter((data) =>
        data?.firstName.toLowerCase().includes(search.toLowerCase())
    );
         return (
            <div className='container mt-5'>
            <h2>Simple Pagination Example in React</h2>
            <Records data={filteredRecords} search={search} handleSearch={handleSearch} />
            <Pagination
                nPages={nPages}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}/>
      
    </div>
  )
}

export default PaginateData;
