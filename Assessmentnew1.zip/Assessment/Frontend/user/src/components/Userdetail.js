import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './user.css'

function Userdetail() {
    const navigate = useNavigate();
    
    const [data, setData] = useState([]);
    const [view, setView] = useState(null);
    

    // const[search,setSearch]=useState('');
    // const[currentPage,setCurrentPage]=useState(1);
    // const[perPage,setPerpage]=useState(3);

    // const indexoflastrecord=currentPage*perPage;
    // const indexoffirstrecord=indexoflastrecord-perPage;
    // const currentRecords=data.slice(indexoffirstrecord,indexoflastrecord);
    // const nPages=Math.ceil(data.length/perPage);

    // const handleSearch=(data)=>{
    //     setSearch(data);
    // };
    // const filteredRecords = currentRecords.filter((data) =>
    //     data?.firstName.toLowerCase().includes(search.toLowerCase())
    // );



    // To fetch the data
    const fetchData = async () => {
        let token=localStorage.getItem('userdata');

        let auth={
            headers:{
                Authorization: `bearer ${token}`
            },
        };
        try {
            const response = await axios.get('http://localhost:4000/users/get',auth);
            console.log(response.data.users);

            setData(response.data.users);

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const handleadd = async (id) => {
       navigate('/add')
    };

    const viewdata = async (id) => {
        try {

            const response = await axios.get(`http://localhost:4000/users/view/${id}`);

            setView(response.data);
            console.log(response, "geting")

        } catch (error) {
            console.log('Error in getting data:', error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    return (
        <div>
            <h2>DashBoard</h2>
            <button onClick={()=>navigate('/myprofile')}>My Profile</button>
            <table>
                <thead>
                    <tr>
                       
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((user, index) => (
                        <tr key={user._id}>
                            <td>{user.firstname}</td>
                            <td>{user.lastname}</td>
                            <td>{user.email}</td>
                            <td>
                                <button onClick={() => viewdata(user._id)}>View</button>
                                <button onClick={()=>navigate('/add')}>Update</button>
                                
                                
                            </td>
                        </tr>

                    ))}
                    <button onClick={() => handleadd()}>Add User</button>
                    <button onClick={()=>navigate('/')}>LogOut</button>
                </tbody>
            </table>

            {view && (
                <div>
                    <h3>Details:</h3>

                    <div key={view._id}>
                        <p>First Name: {view.firstname}</p>
                        <p>Last Name: {view.lastname}</p>
                        <p>Email: {view.email}</p>
                        
                    </div>

                </div>
            )}
            {/* <div className='container mt-5'>
                 <h2>Simple Pagination Example in React</h2>
                <Records data={filteredRecords} search={search} handleSearch={handleSearch} />
                <Pagination
                    nPages={nPages}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}/>
      
                 </div> */}
        </div>

    );
};

export default Userdetail;
