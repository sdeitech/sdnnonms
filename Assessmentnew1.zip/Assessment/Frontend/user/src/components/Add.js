import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './add.css';

const Add = () => {
    const navigate = useNavigate();
    const [postData, setPostData] = useState({
        firstname: "",
        lastname: '',
        email: "",
        DOB: "",
        gender: ''

    });

    const [data, setData] = useState([]);
    const [edit, setEdit] = useState(null);


    const handleChange = (e) => {
        const { name, value } = e.target;
        setPostData({
            ...postData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!edit) {
            try {
                await axios.post('http://localhost:4000/users/post', postData);
                setPostData({
                    firstname: "",
                    lastname: '',
                    email: "",
                    DOB: "",
                    gender: ''
                });
            
            } catch (error) {
                console.error('Error posting data:', error);
            }


        } else if (edit) {
            try {
                await axios.put(`http://localhost:4000/users/put/${edit}`, postData);
                setEdit(null);
                setPostData({
                    firstname: "",
                    lastname: '',
                    email: "",
                    DOB: "",
                    gender: ''
                });

            } catch (error) {
                console.error('Error updating data:', error);
            }
        } else {

        }
    }

    const handleEdit=(user)=>{
       
        setEdit(user._id);
        setPostData({
            firstname: user.firstname,
            lastname: user.lastname,
            email: user.email,
            DOB: user.DOB,
        });
       
    }



    return (
        <div>
            <h1 > Add user</h1 >
            <form onSubmit={handleSubmit}>
                <label>First Name: </label>
                <input
                    type="text"
                    name="firstname"
                    placeholder="First Name"
                    value={postData.firstname}
                    onChange={handleChange}
                    required
                />
                <label>Last Name: </label>
                <input
                    type="text"
                    name="lastname"
                    placeholder="Last Name"
                    value={postData.lastname}
                    onChange={handleChange}
                    required
                /><br></br>
                <label>Email: </label>
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={postData.email}
                    onChange={handleChange}
                    required
                /><br></br>
                <label>Date of Birth: </label>
                <input
                    type="date"
                    name="DOB"
                    placeholder="DOB"
                    value={postData.DOB}
                    onChange={handleChange}
                    required />
                    <br></br>
                <label>Gender : </label>
                <input
                        type="radio"
                        name='gender'
                        value="male"
                        checked={postData.gender === 'male'}
                        onChange={handleChange} />Male
                        <input
                        type='radio'
                        name='gender'
                        value="female"
                        checked={postData.gender === 'female'}
                        onChange={handleChange} />Female
                <br></br>
                <button type="submit" >{edit ? "Update" : "Add"} User</button>

            </form>
            <button onClick={() => navigate('/user')}>Back to DashBoard</button>
            {/* <Add handleEdit={handleEdit}/> */}
        </div>
    )
}

export default Add;