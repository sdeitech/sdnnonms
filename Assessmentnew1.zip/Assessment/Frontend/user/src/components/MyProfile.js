import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function MyProfile() {
  
  const navigate=useNavigate();
  const user=localStorage.getItem("userdata");
  const newuser=JSON.parse(user);
  console.log(newuser, "asdf");



  return (
    <div>
      <h3>My Profile</h3>
      <p>FirstName: {newuser.firstname}</p>
      <p>LastName: {newuser.lastname}</p>
      <p>Email: {newuser.email}</p>  
      <p>Date of Birth:{newuser.DOB}</p>
      <p>Gender:{newuser.gender}</p>          
       <button type="submit">UPDATE</button>        
     <button onClick={()=>navigate('/user')}>Go to DashBoard</button>
    </div>
  )
}

export default MyProfile
