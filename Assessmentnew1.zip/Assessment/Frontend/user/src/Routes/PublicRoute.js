import {React} from 'react';
import Login from '../Forms/Login';
import PublicLayout from '../Layouts/PublicLayout';
import Register from '../Forms/Register';
import Userdetail from '../components/Userdetail';
import Add from '../components/Add';
import MyProfile from '../components/MyProfile';

const PublicRoute=[
    {
        path:"/",
        exact:true,
        element: <PublicLayout><Login/></PublicLayout>
    },
    {
        path:"/Register",
        exact:true,
        element:<PublicLayout><Register/></PublicLayout>
    },
    {
        path:"/user",
        exact:true,
        element:<PublicLayout><Userdetail/></PublicLayout>
    },
    {
        path:'/add',
        exact:true,
        element:<PublicLayout><Add/></PublicLayout>
    },
    {
        path:'/myprofile',
        exact:true,
        element:<PublicLayout><MyProfile/></PublicLayout>
    }


];
export default PublicRoute;