import React,{useEffect} from "react";
import {useNavigate}from "react-router";


const PrivateLayout=({children})=>{
    let token=localStorage.getItem('userdata');
    let navigate=useNavigate();
    useEffect(()=>{
        if (!token){
            navigate("/login")
        }
    }, [token, navigate]);

    return (

        <>
        {children}
        </>
    )
};
export default PrivateLayout;