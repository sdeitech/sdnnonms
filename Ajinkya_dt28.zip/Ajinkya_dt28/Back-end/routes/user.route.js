const router = require('express').Router()
const { register, logIn } = require('../controller/user.controller')
const verifyToken = require('../middleware/verifyToken')
const {isRequestValidated, validateSignUpRequest, validateSignIpRequest} = require('../validate/auth')

router.route("/register").post(validateSignIpRequest, isRequestValidated, register);

router.route("/login").post(validateSignUpRequest, isRequestValidated, logIn);

router.get('/protected', verifyToken, (req, res) => {
    res.send(req.user)
});



module.exports = router