const express = require('express');
// const router = express.Router();
const router = require('express').Router()
const itemController = require('../controller/item-controller');
//const verifyToken = require('../middleware/verifytoken.js')

// CRUD routes using controller methods
router.post('/add',itemController.createItem); // Create
router.get('/getItem', itemController.getItem); //Read
router.put('/:id', itemController.updateItem); // Update
router.delete('/:id', itemController.deleteItem); // Delete

module.exports = router;