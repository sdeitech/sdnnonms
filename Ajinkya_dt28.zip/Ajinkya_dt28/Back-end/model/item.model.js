const mongoose = require('mongoose');
// Define Item Schema
const itemSchema = new mongoose.Schema({
 SrNo: { type: Number, required: true },
 firstname: { type: String, required: true },
 lastname: { type: String, required: true },
 email: { type: String, required: true },
});
// Create Item Model
const Item = mongoose.model('Item', itemSchema);
module.exports = Item;