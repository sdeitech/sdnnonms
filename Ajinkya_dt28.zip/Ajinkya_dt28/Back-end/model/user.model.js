const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    firstName: {type:String , require:true, trim : true, min:2, max:20},
    lastName: {type:String , require:true, trim : true, min:2, max:20},
    email : {type:String, require:true, trim: true, unique: true, lowercase: true},
    DOB :{type:String, require:true},
    password:{type:String, require :true},
    gender :{type:String, require:true}
})

const User = mongoose.model("User" , UserSchema)

module.exports = User
