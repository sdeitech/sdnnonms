require('dotenv/config');


 export const config = {
    "local":{
        DB: {
            HOST:  "127.0.0.1",
            PORT:  "27017",
            DATABASE:  "FormDetails",
            USERNAME: "",
            PASSWORD:  "",
          },
        apiPort:"5000"  
    },
    "staging":{

    },
    "prod":{

    },

}


