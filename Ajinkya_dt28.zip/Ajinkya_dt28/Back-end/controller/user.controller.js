const bcrypt = require("bcrypt");
const User = require("../model/user.model");
const jwt = require('jsonwebtoken')



exports.register = async (req, res) => {
  const { firstName,lastName, email, DOB, password, gender } = req.body;
  if (!(firstName && lastName && DOB && email && password && gender)) {
    return res
      .status(400)
      .json({ status: 400, message: "all field are mandatory " });
  }
  try {
    const oldUser = await User.findOne({ email: email });
    console.log(oldUser);

    if (oldUser) {
      return res
        .status(409)
        .json({ status: 409, message: "User already exists." });
    }
// 
    const hashPassword = await bcrypt.hash(password, 10);
    req.body.password = hashPassword;
    console.log(hashPassword);
    const newUser = new User(req.body);

    newUser.save();

    return res
      .status(201)
      .json({
        status: 201,
        message: "user inserted Successfully",
        user: newUser,
      });
  } catch (error) {
    console.log(error.message);
    res
      .status(400)
      .json({
        status: 400,
        message: "faild to register user ",
        error: error.message,
      });
  }
};


exports.logIn = async(req,res)=>{
  const {email , password } = req.body
  if(!(email && password)){
   return  res.status(400).json({
        message:"all field are mandatory",
        status:400
    })
  }
  try {
    const user = await User.findOne({email:email})
    console.log(user)
    if(!user){
      return res.status(400).json({message:"user not exit"})
    }

    const isCorrect = await bcrypt.compare(password ,user.password )
    console.log(isCorrect);
    

    if(isCorrect){
       const token = jwt.sign({email},"process.env.SECRET_TOKEN_KEY" ,{ expiresIn:'1hr'})

      return res.status(200).json({message:"token generated successfully" , token : token})
    }
    
    return res.status(400).json(
        {message:"wrong password , logIn faild " , status:400}
    )

  } catch (error) {
    res.status(400).json({message:"login Faild" , error : error.message})
    
  }


}




