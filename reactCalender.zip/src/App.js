import "./App.css";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import React, { useState } from "react";

function App() {
  const localizer = momentLocalizer(moment);

  const [events, setEvents] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [eventTitle, setEventsTitle] = useState("");

  const handleSelectSlot = (slotInfo) => {
    setShowModal(true);
    setSelectedDate(slotInfo.start);
  };

  const saveEvent = () => {
    if (eventTitle && selectedDate) {
      const newEvent = {
        title: eventTitle,
        start: selectedDate,
        end: moment(selectedDate).add(1, "hours").toDate(),
      };
      setEvents([...events, newEvent]);
      setShowModal(false);
      setEventsTitle("");
    }
  };

  return (
    <div style={{ height: "500px" }}>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        style={{ margin: "50px" }}
        selectable={true}
        onSelectSlot={handleSelectSlot}
      />

      {showModal && (
        <div
          class="modal"
          style={{
            display: "block",
            backgroundColor: "rgba(0.0.0.0.5)",
            position: "fixed",
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          }}
        >
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <button
                  type="button"
                  class="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div class="modal-body">
                <label>Event Title:</label>
                <input
                  type="text"
                  id="eventTitle"
                  className="form-control"
                  value={eventTitle}
                  onChange={(e) => setEventsTitle(e.target.value)}
                />
              </div>
              <div class="modal-footer">
                <button type="button" onClick={saveEvent}>
                  Save changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
