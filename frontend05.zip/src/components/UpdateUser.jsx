import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const UpdateUser = () => {
  const navigate = useNavigate();
  const token = useSelector((state) => state.loginUser.userToken);

  // const data = localStorage.getItem("token");
  // const userData = JSON.parse(data);

  const userData = useSelector((state) => state.loginUser.token);

  const [formData, setFormData] = useState({
    firstname: userData?.firstname,
    lastname: userData?.lastname,
    email: userData?.email,
    DOB: userData?.DOB,
    profile: null,
    married: userData?.married || false, // Default to false if no value is found
    gender: userData?.gender || "", // Default to empty if no value is found
  });

  const apiUrl = "http://localhost:8001/api";

  const handleChange = (e) => {
    const { name, value, type, files, checked } = e.target;
    if (type === "file") {
      setFormData({ ...formData, [name]: files[0] });
    } else if (type === "checked") {
      setFormData({ ...formData, [name]: checked });
    } else if (type === "checkbox") {
      setFormData({ ...formData, [name]: checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  console.log(formData, "data deom form");
  const fetchProfile = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put(
        `${apiUrl}/getuser/${localStorage.getItem("id")}`,
        formData,
        {
          headers: {
            Authorization: token,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log(res.data);
      localStorage.setItem("token", JSON.stringify(res.data));
      setFormData(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div
      style={{
        justifyContent: "center",
        display: "flex",
        alignItems: "center",
        border: "solid 3px",
        padding: "20px",
        flexDirection: "column",
        width: "500px",
        margin: "auto",
        marginTop: "50px",
        borderRadius: "10px",
      }}
    >
      <h1>My Profile</h1>
      <div>
        <img
          src={`http://localhost:8001/getimage/${userData?.profile}`}
          height={70}
          width={70}
          alt=""
          style={{ borderRadius: "50%", border: "1px solid black" }}
        />
      </div>
      <form
        onSubmit={fetchProfile}
        style={{ display: "flex", flexDirection: "column", width: "100%" }}
      >
        <input
          type="text"
          name="firstname"
          value={formData?.firstname}
          placeholder="Enter firstname"
          onChange={handleChange}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="tel"
          name="lastname"
          value={formData?.lastname}
          placeholder="Enter lastname"
          onChange={handleChange}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="text"
          name="email"
          value={formData?.email}
          placeholder="Enter email"
          onChange={handleChange}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="date"
          name="DOB"
          value={formData?.DOB}
          placeholder="Enter DOB"
          onChange={handleChange}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <label>
          <input
            type="checkbox"
            name="married"
            checked={formData.married}
            onChange={handleChange}
          />
          Married
        </label>
        <div
          style={{
            marginBottom: "10px",
            display: "flex",
            justifyContent: "space-around",
          }}
        >
          <label>
            Male
            <input
              type="radio"
              name="gender"
              value="male"
              checked={formData.gender === "male"}
              onChange={handleChange}
              style={{ marginLeft: "5px" }}
            />
          </label>
          <label>
            Female
            <input
              type="radio"
              name="gender"
              value="female"
              checked={formData.gender === "female"}
              onChange={handleChange}
              style={{ marginLeft: "5px" }}
            />
          </label>
        </div>
        <input
          type="file"
          name="profile"
          onChange={handleChange}
          style={{ marginBottom: "10px", border: "none" }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            borderRadius: "5px",
            backgroundColor: "#007bff",
            color: "#fff",
            border: "none",
            cursor: "pointer",
          }}
        >
          Update
        </button>
      </form>
    </div>
  );
};

export default UpdateUser;
