import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import toast, { Toaster } from 'react-hot-toast';
import { useSelector } from "react-redux";



function AddUser() {
  // const id = localStorage.getItem("id")


  const id = useSelector(state => state.loginUser.userId)
  

  const navigate = useNavigate();
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    email: "",
  });


  console.log(user,"hhahksh")
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const myToken = JSON.parse(localStorage.getItem("token"))
    console.log(myToken,"hddde")
    user["userId"] = myToken.id;
    try {
      const response = await axios.post(`http://localhost:8001/add/postdata/${id}` ,user,{
        headers:{
          Authorization:localStorage.getItem("usertoken")
        }
      });

      toast.success('user Added Successfully..!')

      setTimeout(() => {
        
      navigate("/datatable");
      }, 2000);
      
    } catch (err) {
      console.error("Error in submitting form:", err.message);
    }

    
  };



  return (
    <div
      style={{
        border: "3px solid",
        marginLeft: "auto",
        marginRight: "auto",
        marginTop: "10px",
        width: "50%",
        height: "50%",
        alignItems: "center",
      }}
    >
      <div style={{ border: "2px solid", backgroundColor:"aquamarine",height:"auto",width:"auto"}}>
      <h2 style={{color:"black",textAlign:"center"}}>Add User</h2>
      <form onSubmit={handleSubmit}style={{display:"flex",gap:"4px",paddingRight:"10%",flexDirection:"column",alignItems:"center",justifyContent:"center",alignContent:"center",padding:"20px 10px"}}>
        <div>
          <label>firstname:</label>
          <input
            type="text"
            name="firstname"
            value={user.firstname}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>lastname:</label>
          <input
            type="text"
            name="lastname"
            value={user.lastname}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>email:</label>
          <input
            type="email"
            name="email"
            value={user.email}
            onChange={handleInputChange}
            required
          />
        </div>
          <button type="submit">Submit</button>
      </form>
      </div>
      <Toaster/>
    </div>
  );
}

export default AddUser;

 