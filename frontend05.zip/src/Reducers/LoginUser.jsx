import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  userId: null,
  token: null,
  userToken :null
};
const LoginUserSlice = createSlice({
  name: "loginDetails",
  initialState: initialState,
  reducers: {
    loginSuccess: (state, action) => {
      console.log(action.payload);
      state.userId = action.payload.id;
      state.token = action.payload.token;
      state.userToken = action.payload.usertoken
    },
    logoutUser: (state) => {
      state.userId = null;
      state.userData = null;
      state.token = null;
    },
  },
});

export const { loginSuccess, logoutUser } = LoginUserSlice.actions;
export default LoginUserSlice.reducer;


// import { createSlice } from "@reduxjs/toolkit";


// const userSlice = createSlice({
//     name:"auth",
//     initialState:{
//     authUser:{

//         token:null,
//         userId:null,
//         // logindetails:{}
//         userToken : null
//     }
// },
// reducers:{
//     authUser:(state,action)=>{
//         console.log(action.payload,"==============================================")
//         state.authUser.token =action.payload.token
//         state.authUser.logindetails =action.payload.userData
//         state.userId = action.payload.id;
//         // state.userToken = 


//     }
//     }
// })
// export default userSlice.reducer;
// export const {authUser}=userSlice.actions