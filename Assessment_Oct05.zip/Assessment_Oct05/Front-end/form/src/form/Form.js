import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import GoogleSignIn from '../component/GoogleSignIn';


const Form = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
    });
   

    const [error, setError] = useState(null);
    const navigate = useNavigate()

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Example of making a login request
            const response = await axios.post('http://localhost:5000/user/login', formData);
            
            localStorage.setItem('token', response.data.token)
            localStorage.setItem('user', JSON.stringify(response.data.user));
            navigate('/users');
            console.log('Login successful:');
        } catch (err) {
            setError('Login failed. Please check your credentials.');
        }
    };
    
    return (
        <div className="container mt-5" style={{width: '800px',
            height: '500px',
            borderRadius: '10px', // Rounded corners
            border: '2px solid #ccc', margin: 'auto'}}><br/><br/><br/>
            <h2>Login</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit} >
            <div className="form-group">
                    <label>Email:</label>
                    <input type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="form-control"
                    /> 
                </div><br />
                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                        className="form-control"
                    /><br />
                </div><br/>
                <Button type="submit" class="btn btn-secondary" data-dismiss="modal" style={{marginRight : '3%'}} >Login</Button>
                <Button variant="primary" onClick={() => navigate('/signUp')}>
                    Register
                </Button>
                <br/>

            </form><br/>
            <div style={{margin: 'auto', width: '26%',border: '1px #b0eef5',padding: '10px'}}>
            <GoogleSignIn/></div>

        </div>
    );
};

export default Form;
