import express from 'express';
import itemController from '../controller/item.controller';
import verifyToken from '../middleware/veriftToken';
var router = express.Router();
// CRUD routes using controller methods
router.post('/add', verifyToken, itemController.createItem); // Create
// router.get('/getItem', itemController.getItem); //Read
router.put('/:id', itemController.updateItem); // Update
router.delete('/:id', itemController.deleteItem); // Delete
router.post('/getItem', verifyToken, itemController.getItem);

module.exports = router;