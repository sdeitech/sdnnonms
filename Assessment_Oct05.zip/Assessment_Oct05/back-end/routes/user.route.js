import express from 'express';
import { register, logIn , getUserById, updateUser ,upload} from '../controller/user.controller';
//const verifyToken = require('../middleware/verifyToken')
import verifyToken from '../middleware/veriftToken';

import {isRequestValidated, validateSignUpRequest, validateSignIpRequest} from '../validate/auth';
var router = express.Router();

router.post('/register', upload.single('profilePic'), register);
router.route("/login").post(validateSignUpRequest,isRequestValidated, logIn);

router.get("/userById/:id", getUserById); 

router.route("/userEdit/:id").put( updateUser); 
module.exports = router