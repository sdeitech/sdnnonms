import bcrypt from 'bcrypt';
import User from '../model/user.model';
import jwt from 'jsonwebtoken';
import multer from 'multer'
import path from 'path';


// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // Uploads folder to store the profile picture
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // File name with timestamp
  }
});

// Filter to allow only image files
const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);
  
  if (extname && mimetype) {
    cb(null, true);
  } else {
    cb(new Error('Only images are allowed'));
  }
};

// Initialize multer upload middleware
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 2 * 1024 * 1024 } // Limit file size to 2MB
});

exports.register = async (req, res) => {
  const { firstName, lastName, email, DOB, password, gender, isMarried } = req.body;
  const profilePicPath = req.file ? req.file.path : null; // Get the uploaded file path

  if (!(firstName && lastName && DOB && email && password && gender && isMarried)) {
    return res.status(400).json({ status: 400, message: "All fields are mandatory." });
  }

  try {
    const oldUser = await User.findOne({ email: email });
    if (oldUser) {
      return res.status(409).json({ status: 409, message: "User already exists." });
    }

    const hashPassword = await bcrypt.hash(password, 10);
    
    // Create a new user with the profile picture path
    const newUser = new User({
      firstName,
      lastName,
      email,
      DOB,
      password: hashPassword,
      gender,
      isMarried,
      profilePic: profilePicPath // Save the profile picture path
    });

    await newUser.save(); // Save the new user

    return res.status(201).json({
      status: 201,
      message: "User registered successfully",
      user: newUser,
    });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({
      status: 400,
      message: "Failed to register user",
      error: error.message,
    });
  }
};

exports.getUserById = async (req, res) => {
  const userId = req.params.id; // or req.body.id if you want to pass ID in the body

  try {
      const user = await User.findById(userId);  // Fetch user by ID

      if (!user) {
          return res.status(404).json({ status: 404, message: "User not found" });
      }

      return res.status(200).json({
          status: 200,
          message: "User fetched successfully",
          user: user,
      });
  } catch (error) {
      res.status(400).json({
          status: 400,
          message: "Failed to fetch user",
          error: error.message,
      });
  }
};

exports.updateUser = async (req, res) => {
  const userId = req.params.id; // Get the user ID from the URL parameters
  const { firstName, lastName, email, DOB, gender, isMarried} = req.body; // Get the updated fields from the request body

  try {
      // Find the user by ID and update their details
      const updatedUser = await User.findByIdAndUpdate(
          userId,
          { firstName, lastName, email, DOB, gender, isMarried},  // Update these fields
          { new: true, runValidators: true } // Options: return the updated document and run validators
      );

      if (!updatedUser) {
          return res.status(404).json({ status: 404, message: "User not found" });
      }

      return res.status(200).json({
          status: 200,
          message: "User updated successfully",
          user: updatedUser,
      });
  } catch (error) {
      res.status(400).json({
          status: 400,
          message: "Failed to update user",
          error: error.message,
      });
  }
};

exports.logIn = async (req, res) => {
  const { email, password } = req.body;

  // Check if both email and password are provided
  if (!(email && password)) {
      return res.status(400).json({
          message: "All fields are mandatory",
          status: 400
      });
  }

  try {
      // Find the user by email
      const user = await User.findOne({ email: email });
      if (!user) {
          return res.status(400).json({ message: "User does not exist" });
      }

      // Compare the provided password with the stored hashed password
      const isCorrect = await bcrypt.compare(password, user.password);

      if (isCorrect) {
          // Generate a JWT token
          const token = jwt.sign({email},"process.env.SECRET_TOKEN_KEY" ,{ expiresIn:'1hr'})

          // Return success response with token and user details
          return res.status(200).json({
              message: "Token generated successfully",
              token: token,
              user: {
                  id: user._id,
                  firstName: user.firstName,
                  lastName: user.lastName,
                  email: user.email,
                  DOB : user.DOB,
                  gender : user.gender,
                  isMarried : user.isMarried
              }
          });
      }

      // If password is incorrect
      return res.status(400).json({
          message: "Wrong password, login failed",
          status: 400
      });

  } catch (error) {
      res.status(400).json({ message: "Login failed", error: error.message });
  }


}

exports.upload = upload;





