import express from 'express';
import bodyParser from 'body-parser';
import userRoutes from './routes/user.route';
import itemRoutes from './routes/item.route';
import cors from 'cors';
import db from './db';
import path from 'path';
const app = express();

// Get All Items 

app.use(cors());
app.use(express.json());
app.use('/user', userRoutes);
app.use('/item', itemRoutes);
app.use(express.json({ limit: "50mb" }));
app.use('/uploads',express.static(path.join(__dirname,'uploads')));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));

// app.listen(PORT, () => {
//  console.log(`Server is running on http://localhost:${PORT}`);
// });
export default app;