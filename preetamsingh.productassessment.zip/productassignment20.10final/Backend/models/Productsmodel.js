const mongoose = require('mongoose');
const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    quantity: { type: Number , required: true},
    expiryDate: { type: Number , required: true},
    manufacturer: { type: String , required: true}
    }
);
console.log("your model is ready");

const products = mongoose.model('products', ProductSchema);
module.exports = products;