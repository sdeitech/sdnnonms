import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Button, Modal, Navbar, Container } from 'react-bootstrap'
import RegisterForm from './components/RegisterForm'

function App() {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = (product) => {
    if (product) {
      setIsEditing(true);
      setEditProductId(product._id);
      setName(product.name);
      setDescription(product.description);
      setQuantity(product.quantity);
      setExpiryDate(product.expiryDate);
      setmanufacturer(product.manufacturer);
    }
    setShow(true);
  };
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState();
  const [expiryDate, setExpiryDate] = useState('');
  const [manufacturer, setmanufacturer] = useState('');
  const [user, setUser] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editProductId, setEditProductId] = useState(null);

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:4000/DP/api/product', {
        method: 'GET'
      });
      const data = await response.json();
      setUser(data);
    } catch (error) {
      console.log('Error fetching data:', error);
    }
  };

  const deleteProduct = async (id) => {
    try {
      const response = await fetch(`http://localhost:4000/DP/api/product/${id}`, {
        method: 'DELETE',
      });
      const result = await response.json();
      if (response.ok) {
        setUser(user.filter((product) => product._id !== id));
      } else {
        alert(result.error);
      }
    } catch (error) {
      console.log('Error deleting product:', error);
    }
  };

  const postData = async (e) => {
    console.log(e)
    try {
      const response = await axios.post('http://localhost:4000/DP/api/product', {
        name,
        description,
        quantity,
        expiryDate,
        manufacturer,
      });
      setUser((prevUsers) => [...prevUsers, response.data]);
      resetForm();
      console.log('Data posted successfully:', response.data);
    } catch (error) {
      console.error('Error posting data:', error);
    }
  };

  const updateProduct = async (id) => {
    try {
      const response = await axios.put(`http://localhost:4000/DP/api/product/${id}`, {
        name,
        description,
        quantity,
        expiryDate,
        manufacturer,
      });
      setUser((prevUsers) =>
        prevUsers.map((product) => (product._id === editProductId ? response.data : product))
      );
      setIsEditing(true);
      resetForm();
      handleClose()
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEditing) {
      updateProduct(editProductId);
    } else {
      postData();
    }
  };

 
  const resetForm = () => {
    setName('');
    setDescription('');
    setQuantity('');
    setExpiryDate('');
    setmanufacturer('');
  };

  useEffect(() => {
    fetchData();
  }, []);



  return (
    <div>
      <Navbar className="bg-body-tertiary">
        <Container>
          <Navbar.Brand href="#home">Products Management System</Navbar.Brand>
          <Navbar.Toggle />
          <Navbar.Collapse className="justify-content-end">
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <div>
        <RegisterForm />
      </div>
      <div>
        <table border="1" cellPadding="8" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Description</th>
              <th>Quantity</th>
              <th>Expiry Date</th>
              <th>Manufacturer</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {user.length > 0 ? (
              user.map((product) => (
                <tr key={product._id}>
                  <td>{product.name}</td>
                  <td>{product.description}</td>
                  <td>{product.quantity}</td>
                  <td>{product.expiryDate}</td>
                  <td>{product.manufacturer}</td>
                  <td>
                    <button type="button" onClick={() => deleteProduct(product._id)}>Delete</button>
                    <button type="button" onClick={() => handleShow(product)}>Edit</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6">Loading...</td>
              </tr>
            )}
          </tbody>
        </table>
        <br />
        <>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Modal heading</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoFocus
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>description</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="enter description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    autoFocus
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>Quantity</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="0-100"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    autoFocus
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>ExpiryDate</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="DD-MM-YYYY"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    autoFocus
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlTextarea1"
                >
                  <Form.Label>Manufacturer</Form.Label>
                  <Form.Control
                    type='text'
                    value={manufacturer}
                    onChange={(e) => setmanufacturer(e.target.value)}
                    placeholder='manufacturer' />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button variant="primary" onClick={handleSubmit}>
                Save Changes
              </Button>
            </Modal.Footer>
          </Modal>
        </>

      </div>
    </div>
  );
}

export default App;
