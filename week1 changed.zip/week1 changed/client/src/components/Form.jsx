import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input, FormGroup, Row, Col } from 'reactstrap';
import axios from "axios";

function MyForm({ updateProduct, editProduct, setEditProduct, setProduct, fetchProduct }) {
  const [formData, setFormData] = useState({
    productName: '',
    description: '',
    quantity: '',
    expiryDate: '',
    manufacturerName: ''
  });


  useEffect(() => {
    if (editProduct) {
      setFormData({
        productName: editProduct.productName,
        description: editProduct.description,
        quantity: editProduct.quantity,
        expiryDate: editProduct.expiryDate,
        manufacturerName: editProduct.manufacturerName
      });
    } else {
      setFormData({
        productName: '',
        description: '',
        quantity: '',
        expiryDate: '',
        manufacturerName: ''
      });
    }
  }, [editProduct]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editProduct) {
      // Update existing product
      updateProduct(editProduct._id, formData);
    } else {
      // Add new product
      try {
        const response = await axios.post(`http://localhost:8000/api/product`, formData);
        setProduct(prevProduct => [...prevProduct, response.data]);
        fetchProduct();  // Fetch updated products list
      } catch (error) {
        console.error("Error adding product", error);
      }
    }

    // Clear form and edit state
    setFormData({
      productName: '',
      description: '',
      quantity: '',
      expiryDate: '',
      manufacturerName: ''
    });
    setEditProduct(null);
  };

  return (
    <div>
      <h1>{editProduct ? 'Edit Product' : 'Add Product'}</h1>
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="productName">Product Name</Label>
              <Input
                id="productName"
                name="productName"
                value={formData.productName}
                onChange={handleInputChange}
                type="text"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="description">Description</Label>
              <Input
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                type="text"
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="quantity">Quantity</Label>
              <Input
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleInputChange}
                type="number"
              />
            </FormGroup>
            <FormGroup>
              <Label for="expiryDate">Expiry Date</Label>
              <Input
                id="expiryDate"
                name="expiryDate"
                value={formData.expiryDate}
                onChange={handleInputChange}
                type="date"
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="manufacturerName">Manufacturer Name</Label>
              <Input
                id="manufacturerName"
                name="manufacturerName"
                value={formData.manufacturerName}
                onChange={handleInputChange}
                type="text"
              />
            </FormGroup>
          </Col>
        </Row>
        <Button type="submit">{editProduct ? 'Update Product' : 'Add Product'}</Button>
      </Form>
    </div>
  );
}

export default MyForm;
