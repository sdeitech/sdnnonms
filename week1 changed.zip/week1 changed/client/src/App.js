import { useEffect, useState } from 'react';
import './App.css';
import MyForm from './components/Form';
import ProductDetail from './components/ProductDetail';
import ProductList from './components/ProductList';
import axios from 'axios';

function App() {
  const [product, setProduct] = useState([]);
  const [selector, setSelector] = useState(null);
  const [editProduct, setEditProduct] = useState(null); 
  // set [editSelector, setEditSelector] = useState();

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`http://localhost:8000/api/product`);
      setProduct(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const updateProduct = async (productId, updatedData) => {
    try {
      const response = await axios.put(`http://localhost:8000/api/product/${productId}`, updatedData);
      setProduct(prevData =>
        prevData.map(product => (product._id === productId ? response.data : product))
      );
      setEditProduct(null); 
      console.log("Updated product:", response.data);
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const deleteProduct = async (productId) => {
    try {
      await axios.delete(`http://localhost:8000/api/product/${productId}`);
      fetchProduct();  
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  return (
    <div>

<div className="mt-4">
  <MyForm
    updateProduct={updateProduct}
    editProduct={editProduct}
    setEditProduct={setEditProduct}
    setProduct={setProduct}
    fetchProduct={fetchProduct}
  />
      </div>

  <ProductList
    product={product}
    viewProduct={setSelector}
    updateProduct={setEditProduct}
    deleteProduct={deleteProduct}
  />

  {selector && <ProductDetail product={selector} />}


    </div>
  );
}

export default App;
