import axios from "axios"
import { useState, useEffect } from "react"
import {
    TextField,
    Button,
} from "@mui/material";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import { useNavigate } from "react-router-dom";
// import '../component/userProfile.css'

const UserProfile = () => {

    const navigate = useNavigate()
    const user = localStorage.getItem('userId')

    console.log('user-----', user)

    const [data, setData] = useState([])

    console.log('data------', data)


    const fetchUserById = async (user) => {
        try {
            const response = await axios.get(`http://localhost:5000/api/${user}`)
            console.log(response.data)
            setData(response.data)
        } catch (error) {
            setData([])
        }
    }

    useEffect(() => {
        fetchUserById(user)
    }, [user])

    const handleChange = (e) => {
        const { name, value } = e.target;
        setData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            await axios.put(`http://localhost:5000/api/${user}`, data)
            Swal.fire('Success', 'User Updated SucessFully', 'success')
            navigate('/students')
        } catch (error) {
            console.error('Error Updating users data', error)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="form-container">
            <h1>User Profile</h1>


            <div className="profile">
                <p>Profile Pitcure</p>
                <img 
                    src={`http://localhost:5000/getimg/${data.photo}`}
                    alt="photo"
                    height={100}
                    width={100}
                    
                />
            </div>

            <TextField
                id="firstName"
                name="firstName"
                value={data.firstName}
                onChange={handleChange}
                defaultValue=""
                fullWidth
                sx={{ mb: 3 }}

            />

            <TextField
                id="lastName"
                name="lastName"
                value={data.lastName}
                onChange={handleChange}
                defaultValue=""
                fullWidth
                sx={{ mb: 3 }}

            />

            <TextField
                id="email"
                name="email"
                value={data.email}
                onChange={handleChange}
                defaultValue=""
                fullWidth
                sx={{ mb: 3 }}

            />

            <TextField
                id="gender"
                name="gender"
                value={data.gender}
                onChange={handleChange}
                defaultValue=""
                fullWidth
                sx={{ mb: 3 }}

            />

            <TextField
                id="maritalStatus"
                name="maritalStatus"
                value={data.maritalStatus}
                onChange={handleChange}
                defaultValue=""
                fullWidth
                sx={{ mb: 3 }}

            />

            <Button variant="contained" color="primary" type="submit">
                Update
            </Button>




        </form>
    )
}

export default UserProfile;

