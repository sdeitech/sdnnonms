import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";
import React, { useState } from 'react';
import axios from 'axios'

const clientId = "1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com";
 const Login = () => {
    const [logindata,setloginData]=useState(
        localStorage.getItem("loginData")
        ?JSON.parse(localStorage.getItem("loginData")):null
    )

    const handleSuccess = async (response) => {
        console.log("response",response)
        try {
            const res= await fetch("http://localhost:5000/google-login",{
                method:"post",
                body:JSON.stringify({token:response}),
                headers:{"Content-Type":"application/json"}
            });
            console.log("login with google success");
            if(!res.ok)
            {
               throw new Error("failed to login with google");
            }
            const data = await res.json();

            setloginData(data);
            localStorage.setItem("loginData",JSON.stringify(data));

        }
        catch (error) {
            console.log("login not success");
        }

    }
    const handleError = () => {
        console.log("error while login")
    }
    return (
        <div className="container ">
            <button type="button">
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={(CredentialResponse)=>{
                        handleSuccess(CredentialResponse.credential);
                    }}
                    onError={handleError}
                />
            </GoogleOAuthProvider>
            </button>
        </div>
    )
}

export default Login












//////////

// import React from "react";
// import {GoogleOAuthProvider,GoogleLogin,googleLogout} from "@react-oauth/google";
// import { jwtDecode } from "jwt-decode";
// import Logout from "./logout";

// const CLIENT_ID = `1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com`;
// console.log('client id--------',CLIENT_ID);

// export default function login() {
//   const handelLogin = (googleData) => {
//     const userData = jwtDecode(googleData);
//     console.log("userData====>",userData);
//   };
//   return (
//     <div className="App">
//       <button type="button">
//         <GoogleOAuthProvider clientId={CLIENT_ID}>
//           <GoogleLogin
//             onSuccess={(credentialResponse) => {
//               handelLogin(credentialResponse.credential);
//             }}
//             onError={() => {}}
//           />
//         </GoogleOAuthProvider>
//       </button>

//       <Logout></Logout>
//     </div>
//   );
// }