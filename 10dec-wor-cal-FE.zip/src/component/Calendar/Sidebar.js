import React, { useState, useEffect } from 'react';
import './Sidebar.css';
import moment from 'moment';

const Sidebar = ({ show, onHide, onAddEvent, onEditEvent, onDeleteEvent, selectedEvent }) => {
    console.log("selectedEvent---", selectedEvent);
    
  const [eventTitle, setEventTitle] = useState('');  
  const [eventDate, setEventDate] = useState('');    
  const [eventStartTime, setEventStartTime] = useState('');  
  const [eventEndTime, setEventEndTime] = useState('');      

  useEffect(() => {
    if (selectedEvent) {
      setEventTitle(selectedEvent.title || '');  
      setEventDate(moment(selectedEvent.start).format('YYYY-MM-DD') || '');  // Matching event_date
      setEventStartTime(selectedEvent.start ? moment(selectedEvent.start, 'HH:mm').format('HH:mm') : '');  // Matching event_startTime
      setEventEndTime(selectedEvent.end ? moment(selectedEvent.end, 'HH:mm').format('HH:mm') : '');  // Matching event_endTime
    } else {
      setEventTitle('');
      setEventDate(''); 
      setEventStartTime('');
      setEventEndTime('');
    }
  }, [selectedEvent]);

  const handleSubmit = () => {
    const newEvent = {
      event_title: eventTitle, 
      event_date: moment(eventDate).set({ hour: eventStartTime.split(':')[0], minute: eventStartTime.split(':')[1] }).toDate(),  // Matching event_date
      event_startTime: eventStartTime,  
      event_endTime: eventEndTime,
    };

    if (selectedEvent) {
      // If an event is selected, update it
      const updatedEvent = { ...selectedEvent, ...newEvent };
      onEditEvent(updatedEvent);
    } else {
      // If no event is selected, create a new one
      onAddEvent(newEvent);
    }
  };

  const handleDelete = () => {
    if (selectedEvent) {
      onDeleteEvent(selectedEvent._id);  // Assuming _id is the event ID from the backend schema
    }
  };

  const handleDateChange = (e) => {
    const selectedDate = e.target.value;
    const today = new Date().toISOString().split('T')[0];

    if (selectedDate >= today) {
      setEventDate(selectedDate);  // Renamed to match event_date
    }
  };

  return (
    <div className={`sidebar ${show ? 'show' : ''}`}>
      <div className="sidebar-content">
        <div className="sidebar-header">
          <h3>{selectedEvent ? 'Edit Event' : 'Add Event'}</h3>
          <button className="close-btn" onClick={onHide}>Close</button>
        </div>
        <div className="sidebar-body">
          <label>Title</label>
          <input
            type="text"
            placeholder="Event Title"
            value={eventTitle}  
            onChange={(e) => setEventTitle(e.target.value)}  // Renamed to match event_title
          />
          <label>Date</label>
          <input
            type="date"
            value={eventDate}  
            onChange={handleDateChange}
          />
          <label>Start Time</label>
          <input
            type="time"
            value={eventStartTime}  // Renamed to match event_startTime
            onChange={(e) => setEventStartTime(e.target.value)}  // Renamed to match event_startTime
          />
          <label>End Time</label>
          <input
            type="time"
            value={eventEndTime}  // Renamed to match event_endTime
            onChange={(e) => setEventEndTime(e.target.value)}  // Renamed to match event_endTime
          />
          <button className="btn btn-primary" onClick={handleSubmit}>{selectedEvent ? 'Update' : 'Submit'}</button>
          {selectedEvent && <button className="btn btn-danger" onClick={handleDelete}>Delete</button>}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;