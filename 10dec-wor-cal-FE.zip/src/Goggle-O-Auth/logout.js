import React from "react";
export default function Logout() {
  return (
    <div>
      <button type="button">Logout</button>
    </div>
  );
}