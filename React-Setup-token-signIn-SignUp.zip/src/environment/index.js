/* eslint-disable no-undef */

//For local setup 
const dev = {
	API_URL: "http://localhost:8000/api/v1" 
};

//For staging server
const staging = {
	API_URL: "http://localhost:8000/api/v1"
};

//For live server
const production = {
	API_URL: "http://localhost:8000/api/v1"
};

if (process.env.REACT_APP_ENV === "dev") module.exports = dev;
else if (process.env.REACT_APP_ENV === "staging") module.exports = staging;
else if (process.env.REACT_APP_ENV === "production") module.exports = production;
else module.exports = staging;
