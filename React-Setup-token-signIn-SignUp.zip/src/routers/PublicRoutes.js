import {React} from "react" 
import PublicLayout from "../components/layouts/PublicLayout";
import SignIn from "../modules/authentication/signin/SignIn";
import SignUP from "../modules/authentication/signup/SignUp";

const publicRoutes = [
	{
		path: "/login",
		exact: true,
		element: <PublicLayout><SignIn /></PublicLayout>
	},
	{
		path: "/signUp",
		exact: true,
		element: <PublicLayout><SignUP /></PublicLayout>
	},
	// { path: "/*", element: <SignIn/> },
];
export default publicRoutes;
