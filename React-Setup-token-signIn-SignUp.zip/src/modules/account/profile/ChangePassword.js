function ChangePassword() {
	return (
		<>Change Password</>
	);
}
export default ChangePassword;