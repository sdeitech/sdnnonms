/* eslint-disable react/prop-types */
import React, { useEffect } from "react";
import { useNavigate } from "react-router";
import Header from "../header/Header";
import Sidebar from "../sidebar/Sidebar";
import Footer from "../footer/Footer";
// import { useSelector } from "react-redux";

const PrivateLayout = ({ children }) => {
let navigate = useNavigate();
//   let { token } = useSelector(state => state.user);
let token = "fsdfsdf"
  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
  });
  return (
    <div className="layout">
      <Header/>
      <Sidebar/>
      <div className="content">{token ? children : null}</div>
      <Footer/>
    </div>
  );
};

export default PrivateLayout;