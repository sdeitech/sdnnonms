/* eslint-disable react/prop-types */

const NoLayout = ({ children }) => {
	return (
		<>
			{children}
		</>
	);
};

export default NoLayout;