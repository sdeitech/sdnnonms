export const superAdminMenu = (permissions,admin) => {
    const menuItems =

    [
        {
            name: "Home",
            URL: "/app/home",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Activity",
            URL: "/app/profile",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Dashboard",
            // children: [
            //     {
            //         name: "Create",
            //         URL: "/app/create-individual",
            //         enabled: permissions?.includes("Manage Individuals") || admin
            //     },
            //     {
            //         name: "Manage",
            //         URL: "/app/manage-individuals",
            //         enabled: permissions?.includes("Manage Individuals") || admin
            //     },
            // ],
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Workflows",
            URL: "/app/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Patient",
            URL: "/app/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Cases",
            URL: "/app/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Repository",
            URL: "/app/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
    ].filter(item => {
        if (item.children) {
            item.children = item.children.filter(child => child.enabled === true);
            return item.children.length > 0;
        }
        return item.enabled === true;
});
    return menuItems;
};
export const orgAdminMenu = (permissions,admin) => {
    const menuItems =

    [
        {
            name: "Organizations",
            URL: "/admin/manage-organization",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Roles",
            URL: "/admin/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Users",
            // children: [
            //     {
            //         name: "Create",
            //         URL: "/app/create-individual",
            //         enabled: permissions?.includes("Manage Individuals") || admin
            //     },
            //     {
            //         name: "Manage",
            //         URL: "/app/manage-individuals",
            //         enabled: permissions?.includes("Manage Individuals") || admin
            //     },
            // ],
            enabled: permissions?.includes("Manage Organization") || admin,
        }
    ].filter(item => {
        if (item.children) {
            item.children = item.children.filter(child => child.enabled === true);
            return item.children.length > 0;
        }
        return item.enabled === true;
});
    return menuItems;
};
export const patientMenu = (permissions,admin) => {
    const menuItems =

    [
        {
            name: "Organizations",
            URL: "/patient/manage-organization",
            enabled: permissions?.includes("Manage Organization") || admin,
        },
        {
            name: "Roles",
            URL: "/patient/manage-roles",
            enabled: permissions?.includes("Manage Organization") || admin,
        }
    ].filter(item => {
        if (item.children) {
            item.children = item.children.filter(child => child.enabled === true);
            return item.children.length > 0;
        }
        return item.enabled === true;
});
    return menuItems;
};