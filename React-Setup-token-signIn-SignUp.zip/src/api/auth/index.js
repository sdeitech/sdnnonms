import ApiClient from "../../api-client"
import { API_URL } from "../../environment"


export const signUp = ({payload, dispatch}) => {
    return ApiClient.post(`${API_URL}/user/signup`, payload, null, dispatch)
}