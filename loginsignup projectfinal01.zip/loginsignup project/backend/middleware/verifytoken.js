const jwt = require("jsonwebtoken");

const  verifytoken = (req,res,next) =>{
    const token = req.header ('authorization');
    console.log(token);
    if (!token){
        res.status(403).send("a token is reqired for authentation");
    }

    try {
        const decoded = jwt.verify(token,"...");
        console.log(decoded);
        req.user = decoded;
         

    } catch (error) {
        return res.status(401).send("invalid token");
    }
    next();

    
}

module.exports = verifytoken;