const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
    Name: { type: String, required: true },
    Quantity: { type: Number , required: true},
    }
);
console.log("your model is ready");

const Users = mongoose.model('products', UserSchema);
module.exports = Users;