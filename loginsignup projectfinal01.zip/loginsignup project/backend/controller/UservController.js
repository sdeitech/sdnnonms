const user = require('../models/UserVmodel'); 

exports.CreateUser = async (req,res) => {
    console.log("user create function is ready");
    try {
       const newUser = new user(req.body)
       await newUser.save();
       res.status(200).json(newUser);
       console.log("user added succussfully");
       
    } catch (error) {
     res.error(400).json({error:error.message});

    }

};


exports.getUser = async (req,res) => {
   try {
    console.log("yu are in view section");
    
       const user01 = await user.find();
       res.json(user01);
       console.log("users are in the database:");
       
   } catch (error) {
       res.status(400).json({error:error.message});
   }
}



