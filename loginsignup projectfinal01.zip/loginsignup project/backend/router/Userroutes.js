const express = require('express');
const router = express.Router();
const UserController = require('../controller/UserController');
const UserVController = require('../controller/UservController')
console.log("your router file is getting ready");

router.post('/toregister',UserController.register);
router.post('/tologin',UserController.logIn); 

router.post('/topostUser',UserVController.CreateUser); 

router.get('/togetUser',UserVController.getUser); 


module.exports = router;    