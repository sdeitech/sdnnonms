import Container from 'react-bootstrap/Container';

import Navbar from 'react-bootstrap/Navbar';
import './RegisterNavbar.css'; // Import your custom CSS

function RegisterNavbar() {
  return (
    <>
      <Navbar bg="primary" data-bs-theme="dark">
        <Container className="justify-content-center">
          <Navbar.Brand href="#home" className="text-center">This is your sign-up page</Navbar.Brand>
        </Container>
      </Navbar>

      <br />
    </>
  );
}

export default RegisterNavbar;
