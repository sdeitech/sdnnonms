import axios from "axios";
import { useState } from "react"
import { Navigate } from "react-router-dom";

function UserDetails() {
    const navigate = Navigate;

    const[users,setusers] = useState({
        name:"",
        price:""
    })
    const handleChange = (e) =>{
    
       setusers({
        ...users,[e.target.name]:e.target.value
       });
    }
    const handlesubmit = async() => {
        try {
            console.log("you are in posting section",users);

            const response = await axios.post('http://localhost:3006/togetUser',users)
            console.log("your data is:",response.data);        
        } catch (error) {
            console.log(error);
            console.log("failded to post the data");
    }
        
    }
    return (
        <>
        <div>
        <form onSubmit={handlesubmit}>
            <input 
             type="text"
             name='Name'
             placeholder="name"
             autoFocus
             onChange={handleChange}></input>
            <input type = "number" name = 'price' placeholder="enter price" onChange={handleChange}></input>
            <button type="submit" >submit</button>
        </form>
        </div></>
    )
}

export default UserDetails;