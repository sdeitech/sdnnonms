import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiRespnse } from '../model/interface/role';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  constructor(private http : HttpClient) { }

  getDesignation():Observable<ApiRespnse> {
    return this.http.get<ApiRespnse>(`https://freeapi.miniprojectideas.com/api/ClientStrive/GetAllDesignation`)
    
  }
}
