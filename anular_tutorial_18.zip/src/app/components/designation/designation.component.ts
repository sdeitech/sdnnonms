import { CommonModule } from '@angular/common';
import { ApiRespnse, IDesignation } from '../../model/interface/role';
import { MasterService } from './../../services/master.service';
import { Component, inject, OnInit } from '@angular/core';

@Component({
  selector: 'app-designation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './designation.component.html',
  styleUrl: './designation.component.css'
})
export class DesignationComponent implements OnInit{

  isloading : boolean = true;
  designationlist : IDesignation[] = [];
  masterService = inject(MasterService);

  ngOnInit(): void {
    this.masterService.getDesignation().subscribe((result:ApiRespnse)=>{
    this.designationlist = result.data
    this.isloading = false
    },error=>{
      alert("Error")
    this.isloading = false


    })
  }
}
