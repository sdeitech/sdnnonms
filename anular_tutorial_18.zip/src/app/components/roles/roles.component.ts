import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';  //OnInit is a lifecycle method used to call api when component renders
import { ApiRespnse, IRole } from '../../model/interface/role';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

//here this decorator will provide information about class like what this class is going to do
@Component({
  selector: 'app-roles',  //selector is something by which we can call or render a component in to another component
  standalone: true,
  imports: [FormsModule, CommonModule],  //to use ngModel for 2 way data binding
  templateUrl: './roles.component.html',  //here link with html and css files
  styleUrl: './roles.component.css'
})

export class RolesComponent implements OnInit {

  roleList: IRole [] = [];
  http = inject(HttpClient);

  ngOnInit(): void {      //lifecycle method which calls api when component reload this is just like useEffect Hook in react
    this.getAllRoles()
  }

  //here api will return some data and to catch that data we use .subscribe() method
  getAllRoles(){
    this.http.get<ApiRespnse>("https://freeapi.miniprojectideas.com/api/ClientStrive/GetAllRoles").subscribe((res:ApiRespnse)=>{
      this.roleList = res.data
    })
    
  }

  //string, number, booleaen, date, object, array, null, undefined

  // firstname: string = "Angular"
  // angularVersion = "Version 18"
  // version:number=18;
  // isActive: boolean = true;
  // currentDate : Date = new Date()
  // inputType: string = "checkbox"
  // selectedState: string = ''
  // showWelcomeAlert(){
  //   alert("Welcome to Angular 18")
  // }
  // showMessage(message: string) {
  //   alert(message)
  // }



}
