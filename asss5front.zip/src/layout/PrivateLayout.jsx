import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Footer from "../constants/footer/Footer";
import { useSelector } from "react-redux";
import Header from "../constants/header/Header";

const PrivateLayout = ({ children }) => {
  const navigate = useNavigate();
  const token = useSelector((state) => state.loginUser?.token);

  useEffect(() => {
    if (!token) {
      navigate("/");
    }
  }, [navigate, token]);
  return (
    <div>
      <Header />
      <div style={{ height: "100vh" }}>{children}</div>
      <Footer />
    </div>
  );
};

export default PrivateLayout;
