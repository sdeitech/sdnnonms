import { createBrowserRouter } from "react-router-dom";
import PrivateRouters from "./PrivateRouters";
import PublicRouters from "./PublicRouters";

const router = createBrowserRouter([...PrivateRouters, ...PublicRouters]);

export default router;
