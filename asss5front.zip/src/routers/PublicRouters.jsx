import React from "react";
import PublicLayout from "../layout/PublicLayout";
import SignIn from "../pages/SignIn";
import SignUp from "../pages/SignUp";

const PublicRouters = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignUp />
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />
      </PublicLayout>
    ),
  },
];

export default PublicRouters;
