import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "userData",
  initialState: {
    userInfo: null,
    subUsers: null,
    pagination: null

  },
  reducers: {
    saveUserData: (state, action) => {
      console.log(action.payload, "payload from userslice");
      state.userInfo = action.payload.userInfo;
      state.subUsers = action.payload.subUsers;
      state.pagination = action.payload.pagination
    },
    clearUsers: (state) => {
      state.userData = null;
    },
  },
});

export const { saveUserData, clearUsers } = userSlice.actions;
export default userSlice.reducer;
