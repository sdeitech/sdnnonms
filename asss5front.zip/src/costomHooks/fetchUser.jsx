import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { saveUserData } from "../context/Reducers/userSlice";

const fetchUser = async () => {
  const dispatch = useDispatch();
  const id = useSelector((state) => state.loginUser?.userId);
  try {
    const res = await axios.get(`http://localhost:3002/api/user/${id}`, {
      headers: {
        Authorization: token,
      },
    });
    dispatch(saveUserData(res.data));
    console.log(res.data, "from call");
  } catch (error) {
    console.log(error);
  }
};

export default fetchUser;
