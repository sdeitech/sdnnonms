import React, { useEffect, useState } from 'react'

const useFetch = (url) => {
    const [data, setData] = useState(null)
    const [isLoading, setIsLoading] = useState(true)
    const [error, setError] = useState(null)

    const fetchData = async () => {
        setIsLoading(true)
        try {
            const res = await axios.get(`${url}`)
            setData(res.data)
            setIsLoading(false)

        } catch (error) {
            setError(error.message)
        }
    }
    useEffect(() => {
        fetchData()
    }, [url])

    return {
        data, isLoading, error
    }
}

export default useFetch
