import React, { useEffect, useState } from "react";
import { Radio } from "@material-tailwind/react";
import { Link } from "react-router-dom";
import useForm from "../costomHooks/useForm";
import Icons from "../assets/assets";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";

const SignUp = () => {
  const SignUpData = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    gender: "",
    isMarried: false,
    DOB: "",
    profile: null,
  };

  const [toastShown, setToastShown] = useState(false);

  const { formData, previewImg, handleChange, resetForm } = useForm(SignUpData);

  console.log(formData);
  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);

    const formDataToSend = new FormData();

    formDataToSend.append("firstName", formData.firstName);
    formDataToSend.append("lastName", formData.lastName);
    formDataToSend.append("email", formData.email);
    formDataToSend.append("password", formData.password);
    formDataToSend.append("gender", formData.gender);
    formDataToSend.append("isMarried", formData.isMarried);
    formDataToSend.append("DOB", formData.DOB);

    if (formData.profile) {
      formDataToSend.append("profile", formData.profile);
    }

    try {
      const res = await axios.post(
        `http://localhost:3002/api/signup`,
        formDataToSend
      );
      setToastShown(true);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Registration successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="py-10 px-8 rounded-3xl shadow-2xl flex flex-col items-center mx-auto border border-blue-300 bg-gradient-to-r from-blue-100 to-blue-200 w-1/2">
      <div className="text-3xl mb-8 font-semibold text-blue-800">
        <p>Sign Up Here</p>
      </div>

      <div className="mb-6">
        {previewImg ? (
          <div className="rounded-full h-24 w-24 border-4 border-blue-500 p-1 shadow-lg">
            <img
              src={previewImg}
              alt="Profile Preview"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        ) : (
          <div className="rounded-full h-24 w-24 border-4 border-blue-500 p-1 shadow-lg flex items-center justify-center bg-blue-100">
            {/* Replace with your SVG icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-16 w-16 text-blue-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 14.5c-4 0-7.5 3-7.5 7.5H7a9 9 0 0118 0h-2c0-4.5-3.5-7.5-7.5-7.5zM12 12a4 4 0 100-8 4 4 0 000 8z"
              />
            </svg>
          </div>
        )}
      </div>

      <form onSubmit={handleLoginSubmit} className="w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <input
            type="text"
            name="firstName"
            onChange={handleChange}
            placeholder="First Name"
            className="focus:outline-none h-12 w-full px-4 rounded-lg text-blue-700 border-2 border-blue-300 shadow-sm focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="text"
            name="lastName"
            onChange={handleChange}
            placeholder="Last Name"
            className="focus:outline-none h-12 w-full px-4 rounded-lg text-blue-700 border-2 border-blue-300 shadow-sm focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="email"
            name="email"
            onChange={handleChange}
            placeholder="Email"
            className="focus:outline-none h-12 w-full px-4 rounded-lg text-blue-700 border-2 border-blue-300 shadow-sm focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="password"
            name="password"
            onChange={handleChange}
            placeholder="Password"
            className="focus:outline-none h-12 w-full px-4 rounded-lg text-blue-700 border-2 border-blue-300 shadow-sm focus:ring-2 focus:ring-blue-500"
          />

          <div className="flex items-center justify-between col-span-2">
            <label className="text-blue-700">Gender:</label>
            <div className="flex items-center gap-6">
              <Radio
                name="gender"
                label="Male"
                value="male"
                checked={formData.gender === "male"}
                onChange={handleChange}
                className="text-blue-700"
              />
              <Radio
                name="gender"
                label="Female"
                value="female"
                checked={formData.gender === "female"}
                onChange={handleChange}
                className="text-blue-700"
              />
            </div>
          </div>

          <input
            type="date"
            name="DOB"
            onChange={handleChange}
            className="focus:outline-none h-12 w-full px-4 rounded-lg text-blue-700 border-2 border-blue-300 shadow-sm focus:ring-2 focus:ring-blue-500"
          />

          <div className="flex items-center gap-3 col-span-2">
            <label className="text-blue-700">Is married?</label>
            <input
              type="checkbox"
              name="isMarried"
              checked={FormData.isMarried}
              onChange={handleChange}
              className="w-6 h-6 text-blue-600 bg-blue-100 border-blue-300 rounded focus:ring-blue-500 focus:ring-2"
            />
          </div>

          <div className="flex flex-col items-center col-span-2">
            <label
              htmlFor="profile"
              className="cursor-pointer bg-blue-600 text-white px-6 py-2 rounded-lg shadow hover:bg-blue-700 transition duration-300"
            >
              Upload Profile
            </label>
            <input
              type="file"
              id="profile"
              name="profile"
              onChange={handleChange}
              style={{ display: "none" }}
            />
            {previewImg && (
              <a
                href={previewImg}
                target="_blank"
                className="text-blue-600 mt-2"
              >
                View Profile
              </a>
            )}
          </div>
        </div>

        <div className="flex flex-col items-center mt-6 gap-4">
          <button
            type="submit"
            className="bg-blue-600 text-white py-3 px-10 rounded-lg shadow-md hover:bg-blue-700 transition duration-300"
          >
            Sign Up
          </button>

          <p>
            Already have an account?{" "}
            <Link to={"/login"} className="text-blue-500 hover:underline">
              Click here
            </Link>
          </p>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default SignUp;
