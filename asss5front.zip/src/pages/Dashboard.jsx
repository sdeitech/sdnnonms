import axios from "axios";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveUserData } from "../context/Reducers/userSlice";
import { Card, Typography } from "@material-tailwind/react";
import Icons from "../assets/assets";
// import fetchUser from "../costomHooks/fetchUser";

const TABLE_HEAD = ["Profile", "First Name", "LastName", "Email", "Action"];

const Dashboard = () => {
  const uid = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);

  console.log(uid, token);

  const userData = useSelector((state) => state.userData.subUsers);
  console.log(userData, "demoooooooooooooooooooooooooooooooooo");

  const dispatch = useDispatch();

  const fetchUser = async () => {
    try {
      const res = await axios.get(`http://localhost:3002/api/user/${uid}`, {
        headers: {
          Authorization: token,
        },
      });
      dispatch(saveUserData(res.data));
      console.log(res.data, "from call");
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    console.log("calling api");
    fetchUser();
  }, []);

  return (
    <div className="w-5/6 mx-auto mt-8">
      <Card className="h-full w-full overflow-scroll shadow-lg rounded-lg">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr className="bg-gradient-to-r from-blue-500 to-blue-300 text-white">
              {TABLE_HEAD.map((head) => (
                <th key={head} className="p-4 border-b border-blue-100">
                  <Typography
                    variant="small"
                    className="font-semibold leading-none"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {userData?.map(({ _id, firstName, lastName, email }, index) => (
              <tr
                key={_id}
                className="even:bg-blue-50 transition duration-200 hover:bg-blue-100"
              >
                <td className="p-4">
                  <img
                    src={Icons.profile}
                    alt=""
                    height={40}
                    width={40}
                    className="rounded-full border border-blue-300 shadow-sm"
                  />
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    className="font-normal text-gray-800"
                  >
                    {firstName}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    className="font-normal text-gray-800"
                  >
                    {lastName}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    className="font-normal text-gray-800"
                  >
                    {email}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    as="a"
                    href="#"
                    variant="small"
                    className="font-medium text-blue-500 hover:underline"
                  >
                    View
                  </Typography>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default Dashboard;
