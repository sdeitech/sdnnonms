import React, { useEffect, useState } from "react";
import Icons from "../assets/assets";
import useForm from "../costomHooks/useForm";
import { Link } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";
import fetchUser from "../costomHooks/fetchUser";
import toast, { Toaster } from "react-hot-toast";

const AddUser = () => {
  const id = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);
  const [updateState, setUpdateState] = useState(false);

  const addUserData = {
    firstName: "",
    lastName: "",
    email: "",
  };
  const { formData, handleChange, resetForm } = useForm(addUserData);

  console.log(formData);

  const handleAddUserSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/user/${id}`,
        formData,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      setUpdateState(!updateState);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  //   useEffect(() => {
  //     fetchUser();
  //   }, [updateState]);

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <form
        onSubmit={handleAddUserSubmit}
        className="bg-white shadow-lg rounded-lg p-8 w-96 flex flex-col gap-6"
      >
        <h2 className="text-2xl font-bold text-center text-blue-700">
          Create User
        </h2>

        <div className="flex flex-col gap-4">
          <input
            type="text"
            name="firstName"
            onChange={handleChange}
            placeholder="First Name"
            className="focus:outline-none h-12 px-4 rounded-lg border border-blue-300 shadow-md transition duration-200 focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="text"
            name="lastName"
            onChange={handleChange}
            placeholder="Last Name"
            className="focus:outline-none h-12 px-4 rounded-lg border border-blue-300 shadow-md transition duration-200 focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="email"
            name="email"
            onChange={handleChange}
            placeholder="Email"
            className="focus:outline-none h-12 px-4 rounded-lg border border-blue-300 shadow-md transition duration-200 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition duration-300 shadow-lg"
        >
          Add User
        </button>

        <Link to="/dashboard" className="flex items-center justify-center">
          <div className="bg-gray-300 hover:bg-gray-400 p-2 rounded-full transition duration-300">
            <Icons.crossIcon />
          </div>
        </Link>
      </form>
      <Toaster />
    </div>
  );
};

export default AddUser;
