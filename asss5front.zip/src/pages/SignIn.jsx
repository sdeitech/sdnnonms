import React, { useEffect, useState } from "react";
import useForm from "../costomHooks/useForm";
import toast, { Toaster } from "react-hot-toast";
import axios from "axios";
import { loginSuccess } from "../context/Reducers/LoginUser";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  const dispatch = useDispatch();

  const navigate = useNavigate();
  const [toastShown, setToastShown] = useState(false);

  const data = useSelector((state) => state.loginUser);

  console.log(data, "userdata");

  const signInData = {
    email: "",
    password: "",
  };

  const { formData, handleChange } = useForm(signInData);

  const handleSignIn = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/signin`,
        formData
      );
      setToastShown(true);

      dispatch(loginSuccess(res.data));

      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Login successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="bg-white py-10 px-8 rounded-3xl shadow-lg w-96 flex flex-col items-center mx-auto mt-20 border border-gray-200">
      <div className="text-3xl font-bold text-gray-800 mb-8">
        <p>Login</p>
      </div>
      <form onSubmit={handleSignIn} className="flex flex-col gap-6 w-full">
        <div className="relative">
          <input
            type="email"
            name="email"
            onChange={handleChange}
            placeholder="Enter your email"
            className="focus:outline-none h-12 w-full px-4 rounded-lg border border-gray-300 text-gray-700 shadow-sm focus:ring-2 focus:ring-blue-400 transition duration-200"
          />
        </div>

        <div className="relative">
          <input
            type="password"
            name="password"
            onChange={handleChange}
            placeholder="Enter your password"
            className="focus:outline-none h-12 w-full px-4 rounded-lg border border-gray-300 text-gray-700 shadow-sm focus:ring-2 focus:ring-blue-400 transition duration-200"
          />
        </div>

        <div className="text-center">
          <button
            type="submit"
            className="bg-gradient-to-r from-green-400 to-blue-500 text-white py-3 px-8 rounded-lg shadow-md hover:scale-105 transition-transform duration-300"
          >
            Login
          </button>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default SignIn;
