import { createBrowserRouter } from "react-router-dom";
import PrivateRoutes from "./PrivateRoute";
import PublicRoutes from "./PublicRoute";

const routers = createBrowserRouter([...PrivateRoutes, ...PublicRoutes]);

export default routers;
