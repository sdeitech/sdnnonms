import Dashboard from "../components/commonpages/Dashboard";
import PrivateLayout from "../layout/PrivateLayout";
import Cart from "../components/cartPages/cart";
import AddProduct from "../components/adminpages/addProductpage";
import UpdateProduct from "../components/adminpages/updateProduct";
import ViewProduct from "../components/adminpages/viewProduct";
import OrderComponent from "../components/cartPages/Order";

const PrivateRoutes = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },
  {
    path: "/Cart",
    element: (
      <PrivateLayout>
        <Cart />
      </PrivateLayout>
    ),
  },
  {
    path: "/add-product",
    element: (
      <PrivateLayout>
        <AddProduct />
      </PrivateLayout>
    ),
  },
  {
    path: "/update-product",
    element: (
      <PrivateLayout>
        <UpdateProduct />
      </PrivateLayout>
    ),
  },
  {
    path: "/view-product",
    element: (
      <PrivateLayout>
        <ViewProduct />
      </PrivateLayout>
    ),
  },

  {
    path: "/order",
    element: (
      <PrivateLayout>
        <OrderComponent />
      </PrivateLayout>
    ),
  },
];
export default PrivateRoutes;