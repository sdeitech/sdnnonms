import axios from "axios";

const apiUrl = process.env.REACT_APP_API_URL || "http://localhost:3002/api";

// Function to call the registration API
export const registerUser = async (formData) => {
  try {
    const response = await axios.post(`${apiUrl}/signup`, formData, {
      headers: {
        "Content-Type": "multipart/form-data", // Correct content-type
      },
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Registration failed");
  }
};

// Function to call the login API
export const loginUser = async (loginData) => {
  try {
    const response = await axios.post(`${apiUrl}/login`, loginData);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Login failed");
  }
};

//==============================adduser=========================================

export const fetchUsers = async () => {
    try {
      const response = await axios.get(`${apiUrl}/user`); // Adjust the endpoint as necessary
      return response.data; // Return the user data
    } catch (error) {
      throw new Error(error.response?.data?.message || "Failed to fetch user data");
    }
  };

export const fetchUser = async (page = 1, limit = 2) => {
    const response = await axios.get(`/api/products?page=${page}&limit=${limit}`);
    return response.data; // Return the paginated products and pagination info
  };
  
  // Function to add a product
  export const addUser = async (user) => {
    try {
      const response = await axios.post(`${apiUrl}/createusers`, user); // Adjusted the URL to use apiUrl
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || "Failed to add user");
    }
  };

  export const getPeginatedData = async (pageNo) => {
      const response = await axios.get(`${apiUrl}/pagination?page=${pageNo}`); 
      return response; 
    } ;
