import React from 'react';
import { useSelector } from 'react-redux';
import './viewProduct.css';

const ViewProduct = () => {
    const product = useSelector((state) => state.products.selectedProduct); 

    if (!product) {
        return <p>Product not found</p>;
    }

    return (
        <div className="view-product-container">
            {product.image && (
                <img
                    src={`http://localhost:3219/getimg/${product.image}`}
                    alt={product.name}
                    className="product-image"
                />
            )}

            {/* Display Name, Price, and Description */}
            <h2 className="product-title">{product.name}</h2>
            <p className="product-price">Price: ₹{product.price}</p>
            <p className="product-description">{product.description}</p>
        </div>
    );
};

export default ViewProduct;
