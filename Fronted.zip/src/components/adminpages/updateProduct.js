import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { updateProduct } from '../../reduxComponent/ProductSlice';
import { useNavigate } from 'react-router-dom';
import './updateProduct.css';

const UpdateProduct = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const selectedProduct = useSelector((state) => state.products.selectedProduct);
    const { token } = useSelector((state) => state.users.authUser);


    const [updatedProduct, setUpdatedProduct] = useState({
        name: '',
        price: '',
        description: '',
        image: null,
    });

    useEffect(() => {
        if (selectedProduct) {
            setUpdatedProduct({
                name: selectedProduct.name || '',
                price: selectedProduct.price || '',
                description: selectedProduct.description || '',
                image: null,
            });
        }
    }, [selectedProduct]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUpdatedProduct((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleFileChange = (e) => {
        setUpdatedProduct((prev) => ({
            ...prev,
            image: e.target.files[0],
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('name', updatedProduct.name);
        formData.append('price', updatedProduct.price);
        formData.append('description', updatedProduct.description);
        if (updatedProduct.image) {
            formData.append('image', updatedProduct.image);
        }

        try {
            const response = await axios.put(`http://localhost:3219/api/productadmin/updateproduct/${selectedProduct._id}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: token

                },
            });
            dispatch(updateProduct(response.data));
            navigate('/dashboard');
        } catch (error) {
            console.error('Error updating product:', error);
        }
    };

    return (
        <div>
            <h2 className="update-product-title">Update Product</h2>
            <div className="update-product-container">
                <form onSubmit={handleSubmit} className="update-product-form">
                    <div className="form-group">
                        <label>Name:</label>
                        <input
                            type="text"
                            name="name"
                            value={updatedProduct.name}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Price:</label>
                        <input
                            type="number"
                            name="price"
                            value={updatedProduct.price}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Description:</label>
                        <textarea
                            name="description"
                            value={updatedProduct.description}
                            onChange={handleChange}
                            required
                        ></textarea>
                    </div>
                    <div className="form-group">
                        <label>Image:</label>
                        <input type="file" onChange={handleFileChange} />
                    </div>
                    <img
                        src={`http://localhost:3219/getimg/${selectedProduct.image}`}
                        alt={selectedProduct.name}
                        className="product-image"
                    />
                    <button type="submit" className="submit-button">Update Product</button>
                </form>
            </div>
        </div>
    );
};

export default UpdateProduct;
