import React, { useState } from 'react';
import { useNavigate , Link} from 'react-router-dom';
import './Navbar.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import {resetUsers} from '../../reduxComponent/Userslice'
import { useDispatch } from 'react-redux';



const Navbar = ({ onSearch, role}) => {
    const [searchInput, setSearchInput] = useState('');
    const navigate = useNavigate();
    const dispatch = useDispatch();


    const handleSearch = (e) => {
        setSearchInput(e.target.value);
        onSearch(e.target.value);
    };

    // const navigateToSignup = () => navigate('/');
    // const navigateToSignin = () => navigate('/login');

    const handleLogout = () => {
        dispatch(resetUsers());
        navigate('/login');
    };
    

    return (
        <nav className="navbar navbar-expand-lg custom-navbar">
            <div className="container-fluid">
                <a className="navbar-brand" >
                    <i className="fas fa-shopping-cart"></i> <span className="navbar-title">Meesho</span>
                </a>

                <button 
                    className="navbar-toggler" 
                    type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#navbarContent" 
                    aria-controls="navbarContent" 
                    aria-expanded="false" 
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarContent">
                    <form className="d-flex mx-auto custom-search-form" role="search">
                        <input 
                            className="form-control" 
                            type="search" 
                            placeholder="Search by product name" 
                            aria-label="Search" 
                            value={searchInput}
                            onChange={handleSearch}
                        />
                    </form>

                    <div className="navbar-buttons ms-auto">
                        {role == 'user' && 
                   <Link to = {"/cart"}>
                    <button className="btn btn-link text-light" >
                        Cart
                    </button>
                   
                   </Link>
            }
                        <button onClick={handleLogout} className="btn btn-link text-light">Logout</button>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
