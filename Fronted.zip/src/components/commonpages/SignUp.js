import React, { useState, useEffect } from "react";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput,
} from "mdb-react-ui-kit";
import { FaUser, FaPhone, FaEnvelope, FaLock, FaUserTag } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";

const SignUp = () => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    mobileno: "",
    email: "",
    password: "",
    role: "",
  });
  const [toastShown, setToastShown] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3219/api/user/register", formData);
      setToastShown(true);
      console.log(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Registration successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div style={{ backgroundColor: '#8B4513', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <MDBContainer>
        <MDBCard className="shadow-sm">
          <MDBRow className="g-0">
            <MDBCol md="5">
              <MDBCardImage
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp"
                alt="Sign Up"
                className="rounded-start w-100 h-100"
                style={{ objectFit: 'cover', height: '100%' }}
              />
            </MDBCol>

            <MDBCol md="7">
              <MDBCardBody className="d-flex flex-column align-items-center p-4">
                <div className="d-flex flex-row align-items-center mt-2">
                  <FaShoppingCart size={40} style={{ color: "#ff6219", marginRight: "10px" }} />
                  <span style={{color: 'black', fontSize: 30, }}>Meesho</span>
                </div>

                <h6 style={{color: 'black', fontSize: 20, }}>Create your account</h6>

                {/* Centered and consistent-width input fields */}
                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaUser />
                  </span>
                  <MDBInput
                    placeholder="First Name"
                    name="firstname"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaUser />
                  </span>
                  <MDBInput
                    placeholder="Last Name"
                    name="lastname"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaPhone />
                  </span>
                  <MDBInput
                    placeholder="Mobile Number"
                    name="mobileno"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaEnvelope />
                  </span>
                  <MDBInput
                    placeholder="Email address"
                    name="email"
                    type="email"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaLock />
                  </span>
                  <MDBInput
                    placeholder="Password"
                    name="password"
                    type="password"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-4 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaUserTag />
                  </span>
                  <select
                    name="role"
                    onChange={handleChange}
                    required
                    className="form-select"
                    style={{ padding: "0.8rem", fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px"}}
                  >
                    <option value="">Select Role</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>

                <MDBBtn onClick={handleSubmit} className="mb-3 px-4" color="dark" size="lg">
                  Sign Up
                </MDBBtn>
                <p className="small mb-5" style={{ fontSize: "1rem", color: "#393f81" }}>
                  Already have an account? <a href="/login" style={{ fontSize: "1rem", color: "#393f81" }}>Sign In</a>
                </p>
                <Toaster />
              </MDBCardBody>
            </MDBCol>
          </MDBRow>
        </MDBCard>
      </MDBContainer>
    </div>
  );
};

export default SignUp;


// import React, { useEffect, useState } from 'react';
//  import { useDispatch, useSelector } from 'react-redux'; 
//  import axios from 'axios';
//   import Navbar from './Navbar'; 
//  import { fetchProductsSuccess, fetchProductsFailure, fetchProductsStart } from '../../reduxComponent/ProductSlice'; 
//  import { Pagination } from 'react-bootstrap'; 
//  import 'bootstrap/dist/css/bootstrap.min.css'; 
//  import './Dashboard.css';

// const Dashboard = () => { const dispatch = useDispatch();
// const { productList, loading, error } = useSelector((state) => state.products); 
//const [searchTerm, setSearchTerm] = useState('');
// const [localLoading, setLocalLoading] = useState(true); 
//const [currentPage, setCurrentPage] = useState(1);
//const [totalPages, setTotalPages] = useState(1);

// const { token } = useSelector((state) => state.users.authUser);

// useEffect(() => {
//     const fetchProducts = async () => {
//         dispatch(fetchProductsStart());
//         setLocalLoading(true);
//         try {
//             const response = await axios.get(`http://localhost:3219/api/productadmin/getproduct?page=${currentPage}&limit=3`, {
//                 headers: { Authorization: token }
//             });
//             dispatch(fetchProductsSuccess(response.data.products));
//             setTotalPages(response.data.totalPages);
//         } catch (error) {
//             dispatch(fetchProductsFailure(error.message));
//         } finally {
//             setLocalLoading(false);
//         }
//     };
//     fetchProducts();
// }, [dispatch, currentPage]);

// const handlePageChange = (pageNumber) => setCurrentPage(pageNumber);

// if (localLoading) return <p>Loading products...</p>;
// if (error) return <p>Error fetching products: {error}</p>;

// return (
//     <div className="dashboard">
//         <Navbar onSearch={setSearchTerm} />

//         <div className="product-list">
//             {productList.map((product) => (
//                 <div key={product._id} className="product-card">
//                     <h4 className="product-name">{product.name}</h4>
//                     <p className="product-price">₹{product.price}</p>
//                 </div>
//             ))}
//         </div>

//         <Pagination>
//             {[...Array(totalPages)].map((_, index) => (
//                 <Pagination.Item
//                     key={index + 1}
//                     active={index + 1 === currentPage}
//                     onClick={() => handlePageChange(index + 1)}
//                 >
//                     {index + 1}
//                 </Pagination.Item>
//             ))}
//         </Pagination>
//     </div>
// );
// };

// export default Dashboard;