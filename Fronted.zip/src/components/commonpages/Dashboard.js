import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import Navbar from './Navbar';
import { fetchProductsSuccess, fetchProductsFailure, fetchProductsStart, deleteProduct, setSelectedProduct } from '../../reduxComponent/ProductSlice';
import { addToCart } from '../../reduxComponent/Userslice';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faEdit, faEye, faCartPlus } from '@fortawesome/free-solid-svg-icons';
import './Dashboard.css';
 import { Pagination } from 'react-bootstrap'; 


const Dashboard = () => {
    const dispatch = useDispatch();
    const { productList, loading, error } = useSelector((state) => state.products);
    const [searchTerm, setSearchTerm] = useState('');
    const [localLoading, setLocalLoading] = useState(true);
    const { authUser } = useSelector((state) => state.users);
    const { token, userId, role } = useSelector((state) => state.users.authUser);

    const [currentPage, setCurrentPage] = useState(1);
   const [totalPages, setTotalPages] = useState(1);

    const handlePageChange = (pageNumber) => setCurrentPage(pageNumber);

    const navigate = useNavigate();

    useEffect(() => {
        const fetchProducts = async () => {
            dispatch(fetchProductsStart());
            setLocalLoading(true);
            try {
                const response = await axios.get("http://localhost:3219/api/productadmin/getproduct", {
                    headers: {
                        Authorization: token,
                    },
                });
                dispatch(fetchProductsSuccess(response.data));
                console.log(response.data, "tetsting")

            } catch (error) {
                dispatch(fetchProductsFailure(error.message));
            } finally {
                setLocalLoading(false);
            }
        };

        fetchProducts();
    }, [dispatch]);

    const handleAddToCart = async (product) => {
        console.log(product, "payal");
        const res = await axios.post("http://localhost:3219/api/cart/addcart", {
            productId: product._id,
            quantity: 1,
            userId: userId,
            price: product.price,
        }, {
            headers: {
                Authorization: token
            }
        });
        console.log(res, "resss");

        dispatch(addToCart({ productId: product._id, quantity: 1 }));
        alert(`${product.name} added to cart!`);
        // navigate('/cart'); // Make sure the route matches the setup in your Router
    };


    const handleAddProductRedirect = () => {
        navigate('/add-product');
    };

    const handleUpdateProduct = (product) => {
        dispatch(setSelectedProduct(product));

        navigate('/update-product');
    };

    const handleViewProduct = (product) => {
        dispatch(setSelectedProduct(product));
        navigate('/view-product');
    };

    const handleDeleteProduct = async (productId) => {
        const confirmed = window.confirm("Are you sure you want to delete this product?");
        if (confirmed) {
            try {
                await axios.delete(`http://localhost:3219/api/productadmin/deleteproduct/${productId}`, {
                    headers: {
                        Authorization: token,
                    },
                });
                dispatch(deleteProduct(productId));
                alert("Product deleted successfully!");
            } catch (error) {
                alert("Failed to delete product. Please try again.");
            }
        }
    };


    const filteredProducts = productList?.filter((product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (localLoading) return <p>Loading products...</p>;
    if (error) return <p>Error fetching products: {error}</p>;

    return (
        <div className="dashboard">
            <Navbar onSearch={setSearchTerm} role={role} />

            {role === 'admin' && (
                <div className="add-product-container">
                    <button onClick={handleAddProductRedirect} className="add-product-button">
                        Add New Product
                    </button>
                </div>
            )}
            <div className="product-list">
                {filteredProducts.map((product) => (
                    <div key={product._id} className="product-card">
                        <img src={`http://localhost:3219/getimg/${product.image}`} alt={product.name} className="product-image" />
                        <h4 className="product-name">{product.name}</h4>
                        <p className="product-price">₹{product.price}</p>
                        <p className="product-description">{product.description}</p>
                        <div className="action-buttons">
                            {authUser.role === 'admin' ? (
                                <>
                                    <button onClick={() => handleDeleteProduct(product._id)} className="action-button delete-button">
                                        <FontAwesomeIcon icon={faTrash} />
                                    </button>
                                    <button onClick={() => handleUpdateProduct(product)} className="action-button update-button">
                                        <FontAwesomeIcon icon={faEdit} />
                                    </button>
                                    <button onClick={() => handleViewProduct(product)} className="action-button view-button">
                                        <FontAwesomeIcon icon={faEye} />
                                    </button>
                                </>
                            ) : (
                                <button onClick={() => handleAddToCart(product)} className="action-button add-to-cart-button">
                                    <FontAwesomeIcon icon={faCartPlus} />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
            <Pagination>
                {[...Array(totalPages)].map((_, index) => (
                    <Pagination.Item
                        key={index + 1}
                        active={index + 1 === currentPage}
                        onClick={() => handlePageChange(index + 1)}
                    >
                        {index + 1}
                    </Pagination.Item>
                ))}
            </Pagination>
        </div>
    );
};

export default Dashboard;
