import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import axios from "axios";
import { authUser } from "../../reduxComponent/Userslice";
import toast, { Toaster } from "react-hot-toast";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput,
} from "mdb-react-ui-kit";
import { FaEnvelope, FaLock, FaShoppingCart } from "react-icons/fa";

const SignIn = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [toastShown, setToastShown] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3219/api/user/login", formData);
      setToastShown(true);
      dispatch(authUser(res.data));
      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
    } catch (error) {
      console.log(error.message);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Login successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div style={{ backgroundColor: '#8B4513', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <MDBContainer>
        <MDBCard className="shadow-sm">
          <MDBRow className="g-0">
            <MDBCol md="5">
              <MDBCardImage
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp"
                alt="login form"
                className="rounded-start w-100 h-100"
                style={{ objectFit: 'cover', height: '100%' }}
              />
            </MDBCol>

            <MDBCol md="7">
              <MDBCardBody className="d-flex flex-column align-items-center p-4">
                <div className="d-flex flex-row align-items-center mt-2">
                  <FaShoppingCart size={40} style={{ color: "#ff6219", marginRight: "10px" }} />
                  <span style={{color: 'black', fontSize: 30, }}>Meesho</span>
                </div>

                <h6 style={{color: 'black', fontSize: 17, }}>Sign into your account</h6>

                <div className="input-group mb-3 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaEnvelope />
                  </span>
                  <MDBInput
                    placeholder="Email address"
                    name="email"
                    type="email"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <div className="input-group mb-4 w-100" style={{ maxWidth: "500px" }}>
                  <span className="input-group-text bg-light border-0">
                    <FaLock />
                  </span>
                  <MDBInput
                    placeholder="Password"
                    name="password"
                    type="password"
                    onChange={handleChange}
                    size="lg"
                    style={{ fontSize: "1.2rem", borderRadius: "0px 8px 8px 0px", width: "100%" }}
                  />
                </div>

                <MDBBtn
                  className="mb-4 px-5"
                  color="dark"
                  size="lg"
                  onClick={handleSubmit}
                >
                  Login
                </MDBBtn>

                <p className="mb-5" style={{ color: "#393f81" }}>
                  Don't have an account?{" "}
                  <a href="/" style={{ color: "#393f81" }}>Register here</a>
                </p>

                <Toaster />
              </MDBCardBody>
            </MDBCol>
          </MDBRow>
        </MDBCard>
      </MDBContainer>
    </div>
  );
};

export default SignIn;
