import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import {  addToCart, removeFromCart } from '../../reduxComponent/Userslice';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faMinus, faTrash } from '@fortawesome/free-solid-svg-icons';

const styles = {
    container: {
        maxWidth: '800px',
        margin: '20px auto',
        padding: '20px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    table: {
        width: '100%',
        borderCollapse: 'collapse',
    },
    tableHeader: {
        backgroundColor: '#ddd',
        fontWeight: 'bold',
        color: '#8B4513', 
    },
    tableCell: {
        padding: '10px',
        border: '1px solid #ccc',
        textAlign: 'center',
        color: '#8B4513', 
    },
    button: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        fontSize: '16px',
        color: '#8B4513',
    },
    totalRow: {
        fontWeight: 'bold',
        fontSize: '18px',
        color: '#8B4513', 
    },
    checkoutButton: {
        marginTop: '20px',
        padding: '10px 20px',
        fontSize: '16px',
        backgroundColor: "#6b4226",
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    }
};

const Cart = () => {
    const dispatch = useDispatch();
    const { userId, token } = useSelector((state) => state.users.authUser); 
    const [cartItems, setCartItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchCart = async () => {
            try {
                const response = await axios.get(`http://localhost:3219/api/cart/getcart`, {
                    params: { user: userId },
                    headers: { Authorization: `Bearer ${token}` }
                });
                setCartItems(response.data.items || []);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching cart:", error);
                setError(error.message);
                setLoading(false);
            }
        };

        fetchCart();
    }, [userId, token]);

    const handleIncreaseQuantity = async (productId) => {
        try {
            const item = cartItems.find(item => item.product._id === productId);
            const updatedQuantity = item.quantity + 1;

            await axios.put('http://localhost:3219/api/cart/updatecart', {
                user: userId,
                productId,
                quantity: updatedQuantity
            }, {
                headers: {
                    Authorization: token
                }
            });
            dispatch(addToCart({ productId, quantity: 1 }));
            setCartItems(cartItems.map(item => item.product._id === productId ? { ...item, quantity: updatedQuantity } : item));
        } catch (error) {
            console.error('Error increasing quantity:', error);
        }
    };

    const handleDecreaseQuantity = async (productId) => {
        try {
            const item = cartItems.find(item => item.product._id === productId);
            const updatedQuantity = item.quantity - 1;

            if (updatedQuantity > 0) {
                await axios.put('http://localhost:3219/api/cart/updatecart', {
                    user: userId,
                    productId,
                    quantity: updatedQuantity
                }, {
                    headers: {
                        Authorization: token
                    }
                });
                dispatch(addToCart({ productId, quantity: -1 }));
                setCartItems(cartItems.map(item => item.product._id === productId ? { ...item, quantity: updatedQuantity } : item));
            } else {
                handleRemoveItem(productId);
            }
        } catch (error) {
            console.error('Error decreasing quantity:', error);
        }
    };

    const handleRemoveItem = async (productId) => {
        try {
            await axios.delete(`http://localhost:3219/api/cart/deletecart/${productId}`, {
                data: { user: userId },
                headers: { Authorization: token }
            });
            dispatch(removeFromCart(productId));
            setCartItems(cartItems.filter(item => item.product._id !== productId));
        } catch (error) {
            console.error('Error removing item:', error);
        }
    };

    const calculateTotal = () => {
        return cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
    };

    const handleCheckout = async () => {
        const items = cartItems.map(item => ({
            product: item.product._id,
            price: item.product.price,
            quantity: item.quantity,
        }));
        const totalAmount = calculateTotal();

        try {
            await axios.post(`http://localhost:3219/api/order/createorderproduct`, {
                user: userId,
                items,
                totalAmount
            });
            navigate('/order');
        } catch (error) {
            console.log(error);
        }
    };

    if (loading) return <p>Loading cart...</p>;
    if (error) return <p>Error fetching cart: {error}</p>;

    return (
        <>
        <div>
        <h1 style={{color: "brown"}}>Your Cart </h1>
        
        </div>
        <div style={styles.container}>
            {cartItems.length === 0 ? (
                <p>Your cart is empty.</p>
            ) : (
                <div>
                    <table style={styles.table}>
                        <thead style={styles.tableHeader}>
                            <tr>
                                <th style={styles.tableCell}>Product</th>
                                <th style={styles.tableCell}>Price</th>
                                <th style={styles.tableCell}>Quantity</th>
                                <th style={styles.tableCell}>Subtotal</th>
                                <th style={styles.tableCell}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cartItems.map((item) => (
                                <tr key={item.product._id}>
                                    <td style={styles.tableCell}>{item.product.name}</td>
                                    <td style={styles.tableCell}>${item.product.price}</td>
                                    <td style={styles.tableCell}>{item.quantity}</td>
                                    <td style={styles.tableCell}>${item.product.price * item.quantity}</td>
                                    <td style={styles.tableCell}>
                                        <button style={styles.button} onClick={() => handleIncreaseQuantity(item.product._id)}>
                                            <FontAwesomeIcon icon={faPlus} />
                                        </button>
                                        <button style={styles.button} onClick={() => handleDecreaseQuantity(item.product._id)}>
                                            <FontAwesomeIcon icon={faMinus} />
                                        </button>
                                        <button style={styles.button} onClick={() => handleRemoveItem(item.product._id)}>
                                            <FontAwesomeIcon icon={faTrash} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            <tr style={styles.totalRow}>
                                <td colSpan="3" style={styles.tableCell}>Total</td>
                                <td style={styles.tableCell}>${calculateTotal()}</td>
                                <td style={styles.tableCell}></td>
                            </tr>
                        </tbody>
                    </table>
                    <button style={styles.checkoutButton} onClick={handleCheckout}>Check Out</button>
                </div>
            )}
        </div>
        </>
    );
};

export default Cart;
