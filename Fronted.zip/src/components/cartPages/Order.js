import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

const styles = {
    container: {
        maxWidth: '800px',
        margin: '20px auto',
        padding: '20px',
        backgroundColor: '#f9f9f9',
        borderRadius: '12px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    order: {
        borderBottom: '1px solid #ddd',
        padding: '15px 0',
    },
    orderTitle: {
        fontSize: '18px',
        fontWeight: 'bold',
        color: '#333',
    },
    orderDetail: {
        margin: '5px 0',
        color: '#555',
    },
    itemsList: {
        listStyleType: 'none',
        padding: 0,
    },
    item: {
        padding: '10px',
        backgroundColor: '#f3f3f3',
        borderRadius: '5px',
        margin: '8px 0',
    },
    itemDetail: {
        margin: '3px 0',
        color: '#666',
    }
};

const OrderComponent = () => {
    const { userId, token } = useSelector((state) => state.users.authUser); 
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get(`http://localhost:3219/api/order/getorder/${userId}`);
                setOrders(response.data);
            } catch (err) {
                setError('Error fetching orders');
            } finally {
                setLoading(false);
            }
        };
        
        fetchOrders();
    }, [userId]);

    if (loading) return <p>Loading orders...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div style={styles.container}>
            <h2 style={styles.orderTitle}>Order History</h2>
            {orders.length === 0 ? (
                <p>No orders found.</p>
            ) : (
                orders.map(order => (
                    <div key={order._id} style={styles.order}>
                        <h3 style={styles.orderTitle}>Order ID: {order._id}</h3>
                        <p style={styles.orderDetail}>User Email: {order.user.email}</p>
                        <p style={styles.orderDetail}>Total Amount: ${order.totalAmount}</p>
                        <p style={styles.orderDetail}>Created At: {new Date(order.createdAt).toLocaleDateString()}</p>
                        
                        <h4 style={styles.orderTitle}>Items:</h4>
                        <ul style={styles.itemsList}>
                            {order.items.map(item => (
                                <li key={item._id} style={styles.item}>
                                    <p style={styles.itemDetail}>Product: {item.product.name}</p>
                                    <p style={styles.itemDetail}>Price: ${item.product.price}</p>
                                    <p style={styles.itemDetail}>Quantity: {item.quantity}</p>
                                    <p style={styles.itemDetail}>Subtotal: ${item.price * item.quantity}</p>
                                </li>
                            ))}
                        </ul>
                    </div>
                ))
            )}
        </div>
    );
};

export default OrderComponent;
