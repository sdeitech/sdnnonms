import React, { useState, useEffect } from "react";
import { fetchUsers, addUser, fetchUser, getPeginatedData } from "../api";
import "./Dashboard.css";
import View from './View'

const Dashboard = () => {
  const [users, setUsers] = useState(() => {

    const savedUsers = localStorage.getItem("users");
    return savedUsers ? JSON.parse(savedUsers) : [];
  });

  const [totalPages, settotalPages] = useState(1)
  const [pageNo, setpageNo] = useState(1)

  const handlepagenet = (event, page) => {
    setpageNo(page)
  }

  const fetchpagenetData = async () => {
    try {
      const response = await getPeginatedData(pageNo)
      console.log(response.data);
      setUsers(response.data.user)
      settotalPages(response.data.totalPages)
      setpageNo(response.data.pageNo)

      console.log(response.data.pageNo, "payal")
      console.log(response.data, "aaaa")

    } catch (error) {
      console.log(error.message);

    }
  };

  useEffect(() => {
    fetchpagenetData()
  }, [pageNo])


  const [currentUser, setCurrentUser] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };


  const [searchUser, setSearchUser] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newUser = await addUser(formData);
      const updatedUser = [...users, newUser];
      setUsers(updatedUser);

      localStorage.setItem("users", JSON.stringify(updatedUser));

      setFormData({
        firstname: "",
        lastname: "",
        email: "",
      });
      setShowModal(false);
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };

  const [result, setResult] = useState(null);
  const [showview, setShowView] = useState(false);


  const loadUser = async () => {
    try {
      const fetchedUser = await fetchUser();
      console.log("Fetched User Data:", fetchedUser);
      setCurrentUser(fetchedUser);
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  useEffect(() => {
    
    loadUser();
  }, []);

  const handleSearchChange = (e) => {
    setSearchUser(e.target.value);
  }

  const filteredUser = users.filter(user =>
    user.firstname.toLowerCase().includes(searchUser.toLowerCase()) ||
    user.lastname.toLowerCase().includes(searchUser.toLowerCase()) ||
    user.email.toLowerCase().includes(searchUser.toLowerCase())

  );

  return (
    <div className="dashboard-container">
      <div className="title">
        <h1>Dashboard</h1>
      </div>
      <button onClick={() => setShowModal(true)}>
        Add User
      </button>
      <input type="text" placeholder="Search Users" value={searchUser}
        onChange={handleSearchChange} />

      <table className="user-table">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>{user.firstname}</td>
              <td>{user.lastname}</td>
              <td>{user.email}</td>
              <td>
                <button onClick={() => {
                  setShowView(!showview);
                  setResult(user);
                }}>
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
        {showview && <View result={result} />}
      </table>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Add User</h2>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="firstname"
                placeholder="First Name"
                value={formData.firstname}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="lastname"
                placeholder="Last Name"
                value={formData.lastname}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                required
              />

              <div className="modal-buttons">
                <button type="submit">Add</button>
                <button type="button" onClick={() => setShowModal(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
