import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../api";
import '../components/style.css';

const SignIn = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await loginUser(formData);
      console.log("Login Success:", result);
      localStorage.setItem("token", result.token);
      alert("Login Successful!!!")
      navigate("/dashboard");
    } catch (error) { 
      console.error("Login Error:", error.message);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-container">
        <h2 className="auth-title">Welcome Back!</h2>
        <p className="auth-subtitle">Login to access your account</p>
        <form className="auth-form" onSubmit={handleSubmit}>
          <input type="email" name="email" placeholder="Enter email" onChange={handleChange} required />
          <input type="password" name="password" placeholder="Enter password" onChange={handleChange} required />
          <button type="submit" className="small-button"  onClick={() => navigate("/dashboard")}>Login</button>
        </form>
        <div className="auth-footer">
          <h3>Don't have an account? <span className="auth-link" onClick={() => navigate("/signup")}>Register here</span></h3>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
