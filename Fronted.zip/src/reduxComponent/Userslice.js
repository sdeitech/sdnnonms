import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "auth",
  initialState: {
    authUser: {
      token: null,
      userId: null,
      role:null,
    },
    cart: { 
      items: [],
    },
  },
  reducers: {
    authUser: (state, action) => {
      state.authUser.token = action.payload.token;
      state.authUser.userId = action.payload.userId;
      state.authUser.role = action.payload.role;

    },
    logoutUser: (state) => {
      state.authUser.token = null;
      state.authUser.userId = null;
    },
    clearUsers: (state) => {
      state.authUser.token = null;
      state.authUser.userId = null;
    },
    resetUsers : (state) => {
      state.authUser.token = null;
      state.authUser.userId = null;
    }, 

    setCart: (state, action) => {
      state.cart.items = action.payload; 
    },
    addToCart: (state, action) => {
      const { productId, quantity } = action.payload;
      const existingProduct = state.cart.items.find(item => item.product === productId);

      if (existingProduct) {
        existingProduct.quantity += quantity;
      } else {
        state.cart.items.push({ product: productId, quantity });
      }
    },
    removeFromCart: (state, action) => {
      const productId = action.payload;
      state.cart.items = state.cart.items.filter(item => item.product !== productId); 
    },
  },
});

export default userSlice.reducer;
export const { authUser, logoutUser, clearUsers, addToCart, setCart,removeFromCart, resetUsers } = userSlice.actions;
