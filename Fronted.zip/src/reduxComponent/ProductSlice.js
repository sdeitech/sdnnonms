import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({
  name: "products",
  initialState: {
    productList: [],
    loading: false,
    error: null,
    selectedProduct: null,
  },
  reducers: {
    fetchProductsStart: (state) => {
      state.loading = true;  
      state.error = null;    
    },
    fetchProductsSuccess: (state, action) => {
      state.loading = false;                
      state.productList = action.payload;  
    },
    fetchProductsFailure: (state, action) => {
      state.loading = false;               
      state.error = action.payload;        
    },
    addProduct: (state, action) => {
      state.productList.push(action.payload);
  },
  deleteProduct(state, action) {
    state.productList = state.productList.filter(product => product._id !== action.payload);
},
setSelectedProduct(state, action) {
  state.selectedProduct = action.payload; 
},
updateProduct(state, action) {
  const index = state.productList.findIndex(product => product._id === action.payload._id);
  if (index !== -1) {
      state.productList[index] = action.payload;
  }
},
   
    resetProducts: (state) => {
      state.productList = [];
      state.loading = false;
      state.error = null;
    },
  },
});

export default productSlice.reducer;
export const { fetchProductsStart, fetchProductsSuccess, fetchProductsFailure, resetProducts,addProduct,deleteProduct,setSelectedProduct,updateProduct } = productSlice.actions;
