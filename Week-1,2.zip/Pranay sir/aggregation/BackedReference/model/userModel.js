import mongoose from "mongoose";


const userSchema = mongoose.Schema(
  {
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
      required: true,
    },
    address: {
      type: String,
    },
    age: {
      type: Number,
    },
    type: {
      type: String,
      enum: ['employee', 'user']
    },
    isActivated: {
      type: Boolean,
      default: true
    },
    assessmentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Assessment'
    },
  },
  {
    timestamps: true,
  }
);

// userSchema.pre('save', async function(next) {
//   const user = this;
//   user.lastName = "NewLast"
// });

const User = mongoose.model("User", userSchema);

module.exports = User;