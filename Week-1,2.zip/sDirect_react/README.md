What is react?
- React is an open source JavaScript library. 
- Its used for building user interface specifically for single page application.
- Handling the view layer for web and mobile app.
Who invented react js?
- Jordan Walke, first used 2011 for facebook, Initially release 29th May 2013.
What is Elememt?
- An element is defined by a starting tag <> some content and ending tag  
<h1>Hello smartData </h1>
What is attribute?
- Attribute is the provide additional information about HTML element.

What is form?
From is the collect the user input data and manage it through components.
It consist of HTML form elements such as <input />, <select>, <textarea> etc 
there are 2 type of forms in react
1) Controller
2) Uncontroller
1) Controller: 
- form data is handled by the component’s state.
- The form element’s value is bound to the component’s state. (UseState)
- any change to the form updates the state. (OnClick Event)
2) Uncontrolled Components:
- the form data is handled by the DOM itself. (useRef)







Validatation
There are two common types of validation:
1) Client-side validation
2) Server-side validation

1) Client-side validation: Performed in the browser, usually using JavaScript or HTML5 attributes
2) Server-side validation: Performed on the server

Advantages of Validation:
- Improved Data Accuracy and Quality:
- Better User Experience:
- Reduces Server Load:
- Consistent Data Format:
- Immediate Feedback:

Checking if the email field is empty:
if (!values.email) {
    errors.email = "Email is required";
}
- If the email field is empty, the error message "Email is required" is added to the errors object under the email key.

Checking if the email format is valid:
else if (!/\S+@\S+\.\S+/.test(values.email)) {
    errors.email = "Email address is invalid";
}
-/\S+@\S+\.\S+/ is the regular expression (regex) used to validate the email format.

const validateUser = (values) => {
    let errors = {};

    if (!values.name) {
        errors.name = "Name is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";
    }

    if (!values.password) {
        errors.password = "Password is required";
    } else if (values.password.length < 6) {
        errors.password = "Password needs to be more than 5 characters";
    }

    if (!values.address) {
        errors.address = "Address is required";
    }

    if (!values.city) {
        errors.city = "City is required";
    }

    if (!values.gender) {
        errors.gender = "Gender is required";
    }

    if (!values.termsAccepted) {
        errors.termsAccepted = "You must accept the terms and conditions";
    }

    return errors;
};

export default validateUser;


import React, { useState } from 'react';
import validateUser from '../../validate/validateUser'
import './User.css';

export default function FormComponent() {
    // State to hold form data
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        address: '',
        city: '',
        gender: '',
        termsAccepted: false,
    });

    const [errors, setErrors] = useState({});

    // Handle input changes
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value,
        });
    };

    // Handle form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Form data submitted:', formData);

        const validationErrors = validateUser(formData);
        if (Object.keys(validationErrors).length === 0) {
            console.log('Form data submitted:', formData);
            // Perform form submission or API call here
        } else {
            setErrors(validationErrors);
        }

        // Log the form data

    };
    
    return (
        <>
            <form className="form-container" onSubmit={handleSubmit}>
                <h2>Register Form</h2>

                <div className="form-group">
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                    {errors.name && <p className="error">{errors.name}</p>}
                </div>

                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                    />
                    {errors.email && <p className="error">{errors.email}</p>}
                </div>

                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                    />
                    {errors.password && <p className="error">{errors.password}</p>}
                </div>

                <div className="form-group">
                    <label>Address:</label>
                    <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        rows="4"
                        cols="34"
                    />
                     {errors.address && <p className="error">{errors.address}</p>}
                </div>

                <div className="form-group">
                    <label>City:</label>
                    <select
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                    >
                        <option value="">Select your city</option>
                        <option value="nagpur">Nagpur</option>
                        <option value="bhandara">Bhandara</option>
                        <option value="wardha">Wardha</option>
                        <option value="amravati">Amravati</option>
                        <option value="akola">Akola</option>
                    </select>
                    {errors.city && <p className="error">{errors.city}</p>}
                </div>

                <div className="form-group">
                    <label>Gender:</label>
                    <div>
                        <input
                            type="radio"
                            name="gender"
                            value="male"
                            checked={formData.gender === 'male'}
                            onChange={handleChange}
                        /> Male
                        <input
                            type="radio"
                            name="gender"
                            value="female"
                            checked={formData.gender === 'female'}
                            onChange={handleChange}
                        /> Female
                        {errors.gender && <p className="error">{errors.gender}</p>}
                    </div>
                </div>

                <div className="form-group">
                    <label>
                        <input
                            type="checkbox"
                            name="termsAccepted"
                            checked={formData.termsAccepted}
                            onChange={handleChange}
                        /> I accept the terms and conditions
                    </label>
                    {errors.termsAccepted && <p className="error">{errors.termsAccepted}</p>}
                    
                </div>

                <div className="form-group">
                    <button type="submit" className="submit-button">Submit</button>
                </div>
            </form>
        </>
    );
}

