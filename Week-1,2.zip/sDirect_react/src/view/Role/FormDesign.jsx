import React, { useState } from 'react'

export default function FormDesign() {

    const [userData, setUserData] = useState({
        name: "",
        email: "",
        password: ""

    })

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setUserData({
            ...userData, 
            [name]: type === 'checkbox' ? checked : value,
        });
    }


  return (
    <>
        <form className="form-container">
            <h1>Registration</h1>
            <div className='form-group'>
                <label>Name:</label>
                <input 
                    placeholder='Enter a name'
                    name='name'
                    value={userData.name}
                    onChange={handleChange}
                />
            </div>

        </form>
    </>
  ) 
}
