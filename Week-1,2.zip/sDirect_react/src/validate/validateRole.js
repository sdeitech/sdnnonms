const validateUser = (values) => {
    let errors = {};

    if (!values.name) {
        errors.name = "Name is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";
    }

    if (!values.password) {
        errors.password = "Password is required";
    } else if (values.password.length < 6) {
        errors.password = "Password needs to be more than 5 characters";
    }

    if (!values.address) {
        errors.address = "Address is required";
    }

    if (!values.city) {
        errors.city = "City is required";
    }

    if (!values.gender) {
        errors.gender = "Gender is required";
    }

    if (!values.termsAccepted) {
        errors.termsAccepted = "You must accept the terms and conditions";
    }

    return errors;
};

export default validateUser;
