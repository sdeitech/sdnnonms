const express = require('express')
const { appendFile } = require('fs')
const http = require('http')
const bodyParser = require('body-parser')
const createConnection = require('./db.js')

let collection;

const connectToDb = async () => {
  try {
    collection = await createConnection(); // Get the collection after connecting
  } catch (error) {
    console.error("Error connecting to database:", error);
  }
};

// Call the connection function when the server starts
connectToDb();

const app = express()

app.use(bodyParser.json())

app.post('/add-rescord', async (req,res) => {
    try {
        const {firstName, lastNAme} = req.body
        const addRecord = await collection.insertOne({
            firstName, lastNAme
        })
        res.json({
            message: 'Records inserted Successfully'
        })
    } catch (error) {
        console.log(error, 'error');
        res.json({
            error,
            message: 'Something went wrong'
        }) 
    }
})

const server = http.createServer(app)


server.listen(4000, (err, res) => {
    if (err) throw err
    console.log('listening on port 4000');
})