const { messages } = require("../config/constants")
const { Responses } = require("../middleware/responses")
import User from "../model/userModel"
import Assessment from "../model/assessmentModel"
import mongoose from "mongoose"

const addData = async (req, res) => {
    try {
        const { firstName, lastName, address, age, type, assessmentId } = req.body
        console.log(typeof age)
        const saveData = new User({ 
            firstName, 
            lastName, 
            address, 
            age, 
            type, 
            assessmentId
        })
        await saveData.save()
        Responses._201(res, {
            status: true,
            message: messages.add,
            body: saveData,
        })
    } catch (error) {
        Responses._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}
const addAssessment = async (req, res) => {
    try {
        const { question, type, options, name} = req.body
        const data = {
            question,
            type,
            options,
            name
        }
        const saveData = new Assessment(data)
        await saveData.save()
        Responses._201(res, {
            status: true,
            message: messages.add,
            body: saveData,
        })
    } catch (error) {
        Responses._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}
const getAssessment = async (req, res) => {
    try {
        const { page, limit, searchText } = req.query
        // const getData = await User.find({}).select('firstName age') // Find all users

        const filter = {
            $or:[
                {firstName: {$regex: searchText || '', $options: 'i'},},
                {lastName: {$regex: searchText || '', $options: 'i'},},
            ]
        }

        const getDataWithPopulate = await User.find(filter).select('firstName')
                                    .populate({path:'assessmentId',select: 'question'})
                                    .limit(limit)
                                    .skip((page-1) * limit)
                                    .sort({createdAt: -1})
        
        Responses._201(res, {
            status: true,
            message: messages.listSuccess,
            body: getDataWithPopulate,
        })
    } catch (error) {
        Responses._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}

module.exports = {
    addData,
    addAssessment,
    getAssessment,
}