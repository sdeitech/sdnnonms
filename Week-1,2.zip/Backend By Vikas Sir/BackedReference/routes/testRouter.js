import express from "express";
import { addData, addAssessment, getAssessment } from "../controller/test.controller";
import { authorizeRole, verifyToken } from "../middleware/verifyToken";
import { imageValidator, validator } from "../validator/validator";

const testRouter = express.Router();
// testRouter.use(verifyToken);
testRouter.post("/add-user", addData);
testRouter.post("/add-assessment", addAssessment);
testRouter.get("/get-user", getAssessment);

module.exports = testRouter;
