const Joi = require('joi');

function createPostSchema(req, res, next) {
    const schema = Joi.object({
        title: Joi.string().required(),
        description : Joi.string().required(),
        status: Joi.string().required(),
        
    });
    validateRequest(req, res, next, schema);
}

function createCategorySchema(req, res, next) {
    const schema = Joi.object({
        cat_name: Joi.string().required(),
        cat_desc: Joi.string(),
        status: Joi.string().required()
    });
    validateRequest(req, res, next, schema);
}
function createAutherSchema(req, res, next) {
    const schema = Joi.object({
        first_name: Joi.string().required(),
        last_name: Joi.string().required(),
        email: Joi.string().required().email(),
        phone: Joi.number().integer().required(),
       
    });
    validateRequest(req, res, next, schema);
}


function validateRequest(req, res, next, schema) {
    const options = {
        abortEarly: false, // include all errors
        allowUnknown: true, // ignore unknown props
        stripUnknown: true // remove unknown props
    };
    const { error, value } = schema.validate(req.body, options);
    if (error) {
       // next(`Validation error: ${error.details.map(x => x.message).join(', ')}`);
       res.send(error);
    } else {
        req.body = value;
        next();
    }
}

module.exports = { createCategorySchema, createPostSchema, createAutherSchema }





// router.post('/addpost',validation.createPostSchema, postController.addPosts)
