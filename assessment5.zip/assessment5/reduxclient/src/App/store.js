import { configureStore } from "@reduxjs/toolkit";
import Authreducer from "../features/Authuser";
export const store = configureStore({
  reducer: {
    AuthUser: Authreducer,
  },
});
