import Privatelayout from "../layouts/Privatelayout";
import Maindashboard from "../Component/Dashboard/Maindashboard";
import Import from "../Component/Dashboard/Import";
import { Viewprofile } from "../Component/Dashboard/Viewprofile";
import View from "../Component/Dashboard/View";
const Privateroute= [
    {
        path:'/maindashboard',
        exact:true,
        element:<Privatelayout><Maindashboard/></Privatelayout>
    },
    {
        path:'/import',
        exact:true,
        element:<Privatelayout><Import /></Privatelayout>
    },
    {
        path:'/viewProfile',
        exact:true,
        element:<Privatelayout><Viewprofile /></Privatelayout>
    },
    {
        path:'/view',
        eaxct:true,
        element:<Privatelayout><View/></Privatelayout>
    }
]

export default Privateroute;