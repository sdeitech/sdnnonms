import axios from 'axios';

const base_url= "http://localhost:4000";

const apiCall= axios.create({
    baseURL:base_url,
    headers:{
        "Content-Type":"application/json"
    }
})

export default apiCall;