import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { LoginAuthUser } from '../features/Authuser';
import { useNavigate } from 'react-router-dom';
import { GoogleLogin, GoogleOAuthProvider } from '@react-oauth/google';
const clientId = "598813302719-b6jeo85np0pnma5qasggi0qre5mfpe2l.apps.googleusercontent.com";

export const Login = () => {

    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [formData, setFromData] = useState({
        email: '',
        password: ''
    });
    const [error, setError] = useState(null);
    const [formErrors, setFormErrors] = useState({});

    const validateForm = () => {
        const errors = {};
        if (!formData.email) {
            errors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            errors.email = "Email is invalid";
        }

        if (!formData.password) {
            errors.password = " password is required";
        }

        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const [logindata,setloginData]=useState(
        localStorage.getItem("loginData")
        ?JSON.parse(localStorage.getItem("loginData")):null
    )

    const handlesuccess = async (response) => {
        console.log("response",response)
        try {
            const res= await fetch(`http://localhost:4000/authUser/googlelogin`,{
                method:"post",
                body:JSON.stringify({token:response}),
                headers:{"Content-Type":"application/json"}
            });
            console.log("login with google success");
            if(!res.ok)
            {
               throw new Error("failed to login with google");
            }
            const data = await res.json();

            setloginData(data);
            localStorage.setItem("loginData",JSON.stringify(data));

        }
        catch (error) {
            console.log("login not success");
        }

    }
    const handleError = () => {
        console.log("error while login")
    }

    const handleSimpleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        const result = await dispatch(LoginAuthUser(formData));
        console.log(result, "result")
        if (result?.payload?.status === 200) {
            navigate("/maindashboard")
        }
        else {
            console.log("login not success")
            navigate('/')
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFromData((prev) => ({
            ...prev, [name]: value
        }))
    }

    return (
        <div className='conatainer form-data'>
            <div className='container login-container'>
                <form className='login-form'>
                    <h3 > SIGN IN</h3>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="email"
                            name="email"
                            placeholder='EMAIL'
                            onChange={handleChange}
                            value={formData.email}
                        />
                        {formErrors.email && <p style={{ color: "red" }}>{formErrors.email}</p>}
                    </div>
                    <br></br>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="password"
                            name="password"
                            placeholder='PASSWORD'
                            onChange={handleChange}
                            value={formData.password}
                        />
                        {formErrors.password && <p style={{ color: "red" }}>{formErrors.password}</p>}
                    </div>
                    <br></br>
                    <div>
                        <span
                            type="submit"
                            onClick={() =>
                                navigate('/forgotPassword')
                            }
                        >Forgot password ?</span>
                        <br></br>
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={handleSimpleSubmit}>
                            SUBMIT
                        </button> &nbsp;
                        <button type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={() =>
                                navigate('/register')
                            }>
                            SIGNUP
                        </button> &nbsp;
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                        >
                            <GoogleOAuthProvider clientId={clientId}>
                                <GoogleLogin
                                    onSuccess={(credentialsResponse) => {
                                        handlesuccess(credentialsResponse.credential)
                                    }}
                                    onError={handleError} />
                            </GoogleOAuthProvider>

                        </button>

                    </div>
                </form>
            </div>
        </div>
    )
}
