import React, { useState } from "react";
import { useNavigate } from "react-router";
import Papa, { unparse } from "papaparse";
import { saveAs } from "file-saver";
import Paginate from "./Paginate";
import "../../styles/Register.css";
import axios from "axios";

// const allowExtension = ["csv"];

const Maindashboard = () => {
  const navigate = useNavigate();
  //   const id = localStorage.getItem("id");
  const [viewProfile, setViewProfile] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");

  const loginData = localStorage.getItem("userData");
  const newUserData = JSON.parse(loginData);

  // const [data, setData] = useState([]);
  const [userData, setUserdata] = useState([]);

  const [dataPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(userData.length / dataPerPage);
  const startIndex = (currentPage - 1) * dataPerPage;
  const endIndex = startIndex + dataPerPage;
  const currentItems = userData.slice(startIndex, endIndex);

  const [showSearch, setShowSearch] = useState(false);
  const filterData = userData.filter((item) =>
    item.firstName.toString().toLowerCase().includes(searchTerm.toLowerCase())
  );

  console.log(filterData, "ggg");

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    // console.log(e.target.value,'ff')
    setShowSearch(true);
  };

  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  if (file) {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setUserdata(results.data);
      },
    });
  }
  const formData = new FormData();
  formData.append("csv", file);


  const token=localStorage.getItem("token");
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:4000/uploadfile", formData, {
        headers: {
          "Content-Type": "application/form-data",
          "Authorization":`bearer ${token}`
        }
      });
      // console.log(response, "response")
      console.log("file uploaded successfully");
      navigate("/maindashboard");
    } catch (error) {
      console.log("error while uploading csv file ");
    }
  };

  //logout
  const logout = async () => {
    localStorage.clear();
    navigate("/");
  };

  //download file
  const handleDownload = () => {
    const csv = Papa.unparse(userData);
    const blob = new Blob([csv], { type: "txt/csv;charset=utf-8;" });
    saveAs(blob, "user.csv");
    console.log("file saved");
  };

  //handle view
  const handleView = (value) => {
    navigate("/view", { state: { user: value } });
  };

  return (
    <div className="container bgcolor lightblue">
      <div>
        {" "}
        <strong>USER MANAGEMENT</strong>
        <span style={{ float: "right" }} onClick={logout}>
          logout
        </span>
      </div>
      <hr></hr>
      <div>
        welcome ! {newUserData.firstName}
        <span
          style={{ float: "right" }}
          onClick={(e) => {
            setViewProfile(!viewProfile);
          }}
        >
          My Profile
        </span>
        <br />
      </div>
      {viewProfile && navigate("/viewprofile")}
      <hr></hr>
      <div>
        <input
          type="search"
          placeholder="Search.."
          value={searchTerm}
          name="search"
          onChange={handleSearch}
        />
        &nbsp;
        <hr></hr>
        <div>
          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <input
                className="form-control"
                placeholder="enter csv file"
                type="file"
                accept=".csv"
                onChange={handleFileChange}
              />
              <br></br>
              <button type="submit">Import File</button>
            </div>
          </form>
          <button
            style={{ float: "right" }}
            variant="success"
            onClick={handleDownload}
          >
            EXPORT
          </button>
          <div>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                  <th>Sr. No</th>
                  <th>FirstName</th>
                  <th>LastName</th>
                  <th>email</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {showSearch
                  ? filterData.map((value, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{value.firstName}</td>
                        <td>{value.lastName}</td>
                        <td>{value.email}</td>
                        <td>
                          <button>View</button>
                        </td>
                      </tr>
                    ))
                  : currentItems.map((value, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{value.firstName}</td>
                        <td>{value.lastName}</td>
                        <td>{value.email}</td>
                        <td>
                          <button onClick={() => handleView(value)}>
                            view
                          </button>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </div>
          <Paginate
            totalPages={totalPages}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </div>
      </div>
    </div>
  );
};
export default Maindashboard;
