import React, { useState } from 'react'
import Papa from 'papaparse'

const allowExtension = ["csv"];
const Import = () => {
    const [count, setCount] = useState(0);
    const [data, setData] = useState([]);
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            Papa.parse(file, {
                header: true,
                skipEmptyLines: true,
                complete: (results) => {
                    // console.log(results.data)
                    setData(results.data)
                    setCount(results.data.length);
                    // console.log(results.data.length,"length")
                }
            })
        }
    }
    return (
        <div>
            <input
                placeholder='enter csv file'
                type="file"
                accept='.csv'
                onChange={handleFileChange}
            />

            <div>
                <table className='table table-striped'>
                    <thead className='thead-dark'>
                        <tr>
                            <th>Sr. No</th>
                            <th>FirstName</th>
                            <th>LastName</th>
                            <th>email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((value, index) => (
                                <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td>{value.firstName}</td>
                                    <td>{value.lastName}</td>
                                    <td>{value.email}</td>
                                    <td>
                                        <button>View</button>
                                    </td>

                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    );

}

export default Import