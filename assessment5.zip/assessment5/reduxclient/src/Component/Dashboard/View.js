import React from 'react'

const View = ({ user }) => {
    return (
        <div class="card">
            <h5 class="card-header">User Details</h5>
            <div class="card-body">
                <h5 class="card-title">{user.firstName} {user.lastName}</h5>
                <p >{user.email}</p>
            </div>
        </div>

    )
}

export default View;