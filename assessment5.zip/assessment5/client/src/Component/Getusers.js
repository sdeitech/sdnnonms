import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { View } from './View'
import axios from 'axios'
import "../Style/table.css"
import Paginate from './Paginate'
import validateUser from '../Component/validate';

export const Getusers = () => {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [viewProfile, setViewProfile] = useState(false)
    const [user, setuser] = useState(null);
    const [viewDetails, setViewdetails] = useState(false);

    //searching states
    const [search, setSearch] = useState("");

    //pagination states
    const [dataPerPage, setDataperPage] = useState(5);
    const [currentPage, setCurrentPage] = useState(1);

    const userData = localStorage.getItem("userData");
    const newUserData = JSON.parse(userData);

    const id = localStorage.getItem('id');

    const fetchUserdata = async () => {
        try {
            const result = await axios.get(`http://localhost:4000/getUser/${id}`);
            setData(result.data.Users);

        } catch (error) {
            console.log("error while fetching data")
        }
    }

    //searching 
    const handleSearch = (e) => {
        setSearch(e.target.value);
    }

    //logout
    const logout = async () => {
        localStorage.clear();
        navigate('/')
    }

    const totalPages = Math.ceil(data.length / dataPerPage);
    const startIndex = (currentPage - 1) * dataPerPage;
    const endIndex = startIndex + dataPerPage;
    const currentItems = data.slice(startIndex, endIndex);

    useEffect(() => {
        fetchUserdata();
    }, [])

    return (
        <div className='container'>
            <div><strong>USER MANAGEMENT</strong>
                <span style={{ float: 'right' }} onClick={logout} >logout</span></div>
            <hr></hr>
            <div>welcome ! {newUserData.firstName}
                <span style={{ float: 'right' }} onClick={(e) => { setViewProfile(!viewProfile) }}>My Profile</span>
                <br />

            </div>
            {viewProfile && navigate('/viewprofile')}
            <hr></hr>
            <div>
                <input
                    type="search"
                    placeholder="Search.."
                    name="search"
                    onChange={handleSearch}
                />&nbsp;
                <button onClick={() => navigate('/adduser')}>ADDUSER</button>
                <table>
                    <thead>
                        <tr>
                            <th>SR. No</th>
                            <th>firstName</th>
                            <th>LastName</th>
                            <th>EMAIL</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentItems.map((value, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{value.firstName}</td>
                                <td>{value.lastName}</td>
                                <td>{value.email}</td>
                                <td>
                                    <button
                                        variant="success"
                                        onClick={() => {
                                            setViewdetails(!viewDetails)
                                            setuser(value)
                                        }
                                        }>
                                        view
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <br></br>
                <Paginate
                    totalPages={totalPages}
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                />
                {viewDetails && <View data={user} show={viewDetails} />}
            </div>
        </div>
    )
}
