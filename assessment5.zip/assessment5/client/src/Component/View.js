import React from 'react'
import { useNavigate } from 'react-router';

export const View = ({ data, show }) => {

    return (
        <div>
            <p>Name:{data.firstName} {data.lastName}</p>
            <p>Email: {data.email}</p>
        </div>
    )
}
