import React, { useState } from 'react'
import '../Style/login.css';
import { useNavigate } from 'react-router';
import axios from 'axios'
import validateUser from './validate';

export const Adduser = () => {
    const navigate = useNavigate()
    const id = localStorage.getItem('id');
    const token = localStorage.getItem("token")
    // console.log(id)
    const [formData, setFormdata] = useState({
        firstName: "",
        lastName: "",
        email: "",
        createdBy: id
    });
    const [errors, setErrors] = useState({});

    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationError = validateUser(formData);
        if (Object.keys(validationError).length === 0) {
            try {
                const result = await axios.post(`http://localhost:4000/AddUser`, formData, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                console.log("user added", result.data)
                navigate('/dashboard')
            }
            catch (error) {
                console.log("error while adding user")
            }
        }
        else {
            setErrors(validationError);
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormdata({ ...formData, [name]: value })
    }

    return (
        <div className='conatainer form-data' >
            <div className='container login-container' >
                <form onSubmit={handleSubmit} encType='multipart/form-data' >
                    <h2>Add User</h2>
                    <div className='form-group'>
                        <input
                            type="text"
                            name="firstName"
                            value={formData.firstName}
                            placeholder='firstName'
                            onChange={handleChange}

                        />
                        {errors.firstName && <p className='form-message'>{errors.firstName}</p>}
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type="text"
                            name="lastName"
                            value={formData.lastName}
                            placeholder='lastName'
                            onChange={handleChange}
                        />
                        {errors.lastName && <p className='form-message'> {errors.lastName}</p>}
                    </div>
                    <br></br>
                    <div className='form-group'>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            placeholder='email'
                            onChange={handleChange}
                        />
                        {errors.email && <p className='form-message'>{errors.email}</p>}
                    </div>
                    <br></br>
                    <button type="submit" className="btn btn-primary btn-block" variant="success">
                        add user
                    </button>&nbsp;
                    <div>
                        <span style={{ color: "black" }} onClick={() => navigate('/dashboard')}>back to dashboard</span>
                    </div>
                </form>
            </div>
        </div>
    )
}
