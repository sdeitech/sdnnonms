import Publicroute from "./Publicroute";
import Privateroute from "./Privateroute";
import { createBrowserRouter } from "react-router-dom";

const routers=createBrowserRouter([
    ...Publicroute,
    ...Privateroute
])
export default routers;