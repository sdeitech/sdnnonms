import { Publiclayout } from "../layout/Publiclayout";
import { Login } from "../Component/Login";
import { Register } from "../Component/Register";
const Publicroute=[
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Login /></Publiclayout>
    },
    {
        path:'/register',
        exact:true,
        element:<Publiclayout><Register /></Publiclayout>
    }
]

export default Publicroute;