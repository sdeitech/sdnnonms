import express from "express";
import { RegisterUser, userLogin, googleLogin, updateAuthUser,changePassword } from "../controller/AuthUserController";
import { helperUpload } from "../helper/multer";
import {uploadcsv} from '../helper/csv'
import { AddUser, getUser } from "../controller/userController";
import verifyToken from '../middleware/middleware';
import {uploadFile} from '../controller/fileController'

const route = express.Router();

route.post("/authUser/register", helperUpload, RegisterUser);
route.post("/authUser/login", userLogin);
route.post('/authUser/googlelogin', googleLogin);
route.put("/authUser/update/:id", updateAuthUser)
route.post("/authUser/changePassword",changePassword)

route.post("/uploadfile",uploadcsv,uploadFile)


route.post("/AddUser", verifyToken, AddUser);
route.get('/getUser/:id', getUser)
export default route;
