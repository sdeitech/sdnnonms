import multer from 'multer';
import fs from 'fs'
import path from 'path'

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "./upload");
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const csvFilter = (req, file, cb) => {

    if (file.mimetype.includes('csv')) {
        return cb(null, true);
    }
    cb(new Error("this file type is not allowed"));
};

export const uploadcsv = multer({
    storage: storage,
    fileFilter: csvFilter,
    limit: { filesize: 100 * 1024 * 1024 }

}).single("csv");
