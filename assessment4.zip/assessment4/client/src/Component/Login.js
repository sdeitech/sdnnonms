import React, { useState } from 'react'
import { json, useNavigate } from 'react-router-dom';
import { GoogleLogin, GoogleOAuthProvider } from '@react-oauth/google';
import '../Style/login.css'
import axios from 'axios'
import validateUser from './validate';

const clientId = "9377541509-ecep82q56bv21j9tgiif45c7mldqqstl.apps.googleusercontent.com";

export const Login = () => {
    const navigate = useNavigate();
    const [formData, setFromData] = useState({
        email: '',
        password: ''
    });
    const [show, setShow] = useState(false);
    const [error, setError] = useState(null);

    const [errors, setErrors] = useState({});

    const [loginData, setloginData] = useState(
        localStorage.getItem("loginData")
            ? JSON.parse(localStorage.getItem("loginData")) : null
    )

    const handlesuccess = async (response) => {
        try {
            const result = await fetch("http://localhost:4000/authUser/googlelogin", {
                method: "post",
                body: JSON.stringify({ token: response }),
                headers: { "Content-Type": "application/json" }
            });
            if (!result.ok) {
                throw new Error("failed to login with google")
            }
            const data = result.json();
            setloginData(data);
            localStorage.setItem("loginData", JSON.stringify(data))
            navigate('/dashboard')

        } catch (error) {
            console.log("error while login")
        }
    }

    const handleError = () => {
        alert('error while login');
        console.log("error while login with google");
    }

    const handleSimpleSubmit = async (e) => {
        e.preventDefault();
        const validationError = validateUser(formData);
        if (Object.keys(validationError).length === 0) {
            try {
                const response = await axios.post("http://localhost:4000/authUser/login", formData);
                const { data } = response;
                localStorage.setItem("data", JSON.stringify(response.data));
                localStorage.setItem("token", response.data.token)
                localStorage.setItem("userData", JSON.stringify(response.data.newuser))
                localStorage.setItem("id", response.data.newuser._id)
                localStorage.setItem("profile", response.data.newuser.profile)
                console.log("login Success");
                navigate('/dashboard');
            }
            catch (error) {
                setError("Invalid Credentials ! please SignUp");
            }
        }
        else {
            setErrors(validationError);
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFromData((prev) => ({
            ...prev, [name]: value
        }))
    }

    return (
        <div className='conatainer form-data'>
            <div className='container login-container'>
                <form className='login-form'>
                    <h3 > SIGN IN</h3>
                    {Error && <p style={{ color: 'red' }}>{Error}</p>}

                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="email"
                            name="email"
                            placeholder='EMAIL'
                            onChange={handleChange}
                            value={formData.email}
                        />
                        {errors.email && <p className='form-message'>{errors.email}</p>}
                    </div>
                    <br></br>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="password"
                            name="password"
                            placeholder='PASSWORD'
                            onChange={handleChange}
                            value={formData.password}
                        />
                        {errors.password && <p className='form-message'>{errors.password}</p>}
                    </div>
                    <br></br>
                    <div>
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={handleSimpleSubmit}>
                            SUBMIT
                        </button> &nbsp;
                        <button type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={() =>
                                navigate('/register')
                            }>
                            SIGNUP
                        </button> &nbsp;
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                        >
                            <GoogleOAuthProvider clientId={clientId}>
                                <GoogleLogin
                                    onSuccess={(credentialsResponse) => {
                                        handlesuccess(credentialsResponse.credential)
                                    }}
                                    onError={handleError} />
                            </GoogleOAuthProvider>

                        </button>
                    </div>
                </form>
            </div>

        </div>
    )
}
