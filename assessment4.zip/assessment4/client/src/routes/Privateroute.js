import { Privatelayout } from "../layout/Privatelayout";
import { Getusers } from "../Component/Getusers";
import { Viewprofile } from "../Component/Viewprofile";
import { Adduser } from "../Component/Adduser";
import { View } from "../Component/View";
const Privateroute=[
    {
        path:'/dashboard',
        exact:true,
        element:<Privatelayout><Getusers/></Privatelayout>
    },
    {
        path:'/viewprofile',
        exact:true,
        element:<Privatelayout><Viewprofile/></Privatelayout>
    },
    {
        path:'/adduser',
        exact:true,
        element:<Privatelayout><Adduser/></Privatelayout>
    },
   
]

export default Privateroute;