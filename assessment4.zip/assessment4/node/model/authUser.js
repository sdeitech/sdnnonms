import mongoose, { mongo } from "mongoose";

const AuthuserSchema = mongoose.Schema({
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique:true
    },
    DOB: {
        type: Date,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    isMarried: {
        type: Boolean,
        required: true,
        default:false
    },
    gender: {
        type: String,
        required: true
    },
    profile: {
        type:String,
        required:true
    }
});

const UserAuth = mongoose.model("UserAuth", AuthuserSchema);

export default UserAuth;