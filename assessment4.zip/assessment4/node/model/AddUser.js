import mongoose from 'mongoose';
const AddUserSchema = mongoose.Schema({
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
    }
})

const adduser =mongoose.model("adduser",AddUserSchema);
export default adduser;