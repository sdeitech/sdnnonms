import UserAuth from "../model/authUser";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { OAuth2Client } from 'google-auth-library'

const CLIENT_ID = "9377541509-ecep82q56bv21j9tgiif45c7mldqqstl.apps.googleusercontent.com";
const client = new OAuth2Client(CLIENT_ID);

export const RegisterUser = async (req, res) => {
    try {
        const profile = req.file?.filename;
        const { firstName, lastName, email, DOB, password, isMarried, gender } = req.body;
        const hashPass = await bcrypt.hash(password, 10);

        const newAuthuser = new UserAuth({
            firstName,
            lastName,
            email,
            DOB,
            password: hashPass,
            isMarried,
            gender,
            profile: profile
        })
        
        await newAuthuser.save();
        res.status(200).json(newAuthuser)
    }
    catch (error) {
        res.status(500).json({ message: "error while registering user" });
    }
}

export const userLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        const newuser = await UserAuth.findOne({ email });
        if (!newuser) {
            return res.status(500).json({ message: "email not match" });
        }

        const ismatch = await bcrypt.compare(password, newuser.password);
        if (!ismatch) {
            return res.status(500).json("Invalid credentials");
        }

        const token = jwt.sign({ email: newuser.email, id: newuser._id }, "secret key", { expiresIn: '6hr' });

        await newuser.save();
        res.status(200).json({ message: "login successfull", token, newuser });
    }
    catch (error) {
        res.status(500).json({ message: "error while login " })
    }
}

export const googleLogin = async (req, res) => {
    const { token } = req.body;
    try {
        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: CLIENT_ID
        })
        const payload = ticket.getPayload();

        const googleId = payload['sub'];
        const email = payload['email'];

        const username = email.split('@')[0];
        let user = await UserAuth.findOne({ email });

        if (!user) {
            user = new UserAuth({
                firstName: username,
                lastName,
                email,
                DOB: '',
                password: googleId,
                isMarried,
                gender: '',
                profile: ''
            })
            await user.save();
        }
        const token = jwt.sign({ userId: user._id }, "secret key", { expiresIn: '6hr' });
        res.json({ message: "login success with google", token: token });

    }
    catch (error) {
        console.log("error while login with google");
        res.status(500).json({ message: "error while login with google" });
    }
}

export const updateAuthUser = async (req, res) => {
    try {
        const {firstName,lastName,email,DOB,password,isMarried,gender}=req.body;
        console.log("hh",req.body)
        const profile=req.file?.filename;
        
        const user = await UserAuth.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            console.log("hhshgh")
            return res.json({ message: "user not found" });
            
        }
        res.status(200).json(user);

    } catch (error) {
        res.status(500).json({ message: "error while updating authUser" });
    }
}

export const changePassword=async (req, res) => {
    try {
      const { email, oldPassword, newPassword } = req.body;
  
      // Find the user by email
      const user = await UserAuth.findOne({ email });
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      // Check if the old password matches
      const isMatch = await bcrypt.compare(oldPassword, user.password);
      if (!isMatch) {
        return res.status(400).json({ message: 'Old password is incorrect' });
      }
  
      // Hash the new password
      const salt = await bcrypt.genSalt(10);
      const hashedNewPassword = await bcrypt.hash(newPassword, salt);
  
      // Update user's password
      user.password = hashedNewPassword;
      await user.save();
  
      res.status(200).json({ message: 'Password changed successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Server error' });
    }
}
