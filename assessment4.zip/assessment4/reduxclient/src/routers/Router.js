import Publicroute from "./Publicroute";
import Privateroute from "./Privateroute";
import { createBrowserRouter } from "react-router-dom";

const router=createBrowserRouter([
    ...Publicroute,
    ...Privateroute
])

export default router;