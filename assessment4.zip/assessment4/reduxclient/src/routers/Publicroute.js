import { Register } from "../Component/Register";
import { Login } from "../Component/Login";
import Publiclayout from "../layouts/Publiclayout";
import { Forgotpassword } from "../Component/Forgotpassword";
const Publicroute = [
    {
        path: '/',
        exact: true,
        element: <Publiclayout><Login /></Publiclayout>
    },
    {
        path: '/register',
        exact: true,
        element: <Publiclayout><Register /></Publiclayout>
    },
    {
        path:"/forgotPassword",
        exact:true,
        element:<Publiclayout><Forgotpassword/></Publiclayout>
    }
]

export default Publicroute;