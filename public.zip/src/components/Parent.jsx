import React, { useState } from "react";
import Child from "./Child";

const Parent = () => {
  const [name, setName] = useState("demo user");
  const [data, setData] = useState([
    {
      name: "u1",
      age: 20,
      obj: {
        react: "r1",
        java: "j1",
      },
    },
    {
      name: "u2",
      age: 21,
      obj: {
        react: "r2",
        java: "j2",
      },
    },
    {
      name: "u3",
      age: 22,
      obj: {
        react: "r3",
        java: "j3",
      },
    },
  ]);

  const [obj, setObj] = useState({
    username: "user1",
    pass: "pass1",
  });

  return (
    <div>
      Parent
      <Child name={name} data={data} obj={obj} setName={setName} />
    </div>
  );
};

export default Parent;
