import React, { useState } from "react";

const DropDown = () => {
  const data = [
    {
      id: 1,
      name: "a1",
    },
    {
      id: 2,
      name: "a2",
    },
    {
      id: 3,
      name: "a3",
    },
    {
      id: 4,
      name: "a4",
    },
    {
      id: 5,
      name: "a5",
    },
    {
      id: 6,
      name: "a6",
    },
  ];

  const [id, setId] = useState(null);

  const handleShow = (id) => {
    setId(id);
  };
  return (
    <div>
      <div>
        {data?.map((ele) => {
          let aryan = ele.id === id;
          console.log(aryan, "aryan shreyaaaaa");
          return (
            <div key={ele.id}>
              <h1>{ele.id}</h1>
              {aryan && <h1>{ele.name}</h1>}
              <button
                onClick={() => {
                  handleShow(ele.id);
                }}
              >
                btn
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DropDown;
