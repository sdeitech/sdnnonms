import React from "react";
import Card from "./Card";

// const Child = ({ name, data, obj }) => {
const Child = (props) => {
  console.log(props);
  const { name, data, obj, setName } = props;
  //   console.log(props, "this is props");
  //   console.log(props.name);
  //   console.log(props.data);
  //   console.log(props.obj);
  const prevName = name;
  const chnageName = () => {
    setName("updated name btn1");
  };
  return (
    <>
      <h1>hello child</h1>
      <p>{name}</p>
      <p>{prevName}</p>
      {data?.map((ele, a) => {
        return <Card ele={ele} key={a} />;
      })}
      <button onClick={chnageName}>btn1</button>
      <button
        onClick={() => {
          setName("updated name btn2");
        }}
      >
        btn2
      </button>
    </>
  );
};

export default Child;
