import React, { useState } from "react";

const Toggle = () => {
  const [show, setShow] = useState(true);

  const handleChnage = () => {
    setShow(!show);
  };
  return (
    <div>
      <div style={{ height: "450px", backgroundColor: "gray" }}>
        {!show && (
          <div
            style={{ backgroundColor: "red", height: "400px", width: "400px" }}
          >
            <h1>hello</h1>
          </div>
        )}
      </div>
      <button
        onClick={handleChnage}
        style={{ backgroundColor: "black", color: "white", fontWeight: 100 }}
      >
        {show ? "on" : "off"}
      </button>
    </div>
  );
};

export default Toggle;
