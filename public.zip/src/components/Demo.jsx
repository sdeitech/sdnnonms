import React, { useState } from "react";

const Demo = () => {
  const [data, setData] = useState(null);

  const arr = [{ name: "demo", age: 10 }];
  const addData = () => {
    setData(arr);
  };
  return (
    <div>
      {/* <button onClick={addData}>setdata</button> */}
      <button
        onClick={() => {
          setData(arr);
        }}
      >
        setdata
      </button>
      {data?.map((ele, i) => {
        return (
          <div>
            <h1>{ele.name}</h1>
            <h1>{ele.age}</h1>
          </div>
        );
      })}
    </div>
  );
};

export default Demo;
