import React, { useState } from "react";

const FromC = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    gender: "",
    DOB: "",
    married: false,
    profile: null,
  });

  const [img, setImg] = useState(null);
  console.log(img);

  const handleChange = (e) => {
    console.log(e.target);
    const { name, value, type, checked, files } = e.target;

    if (type === "file") {
      setFormData({ ...formData, [name]: files[0] });
      setImg(URL.createObjectURL(files[0]));
    } else if (type === "checkbox") {
      setFormData({ ...formData, [name]: checked });
    } else if (type === "checked") {
      setFormData({ ...formData, [name]: checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  console.log(formData, "form data");

  return (
    <div>
      <form>
        <input
          type="text"
          name="name"
          value={formData.name}
          placeholder="enter name"
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="enter email"
        />
        <div>
          <label htmlFor="">Male </label>
          <input
            type="radio"
            name="gender"
            value="male"
            checked={formData.gender === "male"}
            onChange={handleChange}
          />
          <label htmlFor="">female </label>
          <input
            type="radio"
            name="gender"
            value="female"
            checked={formData.gender === "female"}
            onChange={handleChange}
          />
        </div>
        <input
          type="date"
          name="DOB"
          value={formData.DOB}
          onChange={handleChange}
          placeholder=""
        />
        <div>
          <label htmlFor="">married</label>
          <input
            type="checkbox"
            name="married"
            value={formData.married}
            checked={formData.married}
            onChange={handleChange}
            placeholder=""
          />
        </div>
        <input
          type="file"
          name="profile"
          onChange={handleChange}
          placeholder=""
        />
        <button type="submit">save</button>
      </form>
    </div>
  );
};

export default FromC;
