import React from "react";

const Card = ({ ele }) => {
  console.log(ele, "ele from card");
  return (
    <div>
      <p>{ele.name}</p>
      <p>{ele.age}</p>
      <p>{ele.obj.java}</p>
      <p>{ele.obj.react}</p>
    </div>
  );
};

export default Card;
