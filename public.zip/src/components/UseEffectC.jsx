import React, { useEffect, useState } from "react";
import axios from "axios";

const UseEffectC = () => {
  const [apiData, setApiData] = useState([]);

  const fetchData = async () => {
    try {
      const res = await axios.get("https://fakestoreapi.com/carts");
      console.log(res.data);
      setApiData(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  // const [btn, setbtn] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div>
      <button onClick={fetchData}>call api</button>
      {/*
      <button
        onClick={() => {
          setbtn(false);
        }}
      >
        btn
      </button> */}

      {apiData?.map((ele) => {
        return (
          <>
            <h1 key={ele.id}>{ele.id}</h1>
            {ele.products.map((p) => (
              <>
                <p>ID : {p.productId}</p>
                <p>QA : {p.quantity}</p>
              </>
            ))}
          </>
        );
      })}
    </div>
  );
};

export default UseEffectC;
