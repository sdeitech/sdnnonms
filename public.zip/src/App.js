import "./App.css";
import Card from "./components/Card";
import Demo from "./components/Demo";
import DropDown from "./components/DropDown";
import FromC from "./components/FromC";
import Parent from "./components/Parent";
import Toggle from "./components/Toggle";
import UseEffectC from "./components/UseEffectC";

function App() {
  const obj = {
    name: "demo",
    age: 100,
    obj: {
      java: "100",
      react: "200",
    },
  };
  return (
    <div className="App">
      {/* <Parent />
      <h1>New card</h1>
      <Card ele={obj} /> */}
      {/* <Demo /> */}
      {/* <Toggle /> */}
      {/* <DropDown /> */}
      {/* <UseEffectC /> */}
      <FromC />
    </div>
  );
}

export default App;
