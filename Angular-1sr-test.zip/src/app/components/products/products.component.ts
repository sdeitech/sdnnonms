import { Component } from '@angular/core';
import { Product } from '../../interface/Product'; // Import the Product interface

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  // Array to hold product information
  products: Product[] = [
    {
      name: 'Mercedes',
      price: 2359.00,
      image: 'https://images.pexels.com/photos/29593342/pexels-photo-29593342/free-photo-of-front-view-of-a-sleek-electric-mercedes-benz-car.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' 
    },
    {
      name: 'Lamborghini',
      price: 839.20,
      image: 'https://images.pexels.com/photos/39855/lamborghini-brno-racing-car-automobiles-39855.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      name: 'Ferrari',
      price: 49.99,
      image: 'https://images.pexels.com/photos/337909/pexels-photo-337909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'},
    {
      name: 'Audi',
      price: 590.00,
      image: 'https://images.pexels.com/photos/1035108/pexels-photo-1035108.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' 
    },
    {
      name: 'Rolls Royce',
      price: 229.90,
      image: 'https://images.pexels.com/photos/5046305/pexels-photo-5046305.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' 
    },
    {
      name: 'BMW',
      price: 390.99,
      image: 'https://images.pexels.com/photos/951318/pexels-photo-951318.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      name: 'Thar',
      price: 249.99,
      image: 'https://images.pexels.com/photos/8337436/pexels-photo-8337436.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'},
    {
      name: 'McLaren ',
      price: 59.99,
      image: 'https://images.pexels.com/photos/4967937/pexels-photo-4967937.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' 
    }
  ];

  addToCart(product: Product) {
    console.log(`${product.name} added to cart!`);
  }
}