import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrl: './aboutus.component.css',
})
export class AboutusComponent {
  heading: string = 'About Our Company';
  description: string = `
    Welcome to BigBoyToys.com! We are your ultimate destination for premium gadgets, gear, and lifestyle products that bring
    excitement and innovation into your life. At BigBoyToys, we specialize in offering a wide range of high-quality items,
    including cutting-edge tech gadgets, unique collectibles, and adventurous outdoor equipment. Our mission is to provide 
    exceptional products that cater to your passions and inspire you to explore more. Thank you for choosing BigBoyToys.com
    as your trusted source for everything extraordinary!`;
}
