
def generate_marksheet(sem):

    semesters = {
        1: {
            'M1': int(input("Enter marks for M1 (out of 80): ")),
            'Physics': int(input("Enter marks for Physics (out of 80): ")),
            'English': int(input("Enter marks for English (out of 80): ")),
            'Chemistry': int(input("Enter marks for Chemistry (out of 80): "))
        },
        2: {
            'Physics': int(input("Enter marks for Physics (out of 80): ")),
            'Chemistry': int(input("Enter marks for Chemistry (out of 80): ")),
            'M2': int(input("Enter marks for M2 (out of 80): ")),
            'DSA': int(input("Enter marks for DSA (out of 80): "))
        },
        # 3: {
        #     'DAA': int(input("Enter marks for DAA (out of 80): ")),
        #     'CAO': int(input("Enter marks for CAO (out of 80): ")),
        #     'DBMS': int(input("Enter marks for DBMS (out of 80): ")),
        #     'Mongo': int(input("Enter marks for MONGO (out of 80): "))
        # },
        # 4: {
        #     'OS': int(input("Enter marks for OS (out of 80): ")),
        #     'WEB': int(input("Enter marks for WEB (out of 80): ")),
        #     'M3': int(input("Enter marks for M3 (out of 80): ")),
        #     'Aptitude': int(input("Enter marks for Aptitude (out of 80): "))
        # },
        # 5: {
        #     'networking': int(input("Enter marks for networking (out of 80): ")),
        #     'PHP': int(input("Enter marks for PHP (out of 80): ")),
        #     'M4': int(input("Enter marks for M4 (out of 80): ")),
        #     'JS': int(input("Enter marks for JS (out of 80): "))
        # },
        # 6: {
        #     'Python': int(input("Enter marks for Python (out of 80): ")),
        #     'Django': int(input("Enter marks for Django (out of 80): ")),
        #     'React': int(input("Enter marks for React (out of 80): ")),
        #     'Node': int(input("Enter marks for Node (out of 80): "))
        # },
        # 7: {
        #     'Physics': int(input("Enter marks for Physics (out of 80): ")),
        #     'Chemistry': int(input("Enter marks for Chemistry (out of 80): ")),
        #     'M2': int(input("Enter marks for M2 (out of 80): ")),
        #     'DSA': int(input("Enter marks for DSA (out of 80): "))
        # },
        # 8: {
        #     'Physics': int(input("Enter marks for Physics (out of 80): ")),
        #     'Chemistry': int(input("Enter marks for Chemistry (out of 80): ")),
        #     'M2': int(input("Enter marks for M2 (out of 80): ")),
        #     'DSA': int(input("Enter marks for DSA (out of 80): "))
        # }
        
        
        
    }

    if sem not in semesters:
        print("Invalid semester selected!")
        return

    selected_semester = semesters[sem]
    print(selected_semester,"ahshashakjsakjshk")

    total = sum(selected_semester.values())
    average = total / len(selected_semester)

    print(f"\n====== Marksheet for Semester {sem} ======")
    for subject, marks in selected_semester.items():
        print(f"{subject}: {marks} / 80")
    
    print(f"Total Marks: {total} / {80 * len(selected_semester)}")
    print(f"Average Marks: {average:.2f}")
    
    if average < 50:
        print("Sorry,You Are Failed")
    elif average > 50 and average < 60:
        print("Congratulations You are Pass With Grade D")
    elif average > 60 and average < 70:
        print("Congratulations You are Pass With Grade C")
    elif average > 70 and average < 80:
        print("Congratulations You are Pass With Grade B")
    else:
        print("Congratulations You are Pass With Grade A")


semester = int(input("Select semester (1 to 8): "))

generate_marksheet(semester)
