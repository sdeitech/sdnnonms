# def last(n):
#   return n[-1]

# def sor_list_last(tuple):
#   return sorted(tuple,key=last);

# print(sor_list_last([(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]))


#solution for removing duplicates


# test_list = [1,2,5,6,7,6]

# print("This Is original List :"+ str(test_list))

# list2 = list(set(test_list))

# print("this is list after removing duplicates"+str(list2))


#cloning a list

# original_list = [23,31,43,42,21,55,77,45]

# clone_list = list(original_list)

# print(original_list)
# print(clone_list)


#true if they have at least one common member

# def common(list1,list2):
#   result = False
  
  
#   for i in list1:
#     for j in list2:
#       if i==j:
#         result = True
#   return result
  
# print(common([2,34,2,1,2,34,5,],[25,45,33,24,36,56,17]))


# longer than given list

# def long(n,str):
  
#   len_word= []
  
#   txt = str.split(" ")
  
#   for x in txt:
#     if len(x) > n:
#       len_word.append(x)
#   return len_word

# print(long(4,"hey ayan zonga"))


# def common(list1,list2):
#   value = False
  
#   for x in list1:
#     for y in list2:
#       if x==y:
#         value = True
#   return value
      
# print(common([12,45,56,62],[75,84,51,54,68,12]))





#Removing even from list


def even_remove(list1):
   
  list2 = []
  for x in list1:
    if x % 2 != 0:
      list2.append(x)
  return list2
      

print(even_remove([12,7,5,14,18,20,22,32,36,5,13]))
  
