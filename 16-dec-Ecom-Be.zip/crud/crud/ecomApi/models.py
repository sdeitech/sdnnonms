from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models
from django.utils.timezone import now


class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='product_images/')

    def __str__(self):
        return self.name
    

# class CustomUser(AbstractUser):
#     address = models.CharField(max_length=255, blank=True, null=True)
#     postal_code = models.CharField(max_length=20, blank=True, null=True)
#     contact_number = models.CharField(max_length=15, blank=True, null=True)
#     email = models.EmailField(unique=True)
#     profile = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)


#     groups = models.ManyToManyField(
#         Group,
#         related_name='customuser_groups',  # Avoid reverse accessor clash
#         blank=True,
#     )
#     user_permissions = models.ManyToManyField(
#         Permission,
#         related_name='customuser_permissions',  # Avoid reverse accessor clash
#         blank=True,
#     )

#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = ['username', 'first_name', 'last_name']

#     def __str__(self):
#         return self.email



class CustomUser(AbstractUser):
    address = models.CharField(max_length=255, blank=True, null=True)
    postal_code = models.CharField(max_length=20, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(unique=True)
    is_admin = models.BooleanField(default=False)  # Add this line to indicate if the user is an admin
    
    groups = models.ManyToManyField(
        Group,
        related_name='customuser_groups',  # Avoid reverse accessor clash
        blank=True,
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name='customuser_permissions',  # Avoid reverse accessor clash
        blank=True,
    )

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']

    def __str__(self):
        return self.email

    
class DiscountToken(models.Model):
    code = models.CharField(max_length=20, unique=True)
    discount_percentage = models.FloatField()
    valid_until = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    def is_valid(self):
        return self.valid_until > now()

    def __str__(self):
        return f"{self.code} - {self.discount_percentage}%"
