from django.urls import path
from . import views

urlpatterns = [
    path('products/', views.get_products, name='getProduct'),  
    path('products/<int:pk>/', views.get_productById, name='getProductById'),  
    path('products/create/', views.create_product, name='creatrProduct'), 
    path('products/<int:pk>/update/', views.update_product, name='updateProduct'),  
    path('products/<int:pk>/delete/', views.delete_product, name='deleteProduct'),  
    path('register/', views.RegisterUserView.as_view(), name='register'),
    path('login/', views.CustomLoginView.as_view(), name='custom-login'),
    path('getuser/', views.RegisterUserView.as_view(), name='getuser'),
    path('discount-tokens/', views.DiscountTokenView.as_view(), name='discount_tokens'),
    path('apply-coupon/', views.ApplyCouponView.as_view(), name='apply_coupon'),
]
