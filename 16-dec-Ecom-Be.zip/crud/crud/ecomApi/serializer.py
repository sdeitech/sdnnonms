from rest_framework import serializers
from .models import Product, CustomUser
from django.contrib.auth import get_user_model
from .models import DiscountToken


User = get_user_model()

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'image']


# class CustomUserSerializer(serializers.ModelSerializer):
#     email = serializers.EmailField(required=True)
#     first_name = serializers.CharField(max_length=30, required=True)
#     last_name = serializers.CharField(max_length=30, required=True)
#     address = serializers.CharField(max_length=255, required=True)
#     postal_code = serializers.CharField(max_length=20, required=True)
#     contact_number = serializers.CharField(max_length=15, required=True)
#     profile = serializers.ImageField(required=False, use_url=True)  # Add profile field

#     class Meta:
#         model = User
#         fields = [
#             'email', 'first_name', 'last_name', 'address',
#             'postal_code', 'contact_number', 'username', 'password', 'profile'
#         ]

    

#     def create(self, validated_data):
#         user = User.objects.create_user(**validated_data)
#         return user


class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'first_name', 'last_name', 'address', 'postal_code', 'contact_number', 'email',  'username', 'password', 'is_admin']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = CustomUser(**validated_data)
        user.set_password(validated_data['password'])  # Set the password correctly
        user.save()
        return user

    
class DiscountTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = DiscountToken
        fields = ['id', 'code', 'discount_percentage', 'valid_until', 'created_at']


