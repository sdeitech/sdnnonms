import {React} from "react" 
import PrivateLayout from "../components/layouts/PrivateLayout";
import Home from "../modules/home/Home";
import Profile from "../modules/account/profile/Profile";
import NotFound from "../components/notfound/NotFound";

const privateRoutes = [
	{
		path: "/app/home",
		exact: true,
		element: <PrivateLayout><Home/></PrivateLayout> 
	},
	{
		path: "/app/profile",
		exact: true,
		element: <PrivateLayout><Profile/></PrivateLayout> 
	},
	{ path: "/*", element: <NotFound/> },
];
export default privateRoutes;
