import { combineReducers } from "redux";
import userSlice from "./user";

const rootReducer = combineReducers({ 
	userReducer :  userSlice.reducer,
});

export default rootReducer;