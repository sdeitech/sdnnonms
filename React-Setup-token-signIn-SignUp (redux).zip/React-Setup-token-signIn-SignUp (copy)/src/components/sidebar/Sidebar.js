import React from "react";
import "./Sidebar.css";
import { Link } from "react-router-dom";
import { orgAdminMenu, patientMenu, superAdminMenu } from "./Constant";

const Sidebar = () => {
  const isSuperAdmin = true
  const isOrgAdmin = false
  const patient = false

  return (
    <div className="sidebar">
      <nav>
        {<ul>
          {isSuperAdmin && superAdminMenu(["Manage Organization"])?.map(({ name, URL, enabled }, index) => (
            <div key={index}>
              {enabled ? <li><Link to={URL}>{name}</Link></li> : null }
            </div>
          ))}
        </ul>}
        {<ul>
          {isOrgAdmin && orgAdminMenu(["Manage Organization"])?.map(({ name, URL, enabled }, index) => (
            <div key={index}>
              {enabled ? <li><Link to={URL}>{name}</Link></li> : null }
            </div>
          ))}
        </ul>}
        {<ul>
          {patient && patientMenu(["Manage Organization"])?.map(({ name, URL, enabled }, index) => (
            <div key={index}>
              {enabled ? <li><Link to={URL}>{name}</Link></li> : null }
            </div>
          ))}
        </ul>}
      </nav>
    </div>
  );
}

export default Sidebar;
