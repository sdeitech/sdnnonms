import React from "react";
import "./Footer.css";
function Footer() {
	return (
		<footer>
			<p>COPYRIGHT @ 2022</p>
		</footer>
	);
}
export default Footer;
