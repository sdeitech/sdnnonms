/* eslint-disable react/prop-types */
import React from "react";
import "./index.css"

const PublicLayout = ({ children }) => {
  return (
	<>
		{children}
	</>
  );
};

export default PublicLayout;