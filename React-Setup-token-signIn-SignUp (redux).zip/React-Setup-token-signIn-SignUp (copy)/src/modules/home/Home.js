import { React, Fragment } from "react";
import "./Home.css"
function Home() {
	return (
		<Fragment>
			<>Some Home structures like static</>
		</Fragment>
	);
}
export default Home;
