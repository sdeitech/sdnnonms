function ResetPassword() {
	return (
		<>Reset Password</>
	);
}
export default ResetPassword;