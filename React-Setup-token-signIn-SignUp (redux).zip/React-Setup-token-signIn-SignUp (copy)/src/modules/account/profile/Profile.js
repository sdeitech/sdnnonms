import React from "react";
function Profile() {
	return (
		<>Profile</>
	);
}
export default Profile;