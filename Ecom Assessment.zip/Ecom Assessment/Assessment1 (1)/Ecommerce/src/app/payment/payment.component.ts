import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Product, ProductsComponent } from '../products/products.component';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
})
export class PaymentComponent implements OnInit {
  orderDetails: {
    cart: Product[];
    totalPrice: number;
    discountPrice: number;
    finalPrice: number;
  } = {
    cart: [],
    totalPrice: 0,
    discountPrice: 0,
    finalPrice: 0,
  }; // Define the structure of orderDetails with Product[] type
  address: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    console.log(navigation ,"navigation")
    const state = navigation?.extras.state as {
      cart: Product[];
      address: string;
    };

    if (state && state.cart && state.cart.length > 0) {
      this.orderDetails.cart = state.cart;
      this.address = state.address;
      this.orderDetails.totalPrice = this.calculateTotalPrice();
      this.orderDetails.discountPrice = this.calculateDiscount();
      this.orderDetails.finalPrice = this.orderDetails.discountPrice;
    } else {
      this.router.navigate(['/checkout']);
    }
  }

  calculateTotalPrice(): number {
    return this.orderDetails.cart.reduce(
      (total: number, product: Product) =>
        total + product.price * product.quantity,
      0
    );
  }

  calculateDiscount(): number {
    // Add discount logic
    return this.calculateTotalPrice();
  }

  completePayment(): void {
    if (!this.address) {
      Swal.fire({
        icon: 'error',
        title: 'Address Missing',
        text: 'Please provide a delivery address before completing the payment.',
      });
      return;
    }

    Swal.fire({
      icon: 'success',
      title: 'Payment Successful!',
      text: `Your payment of ${this.formatCurrency(
        this.orderDetails.finalPrice
      )} has been completed. Your order will be delivered to: ${this.address}`,
    }).then(() => {
      this.router.navigate(['/home']);
    });
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD', // Adjust currency format as needed
    }).format(value);
  }

  cancelPayment(): void {
    this.router.navigate(['/checkout']);
  }

  getimagepath(path: string): string {
    return 'http://127.0.0.1:8000' + path;
  }
}
