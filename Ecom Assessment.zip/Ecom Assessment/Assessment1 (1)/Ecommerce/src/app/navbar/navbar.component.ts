import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/authservice.service';
import { CartService } from '../services/cartservice.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  cartCount: number = 0;
  showLoginPopup: boolean = false;  // Flag to control the visibility of the login popup

  constructor(private router: Router, private authService: AuthService ,private cartService: CartService) { }

  isLoggedIn:boolean = false
  count :any = 0;
  ngOnInit() {
    this.count = this.cartService.getCartCount();  // Get cart count when the component is initialized
    this.updateCartCount();  // Update cart count on initialization
    if (this.authService.isLoggedIn()) {
      this.isLoggedIn = true
    } else {
      this.isLoggedIn = false

    }
  }

    


 

  Logout(){
    this.isLoggedIn = false
    localStorage.removeItem('auth_token'); 
    this.router.navigate(['/home']);

  }

  // Update cart count from localStorage
  updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartCount = cart.length;
  }

  // Handle cart icon click
  onCartClick() {
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/cart']);
    } else {
      this.showLoginPopup = true;
    }
  }

  // Close the login popup
  closePopup() {
    this.showLoginPopup = false;
  }

  // Navigate to the login page
  goToLogin() {
    this.router.navigate(['/login']);
    this.closePopup();  // Close the popup after redirecting
  }
}
