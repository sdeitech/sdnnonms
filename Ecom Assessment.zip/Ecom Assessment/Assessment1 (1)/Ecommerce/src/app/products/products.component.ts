import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { CartService } from '../services/cartservice.service'; // Import the CartService

export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  constructor(private http: HttpClient, private cartService: CartService) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    const apiUrl = 'http://127.0.0.1:8000/products/';

    this.http.get<Product[]>(apiUrl).subscribe(
      (data) => {
        console.log(data);
        this.products = data;
      },
      (error) => {
        console.error('There was an error fetching the products!', error);
      }
    );
  }

  addToCart(product: Product) {
    this.cartService.addToCart(product); // Use CartService to add the product
    Swal.fire({
      title: 'Added Successfully!',
      text: `Added ${product.name} to cart`,
      icon: 'success',
    });
  }

  getimagepath(path: string) {
    return 'http://127.0.0.1:8000' + path;
  }
}
