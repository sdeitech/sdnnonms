import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router'; // For navigation after login
import Swal from 'sweetalert2';  // For displaying alerts

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  // Method to handle the login submission
  onLogin(): void {
    if (this.email && this.password) {
      const loginData = {
        email: this.email,
        password: this.password
      };

      this.http.post('http://localhost:8000/login/', loginData)
        .subscribe(
          (response: any) => {
            localStorage.setItem('auth_token', response.token);

            Swal.fire({
              title: 'Login Successful!',
              text: 'You have successfully logged in.',
              icon: 'success',
              confirmButtonText: 'Proceed'
            }).then(() => {
              // Redirect to home or dashboard page
              this.router.navigate(['/home']);
            });
          },
          (error: any) => {
            // If login fails, show error message
            Swal.fire({
              title: 'Login Failed!',
              text: error.error.error || 'Invalid credentials',
              icon: 'error',
              confirmButtonText: 'Try Again'
            });
          }
        );
    } else {
      Swal.fire({
        title: 'Error!',
        text: 'Please enter both email and password.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  }
}
