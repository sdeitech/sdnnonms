import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cartservice.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { UserService } from './user.service';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  discountPrice: number = 0;
  discountAmount: number = 0; // Store discount amount
  finalPrice: number = 0;
  address: string = ''; 
  paymentMethod: string = ''; 
  isEditingAddress: boolean = false;

  constructor(
    private cartService: CartService,
    public router: Router,
    private userService: UserService 
  ) {}

  ngOnInit(): void {
    this.userService.getUserDetails().subscribe(
      (userDetails) => {
        this.address = userDetails.address; 
        console.log('User address:', this.address); 
      },
      (error) => {
        console.error('Error fetching user details:', error);
        if (error.status === 401) {
          Swal.fire('Unauthorized', 'Please log in to access your details', 'error');
          this.router.navigate(['/login']); 
        }
      }
    );

    this.cartService.cart$.subscribe((cart: any[]) => {
      this.cart = cart;
      this.calculateTotal();
    });
  }

  calculateTotal(): void {
    this.totalPrice = this.cart.reduce(
      (total, product) => total + product.price * product.quantity,
      0
    );

    // Apply discount logic here
    const discountPercentage = 10; // Example: 10% discount
    if (discountPercentage > 0) {
      this.discountAmount = (this.totalPrice * discountPercentage) / 100; // Calculate discount amount
    } else {
      this.discountAmount = 0; // No discount if no percentage is set
    }
    
    this.discountPrice = this.totalPrice - this.discountAmount; // Apply discount to total price
    this.finalPrice = this.discountPrice; // This can be adjusted for taxes or other fees
  }

  placeOrder(): void {
    if (!this.address) {
      Swal.fire({
        icon: 'error',
        title: 'Address Missing',
        text: 'Please provide a delivery address to place your order.',
      });
      return;
    }
  
    const orderData = {
      address: this.address,
      payment_method: this.paymentMethod,
      total_price: this.totalPrice,
      discount: this.discountAmount,
      final_price: this.finalPrice,
    };
  
    this.orderService.placeOrder(orderData).subscribe(
      (response) => {
        Swal.fire({
          icon: 'success',
          title: 'Order placed successfully!',
          text: `Your Order ID is ${response.order_id}.`,
        });
        this.router.navigate(['/home']);
      },
      (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'There was an issue placing your order. Please try again.',
        });
      }
    );
  }
  proceedToPayment(): void {
    if (!this.address) {
      Swal.fire({
        icon: 'error',
        title: 'Address Missing',
        text: 'Please provide a delivery address before proceeding to payment.',
      });
      return;
    }

    // Pass both cart and address to the payment page
    this.router.navigate(['/payment'], {
      state: {
        cart: this.cart,  // Pass the cart data
        address: this.address,  // Pass the address
        paymentMethod: this.paymentMethod,  // Pass the selected payment method
      },
    });
  }

  toggleEditAddress(): void {
    this.isEditingAddress = !this.isEditingAddress;
  }

  getimagepath(path: string) {
    return 'http://127.0.0.1:8000' + path;
  }
}
