import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiUrl = 'http://127.0.0.1:8000/user/details/'; 

  constructor(private http: HttpClient) {}

  getUserDetails(): Observable<any> {
    const token = localStorage.getItem('auth_token');
    if (!token) {
      throw new Error('No token found');
    }

    const headers = new HttpHeaders({
      Authorization: `Token ${token}`, 
    });

    return this.http.get<any>(this.apiUrl, { headers });
  }
}
