import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cartservice.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  discountPrice: number = 0;
  discountPercentage: number = 0;
  couponCode: string = '';
  couponMessage: string = '';
  finalPrice: number = 0;

  constructor(private cartService: CartService, private router: Router) {}

  ngOnInit(): void {
    // Subscribe to the cart observable to get cart data in real-time
    this.cartService.cart$.subscribe((cart: any[]) => {
      this.cart = cart;
      this.calculateTotal();
    });
  }

  removeFromCart(product: any): void {
    this.cartService.removeFromCart(product.id); // Use CartService to remove the product
    this.calculateTotal();
  }

  clearCart(): void {
    this.cartService.clearCart(); // Use CartService to clear the cart
    this.calculateTotal();
  }

  increaseQuantity(product: any): void {
    product.quantity += 1; // Increase quantity
    this.cartService.updateCart(this.cart); // Update the cart in CartService
    this.calculateTotal(); // Recalculate the total price after updating quantity
  }

  decreaseQuantity(product: any): void {
    if (product.quantity > 1) {
      product.quantity -= 1; // Decrease quantity if greater than 1
    } else {
      this.removeFromCart(product); // Remove the product if quantity is 1
    }
    this.cartService.updateCart(this.cart); // Update the cart in CartService
    this.calculateTotal(); // Recalculate the total price after updating quantity
  }

  calculateTotal(): void {
    this.totalPrice = this.cart.reduce(
      (total, product) => total + product.price * product.quantity,
      0
    );

    // Calculate discount
    this.discountPrice = this.totalPrice;
    if (this.discountPercentage > 0) {
      this.discountPrice = this.totalPrice * (1 - this.discountPercentage / 100);
    }

    this.finalPrice = this.discountPrice;
  }

  applyCoupon(): void {
    if (this.couponCode === 'DISCOUNT10') {
      this.discountPercentage = 10;
      this.couponMessage = 'Coupon applied successfully!';
    } else {
      this.couponMessage = 'Invalid coupon code.';
      this.discountPercentage = 0;
    }
    this.calculateTotal();
  }

  checkout(): void {
    if (this.cart.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Empty Cart',
        text: 'You cannot proceed with an empty cart.',
      });
      return;
    }
  
    const orderDetails = {
      cart: this.cart,
      totalPrice: this.totalPrice,
      discountPrice: this.discountPrice,
      finalPrice: this.finalPrice,
    };
  
    // Pass order details to CheckoutComponent
    this.router.navigate(['/orders'], {
      state: { orderDetails }, // Pass the order details to the next component
    });
  }

  getimagepath(path: string) {
    return 'http://127.0.0.1:8000' + path;
  }
}
