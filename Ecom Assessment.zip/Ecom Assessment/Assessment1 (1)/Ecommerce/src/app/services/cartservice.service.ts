import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartCountsubject = new BehaviorSubject<number>(0);
  private cartSubject = new BehaviorSubject<any[]>([]);
  cart$ = this.cartSubject.asObservable();

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    if (isPlatformBrowser(this.platformId)) {
      this.initializeCart();
    }
  }

  // Initialize cart from localStorage when in the browser
  private initializeCart(): void {
    const cart = this.loadCart();
    this.cartSubject.next(cart);
    this.cartCountsubject.next(cart.length); // Set initial cart count
  }

  // Load the cart from localStorage
  loadCart(): any[] {
    if (isPlatformBrowser(this.platformId)) {
      const cart = localStorage.getItem('cart');
      return cart ? JSON.parse(cart) : [];
    }
    return [];
  }

  // Add product to cart or increase quantity if already exists
  addToCart(product: any): void {
    if (isPlatformBrowser(this.platformId)) {
      const cart = this.loadCart();
      const existingProduct = cart.find((item) => item.id === product.id);

      if (existingProduct) {
        existingProduct.quantity += 1; // Increase quantity if product exists
      } else {
        product.quantity = 1;
        cart.push(product);
      }

      this.saveCart(cart);
    }
  }

  // Update cart after quantity change (increase or decrease)
  updateCart(cart: any[]): void {
    if (isPlatformBrowser(this.platformId)) {
      this.saveCart(cart);
    }
  }

  // Increase product quantity in cart
  increaseQuantity(product: any): void {
    if (isPlatformBrowser(this.platformId)) {
      const cart = this.loadCart();
      const existingProduct = cart.find((item) => item.id === product.id);
      if (existingProduct) {
        existingProduct.quantity += 1; // Increase quantity
        this.saveCart(cart);
      }
    }
  }

  // Decrease product quantity in cart
  decreaseQuantity(product: any): void {
    if (isPlatformBrowser(this.platformId)) {
      const cart = this.loadCart();
      const existingProduct = cart.find((item) => item.id === product.id);
      if (existingProduct) {
        if (existingProduct.quantity > 1) {
          existingProduct.quantity -= 1; // Decrease quantity
        } else {
          cart.splice(cart.indexOf(existingProduct), 1); // Remove product if quantity is 1
        }
        this.saveCart(cart);
      }
    }
  }

  // Remove product from cart
  removeFromCart(productId: number): void {
    if (isPlatformBrowser(this.platformId)) {
      let cart = this.loadCart();
      cart = cart.filter((item) => item.id !== productId);
      this.saveCart(cart);
    }
  }

  // Clear cart
  clearCart(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.saveCart([]);
    }
  }

  // Save cart to localStorage and notify subscribers
  private saveCart(cart: any[]): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('cart', JSON.stringify(cart));
      this.cartSubject.next(cart); // Notify subscribers of cart change
      this.cartCountsubject.next(cart.length); // Update the cart count
    }
  }

  // Get cart count
  getCartCount(): number {
    return this.cartCountsubject.value;
  }
}
