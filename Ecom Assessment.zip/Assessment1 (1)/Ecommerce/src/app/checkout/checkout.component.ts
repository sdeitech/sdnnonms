// CheckoutComponent - Retrieve the cart data from navigation state
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  discountPrice: number = 0;
  finalPrice: number = 0;

  constructor(public router: Router) {}

  ngOnInit(): void {
    // Retrieve order details passed via navigation state
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as { orderDetails: any };
    if (state) {
      this.cart = state.orderDetails.cart;
      this.totalPrice = state.orderDetails.totalPrice;
      this.discountPrice = state.orderDetails.discountPrice;
      this.finalPrice = state.orderDetails.finalPrice;
    }
  }

  placeOrder(): void {
    // Add the logic for placing an order (e.g., making an API call to save the order)

    // Show a success message
    Swal.fire({
      icon: 'success',
      title: 'Order placed successfully!',
      text: 'Thank you for your purchase.',
    });

    // Redirect to the home page or order confirmation page
    this.router.navigate(['/home']);
  }

  getimagepath(path: string) {
    return 'http://127.0.0.1:8000' + path;
  }
}
