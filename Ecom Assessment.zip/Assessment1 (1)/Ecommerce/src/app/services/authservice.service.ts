import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  // Check if the user is logged in (based on token existence in localStorage)
  isLoggedIn(): boolean {
    return !!localStorage.getItem('auth_token');  // True if token exists, meaning user is logged in
  }

  // Get the auth token (optional, if needed elsewhere in your app)
  getAuthToken(): string | null {
    return localStorage.getItem('auth_token');
  }

  // Log out the user (removes the auth token)
  logOut() {
    localStorage.removeItem('auth_token');
  }
}
