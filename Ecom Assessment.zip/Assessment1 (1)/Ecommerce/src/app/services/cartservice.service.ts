import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

// CartService - Ensure data is stored in localStorage when updated
@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartSubject = new BehaviorSubject<any[]>(this.loadCart());
  cart$ = this.cartSubject.asObservable();

  constructor() {}

  // Load the cart from localStorage
  loadCart(): any[] {
    const cart = localStorage.getItem('cart');
    return cart ? JSON.parse(cart) : [];
  }

  // Add product to cart
  addToCart(product: any): void {
    const cart = this.loadCart();
    const existingProduct = cart.find((item) => item.id === product.id);

    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      product.quantity = 1;
      cart.push(product);
    }

    this.saveCart(cart);
  }

  // Remove product from cart
  removeFromCart(productId: number): void {
    let cart = this.loadCart();
    cart = cart.filter((item) => item.id !== productId);
    this.saveCart(cart);
  }

  // Update cart after changes (like quantity change)
  updateCart(cart: any[]): void {
    this.saveCart(cart);
  }

  // Clear cart
  clearCart(): void {
    this.saveCart([]);
  }

  // Save cart to localStorage and notify subscribers
  private saveCart(cart: any[]): void {
    localStorage.setItem('cart', JSON.stringify(cart));
    this.cartSubject.next(cart); // Notify subscribers of cart change
  }
}
