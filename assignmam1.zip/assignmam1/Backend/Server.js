const express = require ('express')
 
const cors = require ('cors')

const dotenv = require ('dotenv')

const {mongoConnect} = require('./database/Db')

const route = require('./routes/UserRoute')

//server port 
PORT = 7867
const app = express();
app.use(cors())

//database connection
mongoConnect();

//middleware
app.use(express.json());

//api 
app.use('/api',route);



app.listen(PORT,()=>{
    console.log(`Server is running on: ${PORT}`)

})