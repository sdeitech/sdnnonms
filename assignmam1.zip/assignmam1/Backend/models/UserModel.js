const mongoose = require ('mongoose');

//creating schema for our project means taking fields
const userModel = mongoose.Schema({
    Name:{
        type:String,
        required:true,
    },
    Email:{
        type:String,
        required:true,
    },
    Message:{
        type:String,
        required:true,
    }
});

const userDetails = mongoose.model("users",userModel)
module.exports=userDetails;