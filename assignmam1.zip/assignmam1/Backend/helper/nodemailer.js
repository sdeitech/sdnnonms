const nodemailer = require ('nodemailer')

const transporter = nodemailer.createTransport({
    service : "gmail",
    auth:{
        user:"tarundakhore@gmail.com",
        pass:"tgsmdnyvfdxpicjg",
    },
});

const sendMailToUser = async (to,message)=>{
    const mailOptions = {
        from:"tarundakhore@gmail.com",
        to:to,
        subject:"subject",
        text:message,
        body:message
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("mail sent");
        return {status : true};
        
    } catch (error) {
        console.log(error.message);
        console.log({status:false});
        
    }
};
module.exports = sendMailToUser;