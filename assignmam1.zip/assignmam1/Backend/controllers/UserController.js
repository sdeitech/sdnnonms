const Users = require('../models/UserModel')
const sendMailToUser = require('../helper/nodemailer')
//definition for post/create users

exports.createUser = async (req,res)=>{
    const newUser = new Users(req.body);
    console.log(req.body)
    const data = await sendMailToUser(req.body.Email,req.body.Message)

    console.log(data)
    try {
        const saveUser = await newUser.save();
        res.status(201).json(saveUser);
        
    } catch (error) {
        res.status(400).json(error);
        
    }
};