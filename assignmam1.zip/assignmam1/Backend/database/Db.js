const mongoose = require('mongoose')

exports.mongoConnect = async()=>{
    try {
        const resp = await mongoose.connect("mongodb://localhost:27017/assignmentmam")

        if(resp){
            console.log("Database connected succesfully!");
            
        }
        
    } catch (error) {
        console.log(error);
        
        
    }
}