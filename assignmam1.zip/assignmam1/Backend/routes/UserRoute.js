const express = require('express')

const router = express.Router();

const userDetail = require('../controllers/UserController');

//post method for users
router.post('/create',userDetail.createUser);

module.exports=router;