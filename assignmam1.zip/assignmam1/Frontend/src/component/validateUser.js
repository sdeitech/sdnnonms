const validate = (formData)=>{
    let error = {};
    if(!formData.Name){
        error.Name ="Name is required";
    }
    if(!formData.Email){
        error.Email = "Email is required";
    }
    if(!formData.Message){
        error.Message = "Message required"
    }
    return error;
}
export default validate;