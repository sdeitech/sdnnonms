import logo from './logo.svg';
import './App.css';
// import Form from './component/FormDesign'
import FormComponent from './component/FormDesign';
function App() {
  return (
    <FormComponent/>
    
  );
}

export default App;
