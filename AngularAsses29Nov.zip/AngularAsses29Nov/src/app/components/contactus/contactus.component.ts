import { Component } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrl: './contactus.component.css'
})
export class ContactusComponent {

  // Define the heading and description for the Contact page
  heading: string = 'Contact Us';
  description: string = 'We would love to hear from you! Please fill out the form below to get in touch with us.';

  
  contactForm = {
    name: '',
    subject: '',
    message: ''
  };


  onSubmit() {
    console.log('Form Data:', this.contactForm);
}
}