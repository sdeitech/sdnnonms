import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrl: './aboutus.component.css'
})
export class AboutusComponent {

  heading: string = 'About Our Company';
  description: string = `
    Welcome to our company photogallery company ! We are dedicated to providing high-quality products 
    that enhance images to our customers. Our online store specializes in a 
    variety of img items, including . Thank you for choosing us as your trusted 
    online retailer!`;
}