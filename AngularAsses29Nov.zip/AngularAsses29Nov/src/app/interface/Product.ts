// src/app/models/product.model.ts

export interface Product {
    name: string;
    price: number;
    image: string;
}