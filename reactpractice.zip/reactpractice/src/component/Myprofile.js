import React from 'react'

const Myprofile = () => {
  return (
    <div>Myprofile</div>
  )
}

export default Myprofile