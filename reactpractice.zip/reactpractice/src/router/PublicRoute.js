import {React} from 'react';
import Signup from '../component/Signup';
import { PublicLayout } from '../layout/PublicLayout';
import Login from '../component/Login'

const publicRoutes = [
    {
        path:'/login',
        exact: true,
        element: <PublicLayout><Login/></PublicLayout>
    },
    {
        path:'/signup',
        exact:true,
        element: <PublicLayout><Signup/></PublicLayout>
    },
];
export default publicRoutes;