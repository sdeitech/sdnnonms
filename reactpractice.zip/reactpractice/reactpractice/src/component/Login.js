import React from 'react'
import {useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from 'axios';
import '../styles/login.css';


const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
      });
    
    
      const navigate = useNavigate()
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev, [name]: value
        }))
    }
    
    
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        
        
        try {
          const response = await axios.post('http://localhost:6767/api/login',formData);
          alert("User login Successfully");
          localStorage.setItem("token",response.data.token);
          localStorage.setItem("info", JSON.stringify(response.data.user));
          console.log(response.data.user)
    
          navigate('/dashboard')
    
          console.log('Login Success:', response.data);
        } catch (error) {
          console.error('Signup Error:', error.response?.data || error.message);
        }
      };
    
      return (
        <div className='login-container'>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
       
       <input type="email" 
          name="email" 
          placeholder="Email"
           onChange={handleChange} />
       
      
        <input 
          type="password" 
          name="password" 
          placeholder="Password" 
          onChange={handleChange} />
        
          <button type="submit">Login</button>
          <span>Don't Have an Acoount?
             <Link to="/signup">Sign Up</Link>
          </span>
        
        </form>
        </div>
      );
}

export default Login







