import React from 'react';
import {useState} from 'react';
import { useNavigate } from 'react-router-dom';
// import { Link } from 'react-router-dom';
import axios from 'axios';
import '../styles/signup.css';

const Signup = () => {
  
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        DOB: '',
        isMarried: false,
        gender: ''
      });
      const [profile, setProfile] = useState(null); 
    
      const navigate = useNavigate()
    
      const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
          ...formData,
          [name]: type === 'checkbox' ? checked : value,
        });
      };
    
      const handleFileChange = (e) => {
        setProfile(e.target.files[0]); 
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        
        const data = new FormData();
        data.append('firstName', formData.firstName);
        data.append('lastName', formData.lastName);
        data.append('email', formData.email);
        data.append('password', formData.password);
        data.append('DOB', formData.DOB);
        data.append('isMarried', formData.isMarried);
        data.append('gender', formData.gender);
        data.append('profile', profile); 
    
        try {
          const response = await axios.post('http://localhost:6767/api/register', data, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
            
            
        
          });
          alert("Succesfully Signed Up")
          // localStorage.setItem("info", JSON.stringify(response.data.newuser));
    
          navigate('/login')
    
          console.log('Signup Success:', response.data);
        } catch (error) {
          console.error('Signup Error:', error.response?.data || error.message);
        }
      };
    
      return (
        <div className="signup-container">
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          
          <input type="text" 
          name="firstName" 
          placeholder="First Name" 
          onChange={handleChange} />
        
    
     <input type="text" 
          name="lastName" 
          placeholder="Last Name" 
          onChange={handleChange} />
    
       
       <input type="email" 
          name="email" 
          placeholder="Email"
           onChange={handleChange} />
       
        
        <input 
          type="password" 
          name="password" 
          placeholder="Password" 
          onChange={handleChange} />
        
          
          <input 
          type="date" 
          name="DOB" 
          placeholder="Date of Birth"
          onChange={handleChange} />
        
    
       <input
           type="checkbox" 
           name="isMarried" 
           onChange={handleChange} /> Is Married?
          <select 
          name="gender" 
          onChange={handleChange}>
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
    
      
          <input 
          type="file" 
          name="profile"
           accept="image/*"
            onChange={handleFileChange} />
          <button type="submit">Sign Up</button>
          {/* <span>Already Have an Acoount?
             <Link to="/">Login</Link>
          </span>
       */}
       <div className="login-link">
                Already have an account? <a href="/">Login</a>
            </div>
        </form>
        </div>
      );
}

export default Signup;






