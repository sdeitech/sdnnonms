// import { useRef,useState } from 'react'
import React, { useState } from 'react'
import {Link} from 'react-router-dom';
import '../styles/myprofile.css';




const MyProfile = ({el}) => {
     
//  const [file ,setFile] =useState(null);

//  const handleChange = (e) => {
//   const selectedFile = e.target.files[0];
//   setFile(selectedFile)
//  }
   
    const userInfo = localStorage.getItem("info");
    const newUserInfo = JSON.parse(userInfo)
    console.log("xcdfd" ,newUserInfo);
  
  return (
    <div className='profile-card'>
        <h1>My Profile</h1>
        <div>
        {/* <input type="file" accept='image/*' onChange={handleChange}/>
        {file &&
          <img 
          style={{
            width: "200px",
            height: "200px",
            borderRadius: "50%",
            objectFit: "cover",
          }}
          src={URL.createObjectURL(file)}
          alt='Uploaded'

          /> */}
        {/* } */}
        </div>
        <div className='info'>
            <img
            style={{
            width: "200px",
            height: "200px",
            borderRadius: "50%",
            objectFit: "cover",
          }} 
            src={URL.createObjectURL(newUserInfo.profile)} alt=''/>
            <p>FirstName:{newUserInfo.firstName}</p>
            <p>Last Name:{newUserInfo.lastName}</p>
            <p>Email:{newUserInfo.email}</p>
            <p>Date Of Birth:{newUserInfo.DOB}</p>
            <p>Gender:{newUserInfo.gender}</p>
            <p>Married:{newUserInfo.isMarried}</p>
            {/* <p>Profile:{newUserInfo.profile}</p>    */}
            <button className='action-button' type="submit">Update</button>
            <Link to='/dashboard'>Dashboard</Link>
        </div>
    
    </div>
  )
}
export default MyProfile;