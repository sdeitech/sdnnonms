import React , {useState} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/add.css'


const Add = () =>{
    const [data, setData] = useState([]);

    const [postcontent, setPostContent] = useState({
        productName:'',
        noOfProducts: ' ',
        manufacturer:' ',
        description:' ',
     
      });

      const navigate = useNavigate();
      const handleInput = (e) => {
        const { name, value } = e.target;
        setPostContent({ ...postcontent, [name]: value });
    };
    const createData = async (e) => {
   
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:6767/product/add', postcontent);
            setData([...data, response.data]);
            setPostContent({
              productName:'',
              noOfProducts: ' ',
              manufacturer:' ',
              description:' ',
            });
            
              navigate('/dashboard')
        } catch (error) {
            // console.error(error);
        // setError('cfvdg')
        console.error(error)

        }
    };
return(
    <div>
       {/* <p onClick={() => navigate('/dashboard')}>Add</p> */}
      <form className='form-container'onSubmit={createData}>
                <div className="input-group">
                    <label>FirstName:
                        <input
                            type="text"
                            name="productName"
                            value={postcontent.productName}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>LastName:
                        <input
                            type="text"
                            name="noOfProducts"
                            value={postcontent.noOfProducts}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>
                        Email:
                        <input
                            type="text"
                            name="manufacturer"
                            value={postcontent.manufacturer}
                            onChange={handleInput}
                        />
                    </label>
                    <label>
                        Description:   
                        <input
                            type="text"
                            name="description"
                            value={postcontent.description}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <span>
                    <button type="submit">Submit</button>
                    {/* <button type="reset">Reset</button> */}
                    {/* <input type="reset" value="reset" /> */}
                </span>

            </form>
    </div>
)
}

export default Add;