import React, { useState , useEffect } from 'react'
import { Link } from 'react-router-dom';
import { getProducts } from '../api';
import ProductDetails from './ProductDetails';
// import Add from './Add';
import '../styles/dashboard.css';
import {ToastContainer} from 'react-toastify';


const Dashboard = () => {

  // const [showModal ,setShowModal] = useState(false);
  const [productData , setProductData] = useState({
    "products":[],
    "pagination": {
      "totalProducts": 0,
      "currentPage": 1,
      "totalPages": 1,
      "pageSize": 5
  }
  });

  const fetchProducts = async (search = '' , page = 1 , limit =5) =>{
           try{
            const {data} = await getProducts(search , page , limit);
            setProductData(data);
           } catch(err){
            console.log("Error" , err)
           }
  }
  
  console.log('--------' , productData)
  useEffect(()=>{
    fetchProducts();
  } , [])

//  const handleAddProduct = () =>{
//   setShowModal(true)

//   }
  const handleUpdate = (prodObject)=>{
    console.log("vxc",prodObject)
    setProductData(prodObject);

  }
  const handleDelete = () =>{

  }

  return (
    <div>
    <h1>Product Management</h1>
    <Link className='profile-link'to="/add">Add</Link>
{/*   
    <button className='modal-btn' onClick={()=>handleAddProduct} >
    Add
    </button>
    <input
     type="text"
     placeholder='Search Products...'

    /> */}
    <Link className='profile-link'to="/myprofile">Myprofile</Link>
    <ProductDetails
      handleDelete={handleDelete}
      handleUpdate={handleUpdate}
      fetchProducts={fetchProducts}
      products={productData.products}
      pagination={productData.pagination}

    />
    
  {/* <Add 
    showModal={showModal}
  /> */}
  <ToastContainer
    position='top-right'
    autoClose={3000}
    hideProgressBar={false}
  />
    </div>
  )
}

export default Dashboard;