import React from 'react'
import { Link } from 'react-router-dom';
import '../styles/productdtails.css'
// import Add from './Add';?



function ProductDetails({
    products,
    pagination,
    fetchProducts,
    handleUpdate,
    handleDelete,
})

{
    const headers = ['Product Name' , 'No Of Products' , 'Manufacturer' , 'Description' , 'Action'];

    const {currentPage , totalPages} =pagination;
    const TableRow = ({product}) =>{
        return <tr>
            <td>
                <Link to={`/products/id}`}/>
                {product.productName}
            </td>
            <td>{product.noOfProducts}</td>
            <td>{product.manufacturer}</td>
            <td>{product.description}</td>
    
            <td className='action-buttons'>
                <button onClick={()=>handleUpdate(product)}className = 'update-btn' type="button">Update</button>
                <button className = 'delete-btn' type="button" onClick={()=>handleDelete()}>Delete</button>

            </td>
            
        </tr>

    }
    const pageNumbers = Array.from({length : totalPages},(_,index) => index + 1)
    
    const handleNextPage =()=>{
        if(currentPage < totalPages) {
            handlePagination(currentPage + 1)
        }
    }

    const handlePreviousPage =()=>{
        if(currentPage > 1) {
            handlePagination(currentPage - 1)
        }
    }
 
 
 const handlePagination = (currPage) =>{
   fetchProducts('' , currPage , 5)
 }
 
 
    return (
    <div>
        <table>
            <thead>
                <tr>
                    {
                      headers.map((header , i)=>(
                        <th key={i}>{header}</th>
                      ))
                      
            
                    }
                </tr>
            </thead>
            <tbody> 
                {
                    products.map((prod) => (
                        <TableRow key={prod._id} product={prod}/>
                    ))
                }
            
            </tbody>
           
        </table>
        <div>
                <span className='pagination' >Page{currentPage }of {totalPages}</span>
            </div>
            <button
            onClick={()=>handlePreviousPage()}
            disabled={currentPage === 1}
            >Previous</button>
            {
                pageNumbers.map((page)=>(
                    <button onClick={()=>handlePagination(page)}>
                        {page}
                    </button>
                ))
            }
            <button
            onClick={()=>handleNextPage()}
            disabled={totalPages === currentPage}
            >Next</button>

            
    </div>
  )
}

export default ProductDetails;