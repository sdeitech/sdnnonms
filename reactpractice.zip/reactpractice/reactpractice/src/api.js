import axios from 'axios';
const BASE_URL = 'http://localhost:6767';

export const getProducts = async (search = '' , page = 1 , limit = 5) =>{
    const url = `${BASE_URL}/product/getproduct/?search=${search}&page=${page}&limit=${limit}`;

    try{
        const response = await axios.get(url);
        return response.data;

    } catch(err){
         return err;
    }

}