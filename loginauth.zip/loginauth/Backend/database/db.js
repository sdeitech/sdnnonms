const mongoose = require ('mongoose')


exports.connectToMongo = async()=>{
    try{
        const res = await mongoose.connect("mongodb://localhost:27017/MyProject");
        //const movies = database.collection('ecommerce');
        //console.log(movies);

        if(res){
            console.log("Database connected successfully");
        }
    }
    catch(error){
        console.log(error);
    }
};