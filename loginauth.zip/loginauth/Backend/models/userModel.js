// const express = require ('express')
const mongoose = require('mongoose')

const userSchema = mongoose.Schema({
    Username:{
        type:String,
       
    },
    Password:{
        type:String,
       
    },
    Role:{
        type:String,
    }
})
const userModel = mongoose.model("users",userSchema);
module.exports=userModel;