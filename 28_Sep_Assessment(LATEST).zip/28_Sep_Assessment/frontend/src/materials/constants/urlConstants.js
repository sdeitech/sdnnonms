export const URLs = {
  // For Main Model
  AXIOS_GET_POST_UPDATE_DELETE: "http://localhost:5000/user/api",
  AXIOS_POST_LOGIN: "http://localhost:5000/user/api/login",

  // For Sub Model
  AXIOS_SUB_GET_POST: "http://localhost:5000/user/api/useData",
};
