import axios from "axios";
import "../../App.css";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { URLs } from "../constants/urlConstants";

const SignIn = () => {
  const [inputPara, setInputPara] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  const onChangeHandle = (e) => {
    setInputPara({ ...inputPara, [e.target.name]: e.target.value });
  };

  const loginHandle = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(URLs.AXIOS_POST_LOGIN, inputPara);
      localStorage.setItem("token", result.data?.token);
      console.log(result.data);

      localStorage.setItem("user", JSON.stringify(result.data?.userInfo));
      navigate("/Dashboard");
    } catch (error) {
      console.error(error);
      toast.error("Login failed");
    }
  };

  return (
    <>
      <div className="container mt-5">
        <h2 className="text-center mb-4">Sign In Form</h2>
        <ToastContainer />
        <div className="row justify-content-center">
          <div className="col-md-6">
            <form
              onSubmit={loginHandle}
              className="p-4 border rounded shadow-sm"
            >
              <div className="mb-3">
                <label htmlFor="email" className="form-label">
                  Email address
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  name="email"
                  placeholder="Enter email"
                  value={inputPara.email}
                  onChange={onChangeHandle}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder="Enter Password"
                  value={inputPara.password}
                  onChange={onChangeHandle}
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary w-100 mb-3">
                Sign In
              </button>
              <div className="text-center">
                <Link to="/signup" className="text-decoration-none">
                  Not a User? Sign up
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignIn;
