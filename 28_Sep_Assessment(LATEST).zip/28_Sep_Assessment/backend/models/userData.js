/**
 * Importing Mongoose Package
 */
import mongoose from "mongoose";

/**
 * Declaring Schema for Mongoose to store values
 */
const userDataSchema = mongoose.Schema({
  firstName: {
    type: String,
    required: true,
  },

  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
});

/**
 * Creating collection and importing the Schema
 */
const userDataModel = mongoose.model("userData", userDataSchema);

/**
 * Exporting UserModel
 */
module.exports = userDataModel;
