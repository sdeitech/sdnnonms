import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'; // Import Swal for the alert

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user: any = null;
  error: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.authService.getUserDetailsFromServer().subscribe(
      (data) => {
        console.log('User details fetched:', data); // Debugging
        if (Array.isArray(data) && data.length > 0) {
          this.user = data[0]; // Extract the first object from the array
        } else {
          this.error = 'No user details available.';
        }
      },
      (err) => {
        console.error('Error fetching user details:', err); // Debugging
        console.log('Profile Picture URL:', this.user.profile);

        this.error = 'Failed to fetch user details. Please try again.';
      }
    );
  }

  logout(): void {
    this.authService.logout(); // Log the user out
    Swal.fire({
      title: 'Logout Successful!',
      text: 'You have been logged out successfully.',
      icon: 'success',
      confirmButtonText: 'Proceed',
    }).then(() => {
      this.router.navigate(['/home']); // Redirect to home page after logout
    });
  }
}
