import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { CartService } from '../services/cart.service';

interface Product {
  id?: number;
  title: string;
  description: string;
  price: number;
  image: string;
  quantity: number;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  private baseUrl = 'http://127.0.0.1:8000/products/';
  constructor(private http: HttpClient, private cartService: CartService) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    this.http.get<Product[]>(this.baseUrl).subscribe(
      (data) => {
        this.products = data.map((product) => ({
          ...product,
          image: this.getimagepath(product.image),
        }));
        console.log(this.products);
      },
      (error) => {
        console.error('There was an error fetching the products!', error);

        Swal.fire({
          title: 'Error!',
          text: 'Could not fetch products',
          icon: 'error',
        });
      }
    );
  }

  addToCart(product: Product): void {
    this.cartService.addToCart(product); // Use the CartService to manage the cart

    Swal.fire({
      title: 'Added Successfully!',
      text: `Added ${product.title} to cart`,
      icon: 'success',
    });
  }

  getimagepath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `http://127.0.0.1:8000${path.startsWith('/') ? path : '/' + path}`;
  }
}
