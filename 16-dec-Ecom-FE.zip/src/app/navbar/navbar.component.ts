import Swal from "sweetalert2";
import { AuthService } from "../services/auth.service";
import { Router } from "@angular/router";
import { CartService } from "../services/cart.service";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-navbar",
  templateUrl: "./navbar.component.html",
  styleUrls: ["./navbar.component.css"],
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false;
  cartCount: number = 0;

  constructor(
    private authService: AuthService,
    private router: Router,
    private cartService: CartService
  ) {}

  ngOnInit(): void {
    this.updateLoginStatus();

    // Listen for login/logout events to dynamically update the navbar
    this.authService.loginStatusChanged.subscribe(() => {
      this.updateLoginStatus();
    });

    // Subscribe to the cart count and update dynamically
    this.cartService.getCartCount().subscribe((count) => {
      this.cartCount = count; // This will update the count in the navbar
    });
  }

  updateLoginStatus(): void {
    this.isLoggedIn = this.authService.isAuthenticated();
  }

  checkLoginStatus(): void {
    if (this.isLoggedIn) {
      this.router.navigate(["/cart"]); // Redirect to cart if logged in
    } else {
      // Alert to log in
      Swal.fire({
        icon: "warning",
        title: "Please Log In",
        text: "You need to log in to access your cart.",
        confirmButtonText: "Log In",
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(["/login"]); // Redirect to login page
        }
      });
    }
  }
}
