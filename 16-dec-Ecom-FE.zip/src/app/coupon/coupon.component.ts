import { Component } from '@angular/core';
import { CouponService } from '../services/coupon.service';

@Component({
  selector: 'app-add-coupon',
  templateUrl: './coupon.component.html'
})
export class AddCouponComponent {
  couponCode: string = '';
  discountPercentage: number | null = null;
  validUntil: string = '';
  message: string = '';

  constructor(private couponService: CouponService) {}

  addCoupon() {
    const couponData = {
      code: this.couponCode,
      discount_percentage: this.discountPercentage,
      valid_until: this.validUntil
    };

    this.couponService.addCoupon(couponData).subscribe({
      next: (response) => {
        this.message = 'Coupon added successfully!';
        this.couponCode = '';
        this.discountPercentage = null;
        this.validUntil = '';
      },
      error: (err) => {
        this.message = 'Failed to add coupon. Please try again.';
      }
    });
  }
}

