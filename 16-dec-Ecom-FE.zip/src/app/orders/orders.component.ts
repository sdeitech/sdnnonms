import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css'],
})
export class OrdersComponent implements OnInit {
  user: any = null;
  error: string | null = null;
  isEditing: boolean = false;
  newFields: any[] = []; // Holds dynamically added address fields
  selectedAddress: any = null; // Track the selected address
  success: string | undefined;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.getUserDetailsFromServer().subscribe(
      (data) => {
        if (Array.isArray(data) && data.length > 0) {
          this.user = data[0];
        } else {
          this.error = 'No user details available.';
        }
      },
      (err) => {
        this.error = 'Failed to fetch user details. Please try again.';
      }
    );
  }

  toggleEdit(): void {
    this.isEditing = !this.isEditing;
  }

  saveUserDetails(): void {
    this.isEditing = false;
    this.saveToDatabase(this.user);
  }

  addNewFields(): void {
    this.newFields.push({ name: '', address: '', mobile: '', isSaved: false });
  }

  saveNewField(index: number): void {
    const field = this.newFields[index];
    if (field.name && field.address && field.mobile) {
      field.isSaved = true;
      this.saveToDatabase(field);
    } else {
      Swal.fire({
        title: 'Incomplete Details',
        text: 'Please provide all details.',
        icon: 'error',
        confirmButtonText: 'Try Again',
      });
    }
  }

  editField(index: number): void {
    this.newFields[index].isSaved = false;
  }

  deleteField(index: number): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this address!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        this.newFields.splice(index, 1);
        Swal.fire('Deleted!', 'Your address has been deleted.', 'success');
      }
    });
  }

  selectAddress(address: any): void {
    this.selectedAddress = address; // Set the selected address
    Swal.fire({
      title: 'Address Selected!',
      text: 'This address has been selected for delivery.',
      icon: 'success',
      confirmButtonText: 'OK',
    });
  }

  deliverToAddress(): void {
    if (!this.selectedAddress) {
      Swal.fire({
        title: 'No Address Selected!',
        text: 'Please select an address before proceeding.',
        icon: 'error',
        confirmButtonText: 'OK',
      });
    } else {
      Swal.fire({
        title: 'Order Confirmed!',
        text: `Your order will be delivered to: 
        ${this.selectedAddress.name || ''} 
        ${this.selectedAddress.address || ''}`,
        icon: 'success',
        confirmButtonText: 'OK',
      });
    }
  }

  saveToDatabase(data: any): void {
    console.log('Saving to database:', data);
  }

  paymentMethod: string = '';
  onlinePaymentMethod: string = '';
 
  placeOrder() {
    if (!this.paymentMethod) {
      this.error = 'Please select a payment method.';
      return;
    }
    if (
      this.paymentMethod === 'payOnline' &&
      !this.onlinePaymentMethod
    ) {
      this.error = 'Please select an online payment method.';
      return;
    }

    this.error = '';
    this.success = 'Your order has been placed successfully!';
    console.log('Order Details:', {
      address: this.selectedAddress,
      paymentMethod: this.paymentMethod,
      onlinePaymentMethod: this.onlinePaymentMethod,
    });
  }
}
