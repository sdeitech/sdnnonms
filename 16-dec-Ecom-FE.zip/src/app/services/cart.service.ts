import { isPlatformBrowser } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Inject, Injectable, PLATFORM_ID } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private apiUrl = 'http://127.0.0.1:8000/api/products/';
  private cartCountSubject: BehaviorSubject<number>; 
  private cartSubject: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]); // Initially empty array
  cart$: Observable<any[]> = this.cartSubject.asObservable(); // Expose as observable

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: Object) {
    let initialCartCount = 0;
    let initialCartItems: any[] = [];

    if (isPlatformBrowser(this.platformId)) {
      // Get data from localStorage if available
      initialCartCount = Number(localStorage.getItem('cartCount')) || 0;
      const savedCart = localStorage.getItem('cartItems');
      initialCartItems = savedCart ? JSON.parse(savedCart) : [];
    }

    this.cartCountSubject = new BehaviorSubject<number>(initialCartCount);
    this.cartSubject = new BehaviorSubject<any[]>(initialCartItems);
    this.cart$ = this.cartSubject.asObservable();
  }

  // Expose the cart count as an observable to update in navbar
  getCartCount(): Observable<number> {
    return this.cartCountSubject.asObservable();
  }

  // Update the cart count and save it to localStorage
 // Update cart count
updateCartCount(count: number): void {
  this.cartCountSubject.next(count);
  if (isPlatformBrowser(this.platformId)) {
    localStorage.setItem('cartCount', count.toString()); // Save to localStorage
  }
}


  // Add product to cart and update cart count
// Add product to cart and update cart count
addToCart(product: any): void {
  const currentCart = this.cartSubject.getValue();
  const existingProduct = currentCart.find(item => item.id === product.id);

  if (existingProduct) {
    existingProduct.quantity += 1; // Increase quantity if product is already in the cart
  } else {
    product.quantity = 1; // Add product with quantity 1 if not in the cart
    currentCart.push(product);
  }

  this.cartSubject.next(currentCart);
  this.updateCartCount(currentCart.reduce((acc, item) => acc + item.quantity, 0)); // Update count based on quantity
  this.saveCartToLocalStorage(currentCart);
}

  
  // Remove product from cart and update cart count
  removeFromCart(productId: number): void {
    const currentCart = this.cartSubject.getValue();
    const updatedCart = currentCart.filter(item => item.id !== productId);
    this.cartSubject.next(updatedCart);
    this.updateCartCount(updatedCart.length);
    this.saveCartToLocalStorage(updatedCart);
  }

  // Clear all items from the cart
  clearCart(): void {
    this.cartSubject.next([]);
    this.updateCartCount(0);
    this.saveCartToLocalStorage([]);
  }

  // Update cart items and count
  updateCart(cart: any[]): void {
    this.cartSubject.next(cart);
    this.updateCartCount(cart.length);
    this.saveCartToLocalStorage(cart);
  }

  // Fetch products from API (optional for cart items)
  fetchProductsFromApi(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  private saveCartToLocalStorage(cart: any[]): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('cartItems', JSON.stringify(cart));
    }
  }
  
}
