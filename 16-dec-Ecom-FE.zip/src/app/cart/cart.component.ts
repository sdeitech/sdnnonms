import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Router } from '@angular/router'; // Import Router
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  discountPrice: number = 0;
  discountPercentage: number = 0;
  couponCode: string = '';
  couponMessage: string = '';

  constructor(private cartService: CartService, private router: Router) {} // Inject Router

  ngOnInit(): void {
    // Subscribe to the cart observable to get cart data
    this.cartService.cart$.subscribe((cart: any[]) => {
      this.cart = cart; // Set the cart data
      this.calculateTotal(); // Recalculate total price
    });
  }

  // Remove an item from the cart
  removeFromCart(product: any): void {
    this.cartService.removeFromCart(product.id); // Remove the product from the cart
    this.calculateTotal(); // Recalculate the total
  }

  // Clear the cart completely
  clearCart(): void {
    this.cartService.clearCart(); // Clear the cart
    this.calculateTotal(); // Recalculate the total
  }

  // Increase quantity of an item
  increaseQuantity(product: any): void {
    product.quantity += 1;
    this.cartService.updateCart(this.cart); // Update the cart
    this.calculateTotal(); // Recalculate the total
  }
  
  decreaseQuantity(product: any): void {
    if (product.quantity > 1) {
      product.quantity -= 1;
      this.cartService.updateCart(this.cart); // Update the cart
    } else {
      this.removeFromCart(product); // Remove the item if quantity is 1
    }
    this.calculateTotal(); // Recalculate the total
  }

  // Calculate the total price of the cart
  calculateTotal(): void {
    this.totalPrice = this.cart.reduce(
      (total, product) => total + product.price * product.quantity,
      0
    );

    // Calculate discount
    this.discountPrice = this.totalPrice;
    if (this.discountPercentage > 0) {
      this.discountPrice = this.totalPrice * (1 - this.discountPercentage / 100);
    }
  }

  // Apply a coupon code
  applyCoupon(): void {
    if (this.couponCode === 'DISCOUNT10') {
      this.discountPercentage = 10; // Set discount to 10%
      this.couponMessage = 'Coupon applied successfully!';
    } else {
      this.couponMessage = 'Invalid coupon code.';
      this.discountPercentage = 0; // Reset discount
    }
    this.calculateTotal(); // Recalculate the total after applying the coupon
  }

  // Proceed to checkout and redirect to Orders page
  checkout(): void {
    // Simply redirect to the orders page without any address/payment info yet
    this.router.navigate(['/orders']);
  }
}
