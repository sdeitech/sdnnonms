from django.apps import AppConfig


class AssessementAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assessement_app'
