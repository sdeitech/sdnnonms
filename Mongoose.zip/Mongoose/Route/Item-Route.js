const express = require('express');
const router = express.Router();
const itemController = require('../Controller/Item-Controller');
const { verifToken } = require('../middleware/Authenticate');

router.post('/',verifToken, itemController.createItem)
router.get('/', verifToken, itemController.getItems)
router.patch('/:id', itemController.updateItem)
router.delete('/:id', itemController.deleteItem)

module.exports = router;