const mongoose = require('mongoose');

// Define Item Schema
const itemSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: String,
});
// Create Item Model
const Item = mongoose.model('Item', itemSchema);

module.exports = Item;