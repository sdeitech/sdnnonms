/**
 * Importing Mongoose Package
 */
import mongoose from "mongoose";

/**
 * Declaring Schema for Mongoose to store values
 */
const userSchema = mongoose.Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  dob: {
    type: String,
    required: true,
  },
  marriedStatus: {
    type: String,
    required: true,
  },
  gender: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    select: false,
    required: true,
  },
  token: {
    type: String,
    select: false,
  },
});

/**
 * Creating collection and importing the Schema
 */
const userModel = mongoose.model("userDetails", userSchema);

/**
 * Exporting UserModel
 */
module.exports = userModel;
