import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();

  const logoutHandle = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  return (
    <>
      <header
        style={{
          backgroundColor: "#282c34",
          padding: "10px",
          color: "white",
          fontSize: "25px",
        }}
      >
        SmartData Enterprises Pvt. Ltd
      </header>
      <div>
        <Link to="/myprofile">MY PROFILE</Link>
      </div>
      <div>
        <button onClick={logoutHandle}>LogOut</button>
      </div>
    </>
  );
};

export default Header;
