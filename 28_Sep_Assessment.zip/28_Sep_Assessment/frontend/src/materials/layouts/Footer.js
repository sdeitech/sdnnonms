const Footer = () => {
  return (
    <>
      <footer
        style={{
          backgroundColor: "#282c34",
          padding: "10px",
          color: "white",
          marginTop: "auto",
          fontSize: "20px",
        }}
      >
        Developed By: Roshan Khandagale
      </footer>
    </>
  );
};

export default Footer;
