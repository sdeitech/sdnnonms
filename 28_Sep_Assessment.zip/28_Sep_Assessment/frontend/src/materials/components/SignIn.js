import axios from "axios";
import "../../App.css";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

const SignIn = () => {
  const [inputPara, setInputPara] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();
  
  const onChangeHandle = (e) => {
    setInputPara({ ...inputPara, [e.target.name]: e.target.value });
  };

  const loginHandle = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(
        "http://localhost:5000/user/api/login",
        inputPara
      );
      localStorage.setItem("token", result.data.token);
      console.log(result.data.token);
      toast.success("WARM WELCOME!!");
      navigate("/Dashboard");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <div>
        <h2 className="App-header">SignIn Form</h2>
      </div>
      <ToastContainer />
      <div>
        <form className="Show-body" onSubmit={loginHandle}>
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter email"
            name="email"
            onChange={onChangeHandle}
            required
          />
          <input
            className="w3-input w3-border"
            type="password"
            placeholder="Enter Password"
            name="password"
            onChange={onChangeHandle}
            required
          />
          <button type="submit">Submit</button>
          <Link to="/">Not a User?</Link>
        </form>
      </div>
    </>
  );
};

export default SignIn;
