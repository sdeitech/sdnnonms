import TableData from "./TableData";
import { Button } from "react-bootstrap";

const Dashboard = () => {
  return (
    <>
      <div>
        <Button>Add User</Button>
      </div>
      <div>
        <TableData />
      </div>
    </>
  );
};

export default Dashboard;
