import { useState, useEffect } from "react";
import { Button, Form, Modal } from "react-bootstrap";
import axios from "axios";

function MyProfile({ handleUpdateShow, handleUpdateClose, data, onUpdate }) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    dob: "",
    marriedStatus: false,
    gender: "",
  });
  useEffect(() => {
    axios
      .get("http://localhost:5000/user/api")
      .then((response) => {
        setFormData(response.data?.user);
        console.log(response.data.user);
      })
      .catch((error) => {
        console.error("Unable to load data!!", error);
      });
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");

      // Send updated data to the backend
      await axios.put(
        `http://localhost:4000/reportDetails/api/getReport/${data?._id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Call onUpdate to refresh the table data after successful update
      onUpdate();
      handleUpdateClose();
    } catch (error) {
      console.error("Error updating the record:", error);
    }
  };

  return (
    <>
      <Modal
        show={handleUpdateShow}
        onHide={handleUpdateClose}
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Update Record</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formFirstName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter First Name"
                name="firstName"
                value={formData?.firstName}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formLastName">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Last Name"
                name="lastName"
                value={formData?.lastName}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter Email"
                name="email"
                value={formData?.email}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formMarksEnglish">
              <Form.Label>Date of Birth</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter Date of Birth (DOB)"
                name="Date of Birth"
                value={formData?.dob}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formMarksScience">
              <Form.Label>Married Status</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter Marks in Science"
                name="marriedStatus"
                value={formData?.marriedStatus}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formMarksMaths">
              <Form.Label>Gender</Form.Label>
              <Form.Control
                type="number"
                name="marksMaths"
                value={formData?.gender}
                onChange={handleInputChange}
              />
            </Form.Group>
            <Button variant="warning" type="submit">
              Update
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default MyProfile;
