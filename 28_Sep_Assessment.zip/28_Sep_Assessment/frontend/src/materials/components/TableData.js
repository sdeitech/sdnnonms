/**
 * Importing all necessary packages
 */
import { useEffect, useState } from "react";
import ViewModal from "./ViewModal";
import { Table, Button, Pagination } from "react-bootstrap";
import axios from "axios";

const TableData = () => {
  const [data, setData] = useState([]);
  const [show, setShow] = useState(false);
  const [tableValue, setTableValue] = useState({});
  const [page, setPage] = useState(1);
  const [totalPages] = useState(0);
  const [limit] = useState(5);
  const [search, setSearch] = useState("");

  /**
   * Function to fetch Records
   */
  const getRecordHandle = async (page, limit, search = "") => {
    try {
      const token = localStorage.getItem("token");
      const result = await axios.get("http://localhost:5000/user/api", {
        headers: {
          params: { page, limit, search },
          Authorization: `Bearer ${token}`, // Attach token in Authorization header
        },
      });

      // To validate the data is properly passed in setData or not
      if (result.data && result.data.user) {
        setData(result.data.user);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // useEffect is used to Fetch data
  useEffect(() => {
    getRecordHandle(page, limit, search);
  }, [page, limit, search]);

  // For Modal View Handler
  const handeShow = (ele) => {
    setShow(true);
    setTableValue(ele);
  };

  const handleClose = () => {
    setShow(false);
  };

  // Pagination Handlers for Next Record
  const handleNext = () => {
    if (page < totalPages) setPage(page + 1);
  };

  // Pagination Handlers for Previous Record
  const handlePrevious = () => {
    if (page > 1) setPage(page - 1);
  };

  // For Searching
  const handleSearch = (e) => {
    setSearch(e.target.value);
  };

  return (
    <>
      <div>
        <input
          type="search"
          placeholder="🔍 Search"
          value={search}
          onChange={handleSearch}
        />
        <ViewModal
          show={show}
          tableValue={tableValue}
          handleClose={handleClose}
        />
        <Table striped bordered hover variant="light">
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {Array.isArray(data) &&
              data.map((ele) => {
                return (
                  <tr key={ele._id}>
                    <td>{ele.firstName}</td>
                    <td>{ele.lastName}</td>
                    <td>{ele.email}</td>
                    <td>
                      <Button variant="info" onClick={() => handeShow(ele)}>
                        View
                      </Button>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </div>

      <div>
        <Pagination>
          <Pagination.Prev onClick={handlePrevious} disabled={page === 1} />
          <Pagination.Item active>{page}</Pagination.Item>
          <Pagination.Next
            onClick={handleNext}
            disabled={page === totalPages}
          />
        </Pagination>
      </div>
    </>
  );
};

export default TableData;
