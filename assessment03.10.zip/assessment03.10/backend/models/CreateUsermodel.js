import mongoose from 'mongoose';

const UseraddSchema = new mongoose.Schema({
    FirstName: { type: String, required: true },
    LastName: { type: String, required: true },
    Email: { type: String, required: true },
    userref: [
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:"Users"
        }
    ]
    }
);

const useradd = mongoose.model('Usersadd', UseraddSchema);
module.exports = useradd;