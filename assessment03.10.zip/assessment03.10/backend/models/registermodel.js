import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
    FirstName: { type: String, required: true },
    LastName: { type: String, required: true },
    Email: { type: String, required: true },
    DOB: { type:String,required: true},
    profile: { type :String,required:true},
    Password: { type: String , required: true},
    Gender:{ type: String ,required: true},
    IsMarried:{ type:String,required:true},
    
    // token: { type : String }
    }
);

const user = mongoose.model('Users', UserSchema);
module.exports = user;