require("dotenv/config");

export const config = {
  local: {
    DB: {
      HOST: "127.0.0.1",
      PORT: "27017",
      DATABASE: "test",
      USERNAME: "",
      PASSWORD: "",
    },
    apiPort: "3500",
  },
  staging: {},
  prod: {},
};