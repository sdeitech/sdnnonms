const jwt = require("jsonwebtoken");
const { FORBIDDEN, UNAUTHORIZED } = require('../config/constants');


const  verifytoken = (req,res,next) =>{
    const token = req.header ('authorization');
    console.log(token);
    if (!token){
        res.status(FORBIDDEN).send("a token is reqired for authentation");
    }

    try {
        const decoded = jwt.verify(token,"...");
        console.log(decoded);
        req.user = decoded;
         

    } catch (error) {
        return res.status(UNAUTHORIZED).send("invalid token");
    }
    next();

    
}

module.exports = verifytoken;