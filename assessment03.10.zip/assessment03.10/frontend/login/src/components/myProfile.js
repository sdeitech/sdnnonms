// import React from 'react'
// import { Form,Button } from 'react-router-dom'
// export default function myProfile() {
//   return (
//     <div>
//         <h1>this is my profile section</h1>

//         <Form>
//       <Form.Group className="mb-3">
//         <Form.Label>FirstName</Form.Label>
//         <Form.Control type="email" placeholder="FIRSTNAME"/>
//       </Form.Group>

//       <Form.Group className="mb-3" >
//         <Form.Label>LastName</Form.Label>
//         <Form.Control type="email" placeholder="LASTNAME" />
//       </Form.Group>


//       <Form.Group className="mb-3" >
//         <Form.Label>Email</Form.Label>
//         <Form.Control type="email" placeholder="EMAIL" />
//       </Form.Group>

//       <Form.Group className="mb-3" >
//         <Form.Label>DOB</Form.Label>
//         <Form.Control type="password" placeholder="DOB" />
//       </Form.Group>
//       <Button variant="primary" type="submit">
//         Submit
//       </Button>
//     </Form>
//     </div>
//   )
// }
