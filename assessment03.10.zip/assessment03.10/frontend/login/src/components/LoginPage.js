import { useState } from 'react';
import axios from 'axios';
import './LoginPage.css';
import {  useNavigate } from 'react-router-dom'; // Assuming you want to use a separate CSS file
import toast from 'react-hot-toast';

function LoginPage() {

    const navigate = useNavigate();
    const [user, setUser] = useState({
        Email: "",
        Password: ""
      
    });
    const handleChange = (e) => {
        // setUser({ ...user, [e.target.name]: e.target.value });
        const { name, value} = e.target;
        setUser(() => ({
           
            [name]: value 
        }));
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            console.log("you are in loginpage")
            const result = await axios.post("http://localhost:3500/tologin", user);
            console.log(result);
            
            localStorage.setItem("token", result.data.token);
            localStorage.setItem("user",result.data.user)
            toast.success(`login succuessfull`)
            console.log("You logged in successfully", result.data.user);
            console.log(result.data.token);
            navigate("/dashboard")
            
        } catch (error) {
            console.log("Error", error);
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleSubmit} className="login-form">
                <input 
                    type="email" 
                    name="email" 
                    // value={user.Email}
                    placeholder="Enter email" 
                    onChange={handleChange} 
                    required 
                />
                <input 
                    type="password" 
                    name="Password" 
                    placeholder="Password" 
                    onChange={handleChange}
                />
                <button type="submit" className="login-button" onClick={() => navigate('/dashboard')} >Submit</button>
                <div><div>
                <button type="submit" className="newuser-button" onClick={() => navigate('/signUp')}>New User</button>
                </div></div>
            </form>
        </div>
    );
}
export default LoginPage;
