import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "../../App.css";
// import UserDetails from "./UserDetails";

function ViewModal({ show, viewUser, handleClose }) {

 
  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={true}
      >
        <Modal.Header closeButton>
          <Modal.Title>{viewUser?.firstName} Record</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="Show-body">
            <h2>User Detials</h2>
            <label>First Name</label>
            <h5>{viewUser?.FirstName}</h5>
            <label>Last Name</label>
            <h5>{viewUser?.LastName}</h5>
            <label>Email Address</label>
            <h5>{viewUser?.Email}</h5>
          
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={handleClose}>
            CLOSE
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ViewModal;
