import { React } from "react";
import PublicLayout from "../layout/Publiclayout";
import LoginPage from "../components/LoginPage";
import SignupPage from "../components/Signup";
import UserDetails from "../components/Dashboard/UserDetails";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><LoginPage/></PublicLayout>
    },
    {
        path: "/Signup",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><SignupPage/></PublicLayout>
    },
    // {
    //     path: "/Signup",
    //     exact: true,
    //     // element: <PublicLayout><SignIn /></PublicLayout>
    //     element: <PublicLayout><LoginPage/></PublicLayout>
    // },
   
 ];
export default publicRoutes;