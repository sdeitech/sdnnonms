import React from 'react'
import PrivateLayout from '../layout/Privatelayout'
// import Dashboard from '../components/Dashboard'
// import AddUser from '../components/AddUser'
import UserDetails from '../components/Dashboard/UserDetails'
// import LoginPage from '../components/LoginPage'

const PrivateRoute = [
    // {
    //     path: "/user",
    //     exact: true,
    //     element: <PrivateLayout></PrivateLayout>
    // },
    // {
    //     path: "/add/user",
    //     exact: true,
    //     element: <PrivateLayout></PrivateLayout>
    // },
    {
        path: "/dashboard",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element:<PrivateLayout><UserDetails/></PrivateLayout>
    },
]

export default PrivateRoute