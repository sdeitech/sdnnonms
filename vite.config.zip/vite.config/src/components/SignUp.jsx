import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
const apiUrl = import.meta.env.VITE_API_URL;

const SignUp = () => {
  const [formData, setFormData] = useState({
    email: "",
    mobile: "",
    gender: "",
    profile: null,
    password: "",
  });

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${apiUrl}/signup`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      console.log(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div
      style={{
        justifyContent: "center",
        display: "flex",
        alignItems: "center",
        border: "solid 3px",
        padding: "20px",
        flexDirection: "column",
        width: "400px",
        margin: "auto",
        marginTop: "50px",
        borderRadius: "10px",
      }}
    >
      <h1>Registration Form</h1>
      <form
        onSubmit={handleSubmit}
        style={{ display: "flex", flexDirection: "column", width: "100%" }}
      >
        <input
          type="text"
          name="email"
          placeholder="Enter email"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="tel"
          name="mobile"
          placeholder="Enter mobile"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <div
          style={{
            marginBottom: "10px",
            display: "flex",
            justifyContent: "space-around",
          }}
        >
          <label>
            Male
            <input
              type="radio"
              name="gender"
              value="male"
              checked={formData.gender === "male"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
          <label>
            Female
            <input
              type="radio"
              name="gender"
              value="female"
              checked={formData.gender === "female"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
        </div>
        <input
          type="file"
          name="profile"
          onChange={handleChnage}
          style={{ marginBottom: "10px", border: "none" }}
        />
        <input
          type="text"
          name="password"
          placeholder="Enter password"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            borderRadius: "5px",
            backgroundColor: "#28a745",
            color: "#fff",
            border: "none",
            cursor: "pointer",
          }}
        >
          Register
        </button>
      </form>
      <p style={{ marginTop: "10px" }}>
        Already have an account?{" "}
        <Link
          to={"/login"}
          style={{ color: "#007bff", textDecoration: "none" }}
        >
          <span>click here</span>
        </Link>
      </p>
    </div>
  );
};

export default SignUp;

// const onFinishFailed = (errorInfo) => {
//   console.log("Failed:", errorInfo);
// };
// const App = () => (
//   <>
//     <h1 style={{ textAlign: "center" }}>Register</h1>
//     <div
//       style={{
//         justifyContent: "cenetr",
//         display: "flex",
//         alignItems: "center",
//         border: "solid 3px",
//       }}
//     >
//       <Form
//         name="basic"
//         labelCol={{
//           span: 8,
//         }}
//         wrapperCol={{
//           span: 16,
//         }}
//         style={{
//           maxWidth: 600,
//         }}
//         initialValues={{
//           remember: true,
//         }}
//         onFinish={onFinish}
//         onFinishFailed={onFinishFailed}
//         autoComplete="off"
//       >
//         <Form.Item
//           label="Email"
//           name="Email"
//           rules={[
//             {
//               required: true,
//               message: "Please input your email!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>

//         <Form.Item
//           label="Password"
//           name="password"
//           rules={[
//             {
//               required: true,
//               message: "Please input your password!",
//             },
//           ]}
//         >
//           <Input.Password />
//         </Form.Item>

//         <Form.Item
//           label="Phone"
//           name="phone"
//           rules={[
//             {
//               required: true,
//               message: "Please input your phone number!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>

//         <Form.Item
//           name="remember"
//           wrapperCol={{
//             offset: 8,
//             span: 16,
//           }}
//         >
//           <Checkbox>Remember me</Checkbox>
//         </Form.Item>

//         <Form.Item
//           wrapperCol={{
//             offset: 8,
//             span: 16,
//           }}
//         >
//           <Button
//             type="primary"
//             htmlType="submit"
//             style={{
//               alignItems: "center",
//               display: "flex",
//               justifyContent: "center",
//             }}
//           >
//             Submit
//           </Button>
//         </Form.Item>
//       </Form>
//     </div>
//   </>
// );
// export default App;
