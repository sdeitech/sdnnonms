
import FormExample from './components/Userdesign';
import './App.css';
// import ProductForm from './components/ProductForm';
// import DataTable from './components/DataTable';
import 'bootstrap/dist/css/bootstrap.css';

import DataTable from './components/datatable';
// import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div>
      <FormExample />
      <DataTable />
    </div>
  );
}

export default App;