const validate  =(formData) =>{
    let error= {};

    if(!formData.Firstname){
        error.Firstname="first name is required";
    }
    if (formData.Firstname.length > 8 && formData.Firstname.length<2) {
        error.Firstname = "Length should be between 3 to 8"
    }

    if(!formData.Lastname){
        error.Lastname = "last name required";
    }
    if(!formData.Email){
        error.Email = "Email required";
    }
    if
    (!formData.marksinenglish){
        error.marksinenglish = "Enter valid marks";

    }
    if(!formData.marksinscience){
        error.marksinscience = "Enter valid marks"
    }
    if(!formData.marksinmaths){
        error.marksinmaths = "Enter valid marks"
    }
    if(!formData.About){
        error.about="About Required"
    }

    return error;
}
export default validate;