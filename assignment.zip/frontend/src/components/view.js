import React from "react"
const View = ({curruntUser,showview,setshowview}) => {
    return (
      <div style={{border:"solid 1px",backgroundColor:"aquamarine",position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:"400px", color:"green",margin:"auto",textAlign:"center"}}>   
      <p>firstname :{curruntUser?.Firstname}</p>
      <p>lastname :{curruntUser?.lastname}</p>
      <p>Email :{curruntUser?.Email}</p>
      <p>Marks in English : {curruntUser?.marksinenglish}</p>
      <p>Marks in Science :{curruntUser?.marksinscience}</p>
      <p>Marks in Maths :{curruntUser?.marksinmaths}</p>
     
      <p>percentage :80</p>
     
      <p>grade:"B"</p>
      
      <button onClick={()=>
  
          {setshowview(!showview)}
      }>close</button>
      </div>
    )
  }
  
  export default View;