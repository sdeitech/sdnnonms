import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import axios from 'axios';
import validate from './validate';

const FormExample = () => {

  const [formData, setFormData] = useState({
    Firstname: "",
    Lastname: "",
    Email: "",
    marksinenglish: "",
    marksinscience: "",
    marksinmaths: "",
    About:"",
    percentage: "",
    grade: ""
  });

  //State for error

  const [error, setError] = useState({})

  //handle change 
  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(e.target);

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  //handle submit

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData, "formData");
    const error = validate(formData)
    setError(error)
    console.log(error)
    if (Object.keys(error).length === 0) {
      // console.log(formData)
      try {
        const response = await axios.post(
          "http://localhost:7345/api/createUser",
          formData
        );
        console.log("Form data submitted:", response.data);
      } catch (err) {
        console.error("Error submitting form:", err.message);
      }
    }
    else {
      //alert("please enter valid detals in form")
    }


    // handleSubmit(e);
  };


  return (
    <Form onSubmit={(handleSubmit)} >
      <Row className="mb-3">
        <Form.Group as={Col} md="4" controlId="validationCustom01">
          <Form.Label>Firstname</Form.Label>
          <Form.Control
            name="Firstname"
            type="text"
            placeholder="First name"
            defaultValue=""
            onChange={handleChange}
          />
          {error?.Firstname && <p style={{ color: "red" }}>{error.Firstname}</p>}

        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustom02">
          <Form.Label>Lastname</Form.Label>
          <Form.Control
            name="Lastname"
            type="text"
            placeholder="Last name"
            defaultValue=""
            onChange={handleChange}
          />
          {error?.Lastname && <p style={{ color: "red" }}>{error.Lastname}</p>}

          
        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustomUsername">
          <Form.Label>Email</Form.Label>
          <InputGroup hasValidation>
            <InputGroup.Text id="inputGroupPrepend">@</InputGroup.Text>
            <Form.Control
              name='Email'
              type="text"
              placeholder="Email"
              aria-describedby="inputGroupPrepend"

              onChange={handleChange}
            />
            {error?.Email && <p style={{ color: "red" }}>{error.Email}</p>}
          </InputGroup>
        </Form.Group>
      </Row>
      <Row className="mb-3">
        <Form.Group as={Col} md="6" controlId="validationCustom03">
          <Form.Label>Marksinenglish</Form.Label>
          <Form.Control name="marksinenglish" type="Number" placeholder="Marks in English" onChange={handleChange} />
          {error?.marksinenglish && <p style={{ color: "red" }}>{error.marksinenglish}</p>}

          
        </Form.Group>
        <Form.Group as={Col} md="3" controlId="validationCustom04">
          <Form.Label>Marksinmaths</Form.Label>
          <Form.Control name="marksinscience" type="Number" placeholder="Marks in maths" onChange={handleChange} />
          {error?.marksinscience && <p style={{ color: "red" }}>{error.marksinscience}</p>}
        
        </Form.Group>
        <Form.Group as={Col} md="3" controlId="validationCustom05">
          <Form.Label>Marksinscience</Form.Label>
          <Form.Control name="marksinmaths" type="Number" placeholder="Marks in Science" onChange={handleChange} />
          {error?.marksinmaths && <p style={{ color: "red" }}>{error.marksinmaths}</p>}
          
        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustom01">
          <Form.Label>About</Form.Label>
          <Form.Control
            name="About"
            type="text"
            placeholder="About"
          
            onChange={handleChange}
          />
          {error?.About && <p style={{ color: "red" }}>{error.About}</p>}
          
        </Form.Group>

      </Row>

      <Form.Group className="mb-3">
        <Form.Check

          label="Agree to terms and conditions"
          feedback="You must agree before submitting."
          feedbackType="invalid"
        />
      </Form.Group>
      <Button type="submit">Submit form</Button>
      <Button type="Reset">Reset form</Button>

    </Form>
  );
};

export default FormExample;