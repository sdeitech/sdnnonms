const express = require('express');
const cors = require('cors');
const { connectToMongo } = require("./database/db.js");
const bodyParser = require("body-parser");

const userRouter = require("./routes/userRoutes.js");


const app = express();
const PORT = 7345;

//app.use('port', process.env.PORT || 7345)


app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());

connectToMongo();
app.use(cors());

//middleware

app.use(express.json());

//routes
app.use("/api", userRouter);

// app.get("/Users", (req, res) => {
//     res.json({ message: "hi" })
// })
app.post("/users", (req, res) => {
    //app.push(req.body);
    res.json({ message: "hi" })
})





app.listen(PORT, () => {
    console.log(`server is running on http://localhost:${PORT}`)
});





