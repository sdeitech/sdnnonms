const Users = require("../models/userModels");
const sendMailToUser = require('../helper/nodemailer')

// for creating user
const calculatePercentage =(mark1,mark2,mark3)=>{
  const percentage = ((mark1+mark2+mark3)/300)*100
  return percentage.toFixed(2) }

exports.createUser = async (req, res) => {
  console.log(req.body.email)
    try {
      
    const percentage = await calculatePercentage(100,100,10)
    req.body.percentage =percentage
      const newUser = new Users(req.body);
      await newUser.save();
      const data = await sendMailToUser("aryandakhore123@gmial.com","Hello")
      console.log(data);
      return res.status(201).json({newUser});
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  };

  //get all users means displaying users

exports.getUsers = async (req, res) => {
  try {
    const users = await Users.find();
    res.json({ users: users, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};