const mongoose = require ('mongoose');


//Schema of product details


const userSchema = mongoose.Schema({
    Firstname:{
        type:String,
    },
    Lastname:{
        type:String,
    },
    Email:{
        type:String,
    },
    marksinenglish:{
        type:Number,
    },
    marksinscience:{
        type:Number,
    },
    marksinmaths:{
        type:Number,
    },
    About:{
        type:String,
    },
    percentage:{
        type:Number
    }

});

const userModel = mongoose.model("users",userSchema);
module.exports=userModel;