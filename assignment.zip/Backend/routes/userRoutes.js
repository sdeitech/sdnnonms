const express = require('express');
const router = express.Router();

//calling controller 

const userInfo = require("../controller/userController");


//all cruds

router.post('/createUser',userInfo.createUser);
router.get('/getUser',userInfo.getUsers);



module.exports = router;