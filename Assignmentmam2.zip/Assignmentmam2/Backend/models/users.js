import mongoose, { mongo } from "mongoose";
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  Name: {
    type: String,
    required: true,
  },
  Email: {
    type: String,
    required: true,
  },
  Mobile: {
    type: String,
    required: true,
  },
  Profile: {
    type: String,
    required: true,
  },
});

const Users = mongoose.model("Users", UserSchema);
export default Users;
