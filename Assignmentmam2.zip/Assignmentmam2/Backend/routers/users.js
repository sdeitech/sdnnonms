import express from "express";
const UserProfileRoute = express.Router();
import {
  createProfile,
  getUsers,
  //getPaginatedData,
} from "../controllers/users";
import uploadMiddleware from "../helper/multer";

UserProfileRoute.post("/user", uploadMiddleware, createProfile);
UserProfileRoute.get("/user", getUsers);
//UserProfileRoute.get("/users", getPaginatedData);

export default UserProfileRoute;
