import express from "express";
const app = express();
import UserProfileRoute from "./routers/users";
import cors from "cors";

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use("/getimage", express.static("images"));
app.use("/api", UserProfileRoute);

export default app;
