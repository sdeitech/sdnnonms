import Users from "../models/users";

const createProfile = async (req, res) => {
  const { name, email, mobile } = req.body;
  const fileName = req.file ? req.file.filename : null;

  if (!name || !email || !mobile || !fileName) {
    return res.json({ msg: "All fields are required" });
  }

  try {
    const user = await Users.findOne({ email });
    if (user) {
      return res.json({ msg: "User already exists" });
    }

    const userData = new Users({
      name,
      email,
      mobile,
      profile: fileName,
    });

    await userData.save();
    res.json({ msg: "User created successfully", user: userData });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};

const getUsers = async (req, res) => {
  try {
    const users = await Users.find({});
    res.json({ user: users });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};



export { createProfile, getUsers };
