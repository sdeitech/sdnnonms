import React, { useState } from 'react';
//import './FormDesign.css';
//import validate from './validateUser';
import axios from 'axios';


export default function FormComponent() {
    const [formData, setFormData] = useState({
        Name: '',
        Email: '',
        Mobile: '',
        Profile: '',

    });
    const [display, setDisplay] = useState('');

    const [error, setError] = useState({});

    const clear = () => {
        setFormData({
            Name: '',
            Email: '',
            Mobile: '',
            Profile: '',

        })
    }
    // Handle input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };
    // console.log(formData,"formdata");

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData, "formData");

        // const error = validate(formData)
        // setError(error)
        // console.log(error)
        // if (Object.keys(error).length === 0) {
        try {
            const response = await axios.post("http://localhost:3002/api/user", formData);

            console.log("form data submitted", response.data)
            setDisplay("form data submitted")
        } catch (err) {
            console.log("Error in submitting form", err.message)

        }
    }
    // else {
    //alert("plese enter valid details")
    // }




return (
    <>
        <form className="form-container" onSubmit={(handleSubmit)}>
            <h2>Register Form</h2>

            <div className="form-group">
                <label>Name:</label>
                <input
                    type="text"
                    name="Name"
                    value={formData.Name}
                    onChange={handleChange}
                />
                {/* {error.Name && <p className="error">{error.Name}</p>} */}
            </div>

            <div className="form-group">
                <label>Email:</label>
                <input
                    type="email"
                    name="Email"
                    value={formData.Email}
                    onChange={handleChange}
                />
                {/* {error.Email && <p className="error">{error.Email}</p>} */}
            </div>

            <div className="form-group">
                <label>Mobile:</label>
                <input
                    type="Number"
                    name="Mobile"
                    value={formData.Mobile}
                    onChange={handleChange}
                />
                {/* {error.Message && <p className="error">{error.Message}</p>} */}
            </div>
            <div className="form-group">
                <label>Profile:</label>
                <input
                    type="profile"
                    name="Profile"
                    value={formData.Profile}
                    onChange={handleChange}
                />
                {/* {error.Message && <p className="error">{error.Message}</p>} */}
            </div>






            <div className="form-group">
                <button type="submit" className="submit-button">Submit</button>
                <button type="reset" className="submit-button" onClick={clear}>Reset</button>
                <p>{display}</p>


            </div>

        </form>
    </>

)

}

