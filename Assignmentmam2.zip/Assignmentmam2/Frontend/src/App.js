import logo from './logo.svg';
import './App.css';
import  FormComponent from './component/Form';

function App() {
  return (
    <FormComponent/>

  );
}

export default App;
