# from django.shortcuts import render,HttpResponseRedirect
# from .models import Student, MY_CHOICES
# from .forms import StudentRegistration
# from django.db.models import Q


# def show (request):
#     student=Student.objects.all()
#     return render (request, "crudapp/show.html",{'student':student})



# def adddata(request):
#     if request.method == "POST":
#         fm=StudentRegistration(request.POST)
#         if fm.is_valid():
#             fm.save()
#             return HttpResponseRedirect("/")
#     else:
#         fm=StudentRegistration()
#     return render (request,"crudapp/adddata.html",{'form':fm})



# def updatedata(request ,id):
#     if request.method=="POST":
#         student=Student.objects.get(pk=id)
#         fm=StudentRegistration(request.POST,instance=student)
#         if fm.is_valid():
#             fm.save()
#         return HttpResponseRedirect("/")
#     else:
#         student=Student.objects.get(pk=id)
#         fm=StudentRegistration(instance=student)
#     return render (request, "crudapp/update.html",{'form':fm})


# def deletedata(request ,id):
#     if request.method=="POST":
#         student=Student.objects.get(pk=id)
#         student.delete()
#         return HttpResponseRedirect("/")


# def searchstudent(request):
#     if request.method == 'POST':
#         n1 = request.POST.get('output')
#         print(n1)
#         student = Student.objects.all()
#         std = None  # Initialize the variable
#         if n1:
#             std = student.filter(
#                 Q(fname__icontains=n1) |
#                 Q(lname__icontains=n1) |
#                 Q(email__icontains=n1) |
#                 Q(phone__icontains=n1) |
#                 Q(branch__icontains=n1)
#             )
#             print( std.count())
#         return render(request, "crudapp/show.html", {'student': std})
#     else:
#         return HttpResponse('An Exception Occurred')



from django.views import View
from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from .forms import StudentRegistration
from django.db.models import Q

# Show all students
class ShowStudents(View):
    def get(self, request):
        students = Student.objects.all()
        return render(request, "crudapp/show.html", {'student': students})

# Add new student
class AddStudent(View):
    def get(self, request):
        form = StudentRegistration()
        return render(request, "crudapp/adddata.html", {'form': form})

    def post(self, request):
        form = StudentRegistration(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show')
        return render(request, "crudapp/adddata.html", {'form': form})

# Update student data
class UpdateStudent(View):
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        form = StudentRegistration(instance=student)
        return render(request, "crudapp/update.html", {'form': form})

    def post(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        form = StudentRegistration(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('show')
        return render(request, "crudapp/update.html", {'form': form})

# Delete student data
class DeleteStudent(View):
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        return render(request, "crudapp/delete_confirm.html", {'student': student})

    def post(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        student.delete()
        return redirect('show')

# Search for students
class SearchStudents(View):
    def post(self, request):
        n1 = request.POST.get('output')
        students = Student.objects.all()
        std = None
        
        if n1:
            std = students.filter(
                Q(fname__icontains=n1) |
                Q(lname__icontains=n1) |
                Q(email__icontains=n1) |
                Q(phone__icontains=n1) |
                Q(branch__icontains=n1)
            )
        return render(request, "crudapp/show.html", {'student': std})

    def get(self, request):
        return HttpResponse('An Exception Occurred')
