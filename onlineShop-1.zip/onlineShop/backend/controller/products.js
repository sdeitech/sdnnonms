const products =[

    {
        id:1,
        name:"iphone 13 pro",
        desc:"Better For Video ",
        price:170000,
        image: "https://res.cloudinary.com/dqdvgwdrz/image/upload/v1730807997/iphone12_geon9t.jpg"
    },
    {
        id:2,
        name:"iphone 14",
        desc:"Dynamic Island",
        price:159999,
        image: "https://res.cloudinary.com/dqdvgwdrz/image/upload/v1730807997/iphone12pro_gmz234.jpg"
    },
    {
        id:3,
        name:"Galaxy S24",
        desc:"Performance Centric",
        price:100000,
        image: "https://res.cloudinary.com/dqdvgwdrz/image/upload/v1730807997/galaxyS_nflsov.png"
    },
];

module.exports = products
