import 'dotenv/config.js'

export const config ={
    DB:{

        SERVER:process.env.MONGO_DB_SERVER || "mongodb",
        HOST:process.env.MONGO_DB_HOST,
        PORT:process.env.MONGO_DB_PORT,
        DATABASE:process.env.MONGO_DATABASE_NAME,

    },
    PORT:process.env.PORT,

    TOKENS:{
        
        JWT_EXPIRATION:process.env.JWT_EXPIRATION || "1h",
        NODE_ENV:process.env.NODE_ENV || "local"
    },
};