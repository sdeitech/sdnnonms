export const messages ={
    createUser:"Your Account is Successfully created",
    failCreate:"Unable to Create Account",
    logIn:"Login SuccessFull",
    mongoSuccess:"Connection established with Mongodbserver",
    mongoFailed:"Connection failed with Mongodbserver"

}


export const messageID ={
    successCode:200,
    badRequest:400,
    newResourceCreated:201,
    unAuthorizedUser:401,
    forbidden:403,
    internalServerError:500
};
