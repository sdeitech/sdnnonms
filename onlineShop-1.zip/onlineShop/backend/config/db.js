import mongoose from 'mongoose';
import 'dotenv/config.js';
const config = require('./config');
const {DB} =config.config;
const constant = require('./constant');

const DBURL= `${DB.SERVER}://${DB.HOST}:${DB.PORT}/${DB.DATABASE}`;


export const dbConnection = async(req,res)=>{
    try {
       await mongoose.connect(DBURL)
       console.log('Connection Establish with MongoDb ');
        //  console.log(constant.messages.mongoSuccess)
        
    } catch (error) {
        console.log(error," Error occured During Connection with Mongodb");
        //   console.log(constant.messages.mongoFailed);
        process.exit(1); // Exit process with failure
    }
};