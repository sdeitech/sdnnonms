const jwt = require('jsonwebtoken')
require('dotenv').config()






const genAuthToken =(user)=>{
const secretkey = process.env.JWT_SECRETS

const token = jwt.sign({
    _id:user._id,
    name:user.name,
    email:user.email,
    isAdmin:user.isAdmin
},
secretkey,
{
    expiresIn:"1h"
}
)

return token

};

module.exports = genAuthToken
