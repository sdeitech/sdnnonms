const jwt = require('jsonwebtoken')

const auth = (req,res,next)=>{
    const token = req.header("X-auth-token")

    if(!token){
        return res.status(401).send("Access Denied Not Authenticated")

    }
    try {
    const secretkey = process.env.JWT_SECRETS
    const user= jwt.verify(token,secretkey)
    req.user = user

    next()
        
    } catch (error) {
        console.log(error,"ERROR IN AUTH");
        res.status(400).send("ACCESS DENIED. INVALID AUTH TOKEN")

    }
};

const isAdmin =(req,res,next)=>{
    auth(req,res,()=>{

        if(req.user.isAdmin){
            next()
        }else{
            res.status(403).send("Access denied. Not Authorized...")
        }

    });
};


module.exports = { auth, isAdmin }