import express from 'express';
import bodyParser from "body-parser";
import cors from "cors";
import { dbConnection } from './config/db';
import productRoutes from './routes/productRoutes'
import registerRoute from './routes/registerRoute';
import loginRoute from './routes/loginRoute';
import emailRoute from './routes/emailRoute';
import productsRoute from './routes/createProductsRoute.js'

// import socialRoutes from './routes/socialRoutes';


const app = express();

app.use(cors({
    origin: 'http://localhost:3000',  // Replace with your React app's URL if different
    methods: ['GET', 'POST', 'PUT', 'DELETE'],  // Add any other methods you might need
    credentials: true,  // Allow cookies (if needed)
  }));
// Other middleware and routes here
app.use(bodyParser.json());

app.use('/',productRoutes);
app.use('/api',registerRoute);
app.use('/api',loginRoute);

app.use('/api/products',productsRoute)
app.use('/api', emailRoute);


// app.use('/api',userRoutes);

dbConnection(); //database Connection 

export default app; 

