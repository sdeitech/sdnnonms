const bcrypt = require("bcrypt");
const Joi = require("joi");
const express = require("express");
const { default: User } = require("../model/user");
const genAuthToken = require("../utils/genAuthToken");

const router = express.Router();

router.post("/login", async (req, res) => {
  try {
    const schema = Joi.object({
      email: Joi.string().min(4).max(200).required().email(),
      password: Joi.string().min(8).max(200).required(),
    });
    
    

    const { error } = schema.validate(req.body);
    if (error) return res.status(400).send(error.details[0].message);

    let user = await User.findOne({ email: req.body.email });
    if (!user) {
      return res.status(400).send("Invalid Email or Password.");
    }

    const isValid = await bcrypt.compare(req.body.password, user.password);
    if (!isValid) {
      return res.status(400).send("Invalid Email or Password.");
    }
    console.log(req.body.password);
    console.log(user.password);
    
    

    // Generate token and send success response
    const token = genAuthToken(user);
    res.status(200).send({ token, message: "Login Successful" });

  } catch (error) {
    console.error(error);
    return res.status(500).send("Cannot Login");
  }
});

module.exports = router;
