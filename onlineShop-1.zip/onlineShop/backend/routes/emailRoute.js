// routes/emailRoute.js
import express from 'express';
import nodemailer from 'nodemailer';
import User from '../model/user';    // Assuming User model is defined
const router = express.Router();
import { auth } from '../middleware/auth'; 

router.post('/checkout-email',auth, async (req, res) => {
  const userId = req.user._id;// Ensure the user is authenticated
  console.log(userId);
  
  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).send("User not found.");

    const transporter = nodemailer.createTransport({
      service: 'Gmail', // or your preferred email service
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: user.email,
      subject: 'Order Confirmation',
      text: `Thank you for your order, ${user.name}! Your order has been successfully placed.`,
    };

    await transporter.sendMail(mailOptions);
    res.status(200).send("Email sent successfully");

  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).send("Email could not be sent.");
  }
});

export default router;
