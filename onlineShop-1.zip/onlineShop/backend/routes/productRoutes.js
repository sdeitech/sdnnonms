const router = require('express').Router();
const products  = require('../controller/products')

// router.post('/register',uploadMiddleware ,register);
// router.post('/login',login);
// router.post('/getDataById',getDataById);

router.get('/products',async(req,res) =>{

    res.send(products)
})



module.exports=router;
