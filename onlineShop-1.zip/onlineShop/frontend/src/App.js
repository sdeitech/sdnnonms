import './App.css';
import 'react-toastify/dist/ReactToastify.css' ;
import NavBar from './components/NavBar'
import Cart from './components/Cart'
import Home from './components/Home'
import NotFound from './components/NotFound';
import {BrowserRouter , Route , Routes,Navigate } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'; 
import Register from './auth/Register';
import Login from './auth/Login';
import Dashboard from './admin/Dashboard';
import Products from './admin/Products';
import CreateProducts from './admin/CreateProducts';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <ToastContainer />
      <NavBar/>
      <Routes>
        
        <Route path='/cart' exact element={<Cart/>} />
        <Route path='/register' exact element={<Register/>} />
        <Route path='/login' exact element={<Login/>} />
        <Route path='/not-found' exact element={<NotFound/>} />
        <Route path='/admin' exact element={<Dashboard/>} >
        <Route path='products' exact element={<Products/>} >
        <Route path='create-products' exact element={<CreateProducts/>} />
        </Route>
        </Route>
        <Route path='/' exact element={<Home/>} />
        <Route path = "*" element= {<Navigate to= "/not-found" />} />

      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
