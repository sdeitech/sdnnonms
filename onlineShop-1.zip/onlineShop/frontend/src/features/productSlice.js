import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios';
import apiUrl, { setHeaders } from "./api";
import { toast } from "react-toastify";

const initialState = {
    items: [],
    status: null,
    error: null,
    createStatus: null,
};

export const productFetch = createAsyncThunk(
    "product/productFetch",
    async (_, { rejectWithValue }) => {
        try {
            const response = await axios.get(`${apiUrl}api/products`);
            console.log("Product data fetched:", response.data); // Debugging log
            
            return response.data;
        } catch (error) {
            console.error("Error fetching products:", error); // Debugging log
            return rejectWithValue(error.response?.data || "Error occurred");
        }
    }
);

export const productsCreate = createAsyncThunk(
    "product/productsCreate",
    async (values, { rejectWithValue }) => {
        try {
            const response = await axios.post(`${apiUrl}api/products`, values,setHeaders());
            toast.success("Product Created SuccessFully");
            return response.data;
        } catch (error) {
            console.error("Error creating product:", error); // Debugging log
            toast.error(error.response?.data || "Error occurred");
            return rejectWithValue(error.response?.data);
        }
    }
);

const productsSlice = createSlice({
    name: "products",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(productFetch.pending, (state) => {
                state.status = "pending";
            })
            .addCase(productFetch.fulfilled, (state, action) => {
                state.status = "success";
                state.items = action.payload;
            })
            .addCase(productFetch.rejected, (state, action) => {
                state.status = "rejected";
                state.error = action.payload;
            })
            .addCase(productsCreate.pending, (state) => {
                state.createStatus = "pending";
            })
            .addCase(productsCreate.fulfilled, (state, action) => {
                state.createStatus = "success";
                state.items.push(action.payload);
            })
            .addCase(productsCreate.rejected, (state, action) => {
                state.createStatus = "rejected";
                state.error = action.payload;
            });
    },
});

export default productsSlice.reducer;
