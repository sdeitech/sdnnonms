 const apiUrl = `http://localhost:5000/` 



 export const setHeaders =()=>{
    const headers ={
        headers :{
            "X-auth-token":localStorage.getItem("token")
        },
    };
    return headers;
 }



export default apiUrl