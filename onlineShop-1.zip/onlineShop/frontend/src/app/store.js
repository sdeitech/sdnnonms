import { configureStore } from '@reduxjs/toolkit';
import productReducer, { productFetch } from '../features/productSlice';
import { productsApi } from '../features/productApi.js'
import cartReducer, { getTotals } from '../features/cartSlice.js'
import authReducer, { loadUser } from '../features/authSlice.js'
 


const store = configureStore({
    reducer :{
      products:productReducer,
      cart:cartReducer,
      auth:authReducer,
      
      [productsApi.reducerPath]:productsApi.reducer,
    },
    middleware:(getDefaultMiddleware)=>
      getDefaultMiddleware().concat(productsApi.middleware),
    
  });

  store.dispatch(productFetch())
  store.dispatch(getTotals())
  store.dispatch(loadUser(null))

  

  
  export default store