import React from 'react'
import { Outlet ,useNavigate } from 'react-router-dom'
import { AdminHeaders,PrimaryButton } from './CommonStyled'

function Products() {

  const navigate = useNavigate()

  return (
    <>
    <AdminHeaders>
      <h3>Products page </h3>
      <PrimaryButton onClick={()=>navigate("/admin/products/create-products")} >
        Create
      </PrimaryButton>
    </AdminHeaders>
    <Outlet/>

    </>
    
  )
}

export default Products
