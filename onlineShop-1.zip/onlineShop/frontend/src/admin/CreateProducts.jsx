import React, { useState } from "react";
import { useDispatch } from "react-redux";
import styled from "styled-components";
import { PrimaryButton } from "./CommonStyled.jsx";
import { productsCreate } from "../features/productSlice.js";

function CreateProducts() {

  const dispatch = useDispatch()


  const [productImg, setProductImg] = useState("");
  const [formData, setFormData] = useState({
    name:"",
    brand:"",
    price:"",
    desc:""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };


  console.log(productImg);

  const handleProductImageUpload = (e) => {
    const file = e.target.files[0];
    // console.log(file);
    TransformFile(file);
  };

  const TransformFile = (file) => {
    const reader = new FileReader();

    if (file) {
      reader.readAsDataURL(file);
      reader.onloadend = () => {
        setProductImg(reader.result);
      };
    } else {
      setProductImg("");
    }
  };


  const handleSubmit =(e)=>{
    e.preventDefault()

    dispatch(productsCreate({
      name:formData.name,
      brand:formData.brand,
      price:formData.price,
      desc:formData.desc,
      image:productImg
      
    }))


  }

  return (
    <div>
      <StyledCreateProduct onSubmit={handleSubmit} >
        <StyledForm>
          <h3>Create A Product</h3>
          <input
            type="file"
            accept="image/"
            onChange={handleProductImageUpload}
            required
          />

          <select name="brand" onChange={handleChange} required >

            <option value="">Select Category</option>
            <option value="electronics">Electronics</option>
            <option value="electrical">Electrical</option>
            <option value="clothing">Clothing</option>
            <option value="shoes">Shoes</option>
            <option value="drugs">Drugs</option>
            <option value="food">Food And Nutrition</option>
            <option value="other">Other</option>




          </select>

          <input
            type="text"
            placeholder="Enter Product Name"
            name="name"
            onChange={handleChange}
            required
          />
          
          <input
            type="number"
            placeholder="Enter Product Price"
            name="price"
            onChange={handleChange}
            required
          />
          <input
            type="text"
            placeholder="Enter Product Description"
            name="desc"
            onChange={handleChange}
            required
          />
        
        <PrimaryButton type="submit" >
          Submit
        </PrimaryButton>

        </StyledForm>
        <ImagePreview>
          {productImg ? (
           <img src={productImg} alt="product preview" />
          ) : (
            <p>Image Will Appear Here ! </p>
          )}
        </ImagePreview>
      </StyledCreateProduct>
    </div>
  );
}

export default CreateProducts;

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;
  max-width: 300px;
  margin-top: 2rem;

  select,
  input {
    padding: 7px;
    min-height: 30px;
    outline: none;
    border-radius: 5px;
    border: 1px solid rgb(182, 182, 182);
    margin: 0.3rem 0;

    &:focus {
      border: 2px solid rgb(0, 208, 255);
    }
  }

  select {
    color: rgb(95, 95, 95);
  }
`;

const StyledCreateProduct = styled.div`
  display: flex;
  justify-content: space-between;
`;

const ImagePreview = styled.div`
  margin: 2rem 0 2rem 2rem;
  padding: 2rem;
  border: 1px solid rgb(183, 183, 183);
  max-width: 300px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  color: rgb(78, 78, 78);

  img {
    max-width: 100%;
  }
`;
