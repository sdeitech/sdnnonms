import React,{ useState ,useEffect } from 'react'
import { useDispatch,useSelector } from 'react-redux';
import { StyledForm } from './StyledForm'
import { useNavigate } from 'react-router-dom';
import { loginUser } from '../features/authSlice';


function Login() {

    const [user,setUser]=useState({

        email:"",
        password:""
    })

    const navigate =useNavigate()


    const auth = useSelector((state)=>state.auth)
    console.log(auth);
    
    useEffect(()=>{
        if(auth._id){
            navigate('/cart')
        }
    },[auth._id,navigate]);


    const dispatch =useDispatch()


    console.log(user,"users");
    
    const handleSubmit =(e)=>{
        e.preventDefault()

        dispatch(loginUser(user))
    }


  return (
    <div>

        <StyledForm >

            <h2>Login</h2>

            
            <input type="email" placeholder='email'  onChange={(e)=>setUser({...user,email:e.target.value})} /><br /><br />
            <input type="password" placeholder='password'  onChange={(e)=>setUser({...user,password:e.target.value})}/><br /><br />
            <button onClick={handleSubmit}>{auth.loginStatus==="pending" ? "Submitting" : "Login" }</button>

            {auth.loginStatus==="rejected" ? (<p>{auth.loginError}</p>) : null }


        </StyledForm>
      
    </div>
  )
}

export default Login;
