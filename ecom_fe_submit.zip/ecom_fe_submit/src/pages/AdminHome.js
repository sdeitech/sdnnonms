import NavBar from "../features/navbar/Navbar";
import AdminProductList from "../features/counter/product-list/components/AdminProductList";

function AdminHome () {
    return(
        <div>
            <NavBar>
                <AdminProductList></AdminProductList>
            </NavBar>
        </div>
    );
}

export default AdminHome;