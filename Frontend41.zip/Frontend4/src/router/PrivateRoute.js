import {React} from 'react';
import Dashboard from '../component/Dashboard';
import PrivateLayout from '../layout/PrivateLayout';
import Myprofile from '../component/Myprofile';
import {Add} from '../component/Add';

const privateRoutes = [
    {
        path:'/add',
        exact:true,
        element:<PrivateLayout><Add/></PrivateLayout>
    },
    {
        path:'/dashboard',
        exact:true,
        element:<PrivateLayout><Dashboard/></PrivateLayout>
    },
    {
        path:'/myprofile',
        exact: true,
        element:<PrivateLayout><Myprofile/></PrivateLayout>
    }
];

export default privateRoutes;