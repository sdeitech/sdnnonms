import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from 'axios';
import '../styles/login.css'
import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";

const clientId = "531162091657-a8l74t9nuhjjhgdln9bqd44tfng3bshi.apps.googleusercontent.com";

const Login = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });


  const navigate = useNavigate()

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginData((prev) => ({
      ...prev, [name]: value
    }))
  }



  const handleSubmit = async (e) => {
    e.preventDefault();


    try {
      const response = await axios.post('http://localhost:2003/api/login', loginData);
      const { data } = response;
      console.log("data", data)
      alert("User login Successfully");
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("info", JSON.stringify(response.data.user));
      localStorage.setItem("id", (response.data.user._id));
      localStorage.setItem('profile', response.data.user.profile)
      console.log(response.data.user)

      navigate('/dashboard')

      console.log('Login Success:', response.data);
    } catch (error) {
      console.log(error);
    }
  };
  const [logindata, setloginData] = useState(
    localStorage.getItem("loginData")
      ? JSON.parse(localStorage.getItem("loginData")) : null
  )

  // const handleSuccess = async (response) => {
  //   console.log("response", response)
  //   try {
  //     const res = await fetch("http://localhost:2003/api/glogin", {
  //       method: "post",
  //       body: JSON.stringify({ token: response }),
  //       headers: { "Content-Type": "application/json" }
  //     });
  //     console.log("login with google success");

  //     console.log('res', JSON.stringify(res));

  //     // return

  //     if (res.status !== 200) {
  //       throw new Error("failed to login with google");
  //     }
  //     else if (res.status === 200) {
  //       const data = await res.json();
  //       localStorage.setItem("loginData", JSON.stringify(data));
  //       setloginData(data);

  //       navigate('/dashboard');
  //     }
  //     // console.log("zhdgsdt")


  //   }
  //   catch (error) {
  //     console.log(error);
      
  //     console.log("login not success");
  //   }

  // }
  const handleSuccess = async (response) => {
    console.log("response", response);
    try {
        const res = await fetch("http://localhost:2003/api/glogin", {
            method: "post",
            body: JSON.stringify({ token: response }),
            headers: { "Content-Type": "application/json" }
        });

        // Check if the response status is OK
        if (!res.ok) {
            throw new Error("Failed to login with Google");
        }

        const data = await res.json(); // Parse the JSON response

        // Log the full data received
        console.log("Google Login Data:", data);

        // Set necessary data in localStorage
        localStorage.setItem("token", data.token);
        localStorage.setItem("info", JSON.stringify(data.user));
        localStorage.setItem("id", data.user._id);
        localStorage.setItem('profile', data.user.profile);

        // Update state with login data if necessary
        setloginData(data);

        // Navigate to the dashboard after successful login
        navigate('/dashboard');
    } catch (error) {
        console.log(error);
        console.log("Login not successful");
    }
};

  const handleError = () => {
    console.log("error while login")
  }
  return (
    <div>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div>
          <input type="email"
            name="email"
            placeholder="Email"
            onChange={handleChange} />
        </div>
        <div>
          <input
            type="password"
            name="password"
            placeholder="Password"
            onChange={handleChange} />
        </div>
        <button type="submit">Login</button>
        <span>Don't Have an Acoount?
          <Link to="/signup">Sign Up</Link>
        </span>

      </form>
      <button type="button">
        <GoogleOAuthProvider clientId={clientId}>
          <GoogleLogin
            onSuccess={(CredentialResponse) => {
              handleSuccess(CredentialResponse.credential);
            }}
            onError={handleError}
          />
        </GoogleOAuthProvider>
      </button>
    </div>
  );
}

export default Login







