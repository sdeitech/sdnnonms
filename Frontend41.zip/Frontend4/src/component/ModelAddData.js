// import React, { useState ,useEffect} from 'react';
// import {Button, Modal, Form} from 'react-bootstrap';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';


// function Example() {
//   const [show, setShow] = useState(false);

//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);

//   const [data , setData] = useState([]);
//   const [postcontent, setPostContent] = useState({
//       firstName:'',
//       lastName: ' ',
//       email:' ',
//     });
    
//    const navigate = useNavigate(); 

 
//  useEffect(() => {
//    const getUser = async () =>{
//     const token = localStorage.getItem('authToken');
//     const config ={
//       headers:{
//         Authorization : `Bearer ${token}`,
//       },
//     }
//     const {data} = await axios.get('http://localhost:2003/api/get-user' , config);
//     setData(data);

//    };

//   getUser();
// }, []);

// const createData = async (e) => {
//   e.preventDefault();

//       // // const token = localStorage.setItem('authToken');
//       // const config = {
//       //     headers:{
//       //         Authorization: `Bearer ${token}`,
//       //     }
//       // }
//       const response = await axios.post('http://localhost:2003/api/add', postcontent);
//       console.log(response)
//       setData([...data, response.data]);
//       setPostContent({
//         firstName:'',
//         lastName: ' ',
//         email:' '
//       });
//       navigate('/dashboard')
  
// };

// const handleInput = (e) => {
//   setPostContent(e.target.value);
// };


//   return (
//     <>
//       <Button variant="primary" onClick={handleShow}>
//         Launch demo modal
//       </Button>

//       <Modal show={show} onHide={handleClose}>
//         <Modal.Header closeButton>
//           <Modal.Title>Modal heading</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Form onSubmit={createData}>
//             <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
//               <Form.Label>First Name</Form.Label>
//               <Form.Control
//                 type="firstName"
//                 placeholder="name@example.com"
//                 value={postcontent.firstName}
//                 onChange={handleInput} 
//               />
//               <Form.Label>Last Name</Form.Label>
//               <Form.Control
//                 type="lastName"
//                 placeholder="name@example.com"
//                 value={postcontent.lastName}
//                 onChange={handleInput}
 
//               />
//               <Form.Label>FirstName</Form.Label>
//               <Form.Control
//                 type="email"
//                 placeholder="name@example.com"
//                 autoFocus
//                 value={postcontent.email}
//                 onChange={handleInput}
//               />
//               <Button type="button">Submit</Button>
//             </Form.Group>
//           </Form>
//         </Modal.Body>

       
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleClose}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleClose}>
//             Save Changes
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </>
//   );
// }

// export default Example;