
import React from 'react'
import { Link } from 'react-router-dom'


const MyProfile = () => {
  

  const userInfo = localStorage.getItem("info");
  const newUserInfo = JSON.parse(userInfo);
  
  // const id = localStorage.setItem(id);
  localStorage.getItem("id",userInfo.data.id);
  console.log(userInfo.data ,"====")
  localStorage.getItem('profile',userInfo.data.profile)
  console.log("xcdfd", newUserInfo);


  return (
    <div>
      <h1>My Profile</h1>


      <div>
        <img style={{
          width: "200px",
          height: "200px",
          borderRadius: "50%",
          objectFit: "cover",
        }} src={`http://localhost:2003/images/${newUserInfo.profile}`} />
         <p>FirstName:{newUserInfo.firstName}</p>
        <p>Last Name:{newUserInfo.lastName}</p>
        <p>Email:{newUserInfo.email}</p>
        <p>Date Of Birth:{newUserInfo.DOB}</p>
        <p>Gender:{newUserInfo.gender}</p>
        <p>Married:{newUserInfo.isMarried}</p>
        {/* <p>Profile:{newUserInfo.profile}</p>    */}
        <button type="submit">Update</button>
      </div>
      <Link to='/dashboard'>Dashboard</Link>
    </div>
  )
}
export default MyProfile;