// controllers/upload.js
import File from "../model/multer.modal"; // Adjust path as necessary

// controllers/upload.js
export const uploadimage = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  try {
    const newFile = new File({
        filename: req.file.filename,
        path: req.file.path, // This is the path where the file is saved
        mimetype: req.file.mimetype,
        size: req.file.size,
    });

    // Save file details to the database
    await newFile.save();
    res
      .status(200)
      .json({ message: "File uploaded successfully", file: req.file });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};
