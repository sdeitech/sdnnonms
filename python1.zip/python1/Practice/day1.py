# print("                                           Student Marksheet ")
print("Enter Marks of 5 subjects")
m1,eng,phy,chem,eg=int(input("M1:")),int(input("Eng:")),int(input("Phy:")),int(input("Chem:")),int(input("EG: "))
if m1>=33 and eng >=33 and phy>=33 and chem>=33 and eg>=33:
    print("Result: PASS")
    
    
    
