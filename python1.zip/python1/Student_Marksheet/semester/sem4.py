def SemFour():
    M4=int(input("Enter the M3 Marks : "))
   
    python=int(input("Enter the java Marks : "))
    
    OS=int(input("Enter the DSPD Marks : "))
   
    STQA=int(input("Enter the CN Marks : "))
    
    CW=int(input("Enter the CAO Marks : "))
    if M4>80 or python>80 or OS>80 or STQA>80 or CW>80:
        print("please enter a valid Marks, Your marks should be less than 80 !")
    else:
        M4,python,OS,STQA,CW
        per=(M4+python+OS+STQA+CW)/5
        print("Percentage : ", per)
        if per<=100 and per>=90:
            print("GRADE : A")
        elif per<=90 and per>=80:
            print ("GRADE : B")
        elif per<=80 and per>=60:
            print("GRADE : C")      
        else:
            print("GRADE : D")
