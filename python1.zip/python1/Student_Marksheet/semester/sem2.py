def SemTwo():
    M2=int(input("Enter the M2 Marks : "))
    C_lang=int(input("Enter the C_lang Marks : "))
    Chem=int(input("Enter the Chemistry Marks : "))
    Phy=int(input("Enter the Physics Marks : "))
    CNS=int(input("Enter the CNS Marks : "))
    
    M2internal=int(input("Enter the M2 internal marks: "))
    C_langinternal=int(input("Enter the C_lang internal marks: "))
    Cheminternal=int(input("Enter the Chemistry internal marks: "))
    Phyinternal=int(input("Enter the Physics internal marks: "))
    CNSinternal=int(input("Enter the CNS internal marks: "))
    
    M2external=int(input("Enter the M2 external marks: "))
    C_langexternal=int(input("Enter the C_lang external marks: "))
    Chemexternal=int(input("Enter the Chemistry external marks: "))
    Phyexternal=int(input("Enter the Physics external marks: "))
    CNSexternal=int(input("Enter the CNS external marks: "))
        
    
    if M2>80 or C_lang>80 or Chem>80 or Phy>80 or CNS>80:
        print("please enter a valid Marks, Your marks should be less than 80 !")
        if M2internal>10 or C_langinternal>10 or Cheminternal>10 or Phyinternal>10 or CNSinternal>10:
            print("please enter a valid marks, your marks should be less than 10 !")
            if M2external>10 or C_langexternal>10 or Chemexternal>10 or Phyexternal>10 or CNSexternal>10:
                print("Please enter a valid marks, your marks should be less than 10 !")
        else:
            M2internal,C_langinternal,Cheminternal,Phyinternal,CNSinternal
    else:
        M2,C_lang,Chem,Phy,CNS
        totalmarks=(M2+C_lang+Chem+Phy+CNS+M2internal+C_langinternal+Cheminternal+Phyinternal+CNSinternal+M2external+C_langexternal+Chemexternal+Phyexternal+CNSexternal)
        per=(totalmarks/500)*100
        print("Percentage : ", per)
        if per<=100 and per>=90:
            print("GRADE : A")
        elif per<=90 and per>=80:
            print ("GRADE : B")
        elif per<=80 and per>=60:
            print("GRADE : C")      
        else:
            print("GRADE : D")