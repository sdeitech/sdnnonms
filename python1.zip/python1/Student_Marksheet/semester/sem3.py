def SemThree():
    M3=int(input("Enter the M3 Marks : "))
    
    java=int(input("Enter the java Marks : "))
  
    DSPD=int(input("Enter the DSPD Marks : "))
    
    CN=int(input("Enter the CN Marks : "))
  
    CAO=int(input("Enter the CAO Marks : "))
    
    M3internal=int(input("Enter the M3 internal marks: "))
    javainternal=int(input("Enter the java internal marks: "))
    DSPDinternal=int(input("Enter the DSPD internal marks: "))
    CNinternal=int(input("Enter the CN internal marks: "))
    CAOinternal=int(input("Enter the CAO internal marks: "))
    
    # M3external=int(input("Enter the M3 external marks: "))
    # javaexternal=int(input("Enter the java external marks: "))
    # DSPDexternal=int(input("Enter the Chemistry external marks: "))
    # CNexternal=int(input("Enter the Physics external marks: "))
    # CAOexternal=int(input("Enter the CNS external marks: "))
    
    if M3>80 or java>80 or DSPD>80 or CN>80 or CAO>80:
        print("please enter a valid Marks, Your marks should be less than 80 !")
    else:
        M3,java,DSPD,CN,CAO
        per=(M3+java+DSPD+CN+CAO)/5
        print("Percentage : ", per)
        if per<=100 and per>=90:
            print("GRADE : A")
        elif per<=90 and per>=80:
            print ("GRADE : B")
        elif per<=80 and per>=60:
            print("GRADE : C")      
        else:
            print("GRADE : D")