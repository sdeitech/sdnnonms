from semester.sem1 import SemOne
from semester.sem2 import SemTwo
from semester.sem3 import SemThree
from semester.sem4 import SemFour

def studentInfo():
    StudentName=input("Enter Student Name:")
    RollNo=int(input("Enter the Roll No.:"))
    EnrollmentNo=int(input("Enter the Enrollment No.:"))
    MotherName=input("Enter Mother Name:")
    Semester=input("Enter the Semester:")
    
    if Semester=="first":
        SemOne()
    elif Semester=="second":
        SemTwo()
    elif Semester=="third":
        SemThree()
    elif Semester=="fourth":
        SemFour()
    else:
        print("Please enter a valid semester !")
        
    print("                                  RTMNU University Nagpur")
    print("                                   Student Marksheet")
    print("Student Name :", StudentName, "                                     " "Roll No.: " , RollNo)
    print("Mother Name :", MotherName,"                                       " "Enrollment No.: ",EnrollmentNo)
    print("                                   semester", Semester)
    print("-------------------------------------------------------------------------------------------------------------")
    print("Subjects" "            " "Marks obtained" "             " " percentage " "              " "grade")

studentInfo()