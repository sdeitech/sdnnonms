import express from "express";
import cors from "cors";
const app = express();

import userRouter from "./routes/users.js";

app.use(express.json());
app.use(cors({ origin: "*" }));
app.use("get-img", express.static("profiles"));

app.use("/api", userRouter);

export default app;
