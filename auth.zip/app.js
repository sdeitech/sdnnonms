import express from "express"
const app = express()
require("dotenv").config()
import cors from "cors"
import userRouter from "./routers/users"


app.use(express.json())
app.use(cors({ origin: "*" }))
app.get("/", (req, res) => {
    res.send("hello node")
})

app.use("/api", userRouter)

export default app