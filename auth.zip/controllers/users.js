import Users from "../models/users";
import jwt from "jsonwebtoken"
import bcrypt from "bcrypt"

export const registerUser = async (req, res) => {
    const { username, password } = req.body
    if (!username || !password) {
        return res.json({ msg: "All fileds are req" })
    }
    try {
        const hashedPass = await bcrypt.hash(password, 10)
        const user = new Users({
            username: username,
            password: hashedPass
        })

        await user.save()
        res.json({ msg: "user registered" })

    } catch (error) {
        res.json({ msg: error.message })
    }
}


export const userLogin = async (req, res) => {
    const { username, password } = req.body
    if (!username || !password) {
        return res.json({ msg: "Please enter your credentials" })
    }
    try {
        const user = await Users.findOne({ username: username })
        
        if (!user) {
            return res.json({ msg: "User not found" })
        }

        const isMatched = await bcrypt.compare(password, user.password)
        // console.log(isMatched)
        if (!isMatched) {
            return res.json({ msg: "Invalid credentials" })
        }

        const token = jwt.sign({ username, password }, "ThisIsJwtKey", { expiresIn: "2hr" })
        res.json({ msg: "user logged In", token: token })


    } catch (error) {
        res.json({ msg: error.message })
    }
}





export const getUsers = async (req, res) => {
    try {
        const users = await Users.find({})
        res.json(users)

    } catch (error) {
        res.json({ msg: error.message })
    }
}