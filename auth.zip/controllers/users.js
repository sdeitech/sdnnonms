import Users from "../models/users";
import { STATUS_CODE, MESSAGE } from "../config/constants.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const registerUser = async (req, res) => {
  try {
    const { email, mobile, gender, password } = req.body;
    const profile = req.file?.filename;
    if (!email || !mobile || !gender || !profile || !password) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ message: MESSAGE.ALL_FILEDS_REQ });
    }

    const pass = await bcrypt.hash(password, 10);
    const user = new Users({
      email,
      mobile,
      gender,
      profile: profile,
      password: pass,
    });

    await user.save();
    res.status(STATUS_CODE.NEW_CREATED).json({ msg: MESSAGE.USER_REGISTER });
  } catch (error) {
    res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ msg: error.message });
  }
};



export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ message: MESSAGE.ALL_FILEDS_REQ });
    }
    const existUser = await Users.findOne({ email: email });
    // console.log(existUser);

    if (!existUser) {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ msg: MESSAGE.USER_NOT_FOUND });
    }

    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "com[are");

    if (isMatch) {
      const token = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
      return res
        .status(STATUS_CODE.SUCCESS)
        .json({ msg: MESSAGE.LOGIN, token: token });
    } else {
      return res
        .status(STATUS_CODE.BAD_REQ)
        .json({ msg: MESSAGE.INVALID_CREDENTIALS });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(STATUS_CODE.INTERNAL_SERVER_ERR)
      .json({ msg: error.message });
  }
};
