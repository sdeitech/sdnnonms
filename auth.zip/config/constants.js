const MESSSAGE = {
    CREATED: "Registerd successfull",
    CREATE_FAILED: "Registration failed",
    GET_ALL: "Success",
    ALL_FILED_REQ: "All filed are required",
    ALREADY_EXISTS: "Student already exist"
}

const HTTP_CODE = {
    SUCCESS: 200,
    NEW_CREATED: 201,
    INTERNAL_SERVER_ERR: 500,
    NOT_FOUND: 404,
    FORBIDDEN: 403,
    BAD_REQ: 401
}


export { MESSSAGE, HTTP_CODE }