import express from "express";
import { addUserInList,getUserInList } from "../controllers/users";

const adduserRouter = express.Router();

adduserRouter.post("/postdata",addUserInList)
adduserRouter.get("/getdata",getUserInList)

export default adduserRouter;
