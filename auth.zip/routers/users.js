import express from "express"
import { getUsers, registerUser, userLogin } from "../controllers/users"
const userRouter = express.Router()

userRouter.post("/user", registerUser)
userRouter.get("/user", getUsers)
userRouter.post("/login", userLogin)



export default userRouter