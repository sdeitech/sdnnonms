import { Injectable } from '@nestjs/common';
import { User } from './user.entity';
import { CONSTANTS } from 'src/constants';

@Injectable()
export class UserService {
  public users: User[] = [
    {
      username: 'payal',
      password: 'pass',
      email: 'payal@gmail.com',
      age: 22,
      role: CONSTANTS.ROLES.ANDROID_DEVELOPER,
    },
    {
      username: 'palak',
      password: 'pass1',
      email: 'payal1@gmail.com',
      age: 21,
      role: CONSTANTS.ROLES.WEB_DEVELOPER,
    },
    {
      username: 'prince',
      password: 'pass2',
      email: 'payal2gmail.com',
      age: 16,
      role: CONSTANTS.ROLES.WEB_DEVELOPER,
    },
  ];

  getuserbyusername(username: string): User {
    return this.users.find((user: User) => user.username === username);
  }
}
