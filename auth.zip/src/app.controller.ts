import { Controller, Post, UseGuards, Request, Get } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth/autrh.service';
import { RolesGuards } from './users/role.guards';
import { CONSTANTS } from './constants';

@Controller('app')
export class AppController {
  constructor(private authservice: AuthService) {}

  @Post('/login')
  @UseGuards(AuthGuard('local'))
  login(@Request() req): string {
    return this.authservice.generateToken(req.user);
  }

  @Get('/android-developer')
  @UseGuards(
    AuthGuard('jwt'),
    new RolesGuards(CONSTANTS.ROLES.ANDROID_DEVELOPER),
  )
  androiddeveleoperdata(@Request() req): string {
    return 'This is Confedential data of android' + JSON.stringify(req.user);
  }

  @Get('/android-developer')
  @UseGuards(AuthGuard('jwt'), new RolesGuards(CONSTANTS.ROLES.WEB_DEVELOPER))
  webdeveleoperdata(@Request() req): string {
    return 'This is Confedential data of web' + JSON.stringify(req.user);
  }
}
