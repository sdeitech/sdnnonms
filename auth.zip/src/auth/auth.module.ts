import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { UserModule } from 'src/users/user.module';
import { localStrategy } from './local.strategy';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './autrh.service';
import { jwtStrategy } from './jwt.strategy';

@Module({
  imports: [
    PassportModule,
    UserModule,
    JwtModule.register({
      secret: 'payal',
      signOptions: { expiresIn: '60s' },
    }),
  ],
  controllers: [],
  providers: [localStrategy, jwtStrategy, AuthService],
  exports: [AuthService],
})
export class AuthModule {}
