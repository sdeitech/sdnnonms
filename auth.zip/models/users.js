import mongoose from "mongoose";
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  email: {
    type: String,
  },
  mobile: {
    type: Number,
  },
  gender: {
    type: String,
    enum: ["male", "female"],
  },
  profile: {
    type: String,
  },
  password: {
    type: String,
  },
});

const Users = mongoose.model("Users", UserSchema);
export default Users;
