import express from "express";
import { registerUser, userLogin } from "../controllers/users";
import { uploadMiddleware } from "../helpers/multer";
const userRouter = express.Router();

userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);
userRouter.post("/login", userLogin);

export default userRouter;
