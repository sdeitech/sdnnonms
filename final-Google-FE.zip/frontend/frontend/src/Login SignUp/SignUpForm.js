// import React, { useState } from "react";
// import { TextField, Button, InputAdornment } from "@mui/material";
// import { Link } from "react-router-dom";
// import AccountCircle from '@mui/icons-material/AccountCircle';
// import LockIcon from '@mui/icons-material/Lock';
// import BadgeIcon from '@mui/icons-material/Badge';
// import DateRangeIcon from '@mui/icons-material/DateRange';
// import "./loginform.css";
// import axios from 'axios';
// import { useNavigate } from "react-router-dom";
// import Box from '@mui/material/Box';
// import InputLabel from '@mui/material/InputLabel';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';

// function SignUp() {
//     const navigate = useNavigate();

//     const [state, setState] = useState({
//         firstNameError: "",
//         lastNameError: '',
//         emailError: "",
//         passwordError: "",
//         dobError: "",
//         maritalStatusError: "",
//         genderError : '',
//         photoError : ''
//     });


//     const [formData, setFormData] = useState({
//         firstName: '',
//         lastName: '',
//         email: '',
//         password: '',
//         dob: '',
//         maritalStatus : '',
//         gender : '',
//         photo : null,

//     });

//     const [error, setError] = useState(null);

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData((prevData) => ({
//             ...prevData,
//             [name]: value,
//         }));
//     };

//     const handleFileChange = (e) => {
//       const file = e.target.files[0]
//       console.log(file , "fdkgvnsdjkl");

//         setFormData((prevData) => ({
//             ...prevData,
//             photo : file
//         }));
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         const firstName = e.target.firstName.value;
//         const lastName = e.target.lastName.value;
//         const email = e.target.email.value;
//         const password = e.target.password.value;
//         const dob = e.target.dob.value;
//         const maritalStatus = e.target.maritalStatus.value;
//         const gender = e.target.gender.value;
//         const photo = e.target.photo.value;



//         setState({
//             ...state,
//             firstNameError: firstName === "" ? "Please enter your First Name" : "",
//             lastNameError: lastName === "" ? "Please enter your Last Name" : "",
//             emailError: email === "" ? "Please enter your email" : "",
//             passwordError: password === "" ? "Please enter your password" : "",
//             dobError: dob === "" ? "Please enter your DOB" : "",
//             maritalStatusError: maritalStatus === "" ? "Please enter your Maritial Status" : "",
//             genderError: gender === "" ? "Please enter your Gender" : "",
//             genderError: photo === "" ? "Please enter your Photo" : "",

//         });

//         // const formData = new FormData()
//         const data = new FormData();
//         Object.keys(formData).forEach(key => {
//           if (key === 'photo') {
//             data.append(key, formData[key]);
//           } else {
//             data.append(key, formData[key]); 
//           }
//         });
//          console.log(data , "data")
//         console.log("formdatadata);", data)
//         try {
//             const response = await axios.post('http://localhost:5000/api/register', data);
//             navigate('/');
//             console.log('SignUp successful:');
//         } catch (err) {
//             setError('Login failed. Please check your credentials.');
//         }
//     };


//     return (
//         <React.Fragment>
//             <form autoComplete="off" onSubmit={handleSubmit} className="form-container">
//                 <h1>SIGN UP</h1>

//                 <TextField
//                     id="firstName"
//                     name="firstName"
//                     label="First Name"
//                     value={formData.firstName}
//                     onChange={handleChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment position="start">
//                                 <BadgeIcon />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//                 <span className="error-message">{state.firstNameError}</span>

//                 <TextField
//                     id="lastName"
//                     name="lastName"
//                     label="Last Name"
//                     value={formData.lastName}
//                     onChange={handleChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment position="start">
//                                 <BadgeIcon />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//                 <span className="error-message">{state.lastNameError}</span>


//                 <TextField
//                     id="email"
//                     name="email"
//                     label="email"
//                     value={formData.email}
//                     onChange={handleChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment position="start">
//                                 <AccountCircle />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//                 <span className="error-message">{state.emailError}</span>

//                 <TextField
//                     id="password"
//                     name="password"
//                     label="Password"
//                     type= 'password'
//                     value={formData.password}
//                     onChange={handleChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment position="start">
//                                 <LockIcon />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//                 <span className="error-message">{state.passwordError}</span>

//                 <TextField
//                     id="dob"
//                     name="dob"
//                     type="date"
//                     label="Date Of Birth"
//                     value={formData.dob}
//                     onChange={handleChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment position="start">
//                                 <DateRangeIcon />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//                 <span className="error-message">{state.dobError}</span>


//                 <Box sx={{ minWidth: 120 }}>
//                     <FormControl fullWidth>
//                         <InputLabel id="demo-simple-select-label">Maritial Status</InputLabel>
//                         <Select
//                             id="maritalStatus"
//                             name="maritalStatus"
//                             value={formData.maritalStatus}
//                             label="Maritial Status"
//                             onChange={handleChange}
//                              defaultValue=""
//                         >
//                             <MenuItem value={'Married'}>Married</MenuItem>
//                             <MenuItem value={'UnMarried'}>UnMarried</MenuItem>
//                         </Select>
//                     </FormControl>
//                 </Box>
//                 <span className="error-message">{state.maritalStatusError}</span>

//                 <Box sx={{ minWidth: 120 }}>
//                     <FormControl fullWidth>
//                         <InputLabel id="demo-simple-select-label">Gender</InputLabel>
//                         <Select
//                             id="gender"
//                             name="gender"
//                             value={formData.gender}
//                             label="Gender"
//                             onChange={handleChange}
//                              defaultValue=""
//                         >
//                             <MenuItem value={'Male'}>Male</MenuItem>
//                             <MenuItem value={'Female'}>Female</MenuItem>
//                         </Select>
//                     </FormControl>
//                 </Box>
//                 <span className="error-message">{state.genderError}</span>

//                 <TextField
//                     id="photo"
//                     name="photo"
//                     type="file"
//                     // value={formData.photo}
//                     onChange={handleFileChange}
//                     defaultValue=""
//                     fullWidth
//                     sx={{ mb: 3 }}

//                 />
//                 <span className="error-message">{state.photoError}</span>



//                 <Button variant="outlined" color="secondary" type="submit">
//                     Register
//                 </Button>
//             </form>

//             <small>
//                 Already have Account <Link to="/">Login here</Link>
//             </small>
//         </React.Fragment>
//     );
// }

// export default SignUp;




///////////////


import React, { useState } from "react";
import { TextField, Button, InputAdornment } from "@mui/material";
import { Link } from "react-router-dom";
import AccountCircle from '@mui/icons-material/AccountCircle';
import LockIcon from '@mui/icons-material/Lock';
import BadgeIcon from '@mui/icons-material/Badge';
import DateRangeIcon from '@mui/icons-material/DateRange';
import "./loginform.css";
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import FormGroup from '@mui/material/FormGroup';
import Checkbox from '@mui/material/Checkbox';

function SignUp() {
    const navigate = useNavigate();

    const [state, setState] = useState({
        firstNameError: "",
        lastNameError: '',
        emailError: "",
        passwordError: "",
        dobError: "",
        maritalStatusError: "",
        genderError: '',
        photoError: ''
    });


    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        dob: '',
        maritalStatus: false,
        gender: '',
        photo: null,

    });

    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0]
        console.log(file, "fdkgvnsdjkl");

        setFormData((prevData) => ({
            ...prevData,
            photo: file
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const firstName = e.target.firstName.value;
        const lastName = e.target.lastName.value;
        const email = e.target.email.value;
        const password = e.target.password.value;
        const dob = e.target.dob.value;
        const maritalStatus = e.target.maritalStatus.value;
        const gender = e.target.gender.value;
        const photo = e.target.photo.value;



        setState({
            ...state,
            firstNameError: firstName === "" ? "Please enter your First Name" : "",
            lastNameError: lastName === "" ? "Please enter your Last Name" : "",
            emailError: email === "" ? "Please enter your email" : "",
            passwordError: password === "" ? "Please enter your password" : "",
            dobError: dob === "" ? "Please enter your DOB" : "",
            maritalStatusError: maritalStatus === "" ? "Please enter your Maritial Status" : "",
            genderError: gender === "" ? "Please enter your Gender" : "",
            genderError: photo === "" ? "Please enter your Photo" : "",

        });

        // const formData = new FormData()
        const data = new FormData();
        Object.keys(formData).forEach(key => {
            if (key === 'photo') {
                data.append(key, formData[key]);
            } else {
                data.append(key, formData[key]);
            }
        });
        console.log(data, "data")
        console.log("formdatadata);", data)
        try {
            const response = await axios.post('http://localhost:5000/api/register', data);
            navigate('/');
            console.log('SignUp successful:');
        } catch (err) {
            setError('Login failed. Please check your credentials.');
        }
    };


    return (
        <React.Fragment>
            <form autoComplete="off" onSubmit={handleSubmit} className="form-container">
                <h1>SIGN UP</h1>

                <TextField
                    id="firstName"
                    name="firstName"
                    label="First Name"
                    value={formData.firstName}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <BadgeIcon />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.firstNameError}</span>

                <TextField
                    id="lastName"
                    name="lastName"
                    label="Last Name"
                    value={formData.lastName}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <BadgeIcon />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.lastNameError}</span>


                <TextField
                    id="email"
                    name="email"
                    label="email"
                    value={formData.email}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <AccountCircle />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.emailError}</span>

                <TextField
                    id="password"
                    name="password"
                    label="Password"
                    type='password'
                    value={formData.password}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <LockIcon />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.passwordError}</span>

                <TextField
                    id="dob"
                    name="dob"
                    type="date"
                    label="Date Of Birth"
                    value={formData.dob}
                    onChange={handleChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <DateRangeIcon />
                            </InputAdornment>
                        ),
                    }}
                />
                <span className="error-message">{state.dobError}</span>

                <FormGroup>
                    <FormControlLabel control={<Checkbox defaultChecked />}
                     label="Married"
                     id="maritalStatus"
                     name="maritalStatus"
                     onChange={handleChange}
                     value={formData.maritalStatus}

                     />
                </FormGroup>
                 <span className="error-message">{state.maritalStatusError}</span>

                {/* <div>
                    <label>Married :</label>
                    <div>
                        <input 
                            type="checkbox"
                            name="maritalStatus"
                            onChange={handleChange}
                     value={formData.maritalStatus}

                        />
                    </div>
                </div>
                <span className="error-message">{state.maritalStatusError}</span> */}


                <FormControl>
                    <FormLabel id="gender">Gender</FormLabel>
                    <RadioGroup
                        aria-labelledby="demo-radio-buttons-group-label"
                        defaultValue="male"
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}

                    >
                        <FormControlLabel value="female" control={<Radio />} label="Female" />
                        <FormControlLabel value="male" control={<Radio />} label="Male" />
                        <FormControlLabel value="other" control={<Radio />} label="Other" />
                    </RadioGroup>
                </FormControl>
                <span className="error-message">{state.genderError}</span>


                <TextField
                    id="photo"
                    name="photo"
                    type="file"
                    // value={formData.photo}
                    onChange={handleFileChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}

                />
                <span className="error-message">{state.photoError}</span>



                <Button variant="outlined" color="secondary" type="submit">
                    Register
                </Button>
            </form>

            <small>
                Already have Account <Link to="/">Login here</Link>
            </small>
        </React.Fragment>
    );
}

export default SignUp;