import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios';


//to add user
export const addUser = createAsyncThunk(
    "addUser",
    async (UserData, { rejectWithValue }) => {
        try {
            const response = await axios.post('http://localhost:4000/logReg/register', UserData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                }
            });
            const { data } = response;
            return response;
        } catch (error) {
            return rejectWithValue("Registration Failed");
        }
    }
);
export const login = createAsyncThunk(
    "login",
    async (userdata, { rejectWithValue }) => {
        try {
            const response = await axios.post('http://localhost:4000/logReg/login', userdata);
            const { data } = response;
            return response;
        } catch (error) {
            return rejectWithValue("Login Failed");
        }
    }
);

export const createUser = createAsyncThunk(
    "createUser",
    async (data, { rejectWithValue }) => {
        try {
            const id = localStorage.getItem('userId')
            const response = await axios.post(`http://localhost:4000/users/post/${id}`, data);
            return response;
        } catch (error) {
            return rejectWithValue(error);
        }

    }
);


export const getUser = createAsyncThunk(
    "getUser",
    async (page, limit, search, { rejectWithValue }) => {
        try {
            // let id=localStorage.getItem('userId');
            // const user=localStorage.getItem("userdata");
            // const newuser=JSON.parse(user);
            // let token=localStorage.getItem('token');

            // let auth ={
            //     headers:{
            //         Authorization: `${token}`
            //     },
            // };
            console.log("getting the data")
            const response = await axios.get(`http://localhost:4000/users/paginate/?page=${page}&limit=${limit}&search=${search}`);
            console.log(response);
            return response.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);

export const userDetail = createSlice({
    name: "userDetail",
    initialState: {
        users: {},
        userToken: null,
        loading: false,
        error: null,
    },
    // reducers:{

    // },
    extraReducers: (builder) => {
        builder
            .addCase(addUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(addUser.fulfilled, (state, action) => {
                state.loading = false;
                state.users = action.payload;
            })
            .addCase(addUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            .addCase(login.pending, (state) => {
                state.loading = true;
            })
            .addCase(login.fulfilled, (state, action) => {
                state.loading = false;
                state.users = action.payload;
            })
            .addCase(login.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            .addCase(createUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(createUser.fulfilled, (state, action) => {
                state.loading = false;
                state.users = action.payload;
            })
            .addCase(createUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            .addCase(getUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(getUser.fulfilled, (state, action) => {
                state.loading = false;
                state.users = action.payload;
            })
            .addCase(getUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })


    }


});
export default userDetail.reducer;

