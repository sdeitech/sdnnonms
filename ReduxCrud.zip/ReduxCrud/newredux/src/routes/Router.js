import { createBrowserRouter } from "react-router-dom";
import PublicRoute from "./PublicRoute";


const Router=createBrowserRouter([
    ...PublicRoute,
]);
export default Router;