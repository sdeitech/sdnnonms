import {React} from 'react';
import PublicLayout from '../layouts/PublicLayout';
import Register from '../components/Register';
import Login from '../components/Login';
import AddUser from '../components/AddUser';
import GetUser from '../components/GetUser';

const PublicRoute=[
    {
        path:"/",
        exact:true,
        element:<PublicLayout><Login/></PublicLayout>
    },
    {
        path:"/Register",
        exact:true,
        element:<PublicLayout><Register/></PublicLayout>
    },
    {
        path:"/add",
        exact:true,
        element:<PublicLayout><AddUser/></PublicLayout>
    },
    {
        path:"/dashboard",
        exact:true,
        element:<PublicLayout><GetUser/></PublicLayout>
    }
];

export default PublicRoute;