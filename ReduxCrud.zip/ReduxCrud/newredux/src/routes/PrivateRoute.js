import React from "react";
import PrivateLayout from '../layouts/PrivateLayout';
import AddUser from "../components/AddUser";


const PrivateRoute = [
    // {
    //     path:"/add",
    //     exact:true,
    //     element:<PrivateLayout><AddUser/></PrivateLayout>
    // }
];

export default PrivateRoute;