import React,{useEffect, useState} from "react";
import { useDispatch,useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getUser } from "../features/userDetailSlice";
import './get.css';

const GetUser=()=>{
    const dispatch=useDispatch();
    const {users,loading}=useSelector((state)=>state.app);


    useEffect(()=>{
        dispatch(getUser())
    }, []);
    if(loading){
        return <h2>Loading</h2>
    }

    return(
        <><div>
        <h2>DashBoard</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Sr.No.</th>
                    <th>FirstName</th>
                    <th>LastName</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {users && users.map((ele) => (
                    <tr key={ele.id}>
                        <td>{ele.id + 1}</td>
                        <td>{ele.firstname}</td>
                        <td>{ele.lastname}</td>
                        <td>{ele.email}</td>
                        <td>
                            <button>View</button>
                        </td>
                    </tr>

                ))}
            </tbody>
        </table>
        {/* {view && (
            <div>
                <h3>Details:</h3>

                <div key={view._id}>
                    <p>First Name: {view.firstname}</p>
                    <p>Last Name: {view.lastname}</p>
                    <p>Email: {view.email}</p>

                </div>
            </div>
        )} */}
        {/* <button onClick={() => handleadd()}>Add User</button>
        <button onClick={() => handlelogout()}>LogOut</button> */}
        {/* <div>
            <button onClick={handlePrevPage} disabled={currentPage === 1}>Previous</button>
            <span> Page {currentPage} of {totalPages} </span>
            <button onClick={handleNextPage} disabled={currentPage === totalPages}>Next</button>
        </div> */}
    </div>
        </>

    )
}

export default GetUser;