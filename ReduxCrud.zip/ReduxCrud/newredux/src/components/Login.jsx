import React,{ useState} from 'react'
import { useDispatch} from 'react-redux'
import { useNavigate } from 'react-router-dom';
import { login } from '../features/userDetailSlice';

function Login() {

  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const getUserData = (e) => {
    setLoginData((prevData)=>({...prevData, [e.target.name]: e.target.value }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(login(loginData));
    navigate('/add');
  }

  const GotoSignUp = () => {
    navigate("/register");
  };

  return (
    <div>
      <h2>Login</h2>

      <form className="form-container" onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email:</label>
          <input
            type="text"
            name="email"
            onChange={getUserData}
            required
          /></div>

        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            onChange={getUserData}
            required
          /></div>
        <div className="form-group">
          <button type="submit" className='submit-button' >Login</button>
        </div>
        <p>Don't have account? <button type="submit" onClick={GotoSignUp}>Sign Up</button></p>

      </form>

    </div>
  )
}

export default Login;
