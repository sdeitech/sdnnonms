import React, {useState} from 'react'
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { createUser } from '../features/userDetailSlice';


function AddUser() {
    const [users, setUsers]=useState({});
    const navigate=useNavigate();
    const dispatch=useDispatch();

    const handlechange=(e)=>{
        setUsers({...users,[e.target.name]: e.target.value});
    };

    const handleSubmit=(e)=>{
        e.preventDefault();
        console.log("users//////", users);
        dispatch(createUser(users));
        
    };

  return (
    <div>
    <h2 > Add user</h2 >
    <form className="form-container" onSubmit={handleSubmit}>
    <div className="form-group">
        <label>First Name: </label>
        <input
            type="text"
            name="firstname"
            placeholder="First Name"
            onChange={handlechange}
            required
        />
    </div>
    <div className="form-group">
        <label>Last Name: </label>
        <input
            type="text"
            name="lastname"
            placeholder="Last Name"
            onChange={handlechange}
            required
        />
    </div>
    <div className="form-group">
        <label>Email: </label>
        <input
            type="email"
            name="email"
            placeholder="Email"
            onChange={handlechange}
            required
        />
    </div>
    <div className="form-group">
        <button type="submit"  onClick={()=>alert("Do you want to add user?")}>Add User</button>
        <button onClick={() => navigate('/dashboard')}>Back to DashBoard</button>          
    </div>
    </form>
    
</div>
  )
}

export default AddUser
