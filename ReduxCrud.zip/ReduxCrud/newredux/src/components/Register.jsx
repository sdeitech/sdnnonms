import React, { useState } from "react";
import { useDispatch } from "react-redux";
import {useNavigate} from 'react-router-dom';
import {addUser} from "../features/userDetailSlice";
import './register.css';

const Register =()=>{
    const [regformData, setRegFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        dateofBirth: '',
        password: '',
        gender: '',
        ismarried: false,
        image:null,

    });

    const [error, setError] = useState(null);

    const navigate=useNavigate();
    const dispatch=useDispatch();
    const getUserData=(e)=>{
        setRegFormData((prevData)=>({...prevData, [e.target.name]:e.target.value}));
    };

    const fileOnchange=(e)=>{
        const file=e.target.files[0];
        setRegFormData((prevData)=>({...prevData, image:file,}))
    };
    const handleSubmit=(e)=>{
        e.preventDefault();
        const formdata = new FormData();

        
        formdata.append('firstname', regformData.firstname);
        formdata.append('lastname', regformData.lastname);
        formdata.append('email', regformData.email);
        formdata.append('password', regformData.password);
        formdata.append('dateofBirth', regformData.dateofBirth);
        formdata.append('gender', regformData.gender);
        formdata.append('ismarried',regformData.ismarried);
        formdata.append('image', regformData.image);
        console.log("users...");
        dispatch(addUser(formdata));
        navigate("/");
    };

    return(
        <div>
            <h2>Registration</h2>

           
            <form className="form-container" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>First Name:</label>
                    <input
                        type="text"
                        name="firstname"
                        value={regformData.firstname}
                        onChange={getUserData}
                        required
                    />
                    </div>

                <div className="form-group">
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lastname"
                        value={regformData.lastname}
                        onChange={getUserData}
                        required
                    />
                    
                    </div>

                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={regformData.email}
                        onChange={getUserData}
                        required
                    />
                    
                    </div>

                <div className="form-group">
                    <label>Date of Birth:</label>
                    <input
                        type="date"
                        name="dateofBirth"
                        value={regformData.dateofBirth}
                        onChange={getUserData}
                        required
                    />
                    
                    </div>


                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={regformData.password}
                        onChange={getUserData}
                        required
                    />
                   
                    </div>
                <div className='form-group'>
                    <label>Gender:</label>
                    <div>
                        <input
                            type="radio"
                            name='gender'
                            value="male"
                            checked={regformData.gender === 'male'}
                            onChange={getUserData} />Male
                        <input
                            type='radio'
                            name='gender'
                            value="female"
                            checked={regformData.gender === 'female'}
                            onChange={getUserData} />Female
                    </div>
                   
                </div>
                <div className='form-group'>
                <label>Married</label>
                <input
                    type="checkbox"
                    name='ismarried'
                    value={regformData.ismarried}
                    onChange={getUserData}
                />
                
                </div>
                <div className='form-group'>
                <label>Select Profile Picture: </label>
                <input
                    type="file"
                    name="image"
                    onChange={fileOnchange} />
                   
                </div>

                <div className="form-group">
                    <button type="submit" className='submit-button' onClick={()=>alert('Registered Successfully!')}>Register</button>
                </div>
                <div className="form-group">
                    <button type="submit" className='submit-button' onClick={()=>navigate('/')}>Back to SignIn </button>
                </div>
            </form>
            
        </div>
    );
};

export default Register;