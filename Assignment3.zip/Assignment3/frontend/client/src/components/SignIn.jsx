import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google"
import axios from "axios"


const clientId = "501157667142-bgvcpsv87l572d8mha8s1tcdnicn63o9.apps.googleusercontent.com"

const SignIn = () => {
    console.log(clientId)

    const handleSubmit = async (response) => {
        const { credential } = response
        try {
            const res = await axios.post("http://localhost:3003/api/google", { token: credential })
            console.log(res)

        } catch (error) {
            console.log(error.message)
        }
    }

    const handleErrro = (error) => {
        console.log(error.message)

    }
    return (
        <div>
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={handleSubmit}
                    onError={handleErrro} />
            </GoogleOAuthProvider>
        </div>
    )
}

export default SignIn