import SignIn from "../components/SignIn"
import SignUp from "../components/SignUp"
import PublicLayout from "../layout/PublicLayout"

const PublicRoutes = [
    {
        path: "/",
        element: <PublicLayout> <SignUp /> </PublicLayout>
    },

    {
        path: "/login",
        element: <PublicLayout> <SignIn /> </PublicLayout>
    }
]

export default PublicRoutes