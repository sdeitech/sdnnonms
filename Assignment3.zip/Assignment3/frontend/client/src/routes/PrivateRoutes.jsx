import PrivateLayout from "../layout/PrivateLayout"

const PrivateRoutes = [
    {
        path: "/dashboard",
        element: <PrivateLayout></PrivateLayout>
    },
]

export default PrivateRoutes