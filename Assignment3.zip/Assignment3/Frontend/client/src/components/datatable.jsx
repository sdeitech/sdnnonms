import React, { useEffect, useState } from "react";
import axios from "axios";

import View from "./view";

const DataTable = () => {
    const [data, setData] = useState([]);
    const fetchData = async () => {
        try {
            const response = await axios.get(
                "http://localhost:3002/api/getdata"
            );
            console.log(response.data.users, "hhhgghhghh");

            setData(response.data.users);
            // console.log(setData);
        } catch (error) {
            console.log("error fetching data");
        }
    };


    useEffect(() => {
        fetchData();
    }, [])



    const [curruntUser, setcurruntUser] = useState(null);


    const [showview, setshowview] = useState(false)

    const Handleview = (data) => {
        setshowview(!showview)
        setcurruntUser(data)

    }
    return (
        <div>
            <table border="1">
                

                <thead>
                    <tr >
                        <th>srno</th>
                        <th>firstname</th>
                        <th>lastname</th>
                        <th>email</th>
                        <th>action</th>
                       
                    </tr>
                </thead>
                <tbody>
                    {data && data.map((item, i) => {
                        return (
                            <tr key={i}>
                                <td>{i+1}</td>
                                {/* <td>{item.srno}</td> */}
                                <td>{item.firstname}</td>
                                <td>{item.lastname}</td>
                                <td>{item.email}</td>
                                <button onClick={() => Handleview(item)} >View</button>
                            </tr>
                        )
                    }
                    )}
                </tbody>
            </table>

            {showview && <View curruntUser={curruntUser} showview={showview} setshowview={setshowview} />}
        </div>
    );
};
export default DataTable;