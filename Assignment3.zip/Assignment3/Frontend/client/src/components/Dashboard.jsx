import React  from "react";
//import DataTable from "./datatable";
//import userlist from "./const/userlist";
import { Link } from "react-router-dom"

const Dashboard = () => {



  return (
    
    <div> <h1>Welcome to  Dashboard! please click on add user button to insert the users</h1> <Link to={"/adduser"}><button >Add User</button></Link>
       
      
      {/* <button 
                type="submit"
                style={{
                  padding: '12px',
                  borderRadius: '8px',
                  backgroundColor: '#6a11cb',
                  color: 'white',
                  fontSize: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  marginBottom: '15px',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
                  transition: 'background-color 0.3s ease',
                  
                }}
                


               */} 
      
               
      
    </div>
    
  );
};

export default Dashboard;

