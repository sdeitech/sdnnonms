import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
//const apiUrl = process.env.REACT_APP_API_URL;
import validation from "./validation";
//import { useNavigate } from "react-router-dom";
const SignUp = () => {
  //const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstname:"",
    lastname:"",
    email: "",
    DOB:"",
    password:"",
    gender:"",
    profile: null,
    
  });
  
  const [error, setError] = useState({})


  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const error = validation(formData)
    setError(error)
    console.log(error)
    if(Object.keys(error).length===0){
    try {
      const res = await axios.post("http://localhost:3002/api/signup", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      console.log(res.data);
    } catch (error) {
      console.log(error.message);
    }
  }else{

  }
  };

      return (
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100vh',
            background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
          }}
        >
          <div
            style={{
              padding: '40px',
              backgroundColor: '#fff',
              borderRadius: '12px',
              width: '400px',
              boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)',
              textAlign: 'center',
            }}
          >
            <h1 style={{ fontSize: '28px', marginBottom: '20px', color: '#333' }}>
              Sign Up
            </h1>
            <form
              style={{
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
              }}
              onSubmit={handleSubmit}
              encType="multipart/form-data"
            >
              <input
                type="firstname"
                name="firstname"
                placeholder="First name"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <input
                type="lastname"
                name="lastname"
                placeholder="lastname"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <input
                type="email"
                name="email"
                placeholder="Email Address"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <input
                type="DOB"
                name="DOB"
                placeholder="Date of Birth"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '20px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <div
                style={{
                  marginBottom: '15px',
                  display: 'flex',
                  justifyContent: 'space-around',
                  fontSize: '16px',
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center' }}>
                  Male
                  <input
                    type="radio"
                    name="gender"
                    value="male"
                    checked={formData.gender === 'male'}
                    onChange={handleChnage}
                    style={{ marginLeft: '8px' }}
                  />
                </label>
                <label style={{ display: 'flex', alignItems: 'center' }}>
                  Female
                  <input
                    type="radio"
                    name="gender"
                    value="female"
                    checked={formData.gender === 'female'}
                    onChange={handleChnage}
                    style={{ marginLeft: '8px' }}
                  />
                </label>
              </div>
              <input
                type="file"
                name="profile"
                onChange={handleChnage}
                required
                style={{
                  marginBottom: '15px',
                  padding: '10px',
                  backgroundColor: '#f9f9f9',
                  borderRadius: '8px',
                  border: '1px dashed #ddd',
                  cursor: 'pointer',
                  fontSize: '14px',
                }}
              />
              
              <button
                type="submit"
                style={{
                  padding: '12px',
                  borderRadius: '8px',
                  backgroundColor: '#6a11cb',
                  color: 'white',
                  fontSize: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  marginBottom: '15px',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
                  transition: 'background-color 0.3s ease',
                }}
                onMouseOver={(e) => (e.target.style.backgroundColor = '#5e10b1')}
                onMouseOut={(e) => (e.target.style.backgroundColor = '#6a11cb')}
              >
                Sign Up
              </button>
            </form>
            <p style={{ marginTop: '15px', color: '#666' }}>
              Already have an account?{' '}
              <Link
                to="/login"
                style={{
                  color: '#2575fc',
                  textDecoration: 'none',
                  fontWeight: 'bold',
                }}
                onMouseOver={(e) => (e.target.style.textDecoration = 'underline')}
                onMouseOut={(e) => (e.target.style.textDecoration = 'none')}
              >
                Sign In
              </Link>
            </p>
          </div>
        </div>
      );
    };
    

export default SignUp;