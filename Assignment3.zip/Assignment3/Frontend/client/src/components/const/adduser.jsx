import React, { useState } from "react";
import axios from 'axios'


function AddUser() {
  const [user, setUser] = useState({
  firstname :"",
  lastname :"",
  email :"",
  gender:"",
  phone:""
});
const handleInputChange = (e) => {
  const {name,value} =e.target;
  setUser({...user,[name]:value});
};

const handleSubmit = async (e) => {
  e.preventDefault();
  

  try{
    const response = await axios.post("http://localhost:3002/api/postdata",user);
  
  console.log("user data submitted :", response.user);
  }catch(err){
    console.error("Error in submitting form:",err.message);
    
  }
  setUser({
    firstname :"",
  lastname :"",
  email :"",
  gender:"",
  phone:""
  });
};

  // function add() {
  //   // HERE is the change, you need to keep the previous values 
  //   setAddNew([...addNew, <NewUser />]);
  // }

  return (
    
    <div style={{border:"2px solid", alignContent:"center"}}>
      <h2>Add User</h2>
      <form onSubmit={handleSubmit}>
      <div>
        <label>firstname:</label>
        <input type="text"
        name="firstname"
        value={user.firstname}
        onChange={handleInputChange}required
        />
      </div>
      <div>
        <label>lastname:</label>
        <input type="text"
        name="lastname"
        value={user.lastname}
        onChange={handleInputChange}required
        />
      </div>
      <div>
        <label>email:</label>
        <input type="email"
        name="email"
        value={user.email}
        onChange={handleInputChange}required
        />
      </div>
      <div>
      <label>gender:</label>
      <select name="gender"
        value={user.gender}
        onChange={handleInputChange}required >
          <option value="">select gender</option>
          <option value="male">male</option>
          <option value="female">female</option>
          <option value="female">female</option>
        </select>
      <div>
        <label>phone:</label>
        <input type="Number"
        name="phone"
        value={user.phone}
        onChange={handleInputChange}required
        />
      </div>
      <button type="submit">Add User</button>
    </div>
    </form>
    </div>
  );
}

export default AddUser;

