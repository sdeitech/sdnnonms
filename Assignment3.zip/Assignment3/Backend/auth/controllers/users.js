import Users from "../models/users";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import Userlist from "../models/usermodelforuserlist"

//registraion 
export const registerUser = async (req, res) => {
  try {
    const { firstname, lastname,email, DOB,password,gender } = req.body;
    const profile = req.file?.filename;
    if (!firstname || !lastname || !email || !DOB || !gender || !profile || !password) {
      return res
        .status(400)
        .json({message:"all fields are required"})
        // .json({ message: MESSAGE.ALL_FILEDS_REQ });

    }

    //password bcrypting
    const pass = await bcrypt.hash(password, 10);
    const user = new Users({
      firstname,
      lastname,
      email,
      DOB,
      gender,
      profile: profile,
      password: pass,
    });

    await user.save();
    res.status(201).json({ msg: "user registered successfully" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};


//login
export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "All fields are required"});
    }
    const existUser = await Users.findOne({ email: email });
    // console.log(existUser);

    if (!existUser) {
      return res
        .status(400)
        .json({ msg: "user not found" });
    }

    //checking password entered by user and database user passsword
    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "Thankyou");

    //generating token for user
    if (isMatch) {
      const token = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
      return res
        .status(200)
        .json({ msg: "user logged in successfully", token: token });
    } else {
      return res
        .status(400)
        .json({ msg: "invalid credentials" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ msg: error.message });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const users = await Users.find();
    res.json({ users: users, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.addUserInList = async (req, res) => {
  try {
    const newUser = new Users(req.body);
    await newUser.save();
    return res.status(201).json({newUser});
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
