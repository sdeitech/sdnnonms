import Userlist from "../models/usermodelforuserlist"


exports.addUserInList = async (req, res) => {
    try {
      const newUser = new Userlist(req.body);
      await newUser.save();
      return res.status(201).json({newUser});
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  };