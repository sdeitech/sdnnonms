import express from "express";
import { registerUser, userLogin,getUsers} from "../controllers/users";
 import {addUserInList} from "../controllers/usercontrollerforlist";
import { uploadMiddleware } from "../helpers/multer";
const userRouter = express.Router();

//signup api call
userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);

//login api call
userRouter.post("/login", userLogin);

userRouter.get("/getdata",getUsers)

userRouter.post("/postdata",addUserInList)

export default userRouter;
