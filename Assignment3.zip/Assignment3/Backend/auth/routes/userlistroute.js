import express from "express";
import addUserInList  from "../controllers/usercontrollerforlist"
const Router = express.Router();

Router.post("postdata",addUserInList)

export default Router;