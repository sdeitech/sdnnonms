import mongoose from "mongoose";
const Schema = mongoose.Schema;
 
//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },
  gender: {
    type: String,
  },
  phone: {
    type: Number,
  },
})

const Userlist = mongoose.model("Userlist", UserSchema);
export default Userlist;