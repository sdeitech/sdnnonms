import mongoose from "mongoose";
const Schema = mongoose.Schema;
 
//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },
  DOB: {
    type: String,
  },
  password: {
    type: String,
  },
  gender: {
    type: String,
    enum: ["male", "female"],
  },
  profile:{
    type:String,
  }
});

const Users = mongoose.model("Users", UserSchema);
export default Users;