import { OAuth2Client } from 'google-auth-library';
import jwt from 'jsonwebtoken';
// import { GOOGLE_CLIENT_ID } from '../config/config.js';
const client_id = "501157667142-bgvcpsv87l572d8mha8s1tcdnicn63o9.apps.googleusercontent.com"
const client = new OAuth2Client(client_id);
import Users from "../models/users"

export const googleLogin = async (req, res) => {


  try {
    const { token } = req.body;
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience:client_id,
    });

    const payload = ticket?.payload;
    const { sub, email, name, picture } = payload;

    // Create JWT token
//     const jwtToken = jwt.sign(
//       { userId: sub, email, name, picture },
//       process.env.JWT_SECRET,
//       { expiresIn: '1h' }
//     );

//     res.json({ token: jwtToken });
//   } catch (error) {
//     res.status(400).json({ error: 'Google login failed' });
//   }
// const email = payload?.email
const pass = payload?.sub
console.log(email, pass)
// console.log(ticket)

const user = new Users({
    username: email,
    password: pass
})

const data = await user.save()
console.log(data)

} catch (error) {
console.log(error.message)
}
};
