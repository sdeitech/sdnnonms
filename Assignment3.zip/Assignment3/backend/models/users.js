import { type } from "express/lib/response";
import mongoose from "mongoose";
const Schema = mongoose.Schema

const userSchema = new Schema({
    username: { type: String },
    password: { type: String }
})

const Users = mongoose.model("users", userSchema)
export default Users