// export const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const config = {
    local: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserAuth",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3003
    },
    stage: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserManagement",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3003
    },
    prod: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserManagement",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3003
    }
}

export default config