import mongoose from "mongoose";
const config = require("../config/config.js")
const configuration = config.default[process.env.NODE_ENV]
const DB = configuration.DB
const MONGO_URL = `mongodb://localhost:${DB.DB_PORT}/${DB.DB_NAME}`

const connectToDb = async () => {
    try {
        const db = await mongoose.connect(MONGO_URL)
        console.log(`DB is connected`)

    } catch (error) {
        console.log(`error while connecting to db`)
    }
}

module.exports = connectToDb