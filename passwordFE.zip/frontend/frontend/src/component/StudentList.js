import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Pagination,
  Box,
  TextField,
  Button
} from "@mui/material";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

function StudentList() {

  const navigate = useNavigate()

  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [pagination, setPagination] = useState({
    total_record: 0,
    per_page: 8,
    current_page: 1,
    total_pages: 1,
  });
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");


  const fetchstudentData = async (page = 1) => {
    let token = localStorage.getItem('token')
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:5000/apis/get-student?page=${page}&searchText=${searchText}`, {
        headers: {
          Authorization: `${token}`,
          'Content-Type': 'application/json'
        }
      }
      );
      console.log(response.data);
      setData(response.data.students);
      setPagination({
        total_record: response.data.pagination.total_record,
        per_page: response.data.pagination.per_page,
        current_page: response.data.pagination.current_page,
        total_pages: response.data.pagination.total_pages,
      });
      setError(null);
    } catch (error) {
      setData([]);
      setError("Failed to fetch data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchstudentData(pagination.current_page);
  }, [pagination.current_page, searchText]);

  const handlePageChange = (event, value) => {
    setPagination((prevPagination) => ({
      ...prevPagination,
      current_page: value,
    }));
  };

  const handleSearch = () => {
    fetchstudentData(1);
  };

  const handleLogout = () => {
    localStorage.removeItem('token')
    navigate('/')
  };

  const user = localStorage.getItem('userId')

  console.log('user-----', user)

  const [profile, setProfile] = useState([])

  console.log('data------', profile)


  const fetchUserById = async (user) => {
      try {
          const response = await axios.get(`http://localhost:5000/api/${user}`)
          console.log(response.data)
          setProfile(response.data)
      } catch (error) {
        setProfile([])
      }
  }

  useEffect(() => {
      fetchUserById(user)
  }, [user])


  return (
    <>
      <h3>Welcome {profile.firstName}</h3>

      <Link to={'/userProfile'}>
        <Button
          variant="contained"
          color="primary"
          sx={{ ml: 2 }}
        >
          My Profile
        </Button>
      </Link>

      <Button
        variant="contained"
        color="primary"
        onClick={handleLogout}
        sx={{ ml: 2 }}
      >
        Logout
      </Button>

      <div>
        <h2>Dashboard</h2>
      </div>

      <Box sx={{ mt: 4 }}>
        <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
          <TextField
            label="Search Students"
            variant="outlined"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleSearch}
            sx={{ ml: 2 }}
          >
            Search
          </Button>
        </Box>

        <Link to={'/add-student'}>
          <Button
            variant="contained"
            color="primary"
            sx={{ ml: 2 }}
          >
            Add Student
          </Button>
        </Link>

        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p>{error}</p>
        ) : (
          <>
            <TableContainer component={Paper}>
              <Table aria-label="student table">
                <TableHead>
                  <TableRow>
                    <TableCell><strong>First Name</strong></TableCell>
                    <TableCell><strong>Last Name</strong></TableCell>
                    <TableCell><strong>Email</strong></TableCell>
                    <TableCell><strong>Action</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data.map((student) => (
                    <TableRow key={student._id}>
                      <TableCell>{student.firstName}</TableCell>
                      <TableCell>{student.lastName}</TableCell>
                      <TableCell>{student.email}</TableCell>
                      <TableCell>
                        <Link to={`/details/${student._id}`}>
                          <Button
                            variant="contained"
                            color="primary"
                            sx={{ ml: 2 }}
                          >
                            View
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
              <Pagination
                count={pagination.total_pages}
                page={pagination.current_page}
                onChange={handlePageChange}
                color="primary"
              />
            </Box>
          </>
        )}
      </Box>
    </>
  );
}

export default StudentList;





