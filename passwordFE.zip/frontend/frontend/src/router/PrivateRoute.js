import {React} from "react";
import PrivateLayout from "../layout/PrivateLayout";
import StudentList from "../component/StudentList";
import AddStudent from "../component/AddStudent";
import StudentDetails from "../component/StudentDetail";
import UserProfile from "../component/UserProfile";

const privateRoutes = [
	{
		path: "/students",
		exact: true,
		element: <PrivateLayout><StudentList/></PrivateLayout>
	},
	{
		path: "/add-student",
		exact: true,
		element: <PrivateLayout><AddStudent/></PrivateLayout>
	},
	{
		path: "/details/:id",
		exact: true,
		element: <PrivateLayout><StudentDetails/></PrivateLayout>
	},
	{
    	path: "/userProfile",
    	exact: true,
    	element: <PrivateLayout><UserProfile/></PrivateLayout>
    },
];
export default privateRoutes;
