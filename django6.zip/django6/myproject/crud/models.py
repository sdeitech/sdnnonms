from django.db import models

# Create your models here.

class Student(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    age = models.IntegerField()
    email = models.CharField(max_length=50)
    dob = models.DateField(null=True, blank=True)
    isPassed = models.BooleanField()