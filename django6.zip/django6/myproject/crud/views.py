from django.shortcuts import render, redirect
from .models import Student

# Create your views here.

# def index(request):

#     return render(request, 'index.html')

def index(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        age = request.POST.get('age')
        dob = request.POST.get('dob')
        isPassed = request.POST.get('isPassed')
        if isPassed:
            newobj = Student (
            fname = fname,
            lname = lname,
            email = email,
            age = age,
            dob = dob,
            isPassed= True
            )
            newobj.save()
        else:
            Student.objects.create (
            fname = fname,
            lname = lname,
            email = email,
            age = age,
            dob = dob,
            isPassed= False
            )
        return redirect('/')
    else:
        obj = Student.objects.all()
        context = {'obj' : obj}
        return render(request, 'index.html', context)


# def about(request):
#     if request.method == 'GET' :
#         return render(request, 'aboutus.html')
#     else:
#         num1 = int(request.POST.get('num1'))
#         num2 = int(request.POST.get('num2'))
#         ans = num1 +num2
#         context = {'ans': ans}
#         return render(request, 'aboutus.html',context)
    
# def form(request):
#     if request.method == 'GET' :
#         return render(request, 'form.html')
#     else:
#         fname = (request.POST.get('fname'))
#         lname = (request.POST.get('lname'))
#         age = (request.POST.get('age'))
#         email = (request.POST.get('email'))
#         context ={
#             'fname': fname,
#             'lname': lname,
#             'age':age,
#             'email':email
#         }
#         return render(request, 'form.html', context)

