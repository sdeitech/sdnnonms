from django.shortcuts import render, redirect
from .models import Student
from django.views import View

# Create your views here.


def index(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        age = request.POST.get('age')
        dob = request.POST.get('dob')
        isPassed = request.POST.get('isPassed')
        if isPassed:
            newobj = Student (
            fname = fname,
            lname = lname,
            email = email,
            age = age,
            dob = dob,
            isPassed= True
            )
            newobj.save()
        else:
            Student.objects.create (
            fname = fname,
            lname = lname,
            email = email,
            age = age,
            dob = dob,
            isPassed= False
            )
        return redirect('/')
    else:
        obj = Student.objects.all()
        context = {'obj' : obj}
        return render(request, 'index.html', context)


def delete_student(request, id):
    stu_obj =Student.objects.get(id=id)
    stu_obj.delete()
    return redirect('/')

def update_student(request, id):
    if request.method == 'GET':
        stu_obj = Student.objects.get(id=id)
        context = {'stu_obj': stu_obj}
        return render(request, 'update.html', context)
    else:
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        age = request.POST.get('age')
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        isPassed = request.POST.get('isPassed')

        stu_obj = Student.objects.get(id=id)

        if fname:
            stu_obj.fname  = fname
        
        if lname:
            stu_obj.lname  = lname

        if age:
            stu_obj.age  = age

        if dob:
            stu_obj.dob  = dob

        if email:
            stu_obj.email  = email

        if isPassed == 'on':
            stu_obj.isPassed  = True
        else:
            stu_obj.isPassed = False
        
        stu_obj.save()
        return redirect('/')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
    
        

        





