Use Classicmodels;

select * from customers;
select * from employees;
select * from offices;
select * from orderdetails;
select * from orders;
select * from payments;
select * from productlines;
select * from products;

/***************   Group By ********************

1] The GROUP BY clause groups rows into summary rows based on column values or expressions. 
   It returns one row for each group and reduces the number of rows in the result set.

2] The GROUP BY clause is an optional part of the SELECT statement. 

   --------------------------------------------------------
   SELECT c1, 
          c2,..., 
          cn, 
          aggregate_function(ci)
   FROM   table_name
   WHERE  conditions
   GROUP BY c1 , c2,...,cn;
   --------------------------------------------------------


3]  you place the GROUP BY clause after the FROM and WHERE clauses. 
    Following the the GROUP BY keywords, you list the columns or expressions you want to group, separated by commas.
    
4]  MySQL evaluates the GROUP BY clause after the FROM and WHERE clauses but
    before the HAVING, SELECT, DISTINCT, ORDER BY and LIMIT clauses:    
    
5]  In practice, you often use the GROUP BY clause with aggregate functions such as
    SUM, AVG, MAX, MIN, and COUNT. 
    The aggregate function that appears in the SELECT clause provides the information for each group. 
    
 */
 
SELECT status 
FROM    orders 
GROUP BY status;

-- The output shows that the GROUP BY clause returns unique occurrences of the values in the status columns.

SELECT DISTINCT status 
FROM   orders;

--  Using MySQL GROUP BY with aggregate functions

SELECT status, 
       COUNT(*) as StatusCount
FROM   orders 
GROUP BY status;


SELECT status, 
       SUM(quantityOrdered * priceEach) AS amount 
FROM   orders 
	   INNER JOIN orderdetails USING (orderNumber) 
GROUP BY status;


SELECT orderNumber, 
       SUM(quantityOrdered * priceEach) AS total 
FROM   orderdetails 
GROUP BY orderNumber;


-- MySQL GROUP BY with expression example In addition to columns, you can group rows by expressions. 
-- The following query calculates the total sales for each year:

SELECT  YEAR(orderDate) AS year, 
        SUM(quantityOrdered * priceEach) AS total 
FROM    orders 
        INNER JOIN orderdetails USING (orderNumber) 
WHERE   status = 'Shipped' 
GROUP BY YEAR(orderDate);


/******************** Having Clause ***************/

-- To filter the groups returned by GROUP BY clause, you use a  HAVING clause.

SELECT  YEAR(orderDate) AS year, 
        SUM(quantityOrdered * priceEach) AS total 
FROM    orders 
        INNER JOIN orderdetails USING (orderNumber) 
WHERE   status = 'Shipped' 
GROUP BY year 
HAVING year > 2003;


-- Grouping by multiple columns
-- The following query returns the year, order status, and the total order for 
-- each combination of year and order status by grouping rows into groups:

SELECT YEAR(orderDate) AS year, 
       status, 
       SUM(quantityOrdered * priceEach) AS total 
FROM   orders 
	   INNER JOIN orderdetails USING (orderNumber) 
GROUP BY year, status 
ORDER BY year;


-- The following query is not valid in SQL standard:

SELECT YEAR(orderDate) AS year, 
	   COUNT(orderNumber) 
FROM   orders 
GROUP BY year;


-- The GROUP BY clause vs. DISTINCT clause
-- If you use the GROUP BY clause in the SELECT statement without using aggregate functions, 
-- the GROUP BY clause behaves like the DISTINCT clause.
-- The following statement uses the GROUP BY clause to select the unique states of customers from the customers table.


SELECT state 
FROM   customers 
GROUP BY state;

-- You can achieve a similar result by using the DISTINCT clause:

SELECT DISTINCT state 
FROM   customers;


