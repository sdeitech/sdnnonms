/*   1. Customer Table (Demonstrates Primary Key, Auto Increment, Not Null, Null, Default)  */

CREATE TABLE Customer (
    CustomerId INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    PhoneNumber VARCHAR(15) DEFAULT 'N/A',
    Gender VARCHAR(10),
    Age INT CHECK (Age >= 18),  
    CreatedDate DATE NULL 
);

-- Insert sample data
INSERT INTO Customer (FirstName, LastName, Email, Gender, Age)
VALUES
('Ramesh', 'Singh', 'john.doe@example.com', 'Male', 32),
('Sam', 'Smith', 'jane.smith@example.com', 'Female', 28),
('Kim', 'Kum', 'Kum.smith@example.com', 'Female', 28),
('Zam', 'Zum', 'Zum.smith@example.com', 'Female', 28),
('Suresh', 'Varma', 'Varma.smith@example.com', 'Female', 23),
('Mark', 'Liam', 'Liam.smith@example.com', 'Female', 21),
('Susan', 'Lee', 'Lee.smith@example.com', 'Female', 22),
('Kripan', 'Wagh', 'Wagh.smith@example.com', 'Female', 24),
('Lili', 'james', 'james.smith@example.com', 'Female', 25);

select * from Customer;

/*  CustomerAddress Table (One-to-One Relationship with Customer, Nullable, Foreign Key)  */

CREATE TABLE CustomerAddress (
    AddressId INT PRIMARY KEY AUTO_INCREMENT,
    CustomerId INT NOT NULL,
    AddressLine1 VARCHAR(100) NOT NULL,
    AddressLine2 VARCHAR(100),
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    PostalCode VARCHAR(10),
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId) 
);

-- Insert sample data
INSERT INTO CustomerAddress (CustomerId, AddressLine1, City, State, PostalCode)
VALUES
(1, '123 Main St', 'New York', 'NY', '10001'),
(2, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(9, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(8, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(5, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(4, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(3, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(7, '456 Elm St', 'Los Angeles', 'CA', '90001');

select * from CustomerAddress ;

/* Product Table (Demonstrates Primary Key, Not Null, Check Constraint) */

CREATE TABLE Product (
    ProductId INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL CHECK (Price > 0), -- Price must be positive
    Stock INT DEFAULT 0 
);


-- Insert sample data
INSERT INTO Product (ProductName, Price, Stock)
VALUES
('Laptop', 1200.00, 50),
('Smartphone', 800.00, 30),
('Telephone', 1200.00, 50),
('Watch', 800.00, 30),
('Mouse', 1000.00, 50),
('Monitor', 1400.00, 30),
('Bycycle', 6968.00, 50),
('TV', 3256.00, 30),
('AeroPlane', 858585.00, 50),
('Jet', 6598745.00, 30);

select * from Product ;

/*  Order Table (One-to-Many Relationship with Customer) */

CREATE TABLE Orders(
    OrderId INT PRIMARY KEY AUTO_INCREMENT,
    CustomerId INT NOT NULL,
    OrderDate DATE NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL CHECK (TotalAmount > 0),
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO Orders (CustomerId, OrderDate, TotalAmount)
VALUES
(1, '2024-01-15', 1500.00),
(2, '2024-01-16', 800.00),
(1, '2024-01-20', 250.00),
(3, '2024-01-18', 600.00),
(2, '2024-01-19', 450.00),
(5, '2024-02-20', 250.00),
(6, '2024-03-18', 600.00),
(7, '2024-04-19', 450.00),
(8, '2024-04-4', 250.00),
(7, '2024-03-18', 600.00),
(5, '2024-06-19', 450.00),
(5, '2024-08-8', 250.00),
(9, '2024-05-3', 600.00),
(9, '2024-01-31', 450.00);


select * from Orders;

/*  OrderProduct Table (Many-to-Many Relationship between Order and Product)  */

CREATE TABLE OrderProduct (
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 1 CHECK (Quantity > 0),
    PRIMARY KEY (OrderId, ProductId),
    FOREIGN KEY (OrderId) REFERENCES Orders(OrderId) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Product(ProductId) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO OrderProduct (OrderId, ProductId, Quantity)
VALUES
(1, 1, 2), -- Order 1 has 2 units of Product 1 (Laptop)
(1, 2, 1), -- Order 1 has 1 unit of Product 2 (Smartphone)
(1, 3, 1),
(2, 5, 3),
(2, 6, 4),
(7, 9, 2),
(7, 10, 2),
(8, 2, 1),
(9, 2, 1); 


select * from orders;
select * from Product limit 3;

select * from OrderProduct limit 5;


/************************************************************************************************************/

select * from  customers;
select * from  customeraddress;
select * from  orders;
select * from  product;
select * from  orderproduct;


select *
from   Customer Cu
	   join orders Ord on Cu.customerID = Ord.CutomerId 
	   
	



/******** bascis Commands ***********/

-- Rename table 


RENAME TABLE customers
TO customer;


-- Add columns

ALTER TABLE table_name
ADD COLUMN new_column_name data_type 
[FIRST | AFTER existing_column];


CREATE TABLE vendors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255)
);

-- Adding one column example
ALTER TABLE vendors
ADD COLUMN phone VARCHAR(15) AFTER name;

--  Adding a column as the last column
ALTER TABLE vendors
ADD COLUMN vendor_group INT NOT NULL;


-- Adding two columns example
ALTER TABLE vendors
ADD COLUMN email VARCHAR(100) NOT NULL,
ADD COLUMN hourly_rate decimal(10,2) NOT NULL;

-- DROP COLUMN 

ALTER TABLE table_name
DROP COLUMN column_name;


ALTER TABLE table_name
DROP COLUMN column_name_1,
DROP COLUMN column_name_2
;

CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    excerpt VARCHAR(400),
    content TEXT,
    created_at DATETIME,
    updated_at DATETIME
);


ALTER TABLE posts
DROP COLUMN excerpt;

ALTER TABLE posts
DROP COLUMN created_at,
DROP COLUMN updated_at;

DESCRIBE posts;






