import jwt from 'jsonwebtoken';

import User from '../../models/user.js';
import loginValidate from '../validate/loginValidate.js'


export const loginUser = async (req, res) => {
    try {
        const { email_id, password } = req.body;

        const { error } = loginValidate.validate(req.body);
        if (error) return res.status(bad_request).send({ error: getValidationErrMsg(error) });

        const user = await User.findOne({ email_id });
        if (!user) return res.status(bad_request).send({ error: { email_id: "email_id doesn't exist." } });

        // const isMatch = await bcrypt.compare(password, user.password);
        const isMatch = password;
        if (!isMatch) return res.status(bad_request).send({ error: { password: "Incorrect Password." } });

        const token = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '6h' });

        user.tokens = [{ token }];

        await user.save();

        res.status(ok).json({ message: "Login Successfully", user, token });
    } catch (error) {
        console.error(error);
        res.status(server_error).json({ error: 'Internal Server Error' });
    }
};

