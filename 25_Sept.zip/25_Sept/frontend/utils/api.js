import axios from 'axios';

const SERVER_BASE_URL = `http://44.211.113.36:9273/`;
// const SERVER_BASE_URL = `http://localhost:4000/`;

const GuestApi = axios.create({
    baseURL: SERVER_BASE_URL
});

let accessToken = null;
if(localStorage.getItem('user_data') != null){
    const userLocalStorage = JSON.parse(localStorage.getItem('user_data'));
    const { access_token } = userLocalStorage.token;
    accessToken = access_token;
}

const AuthApi = axios.create({
    baseURL: SERVER_BASE_URL,
    headers: {
        Authorization: `bearer ${accessToken}`
    },
});

AuthApi.interceptors.response.use(response => response, error => {
    const status = error.response ? error.response.status : null
    if (status === 401) {
        console.log(status);
    }

    return Promise.reject(error);
});

export { GuestApi, AuthApi, SERVER_BASE_URL, CLIENT_ID };
