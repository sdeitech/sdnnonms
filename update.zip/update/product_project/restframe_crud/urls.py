from django.urls import path

from product_project import settings
from .views import *
from django.conf.urls.static import static
urlpatterns = [
    path('products/', ProductListCreate.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductRetrieveUpdateDelete.as_view(), name='product-retrieve-update-delete'),
    path('register/', RegisterUserView.as_view(), name='register'),
    path('login/', CustomLoginView.as_view(), name='custom-login'),
    
    path('validate-coupon/', ValidateCouponView.as_view(), name='validate-coupon'),
    path('create-order/', CreateOrderView.as_view(), name='create-order'),
    path('create-order/get-address/', CreateOrderView.as_view(), name='get_address'),
    path('create-order/previous/', PreviousOrdersView.as_view(), name='previous_order'),
          
    # New endpoint to update the shipping address
    path('create-order/update-address/', CreateOrderView.as_view(), name='update_address'),
    
    path('cart/', CartView.as_view(), name='get-cart'),  # Get the user's cart
    path('cart/add/', CartView.as_view(), name='add-to-cart'),  # Add product to cart
    path('cart/update/', UpdateCartItemView.as_view(), name='update-cart-item'),  # Update product quantity
    path('cart/remove/', RemoveFromCartView.as_view(), name='remove-from-cart'),  # Remove product from cart
    path('cart/clear/', CartView.as_view(), name='clear-cart'),
    
    path("create-payment/", CreatePaymentView.as_view(), name="stripe_payment"),
    path("webhook/", stripe_webhook, name="stripe_webhook"),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
    
