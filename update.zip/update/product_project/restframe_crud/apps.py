from django.apps import AppConfig


class RestframeCrudConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'restframe_crud'
