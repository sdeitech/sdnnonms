from django.views import View
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import NotFound

from product_project import settings
from .models import Product
from .serializers import ProductSerializer,CustomUserSerializer
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny




class ProductListCreate(APIView):
    def get(self, request):
        # List all products
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)
    authentication_classes = []  # Disable authentication
    permission_classes = [AllowAny]
    def post(self, request):
        # Create a new product
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProductRetrieveUpdateDelete(APIView):
    def get(self, request, pk):
        # Retrieve a single product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product)
        return Response(serializer.data)

    def put(self, request, pk):
        # Update a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        # Delete a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        product.delete()
        return Response({"detail": "Product deleted successfully."}, status=status.HTTP_204_NO_CONTENT)

class RegisterUserView(APIView):
    authentication_classes = []  # Disable authentication
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({"message": "User registered successfully!"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class CustomLoginView(APIView):
    authentication_classes = []  # Disable authentication
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({"error": "Email and password are required."}, status=status.HTTP_400_BAD_REQUEST)

        # Authenticate user with email and password
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # Generate token for the user
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                "message": "Login successful.",
                "token": token.key  # Return the authentication token
            }, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)




# views.py
from rest_framework import status
from .models import Coupon
from .serializers import CouponSerializer
from django.utils.timezone import now
from datetime import timedelta

class ValidateCouponView(APIView):
    def post(self, request):
        # Add static coupons if they don't exist
        self.add_static_coupons()

        # Get the coupon code from the request
        code = request.data.get('code')

        try:
            # Check if the coupon exists in the database
            coupon = Coupon.objects.get(code=code)
            
            # Check if the coupon is valid
            if coupon.is_valid():
                return Response({
                    'valid': True,
                    'discount_percentage': coupon.discount_percentage
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'valid': False,
                    'message': 'Coupon has expired'
                }, status=status.HTTP_400_BAD_REQUEST)
        except Coupon.DoesNotExist:
            return Response({
                'valid': False,
                'message': 'Invalid coupon code'
            }, status=status.HTTP_400_BAD_REQUEST)

    def add_static_coupons(self):
        """Add static coupons if they don't already exist"""
        if not Coupon.objects.filter(code='WELCOME').exists():
            Coupon.objects.create(
                code='WELCOME',
                discount_percentage=10,
                valid_until=now() + timedelta(days=365)  # Valid for 1 year
            )
        
        if not Coupon.objects.filter(code='FIRSTORDER').exists():
            Coupon.objects.create(
                code='FIRSTORDER',
                discount_percentage=15,
                valid_until=now() + timedelta(minutes=2)  # Valid for 1 year
            )
           
            
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import Order
from django.utils import timezone
from django.core.mail import send_mail
class CreateOrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Place a new order. If no shipping address is provided, use the user's registered address.
        Handle online payment options dynamically.
        """
        user = request.user
        shipping_address = request.data.get('shipping_address')
        payment_method = request.data.get('payment_method')
        total_amount = request.data.get('total_amount')
        payment_gateway = request.data.get('payment_gateway')  # Added for payment gateway

        # Default to the user's registered address if no shipping address is provided
        if not shipping_address:
            shipping_address = user.address  # Use the registered address
            if not shipping_address:
                return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        if not payment_method or not total_amount:
            return Response({"error": "All fields are required"}, status=status.HTTP_400_BAD_REQUEST)

        # Validate payment gateway for online payment
        if payment_method == "online":
            if payment_gateway not in ["gpay", "phonepe", "paytm"]:
                return Response(
                    {"error": "Invalid payment gateway. Choose from gpay, phonepe, or paytm."},
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Simulate payment processing (this is where integration with actual payment gateways would happen)
        payment_status = "success"  # In a real-world scenario, check payment gateway response.

        if payment_status != "success":
            return Response({"error": "Payment failed. Please try again."}, status=status.HTTP_400_BAD_REQUEST)

        # Calculate expected delivery date (1 week from now)
        expected_delivery_date = timezone.now() + timedelta(weeks=1)

        # Create a new order
        order = Order.objects.create(
            user=user,
            shipping_address=shipping_address,
            payment_method=payment_method,
            total_amount=total_amount,
            payment_gateway=payment_gateway if payment_method == "online" else None,
            expected_delivery_date=expected_delivery_date
        )

        # Send email notification
        send_mail(
            'Order Confirmation',
            f'Your order has been placed successfully!\n\nOrder ID: {order.id}\nTotal Amount: {total_amount}\nExpected Delivery Date: {expected_delivery_date.strftime("%Y-%m-%d")}',
            settings.DEFAULT_FROM_EMAIL,  # Replace with your email
            [user.email],
            fail_silently=False,
        )

        return Response(
            {
                "message": "Order placed successfully",
                "order_id": order.id,
                "shipping_address": shipping_address,
                "payment_gateway": payment_gateway if payment_method == "online" else None,
                "expected_delivery_date": expected_delivery_date.strftime("%Y-%m-%d")
            },
            status=status.HTTP_201_CREATED
        )

    def get(self, request):
        """
        Fetch the user's default shipping address (registered address).
        """
        user = request.user
        shipping_address = user.address  # Fetch the registered address

        if not shipping_address:
            return Response({"message": "No address found. Please provide one."}, status=status.HTTP_404_NOT_FOUND)

        return Response({"shipping_address": shipping_address}, status=status.HTTP_200_OK)

    def patch(self, request):
        """
        Update the user's shipping address.
        """
        user = request.user
        new_shipping_address = request.data.get('shipping_address')

        if not new_shipping_address:
            return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Update the user's registered address
        user.address = new_shipping_address
        user.save()

        return Response(
            {"message": "Address updated successfully", "new_shipping_address": new_shipping_address},
            status=status.HTTP_200_OK
        )


class PreviousOrdersView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """
        Fetch the user's previous orders.
        """
        user = request.user
        orders = Order.objects.filter(user=user).order_by('-created_at')  # Fetch orders for the user, ordered by date

        if not orders:
            return Response({"message": "No previous orders found."}, status=status.HTTP_404_NOT_FOUND)

        order_list = []
        for order in orders:
            order_list.append({
                "order_id": order.id,
                "shipping_address": order.shipping_address,
                "total_amount": order.total_amount,
                "payment_method": order.payment_method,
                "payment_gateway": order.payment_gateway,
                "expected_delivery_date": order.expected_delivery_date.strftime("%Y-%m-%d"),
                "created_at": order.created_at.strftime("%Y-%m-%d %H:%M:%S")
            })

        return Response({"orders": order_list}, status=status.HTTP_200_OK)

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Cart, CartItem, Product
from .serializers import CartSerializer, CartItemSerializer        
from rest_framework.authentication import TokenAuthentication
        
class CartView(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Fetch the user's cart
        try:
            cart = Cart.objects.get(user=request.user)
            serializer = CartSerializer(cart)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Cart.DoesNotExist:
            return Response({"detail": "Cart not found."}, status=status.HTTP_404_NOT_FOUND)

    def post(self, request):
        # Add a product to the cart
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity', 1)

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"detail": "Product not found."}, status=status.HTTP_404_NOT_FOUND)

        # Get or create the cart for the user
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Check if the product already exists in the cart
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

        if not created:
            # If the product already exists, update the quantity
            cart_item.quantity += int(quantity)
            cart_item.save()
        else:
            # If it's a new product in the cart, set the quantity
            cart_item.quantity = int(quantity)
            cart_item.save()

        return Response({"detail": "Product added to cart."}, status=status.HTTP_201_CREATED)

    def delete(self, request):
        # Clear the cart
        try:
            cart = Cart.objects.get(user=request.user)
            cart.items.all().delete()  # Delete all items in the cart
            return Response({"detail": "Cart cleared."}, status=status.HTTP_204_NO_CONTENT)
        except Cart.DoesNotExist:
            return Response({"detail": "Cart not found."}, status=status.HTTP_404_NOT_FOUND)


class UpdateCartItemView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity')

        if quantity is None:
            return Response({"error": "Quantity is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            quantity = int(quantity)
        except ValueError:
            return Response({"error": "Quantity must be an integer."}, status=status.HTTP_400_BAD_REQUEST)

        if quantity <= 0:
            return Response({"error": "Quantity must be greater than 0."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.get(cart=cart, product__id=product_id)
            cart_item.quantity = quantity
            cart_item.save()
            return Response({"message": "Cart item updated successfully."}, status=status.HTTP_200_OK)
        except Cart.DoesNotExist:
            return Response({"detail": "Cart not found."}, status=status.HTTP_404_NOT_FOUND)
        except CartItem.DoesNotExist:
            return Response({"detail": "Product not in cart."}, status=status.HTTP_404_NOT_FOUND)

class RemoveFromCartView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        product_id = request.data.get('product_id')

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"detail": "Product not found."}, status=status.HTTP_404_NOT_FOUND)

        try:
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.get(cart=cart, product=product)
            cart_item.delete()
            return Response({"detail": "Product removed from cart."}, status=status.HTTP_204_NO_CONTENT)
        except CartItem.DoesNotExist:
            return Response({"detail": "Product not in cart."}, status=status.HTTP_404_NOT_FOUND)        
        
from rest_framework import status
from product_project import settings   
import stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

class CreatePaymentView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            # Get the token from the request body
            token = request.data.get('token')

            if not token:
                return Response({'error': 'No token provided'}, status=status.HTTP_400_BAD_REQUEST)

            # Create a charge using the Stripe API
            charge = stripe.Charge.create(
                amount=5000,  # Amount in cents (e.g., $50.00)
                currency='usd',
                source=token,  # The token received from the frontend
                description='Payment for Order #12345',
            )

            # Return a success response with the charge details
            return Response({'success': True, 'charge': charge}, status=status.HTTP_200_OK)

        except stripe.error.CardError as e:
            # Handle card errors (e.g., insufficient funds, declined card)
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except stripe.error.StripeError as e:
            # Handle Stripe API errors
            return Response({'error': 'Stripe error occurred'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # Handle any other exceptions
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
        
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META["HTTP_STRIPE_SIGNATURE"]
    endpoint_secret = "your_webhook_secret"

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)

        # Handle the event
        if event["type"] == "payment_intent.succeeded":
            payment_intent = event["data"]["object"]
            print("Payment succeeded:", payment_intent)
        elif event["type"] == "payment_intent.payment_failed":
            print("Payment failed:", event["data"]["object"])

        return JsonResponse({"status": "success"})
    except ValueError as e:
        return JsonResponse({"error": "Invalid payload"}, status=400)
    except stripe.error.SignatureVerificationError as e:
        return JsonResponse({"error": "Invalid signature"}, status=400)        