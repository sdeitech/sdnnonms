from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import NotFound
from .models import Product
from .serializers import ProductSerializer,CustomUserSerializer
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

class ProductListCreate(APIView):
    def get(self, request):
        # List all products
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Create a new product
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProductRetrieveUpdateDelete(APIView):
    def get(self, request, pk):
        # Retrieve a single product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product)
        return Response(serializer.data)

    def put(self, request, pk):
        # Update a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        # Delete a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        product.delete()
        return Response({"detail": "Product deleted successfully."}, status=status.HTTP_204_NO_CONTENT)


class RegisterUserView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({"message": "User registered successfully!"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class CustomLoginView(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({"error": "Email and password are required."}, status=status.HTTP_400_BAD_REQUEST)

        # Authenticate user with email and password
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # Generate token for the user
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                "message": "Login successful.",
                "token": token.key  # Return the authentication token
            }, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)




# views.py
from rest_framework import status
from .models import Coupon
from .serializers import CouponSerializer
from django.utils.timezone import now
from datetime import timedelta

class ValidateCouponView(APIView):
    def post(self, request):
        # Add static coupons if they don't exist
        self.add_static_coupons()

        # Get the coupon code from the request
        code = request.data.get('code')

        try:
            # Check if the coupon exists in the database
            coupon = Coupon.objects.get(code=code)
            
            # Check if the coupon is valid
            if coupon.is_valid():
                return Response({
                    'valid': True,
                    'discount_percentage': coupon.discount_percentage
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'valid': False,
                    'message': 'Coupon has expired'
                }, status=status.HTTP_400_BAD_REQUEST)
        except Coupon.DoesNotExist:
            return Response({
                'valid': False,
                'message': 'Invalid coupon code'
            }, status=status.HTTP_400_BAD_REQUEST)

    def add_static_coupons(self):
        """Add static coupons if they don't already exist"""
        if not Coupon.objects.filter(code='WELCOME').exists():
            Coupon.objects.create(
                code='WELCOME',
                discount_percentage=10,
                valid_until=now() + timedelta(days=365)  # Valid for 1 year
            )
        
        if not Coupon.objects.filter(code='FIRSTORDER').exists():
            Coupon.objects.create(
                code='FIRSTORDER',
                discount_percentage=15,
                valid_until=now() + timedelta(minutes=2)  # Valid for 1 year
            )
           
            
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import Order

class CreateOrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Place a new order. If no shipping address is provided, use the user's registered address.
        Handle online payment options dynamically.
        """
        user = request.user
        shipping_address = request.data.get('shipping_address')
        payment_method = request.data.get('payment_method')
        total_amount = request.data.get('total_amount')
        payment_gateway = request.data.get('payment_gateway')  # Added for payment gateway

        # Default to the user's registered address if no shipping address is provided
        if not shipping_address:
            shipping_address = user.address  # Use the registered address
            if not shipping_address:
                return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        if not payment_method or not total_amount:
            return Response({"error": "All fields are required"}, status=status.HTTP_400_BAD_REQUEST)

        # Validate payment gateway for online payment
        if payment_method == "online":
            if payment_gateway not in ["gpay", "phonepe", "paytm"]:
                return Response(
                    {"error": "Invalid payment gateway. Choose from gpay, phonepe, or paytm."},
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Simulate payment processing (this is where integration with actual payment gateways would happen)
        payment_status = "success"  # In a real-world scenario, check payment gateway response.

        if payment_status != "success":
            return Response({"error": "Payment failed. Please try again."}, status=status.HTTP_400_BAD_REQUEST)

        # Create a new order
        order = Order.objects.create(
            user=user,
            shipping_address=shipping_address,
            payment_method=payment_method,
            total_amount=total_amount
        )

        return Response(
            {
                "message": "Order placed successfully",
                "order_id": order.id,
                "shipping_address": shipping_address,
                "payment_gateway": payment_gateway if payment_method == "online" else None
            },
            status=status.HTTP_201_CREATED
        )

    def get(self, request):
        """
        Fetch the user's default shipping address (registered address).
        """
        user = request.user
        shipping_address = user.address  # Fetch the registered address

        if not shipping_address:
            return Response({"message": "No address found. Please provide one."}, status=status.HTTP_404_NOT_FOUND)

        return Response({"shipping_address": shipping_address}, status=status.HTTP_200_OK)

    def patch(self, request):
        """
        Update the user's shipping address.
        """
        user = request.user
        new_shipping_address = request.data.get('shipping_address')

        if not new_shipping_address:
            return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Update the user's registered address
        user.address = new_shipping_address
        user.save()

        return Response(
            {"message": "Address updated successfully", "new_shipping_address": new_shipping_address},
            status=status.HTTP_200_OK
        )
        


from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Cart, CartItem, Product
from .serializers import CartSerializer, CartItemSerializer        
from rest_framework.authentication import TokenAuthentication
        
class CartView(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Get the user's cart
        try:
            cart = Cart.objects.get(user=request.user)
            serializer = CartSerializer(cart)
            return Response(serializer.data)
        except Cart.DoesNotExist:
            return Response({"detail": "Cart not found."}, status=status.HTTP_404_NOT_FOUND)

    def post(self, request):
        # Add a product to the cart
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity', 1)

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"detail": "Product not found."}, status=status.HTTP_404_NOT_FOUND)

        # Get or create the cart for the user
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Check if the product already exists in the cart
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

        if not created:
            # If the product already exists, update the quantity
            cart_item.quantity += quantity
            cart_item.save()
        else:
            # If it's a new product in the cart, set the quantity
            cart_item.quantity = quantity
            cart_item.save()

        return Response({"detail": "Product added to cart."}, status=status.HTTP_201_CREATED)

    def delete(self, request):
        # Clear the cart
        try:
            cart = Cart.objects.get(user=request.user)
            cart.items.all().delete()  # Delete all items in the cart
            return Response({"detail": "Cart cleared."}, status=status.HTTP_204_NO_CONTENT)
        except Cart.DoesNotExist:
            return Response({"detail": "Cart not found."}, status=status.HTTP_404_NOT_FOUND)


class UpdateCartItemView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
    # Extract data from the request body
      product_id = request.data.get('product_id')
      quantity = request.data.get('quantity')

    # Validate that quantity exists and is an integer
      if quantity is None:
          return Response({"error": "Quantity is required."}, status=status.HTTP_400_BAD_REQUEST)

      try:
        quantity = int(quantity)
      except ValueError:
        return Response({"error": "Quantity must be an integer."}, status=status.HTTP_400_BAD_REQUEST)

      if quantity <= 0:
        return Response({"error": "Quantity must be greater than 0."}, status=status.HTTP_400_BAD_REQUEST)

    # Proceed with your logic to update the cart
    # Example placeholder:
      return Response({"message": "Cart updated successfully."}, status=status.HTTP_200_OK)

class RemoveFromCartView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        # Remove a product from the cart
        product_id = request.data.get('product_id')

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"detail": "Product not found."}, status=status.HTTP_404_NOT_FOUND)

        try:
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.get(cart=cart, product=product)
            cart_item.delete()
            return Response({"detail": "Product removed from cart."}, status=status.HTTP_204_NO_CONTENT)
        except CartItem.DoesNotExist:
            return Response({"detail": "Product not in cart."}, status=status.HTTP_404_NOT_FOUND)        