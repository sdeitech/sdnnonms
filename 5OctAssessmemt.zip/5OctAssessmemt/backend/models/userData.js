import mongoose from "mongoose";

//declare schema
const userDataSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
  },
  { timestamps: true }
);


const userDataModel = mongoose.model("userData", userDataSchema);


export default userDataModel;
