
import express from "express";
import userController from "../controller/user.controller.js";
import verifyToken from "../middleware/tokenVerifier.js";
import { uploadimage } from "../controller/user.controller.js";
import { uploadMiddleware } from "../helper/multer.js";

const router = express.Router();



//crud of user
router.get("/api", userController.getUserDetail);
router.get("/api/:id", verifyToken, userController.getUserDetailById);
router.post("/api", userController.createUserDetail);
router.put("/api/:id", verifyToken, userController.updateUserDetail);
router.delete("/api/:id", userController.deleteUserDetail);

// For creating new model....populate
router.get("/useData/:id", userController.getUserData);
router.post("/api/useData/:id", userController.newUserStorage);

// For Login
router.post("/api/login", userController.loginUser);
router.post("/api/glogin", userController.SocialLogin);


// For Mail
// router.post("/api/mail", userController.mailUser);

// For Multer
router.post("/image", uploadMiddleware.single("image"), uploadimage);


export default router;
