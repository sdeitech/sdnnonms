const Footer = () =>{
    return(
        <>
        <footer
         style={{
            backgroundColor:"282c34",
            padding: "10px",
          color: "white",
          marginTop: "auto",
          fontSize: "20px",

         }}
         >Developrd By : Khushi Jaiswal</footer></>
    );
};
export default Footer;