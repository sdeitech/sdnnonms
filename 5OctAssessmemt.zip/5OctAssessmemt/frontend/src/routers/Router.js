import { createBrowserRouter } from "react-router-dom";
import Layout from "../Layouts/Layout";
import SignUp from "../materials/components/SignUp";
import SignIn from "../materials/components/SignIn";
import PrivateRoute from "../routers/PrivateRouter";
import Dashboard from "../materials/components/Dashboard";
import MyProfile from "../materials/components/MyProfile";

const route = createBrowserRouter([
  {
    path: "/",
    exact: true,
    element: (
      <Layout>
        <SignIn />
      </Layout>
    ),
  },
  {
    path: "/signup",
    exact: true,
    element: (
      <Layout>
        <SignUp />
      </Layout>
    ),
  },
  {
    path: "/myprofile",
    exact: true,
    element: (
      <Layout>
        <PrivateRoute>
          <MyProfile />
        </PrivateRoute>
      </Layout>
    ),
  },
  {
    path: "/dashboard",
    exact: true,
    element: (
      <Layout>
        <PrivateRoute>
          <Dashboard />
        </PrivateRoute>
      </Layout>
    ),
  },
]);

export default route;