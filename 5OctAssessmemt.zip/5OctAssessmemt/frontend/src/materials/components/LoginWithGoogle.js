import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { URLs } from "../components/constants/urlConstants";

const Login = () => {
  const navigate = useNavigate();

  const handleSuccess = async (response) => {
    const { credential } = response;
    console.log("credential---------", credential);

    try {
      const loginResponse = await axios.post(URLs.AXIOS_G, {
        token: credential,
      });
      console.log(loginResponse, "loginresponse");

      const { status, data } = loginResponse;

      if (status === 200 && data.token !== undefined) {
        // setUser(data);
        console.log("Login successful", data);
        localStorage.setItem("token", loginResponse.data.token);
        localStorage.setItem("user_data", JSON.stringify(data));
        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Error during login:", error);
    }
  };

  const handleError = () => {
    console.log("error while login");
  };
  return (
    <div className="container ">
      <button type="button">
        <GoogleOAuthProvider clientId={URL.CLIENT_ID}>
          <GoogleLogin onSuccess={handleSuccess} onError={handleError} />
        </GoogleOAuthProvider>
      </button>
    </div>
  );
};

export default Login;