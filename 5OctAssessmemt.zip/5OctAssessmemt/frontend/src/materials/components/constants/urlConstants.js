export const URLs = {
    // For Main Model
    AXIOS_GET_POST_UPDATE_DELETE: "http://localhost:5001/user/api",
    AXIOS_POST_LOGIN: "http://localhost:5001/user/api/login",

    AXIOS_G : "http://localhost:5001/user/api/glogin",
  
    // For Sub Model
    AXIOS_SUB_GET: "http://localhost:5001/user/useData",
    AXIOS_SUB_POST: "http://localhost:5001/user/api/useData",
  };