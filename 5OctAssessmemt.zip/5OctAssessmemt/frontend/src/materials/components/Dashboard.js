import TableData from "./TableData";
import { Button, Form, Modal } from "react-bootstrap";
import { useState, useEffect } from "react";
import axios from "axios";
import { URLs } from "../components/constants/urlConstants";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Dashboard = () => {
  const [data, setData] = useState([]);


  const [showModal, setShowModal] = useState(false);
  const handleShow = () => setShowModal(true);
  const handleClose = () => setShowModal(false);

  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");
  const obj = JSON.parse(user);
  const userID = obj._id;

  const onChangeHandle = (e) => {
    setData(e.target.value);
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5001/user/useData/${userID}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        console.log("dfd", response.data.info)
        setData(response.data.info);
      } catch (error) {
        toast.error("Error fetching user data");
      }
    };
    fetchUserData();
  }, [token]);

  const addDataHandle = async (e) => {
    e.preventDefault();
    try {
      console.log("OBJ ID 48 --> ", obj._id);
      const response = await axios.post(
        `${URLs.AXIOS_SUB_POST}/${obj._id}`,
        data,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      console.log(response.data, "51 ");
      // setData(response.data)
      toast.success("Data added successfully!");

      // Reset the newData state after successful submission
      setData({ firstName: "", lastName: "", email: "" });
      setShowModal(false); // Close modal after submission
    } catch (error) {
      toast.error("Error adding data");
    }
  };

  return (
    <>
      <ToastContainer />
      <div className="d-flex justify-content-between">
        <h3>User Dashboard</h3>
        <Button variant="primary" onClick={handleShow}>
          Add User
        </Button>
      </div>

      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add New User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={addDataHandle}>
            <Form.Group className="mb-3" controlId="formFirstName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter First Name"
                name="firstName"
                onChange={onChangeHandle}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formLastName">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Last Name"
                name="lastName"
                onChange={onChangeHandle}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter Email Address"
                name="email"
                onChange={onChangeHandle}
                required
              />
            </Form.Group>

            <Button variant="primary" type="submit">
              Add User
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      <div>
        <TableData />
      </div>
    </>
  );
};

export default Dashboard;
