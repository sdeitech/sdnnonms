import { useState, useEffect, useRef } from "react";
import { Button, Form } from "react-bootstrap";
import { URLs } from "../../materials/components/constants/urlConstants"
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

 const Profile = () => {
   
   const [data, setData] = useState({
    firstName: "", 
    lastName:"",
    email:"",
    
   });

   console.log("DATA 17--> ", data);

   const token = localStorage.getItem("token");
   const user = localStorage.getItem("user");
   const obj = JSON.parse(user);
   const navigate = useNavigate();
   const fileUploadRef = useRef(null);

  // Fetch logged-in user's data
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:5001/user/api/${obj._id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        // FOR DEBUGGING
        console.log("DEBUG DATA MYPROFILE ------> ", response.data.user);
        toast.success("Welcome to User Profile");
        setData(response.data.user);
      } catch (error) {
        console.log("Error", error);
      }
    };
    fetchUserData();
  }, [token, obj._id]);

  // Handle input change
  const onChangeHandle = (e) => {
    const { name, value, type, checked } = e.target;
    setData({ ...data, [name]: type === "checkbox" ? checked : value });
  };


  // Handle image file selection
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append("image", file);

      try {
        const response = await axios.post(URLs.AXIOS_UPLOAD_IMAGE, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });

        // Update avatar URL with the uploaded image path
        console.log("AVATAR --> ", response.data.file.path);

        toast.success("Image uploaded successfully!");
      } catch (error) {
        console.error("Error uploading image", error);
        toast.error("Error uploading image");
      }
    }
  };

  // Handle profile update
  const handleUpdateButton = async (e) => {
    if (window.confirm("Are you sure you want to update your profile?")) {
      try {
        await axios.put(`${URL.AXIOS_PUT}/${data._id}`, data, {
          headers: { Authorization: `Bearer ${token}` },
        });
        toast.success("Profile updated successfully!");
      } catch (error) {
        toast.error("Error updating profile");
      }
    }
  };

  const handleDeleteProfile = async () => {
    if (window.confirm("Are you sure you want to delete your profile?")) {
      try {
        await axios.delete(`${URL.AXIOS_DELETE}/${data._id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        toast.success("Profile deleted successfully!");
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        navigate("/");
      } catch (error) {
        toast.error("Error deleting profile");
      }
    }
  };

  return (
    <>
      <ToastContainer />
      <Form encType="multipart/form-data">

        <Form.Group className="mb-3" controlId="formFirstName">
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter First Name"
            name="firstName"
            value={data.firstName}
            onChange={onChangeHandle}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formLastName">
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Last Name"
            name="lastName"
            value={data.lastName}
            onChange={onChangeHandle}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter Email"
            name="email"
            value={data.email}
            onChange={onChangeHandle}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formDob">
          <Form.Label>Date of Birth</Form.Label>
          <Form.Control
            type="date"
            name="dob"
            value={data.dob ? data.dob.split("T")[0] : ""}
            onChange={onChangeHandle}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formMarriedStatus">
          <Form.Check
            type="checkbox"
            label="Married"
            name="marriedStatus"
            checked={data.marriedStatus === "true"}
            onChange={onChangeHandle}
          />
          <Form.Check
            type="checkbox"
            label="Un - Married"
            name="isMarried"
            checked={data.isMarried === "false"}
            onChange={onChangeHandle}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Gender</Form.Label>
          <Form.Check
            type="radio"
            label="Male"
            name="gender"
            value="Male"
            checked={data.gender === "Male"}
            onChange={onChangeHandle}
          />
          <Form.Check
            type="radio"
            label="Female"
            name="gender"
            value="Female"
            checked={data.gender === "Female"}
            onChange={onChangeHandle}
          />
        </Form.Group>

        <Button variant="warning" onClick={handleUpdateButton}>
          Update
        </Button>
        <Button variant="danger" onClick={handleDeleteProfile}>
          Delete
        </Button>
      </Form>
    </>
  );
};

export default Profile;
