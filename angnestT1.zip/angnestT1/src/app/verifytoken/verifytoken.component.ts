import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-verifytoken',
  templateUrl: './verifytoken.component.html',
  styleUrls: ['./verifytoken.component.css']
})
export class VerifytokenComponent implements OnInit {
  token: string | null = null;
  inputToken: string = '';
  verificationMessage: string | null = null;

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    // Retrieve the token from query params
    this.route.queryParams.subscribe(params => {
      this.token = params['token'];
      console.log('Received token:', this.token);  // Log the token value
    });
  }

  verifyToken(): void {
    // Call your API to verify the token
    this.http.post('http://localhost:7890/authorization/verify-token', { token: this.inputToken })
      .subscribe(
        response => {
          this.verificationMessage = 'Token successfully verified!';
          localStorage.setItem('token', this.inputToken);
          console.log(response);
          // After successful verification, navigate to the dashboard
          this.router.navigate(['/dashboard']);
        },
        error => {
          this.verificationMessage = 'Token verification failed. Please try again.';
          console.error(error);
        }
      );
  }
}
