import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TokengenerateComponent } from './tokengenerate.component';

describe('TokengenerateComponent', () => {
  let component: TokengenerateComponent;
  let fixture: ComponentFixture<TokengenerateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TokengenerateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TokengenerateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
