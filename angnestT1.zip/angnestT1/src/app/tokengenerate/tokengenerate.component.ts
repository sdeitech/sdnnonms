import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tokengenerate',
  templateUrl: './tokengenerate.component.html',
  styleUrls: ['./tokengenerate.component.css']
})
export class TokengenerateComponent {
  clientId: string = '';
  password: string = '';
  token: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    const loginData = {
      clientId: this.clientId.trim(), // Trim any unnecessary spaces
      password: this.password.trim() 
    };
  
    console.log('Sending data:', loginData);  // Log the data to make sure it's correct
  
    this.http.post<{ data: { token: string } }>('http://localhost:7890/authorization/tokengeneration', loginData, {
      headers: { 'Content-Type': 'application/json' },
    })
    .subscribe(
      response => {
        // Access the token inside the 'data' field
        console.log('Response from backend:', response);  // Log the full response
        const token = response?.data?.token;
  
        if (token) {
          console.log('Token received and assigned:', token);
          this.token = token;
  
          // Navigate to the verify-token page with the token as query param
          this.router.navigate(['/verify-token'], { queryParams: { token: this.token } });
        } else {
          console.error('Token is missing in the response.');
        }
      },
      error => {
        console.error('Error generating token:', error);
        alert('Failed to generate token.');
      }
    );
  }
  
}


