import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  token: string | null = localStorage.getItem('token');
  data: any[] = [];
  loading: boolean = false;
  errorMessage: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  // Fetch Data from API
  fetchData(endpoint: string) {
    if (this.token) {
      this.loading = true;
      this.errorMessage = null;
      this.http.get<any>(`http://localhost:7777/${endpoint}`, {
        headers: { Authorization: `Bearer ${this.token}` }
      }).subscribe(
        response => {
          console.log('Response:', response); // Debugging
          if (response.success && Array.isArray(response.data)) {
            this.data = response.data; // Extract the data array
          } else {
            this.data = []; // Handle unexpected response structure
          }
          this.loading = false;
        },
        error => {
          console.error('Error fetching data:', error);
          this.errorMessage = `Error fetching ${endpoint} data.`;
          this.loading = false;
        }
      );
    } else {
      this.errorMessage = 'No token found. Please log in.';
    }
  }

  // Fetch States Data
  getStates() {
    this.fetchData('states/all');
  }

  // Fetch Static Data
  getStaticData() {
    this.fetchData('static/data');
  }

  // Fetch Classification Data
  getClassificationData() {
    this.fetchData('classification');
  }

  // Navigate to Home
  navigateToHome() {
    this.router.navigate(['/']);
  }

  // Get Keys for Static Data
  getKeys(item: any): string[] {
    return Object.keys(item);
  }
}
