import { Component } from '@angular/core';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  name: string = '';
  password: string = '';
  email: string = '';
  errorMessage: string = ''; // To store any error message
  successMessage: string = ''; // To store any success message

  constructor(private registerService: RegisterService) {}

  // Method to handle form submission
  onSubmit() {
    if (this.password !== this.password) {
      this.errorMessage = 'Passwords do not match';
      return;
    }

    const userData = {
      name: this.name,
      password: this.password,
      email: this.email
    };

    // Call the service to send the registration data to the backend
    this.registerService.registerUser(userData).subscribe(
      (response) => {
        // If registration is successful, you can handle the response here
        console.log('Registration successful:', response);
        this.successMessage = 'Registration successful! Please log in.';
        this.errorMessage = ''; // Clear error message if successful
      },
      (error) => {
        // If there is an error, handle it here
        console.error('Registration failed:', error);
        this.errorMessage = 'Registration failed! Please try again.';
        this.successMessage = ''; // Clear success message on error
      }
    );
  }
}
