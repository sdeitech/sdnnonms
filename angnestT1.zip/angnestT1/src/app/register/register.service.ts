import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface for the registration data
interface RegisterData {
  name: string;
  password: string;
  email: string;
}

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  // Base API URL for the NestJS backend
  private apiUrl = 'http://localhost:7890/authorization/register';

  constructor(private http: HttpClient) {}

  // Method to send the registration data to the backend
  registerUser(data: RegisterData): Observable<any> {
    return this.http.post(this.apiUrl, data);
  }
}
