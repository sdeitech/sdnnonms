import React, { useContext } from 'react'
import toast from 'react-hot-toast'
import { Link } from 'react-router-dom'
import { userContext } from '../context/AppContext'
import useForm from '../customs/useForm'
import { putApi } from '../utils/apiUtils'


const ProfileCard = () => {

  const { userData, userId } = useContext(userContext)
  console.log(userData, "from update")

  let fomatted_date = (userData.DOB).split("T")[0]


  const updateProfile = {
    firstName: userData?.firstName,
    lastName: userData?.lastName,
    email: userData?.email,
    DOB: fomatted_date,
    isMarried: userData.isMarried,
    gender: userData?.firstName,
  }

  const { formData, handleChange } = useForm(updateProfile)
  console.log(formData)

  const handleSubmit = async (e) => {
    try {
      const res = await putApi(`/update/user/${userId}`, formData)
      // console.log(res.data)
      toast.success("Profile updated")
    } catch (error) {
      toast.error("Cant update profile")
      // console.log(`error while updating user ${error.message}`)
    }

  }
  return (
    <div>
      <div>
        <p>Chnage profile</p>
      </div>
      <div>
        <form onSubmit={handleSubmit} className='form-inputs'>
          <div>
            <img src={`${process.env.REACT_APP_IMAGE_URL}/${userData?.profile}`} alt="Profile" height={70} width={70} style={{ border: "1px solid gray" }} />

          </div>
          <div>
            <input
              type="text"
              name='firstName'
              value={formData.firstName}
              placeholder='First name'
              onChange={handleChange}
            />
          </div>
          <div><input
            type="text"
            name='lastName'
            value={formData.lastName}
            placeholder='Last name'
            onChange={handleChange} /></div>
          <div> <input
            type="email"
            name='email'
            placeholder='Email'
            value={formData.email}
            onChange={handleChange} /></div>
          <div>
            <input
              type="date"
              name='DOB'
              value={formData.DOB}
              onChange={handleChange} />
          </div>

          <div>
            <label>Married</label>
            <input
              type="checkbox"
              name='isMarried'
              checked={formData.isMarried}
              onChange={handleChange}
            />
          </div>

          <div className='gender-div'>
            <div>
              <label>Male</label>
              <input
                type="radio"
                name='gender'
                value="male"
                checked={formData.gender}
                onChange={handleChange} />
            </div>
            <div>
              <label>Female</label>
              <input
                type="radio"
                name='gender'
                value="female"
                checked={formData.gender}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className='submit-btn'>
            <button type='submit' >Update</button>
          </div>
          <div>
            <Link to={"/dashboard"}><p>Back to dashboard</p></Link>
          </div>
        </form>
      </div>
    </div>
  )
}

export default ProfileCard