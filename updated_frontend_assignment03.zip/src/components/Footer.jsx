import React from 'react'

const Footer = () => {
    return (
        <div style={{ width: "100%", backgroundColor: "black", height: "50px" }}>
            <p style={{}}>All Rights Reserved.</p>
        </div>
    )
}

export default Footer