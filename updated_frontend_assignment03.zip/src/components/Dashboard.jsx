import React, { useContext, useState } from 'react'
import { userContext } from '../context/AppContext'
import "../css/Dashboard.css"
import SearchAdd from './SearchAdd'
import ViewUser from './ViewUser'
import PaginationRounded from "../components/PaginationRounded"

const Dashboard = () => {
    const { subUser } = useContext(userContext)
    // console.log(subUser, "from dashboard")

    const [userData, setUserData] = useState(null)
    const [showView, setShowView] = useState(false)
    const { currPage } = useContext(userContext)


    return (
        <>
            <div>

                {
                    !subUser.length && <div>
                        <h1>No data found Please add user</h1>
                    </div>
                }
                <SearchAdd />
                <div className='table-container'>
                    <table>
                        <thead>
                            <tr>
                                <th>Sr No</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                subUser?.map((user, index) => {
                                    return (
                                        <tr key={user._id}>
                                            <td>{(currPage - 1) * 5 + index + 1}</td>
                                            <td>{user?.firstName}</td>
                                            <td>{user?.lastName}</td>
                                            <td>{user?.email}</td>
                                            <td>
                                                <button onClick={() => {
                                                    setUserData(user)
                                                    setShowView(!showView)
                                                }}>View</button>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
                <div style={{ padding: "0 135px" }}>
                    <PaginationRounded />

                </div>
            </div>
            {
                showView && <ViewUser userData={userData} showView={showView} setShowView={setShowView} />
            }
        </>
    )
}

export default Dashboard