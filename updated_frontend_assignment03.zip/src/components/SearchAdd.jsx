import React, { useContext, useState } from 'react'
import "../css/SearchAdd.css"
import AddUser from './AddUser'
import { userContext } from '../context/AppContext'

const SearchAdd = () => {
    const [showAdd, setShowAdd] = useState(false)
    const { search, setSearch } = useContext(userContext)

    const handleSearch = (e) => {
        setSearch(e.target.value)
    }


    return (
        <>
            <div className='search-add'>
                <div>
                    <input type="text" placeholder='search' name='search' onChange={handleSearch} />
                </div>
                <div>
                    <button onClick={() => {
                        setShowAdd(!showAdd)
                    }}>Add User</button>
                </div>
            </div>
            {
                showAdd && <AddUser showAdd={showAdd} setShowAdd={setShowAdd} />
            }
        </>
    )
}

export default SearchAdd