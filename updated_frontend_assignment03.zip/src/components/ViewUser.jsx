import React from 'react'
import "../css/ViewUser.css"

const ViewUser = ({ userData, showView, setShowView }) => {

    return (
        <div className='view-user'>
            <div>
                <p>First Name : {userData?.firstName}</p>
                <p>Last Name : {userData?.lastName}</p>
                <p>Email : {userData?.email}</p>
            </div>
            <div>
                <button onClick={() => {
                    setShowView(!showView)
                }}>close</button>
            </div>
        </div>
    )
}

export default ViewUser