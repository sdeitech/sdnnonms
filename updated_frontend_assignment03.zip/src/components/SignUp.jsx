import React from 'react'
import toast, { Toaster } from 'react-hot-toast'
import { CgProfile } from "react-icons/cg"
import { Link, useNavigate } from 'react-router-dom'
import "../css/SignUp.css"
import useForm from '../customs/useForm'
import { postApi } from '../utils/apiUtils'

const SignUp = () => {
    const navigate = useNavigate()

    const signUpForm = {
        firstName: "",
        lastName: "",
        email: "",
        DOB: "",
        password: "",
        isMarried: false,
        gender: "",
        profile: null
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        console.log(formData)
        try {
            const res = await postApi("/signup", formData, true)
            resetForm()
            toast.success('user registered Successfully !')
            setTimeout(() => {
                navigate("/login")
            }, 1000);
            // console.log(res.data)

        } catch (error) {
            toast.error('please enter valid details!')
            // console.log(`Error while signing up user ${error.message}`)

        }
    }

    const { formData, previewImg, handleChange, resetForm } = useForm(signUpForm)
    console.log(previewImg, "blob")
    console.log(formData)
    return (
        <div className='form-container'>
            <h3>Sign Up</h3>

            <form onSubmit={handleSubmit} className='form-inputs'>
                <div>
                    {previewImg ? <div className='profile-container'> <img src={previewImg} alt="profile" height={60} width={50} /> </div> : <div className='profile-container' > <CgProfile size={50} /> </div>}
                </div>
                <div>
                    <input
                        type="text"
                        name='firstName'
                        placeholder='First name'
                        onChange={handleChange}
                        required
                    />

                </div>
                <div><input
                    type="text"
                    name='lastName'
                    placeholder='Last name'
                    onChange={handleChange}
                    required
                />
                </div>
                <div> <input
                    type="email"
                    name='email'
                    placeholder='Email'
                    onChange={handleChange}
                    required
                />
                </div>
                <div>
                    {/* <label>DOB</label> */}
                    <input
                        type="date"
                        name='DOB'
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <input
                        type="password"
                        name='password'
                        placeholder='password'
                        onChange={handleChange}
                        required

                    />
                </div>
                <div>
                    <label>Married</label>
                    <input
                        type="checkbox"
                        name='isMarried'
                        checked={formData.isMarried}
                        onChange={handleChange}
                    />
                </div>

                <div className='gender-div'>
                    <div>
                        <label>Male</label>
                        <input
                            type="radio"
                            name='gender'
                            value="male"
                            checked={formData.gender === "male"}
                            onChange={handleChange} />
                    </div>
                    <div>
                        <label>Female</label>
                        <input
                            type="radio"
                            name='gender'
                            value="female"
                            checked={formData.gender === "female"}
                            onChange={handleChange}
                        />
                    </div>
                </div>
                <div>
                    <label htmlFor="profile" style={{ backgroundColor: "rgb(131, 226, 255)", padding: "6px 15px", borderRadius: "4px" }}>Upload Profile</label>
                    <input
                        type="file"
                        id='profile'
                        name='profile'
                        placeholder=''
                        onChange={handleChange}
                        required
                        style={{ display: "none" }}
                    />
                </div>
                <div className='submit-btn'>
                    <button type='submit' >submit</button>
                </div>
                <div>
                    <p>Already have an account ? <Link to={"/login"}><span>click here</span></Link></p>
                </div>

            </form>
            <Toaster />
        </div>
    )
}

export default SignUp