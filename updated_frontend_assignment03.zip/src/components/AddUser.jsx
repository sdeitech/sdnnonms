import React, { useContext } from 'react'
import useForm from '../customs/useForm'
// import "../css/AddUser.css"
import axios from 'axios'
import { userContext } from "../context/AppContext"
import toast, { Toaster } from 'react-hot-toast'
import "../css/SignUp.css"

const AddUser = ({ showAdd, setShowAdd }) => {

    const { userId, updateState, setUpdateState, userId1 } = useContext(userContext)

    const userData = {
        firstName: "",
        lastName: "",
        email: ""
    }

    const { formData, handleChange } = useForm(userData)
    console.log(formData)
    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            const res = await axios.post(`http://localhost:3002/api/user/${userId || userId1} `, formData)
            // console.log(res.data)
            toast.success("user added !")
            setUpdateState(!updateState)
        } catch (error) {
            toast.error("cant add user")
            console.log(`error while adding user ${error.message}`)
        }
    }
    return (
        <>
            <div className='add-user-form'>
                <h3>Add User</h3>
                <form onSubmit={handleSubmit} className='form-inputs'>
                    <input type="text" name='firstName' placeholder='First Name' onChange={handleChange} />
                    <input type="text" name='lastName' placeholder='Last Name' onChange={handleChange} />
                    <input type="email" name='email' placeholder='Email' onChange={handleChange} />
                    <div style={{ display: "flex", gap: "40px" }}>
                        <button type="submit">Add</button>
                        <button onClick={() => {
                            setShowAdd(!showAdd)
                        }}>close</button>
                    </div>

                </form>
            </div>
            <Toaster />
        </>
    )
}

export default AddUser