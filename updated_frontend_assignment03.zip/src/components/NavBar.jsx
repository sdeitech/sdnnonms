import React, { useContext } from 'react'
import "../css/NavBar.css"
import { useNavigate } from 'react-router-dom'
import { userContext } from '../context/AppContext'
import { Link } from "react-router-dom"
import { CgProfile } from "react-icons/cg";
import toast, { Toaster } from 'react-hot-toast'

const NavBar = () => {
  const navigate = useNavigate()
  const { userData } = useContext(userContext)
  console.log(userData, "from navbar")

  const logout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("userId")
    toast.success("Logged Out")
    setTimeout(() => {
      navigate("/")
    }, 1000);
  }

  return (
    <div className='container'>
      <div>
        <p>Welcome {userData?.firstName || "Guest"}</p>
      </div>
      <div>
        <h3> Dashboard </h3>
      </div>
      <div className='logout'>
        <Link to={"/profile"} >
          {
            userData?.profile ? <div className='profile'>
              <img src={`${process.env.REACT_APP_IMAGE_URL}/${userData?.profile}`} alt="Profile" height={30} width={30} />
            </div> : <div className='profile'>
              <CgProfile size={30} />
            </div>
          }
        </Link>
        <button onClick={logout}>Logout</button>
      </div>
      <Toaster />
    </div>
  )
}

export default NavBar