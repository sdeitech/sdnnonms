import axios from "axios"
import React, { useContext } from 'react'
import toast, { Toaster } from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { userContext } from '../context/AppContext'
import "../css/SignUp.css"
import useForm from '../customs/useForm'
import { postApi } from "../utils/apiUtils"


const SignIn = () => {
    const navigate = useNavigate()
    const { userId, setUserId } = useContext(userContext)
    const signUpForm = {
        email: "",
        password: "",
    }
    const { formData, handleChange } = useForm(signUpForm)

    const handleSubmit = async (e) => {
        e.preventDefault()
        // console.log(formData)
        try {
            const res = await axios.post(`http://localhost:3002/api/signin`, formData)
            // console.log(res.data)
            localStorage.setItem("token", res.data.token)
            toast.success(`You logged in successfully !`)
            localStorage.setItem("userId", res.data.id)
            setUserId(res.data.id)
            setTimeout(() => {
                navigate("/dashboard")
            }, 1000);

        } catch (error) {
            toast.error("Invalid credentials")
            // console.log(`error while logging ${error.message}`)
        }

    }

    console.log(formData)


    return (
        <>
            <div className='form-container'>
                <h3>Login</h3>
                <form onSubmit={handleSubmit} className='form-inputs'>
                    <div>
                        <input
                            type="email"
                            name='email'
                            placeholder='Email'
                            onChange={handleChange}
                            required />
                    </div>
                    <div>
                        <input
                            type="password"
                            name='password'
                            placeholder='password'
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className='submit-btn'>
                        <button type='submit' >login</button>
                    </div>
                </form>
            </div>
            <Toaster />
        </>
    )
}

export default SignIn