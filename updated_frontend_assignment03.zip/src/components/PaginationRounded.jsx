import React, { useContext } from 'react';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import { userContext } from '../context/AppContext';


const PaginationRounded = () => {
  const { currPage, setCurrPage, totalPage } = useContext(userContext)
  const handlePage = (event, page) => {
    setCurrPage(page)
  }
  return (
    <Stack spacing={2}>
      <Pagination
        count={totalPage || 1}
        page={currPage || 1}
        onChange={handlePage}
        variant="outlined"
        shape="rounded" />
    </Stack>
  );
}

export default PaginationRounded