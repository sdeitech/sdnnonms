import React, { createContext, useEffect, useState } from 'react'
import { getApi } from '../utils/apiUtils'

const userContext = createContext()

const AppContext = ({ children }) => {
    const [userData, setUserData] = useState(null)
    const [subUser, setSubUser] = useState([])
    const [userId, setUserId] = useState(null)

    //pagination data 
    const [totalPage, setTotalPage] = useState(1)
    const [currPage, setCurrPage] = useState(1)
    const [search, setSearch] = useState("")

    // state to update state
    const [updateState, setUpdateState] = useState(false)

    // setting logged in userId
    const userId1 = localStorage.getItem("userId")

    const fetchData = async () => {
        try {

            const res = await getApi(`/user/${userId || userId1}?search=${search}&page=${currPage}&limit=5`)
            setCurrPage(res.pageNo)
            setTotalPage(res.totalPages)
            setUserData(res.user)
            setSubUser(res.user.users)

        } catch (error) {
            console.log(`error while getting user from context${error.message}`)
        }
    }

    useEffect(() => {
        fetchData()
    }, [userId, currPage, search, updateState])


    const values = {
        userData,
        setUserData,
        subUser,
        setSubUser,
        userId,
        setUserId,
        currPage,
        setCurrPage,
        totalPage,
        setSearch,
        updateState,
        setUpdateState,
        userId1
    }


    return (
        <userContext.Provider value={values}>{children}</userContext.Provider>
    )
}

export { AppContext, userContext }
