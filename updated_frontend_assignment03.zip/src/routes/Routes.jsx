import { createBrowserRouter } from "react-router-dom"
import PrivateRoutes from "./PrivateRoutes"
import PublicRoutes from "./PublicRoutes"

const Router = createBrowserRouter([...PrivateRoutes, ...PublicRoutes])
export default Router