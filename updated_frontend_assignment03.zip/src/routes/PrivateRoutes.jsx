import React from 'react'
import PrivateLayout from '../layout/PrivateLayout'
import Dashboard from '../components/Dashboard'
import ProfileCard from '../components/ProfileCard'

const PrivateRoutes = [
    {
        path: "/dashboard",
        element: <PrivateLayout><Dashboard /></PrivateLayout>
    }, {
        path: "/profile",
        element: <PrivateLayout> <ProfileCard /> </PrivateLayout>
    }
]

export default PrivateRoutes