const validation = (formData) => {
    let error = {}

    if (!formData.firstName) {
        error.firstName = "please enter first name"
    }

    if (!formData.lastName) {
        error.firstName = "please enter last name"
    }

    if (!formData.email) {
        error.firstName = "please enter email"
    }

    if (!formData.gender) {
        error.firstName = "please select gender"
    }

    if (!formData.DOB) {
        error.firstName = "please select DOB"
    }

    return error
}

export default validation