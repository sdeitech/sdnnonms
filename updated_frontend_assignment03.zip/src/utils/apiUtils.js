import axios from "axios";

const apiClient = axios.create({
    baseURL: `http://localhost:3002/api`,
});

const setHeader = (isFromData = false) => {
    const header = {
        Authorization: `${localStorage.getItem("token")}`,
        "Content-type": isFromData ? `multipart/form-data` : `application/json`,
    };
    return header;
};

const handleError = (error) => {
    const errorMsg = error.message;
    console.log("API ERROR : ", errorMsg);
    throw errorMsg;
};

export const getApi = async (url) => {
    try {
        const res = await apiClient.get(url);
        return res.data;
    } catch (error) {
        handleError(error);
    }
};

export const postApi = async (url, data = {}, isFormData = false) => {
    try {
        const res = await apiClient.post(url, data, {
            headers: setHeader(isFormData),
        });
        return res.data;
    } catch (error) {
        handleError(error);
    }
};

export const deleteApi = async (url, data = {}) => {
    try {
        const res = await apiClient.delete(url, {
            headers: setHeader(),
            data,
        });

        return res.data;
    } catch (error) {
        handleError(error);
    }
};

export const putApi = async (url, data = {}, isFormData = false) => {
    try {
        const res = await apiClient.put(url, data, {
            headers: setHeader(isFormData),
        });
        return res.data;
    } catch (error) {
        handleError(error);
    }
};