import React, { useEffect } from 'react'
import { useNavigate } from "react-router-dom"
import NavBar from '../components/NavBar'
import Footer from '../components/Footer'

const PrivateLayout = ({ children }) => {
    const navigate = useNavigate()
    const token = localStorage.getItem("token")

    useEffect(() => {
        if (!token) {
            navigate("/")
        }
    }, [token, navigate])

    return (
        <div>
            <NavBar />
            <div style={{ height: "100vh" }}>
                {children}
            </div>
            <Footer />
        </div>
    )
}

export default PrivateLayout