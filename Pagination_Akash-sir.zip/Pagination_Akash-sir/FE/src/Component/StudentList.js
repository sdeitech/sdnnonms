
import { useState, useEffect } from "react";
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from "axios";
import AddStudentDetails from "./AddStudent";
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";
import { Typography, Box } from '@mui/material';
import Pagination from "react-js-pagination";

const StudentList = () => {
    const [data, setData] = useState([]);

    console.log('data---------',data)
    
    const [error, setError] = useState(null);

    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [perPage, setPerPage] = useState(1);

    const getClickedPageNo = (pageNumber) => {
        setCurrentPage(pageNumber);
        fetchData(pageNumber);
    }

    const fetchData = async () => {
        try {
            const response = await axios.get(`http://localhost:3002/api/student`);
            console.log(response.data);
            setData(response.data);
            const { status, data } = response;
            if (status === 200 && data.data !== undefined) {
                setData(data.data);
                const { pagination: { per_page, total_record } } = data || {};
                setPerPage(per_page);
                setTotalRecords(total_record);
            }
        } catch (error) {
            setData([]);
            setError('Failed to fetch data');
        }
    };

    useEffect(() => {
        fetchData(currentPage);
    }, []);

    return (
        <>
            <Box sx={{ padding: 3 }}>
                <Typography variant="h4" component="h1" gutterBottom>
                    Student Management
                </Typography>

                <AddStudentDetails />

                <TableContainer component={Paper} sx={{ marginTop: 2, boxShadow: 3 }}>
                    <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ fontWeight: 'bold' }}>First Name</TableCell>
                                <TableCell align="right" sx={{ fontWeight: 'bold' }}>Last Name</TableCell>
                                <TableCell align="right" sx={{ fontWeight: 'bold' }}>Email</TableCell>
                                <TableCell align="right" sx={{ fontWeight: 'bold' }}>Action</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map((student) => (
                                <TableRow
                                    key={student._id}
                                    sx={{
                                        '&:last-child td, &:last-child th': { border: 0 },
                                        '&:hover': { backgroundColor: '#f5f5f5' }
                                    }}
                                >
                                    <TableCell component="th" scope="row">
                                        {student.firstName}
                                    </TableCell>
                                    <TableCell align="right">{student.lastName}</TableCell>
                                    <TableCell align="right">{student.email}</TableCell>
                                    <TableCell align="right">
                                        <Link to={`/${student._id}`}>
                                            <Button variant="contained" color="primary">View</Button>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>

            <div className="d-flex flex-row py-4 justify-content-center">
                <Pagination
                    activePage={currentPage}
                    prevPageText='prev'
                    nextPageText='next'
                    itemClass="page-item"
                    linkClass="page-link"
                    pageRangeDisplayed={5}
                    itemsCountPerPage={perPage}
                    totalItemsCount={totalRecords}
                    onChange={getClickedPageNo}
                />
            </div>
        </>
    );
};

export default StudentList;








































