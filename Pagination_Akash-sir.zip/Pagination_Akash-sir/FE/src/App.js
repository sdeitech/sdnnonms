import { BrowserRouter, Route , Routes} from 'react-router-dom';
import './App.css';
import StudentList from './Component/StudentList';
import StudentDetails from './Component/StudentDetail';
import Loginform from './Login-SignUp/loginForm';

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<StudentList></StudentList>}></Route>
          <Route path='/:id' element={<StudentDetails></StudentDetails>}></Route>
          <Route path='/login' element={<Loginform></Loginform>}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
