const validateUser = (values) => {
    let errors = {};

    if (!values.firstName) {
        errors.firstName = "First Name is required";
    }

    if (!values.lastName) {
        errors.lastName = "Last Name is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";
    }

    if (!values.english) {
        errors.english = "This is required";
    }

    if (!values.maths) {
        errors.maths = "This is required";
    }

    if (!values.science) {
        errors.science = "This is required";
    }

    return errors;
};

export default validateUser;
