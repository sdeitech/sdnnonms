const express = require('express')
const router = express() 
const studentController = require('../Controller/student-controller')

router.post('/student', studentController.createStudent)
router.get('/student', studentController.fetchStudent)
router.get('/student/:id', studentController.fetchStudentById)



module.exports = router;