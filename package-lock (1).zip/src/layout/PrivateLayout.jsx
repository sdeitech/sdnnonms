import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const PrivateLayout = ({ children }) => {
  const navigate = useNavigate();

  const token = useSelector((state) => state.users.authUser.token);

  useEffect(() => {
    if (!token) {
      navigate("/");
    }
  }, [token, navigate]);

  return <div>{children}</div>;
};

export default PrivateLayout;
