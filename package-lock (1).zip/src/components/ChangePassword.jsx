import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';
import { useSelector } from "react-redux";


const ChangePassword = () => {
  const {userId} = useSelector(state=> state.users.authUser)
  const id = localStorage.getItem("userId");
    const navigate = useNavigate();


  const [currentPassword, setcurrentPassword] = useState("");
  const [newPassword, setnewPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newPassword === confirmPassword) {
      //api
      const response = await axios.put(
        `http://localhost:3217/api/changepass/${userId}`,
        {
          oldPassword: currentPassword,
          newPassword: newPassword,
        }
      );
      console.log(response.data);
      toast.success('Successfully password changed..!')

      setTimeout(() => {
        
      navigate("/login");
      }, 2000);
      
    } else {
      alert("Passwords do not match");
    }
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "#f0f4f8",
      }}
    >
      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "15px",
          padding: "30px",
          width: "400px",
          backgroundColor: "#fff",
          boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
          borderRadius: "8px",
          border: "1px solid #ddd",
        }}
      >
        <h2 style={{ textAlign: "center", color: "#333" }}>Change Password</h2>
        
        <label htmlFor="currentPassword" style={{ fontWeight: "bold", color: "#555" }}>
          Current Password
        </label>
        <input
          type="password"
          placeholder="Enter current password"
          value={currentPassword}
          onChange={(e) => setcurrentPassword(e.target.value)}
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            fontSize: "16px",
          }}
        />
  
        <label htmlFor="newPassword" style={{ fontWeight: "bold", color: "#555" }}>
          New Password
        </label>
        <input
          type="password"
          placeholder="Enter new password"
          value={newPassword}
          onChange={(e) => setnewPassword(e.target.value)}
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            fontSize: "16px",
          }}
        />
  
        <label htmlFor="confirmPassword" style={{ fontWeight: "bold", color: "#555" }}>
          Confirm Password
        </label>
        <input
          type="password"
          placeholder="Confirm new password"
          value={confirmPassword}
          onChange={(e) => setconfirmPassword(e.target.value)}
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            fontSize: "16px",
          }}
        />
  
        <button
          type="submit"
          style={{
            padding: "12px",
            borderRadius: "5px",
            border: "none",
            backgroundColor: "#4CAF50",
            color: "white",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Change Password
        </button>
      </form>
      <Toaster />
    </div>
  )
};

export default ChangePassword;
