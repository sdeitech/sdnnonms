import React from "react";
import { Link } from "react-router-dom";
import DataTable from "./datatable";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logoutUser, clearUsers } from "../reduxcomponent/authslice";
import toast, { Toaster } from "react-hot-toast";
// import UploadCsv from "./Uploadcsv";
const Dashboard = () => {
  // const logout =()=>{
  //   localStorage.clear();

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handlepassword = async () => {
    navigate("/change");
  };

  const handleLogout = () => {
    toast.success("Logged Out");
    localStorage.clear();
    setTimeout(() => {
      dispatch(logoutUser());
      dispatch(clearUsers());
      navigate("/login");
    }, 1000);
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "#f0f4f8",
        padding: "20px",
      }}
    >
   <h1
  style={{
    color: "#333",
    fontSize: "28px", // Increased font size
    textAlign: "center",
    marginBottom: "20px",
    fontWeight: "bold", // Make the text bold
    textTransform: "uppercase", // Transform text to uppercase for emphasis
    letterSpacing: "1px", // Add spacing between letters for a more attractive look
    padding: "10px", // Add some padding
    backgroundColor: "#e0f7fa", // Light background color for contrast
    borderRadius: "8px", // Rounded corners for the background
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow for depth
  }}
>
  Welcome to Dashboard
</h1>
  
      {/* Horizontal Button Layout */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "15px", // Horizontal spacing between buttons
          marginBottom: "20px",
        }}
      >
        <Link to={"/adduser"}>
          <button
            style={{
              padding: "12px 20px",
              borderRadius: "8px",
              backgroundColor: "#007BFF",
              color: "white",
              fontSize: "16px",
              border: "none",
              cursor: "pointer",
              transition: "background-color 0.3s",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#007BFF")}
          >
            Add User
          </button>
        </Link>
  
        <Link to={"/update"}>
          <button
            style={{
              padding: "12px 20px",
              borderRadius: "8px",
              backgroundColor: "#6c757d",
              color: "white",
              fontSize: "16px",
              border: "none",
              cursor: "pointer",
              transition: "background-color 0.3s",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#5a6268")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#6c757d")}
          >
            My Profile
          </button>
        </Link>
  
        <button
          onClick={handleLogout}
          style={{
            padding: "12px 20px",
            borderRadius: "8px",
            backgroundColor: "#dc3545",
            color: "white",
            fontSize: "16px",
            border: "none",
            cursor: "pointer",
            transition: "background-color 0.3s",
          }}
          onMouseOver={(e) => (e.target.style.backgroundColor = "#c82333")}
          onMouseOut={(e) => (e.target.style.backgroundColor = "#dc3545")}
        >
          Log Out
        </button>
  
        <Link to={"/change"}>
          <button
            onSubmit={handlepassword}
            type="submit"
            style={{
              padding: "12px 20px",
              borderRadius: "8px",
              backgroundColor: "#28a745",
              color: "white",
              fontSize: "16px",
              border: "none",
              cursor: "pointer",
              transition: "background-color 0.3s",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#218838")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#28a745")}
          >
            Change Password
          </button>
        </Link>
      </div>
  
      <div style={{ width: "100%", marginTop: "20px" }}>
        <DataTable />
      </div>
  
      <Toaster />
    </div>
  );
};

export default Dashboard;
