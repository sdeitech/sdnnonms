import { useEffect, useState } from 'react';
import './App.css';
import StudentForm from './components/StudentForm';
import StudentDetail from './components/StudentDetail';
import StudentList from './components/StudentList';
import axios from 'axios';


function App() {
  const [product, setProduct] = useState([]);
  const [selector, setSelector] = useState(null);
  const [editProduct, setEditProduct] = useState(null);
  // console.log(product, "data")

  useEffect(() => {
    fetchProduct();
  }, []);

  // shows list dynamically
  const fetchProduct = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/result`);
      setProduct(response.data);
      // console.log(response.data, "response")
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const updateProduct = async (productId, updatedData) => {
    try {
      const response = await axios.put(`http://localhost:8080/api/result/${productId}`, updatedData);
      setProduct(prevData =>
        prevData.map(product => (product._id === productId ? response.data : product))
      );
      setEditProduct(null); 
      console.log("Updated student detail:", response.data);
    } catch (error) {
      console.error('Error updating details:', error);
    }
  };


  return (
    <div>

<div className="mt-4">
  <StudentForm
    updateProduct={updateProduct}
    editProduct={editProduct}
    setEditProduct={setEditProduct}
    setProduct={setProduct}
    fetchProduct={fetchProduct}
    // result={result}
  />
      </div>
  <StudentList
    product={product}
    viewProduct={setSelector}
    updateProduct={setEditProduct}
  />
  {selector && <StudentDetail product={selector} />}
    </div>
  );
}

export default App;
