import React from 'react';
import Table from 'react-bootstrap/Table';
import { Button } from "react-bootstrap";

//outputs list of students
const StudentList = ({ product, viewProduct, updateProduct }) => {
    return (
        <div>
            <h2>Product List</h2>
            <Table striped>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>English</th>
                        <th>Maths</th>
                        <th>Science</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {product.length && product.map(product => (
                        <tr key={product._id}>
                            <td>{product.firstName}</td>
                            <td>{product.lastName}</td>
                            <td>{product.email}</td>
                            <td>{product.english}</td>
                            <td>{product.maths}</td>
                            <td>{product.science}</td>
                            <td>
                                <Button className="me-2" onClick={() => viewProduct(product)}>View</Button>
                                <Button className="me-2" onClick={() => updateProduct(product)}>Edit</Button>
                            </td>
                               
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default StudentList;


