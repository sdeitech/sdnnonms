import React from 'react';

//this component outputs detail of student
const StudentDetail = ({ result, product }) => {
  return (
    <>
    <div>
      <h2>Student Detail</h2>
      <p>First Name: {product.firstName}</p>
      <p>Last Name: {product.lastName}</p>
      <p>Email: {product.email}</p>
      <p>English: {product.english}</p>
      <p>Maths: {product.maths}</p>
      <p>Science: {product.science}</p>
        
    </div>

    {/* <div>
    {result.percentage && (
          <div>
            <h3>Result</h3>
            <p>Percentage: {result.percentage}</p>
            <p>Grade: {result.grade} </p>
          </div>
        )}
    </div> */}
    </>
  );
};

export default StudentDetail;