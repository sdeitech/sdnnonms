import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input, FormGroup, Row, Col } from 'reactstrap';
import axios from "axios";
// import StudentDetail from "./StudentDetail";

//form component
function MyForm({ updateProduct, editProduct, setEditProduct, setProduct, fetchProduct }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    english: '',
    maths: '',
    science: ''
  });

  //state stores and updates % and grade
  const [result, setResult] = useState({
    percentage: '',
    grade: ''
  })


  useEffect(() => {
    if (editProduct) {
      setFormData({
        firstName: editProduct.firstName,
        lastName: editProduct.lastName,
        email: editProduct.email,
        english: editProduct.english,
        maths: editProduct.maths,
        science: editProduct.science
      });
    } else {
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        english: '',
        maths: '',
        science: ''
      });
    }
  }, [editProduct]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    calculate();
    if (editProduct) {
      // Update existing student
      updateProduct(editProduct._id, formData);
    } else {
      // Add new student detail
      try {
        const response = await axios.post(`http://localhost:8080/api/createresult`, formData);
        setProduct(prevProduct => [...prevProduct, response.data]);
        console.log(response.data, "submit")
        fetchProduct();  
      } catch (error) {
        console.error("Error adding detail", error);
      }
    }

    // Clear the form and edit state
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      english: '',
      maths: '',
      science: ''
    });
    setEditProduct(null);
  };

  //reset button function
  const handleReset = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      english: '',
      maths: '',
      science: ''
    });
  }



//calculate function to output % and grade
  const calculate = () => {
    let english = document.querySelector("#english").value;
    let maths = document.querySelector("#maths").value;
    let science = document.querySelector("#science").value;
    let grades = "";

  let totalGrades = parseFloat(english) + parseFloat(maths) + parseFloat(science);
  let percentage = (totalGrades / 400) * 100;
  
  if (percentage <= 100 && percentage >= 90) {
    grades = "A";
} else if (percentage <= 90 && percentage >= 80) {
    grades = "B";
} else {
    grades = "C";
}

setResult({
  percentage: percentage.toFixed(2),
  grade: grades
});
}

  return (
    <div>
      <h1>{editProduct ? 'Edit Detail' : 'Add Detail'}</h1>
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="firstName">First Name</Label>
              <Input
                id="firstName"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                type="text"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="lastName">Last Name</Label>
              <Input
                id="lastName"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                type="text"
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="email">Email</Label>
              <Input
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                type="email"
              />
            </FormGroup>
            <FormGroup>
              <Label for="english">English</Label>
              <Input
                id="english"
                name="english"
                value={formData.english}
                onChange={handleInputChange}
                type="number"
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="maths">Maths</Label>
              <Input
                id="maths"
                name="maths"
                value={formData.maths}
                onChange={handleInputChange}
                type="number"
              />
            </FormGroup>
            <FormGroup>
              <Label for="science">Science</Label>
              <Input
                id="science"
                name="science"
                value={formData.science}
                onChange={handleInputChange}
                type="number"
              />
            </FormGroup>
          </Col>
        </Row>
        <Button className="me-2" type="submit">{editProduct ? 'Update Detail' : 'Add Detail'}</Button>
        <Button type="reset" onClick={handleReset}>Reset</Button>

        {/* <StudentDetail  result.percentage/> */}
        
        {result.percentage && (
          <div>
            <h3>Result</h3>
            <p>Percentage: {result.percentage}</p>
            <p>Grade: {result.grade} </p>
          </div>
        )}

      </Form>
    </div>
  );
}

export default MyForm;
