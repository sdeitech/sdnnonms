const Score = require('../models/scoreModel');
const mongoose = require('mongoose');
const sendMail = require('../services/emailService')
const sendMailToStdudents = require('../services/emailService')

//post request to store data in database
// exports.createScore = async(req,res) => {
  
//     if (error) {
//         return res.status(400).json({ error: error.details[0].message });
//     }
//     try{
//         const newScore = new Score(req.body);
//         await newScore.save();


//         const {email,subject, message} = req.body;
//         const htmlContent = `<p>${message}</p>`
//         const result = sendMail(email,subject,htmlContent);

//   if(result){
//     res.status(200).json({message: 'email sent'});
//   } else {
//     res.status(500).json({message: 'failed to send'})
//   }

//         res.status(201).json(newScore);
//     } catch(error){
//         res.status(400).json({error: error.message});
//     }
// }

exports.createScore = async (req, res) => {

    try {

        const { firstName, lastName, email, maths, science, english } = req.body;
        const percentage = (Number(maths)+ Number(science) + Number(english)) / 300 *100
        req.body.percentage = percentage
        if (percentage >= 90) {
            req.body.grade = "A";
          } else if (percentage >= 60 && percentage < 90) {
            req.body.grade = "B";
          } else {
            req.body.grade = "C";
          }

          const student = new Score(req.body);

          const subject = "Your Test Result";
          const text = `Your Final Result is : ${percentage} % with grade  `;
      
          const emailSend = await sendMailToStdudents(email, subject, text);
      
          await student.save();
          res.status(200).json(student);
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

exports.getScore = async(req,res) => {
  
    try{
        const newScore = await Score.find();
        res.json(newScore);
    } catch (error){
        res.status(400).json({error: error.message});
    }
}

exports.getScoreById = async(req,res) => {

    try{
        const newScore = await Score.findById(req.params.id);
        if(!newScore){
            res.status(400).json({error: 'user not found'});
        }
        res.json(newScore);
    } catch(error){
        res.status(400).json({error: error.message});
    }
}

exports.updateScore = async(req,res) => {

    try{
        const newScore = await Score.findByIdAndUpdate(req.params.id, req.body, {new: true});

        if(!newScore){
            return res.status(404).json({error: 'item not found'});
        }
        res.json(newScore);
    } catch(error){
        console.log(error,"error");
        res.status(400).json({error: error.message});
    }
}



// exports.Result = async (req, res) => {
//     try {
//       const { firstName, lastName, email } = req.body;
     
//       const score = await Score.findOne({  firstName, lastName, email  });
//       if (score.length === 0) {
//         console.log("No result Found");
//         return res.status(404).json(errors);
//       }
//       // let AvgMarks = 0;
//       // let TotalScore = Score.english
//       for (let i = 0; i < score.length; i++) {
//         let subject = await Subject.findOne({ subjectCode });
//         let marks = await Marks.findOne({
//           student: student._id,
//           exam: test[i]._id,
//         });
//         if (marks) {
//           let temp = {
//             marks: marks.marks,
//             totalMarks: test[i].totalMarks,
//             subjectName: subject.subjectName,
            
//           };
  
//           result.push(temp);
//         }
//       }
//       res.status(200).json({ result });
//     } catch (error) {
//       res.status(500).json(error);
//     }
//   };