const nodemailer = require("nodemailer") 
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: 'yashgiradkar02@gmail.com',
        pass: 'zavfkehxlrjcnlwy'
    }
})

const sendMailToStdudents = async (to, subject, text) => {
    const mailOptions = {
        from: "yashgiradkar02@gmail.com",
        to: to,
        subject: "Your Final Grade",
        text: text
    }
    try {
        const info = await transporter.sendMail(mailOptions)
        return { status: true }
    } catch (error) {
        return { status: false }
    }
}

module.exports = sendMailToStdudents