const express = require('express');
const bodyParser = require('body-parser');
const port = 8080;
const app = express();
const cors = require('cors');
const scoreRoutes = require('./routes/scoreRoute');
const db = require('./db');

app.use(cors({origin: "*"}));
app.use(bodyParser.json());
app.use('/api',scoreRoutes);

app.listen(port,() => {
    console.log(`app is running on ${port} port`)
});