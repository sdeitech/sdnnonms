// const Joi = require('Joi');

// const validateResult = (data) => {
//     const schema = Joi.object({
//         firstName: Joi.string().required(),
//         lastName: Joi.string(),
//         email: Joi.email().required(),
//         english: Joi.string().required(),
//         maths: Joi.string().required(),
//         science: Joi.string().requried,
//     });

//     return schema.validate(data);
// };

// module.exports = { validateResult };
