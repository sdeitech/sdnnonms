
const config = {
    EMAIL: {
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        user:"yashgiradkar02@gmail.com",
        password: "zavfkehxlrjcnlwy"
    }
}

module.exports = config;