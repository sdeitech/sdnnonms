const express = require('express');
const router = express.Router();
const ScoreController = require('../controllers/scoreController');


router.get('/result', ScoreController.getScore);

router.get('/result/:id', ScoreController.getScoreById);

router.post('/createresult', ScoreController.createScore);

router.put('/result', ScoreController.updateScore);


// router.get('/score', ScoreController.Result)

module.exports = router;