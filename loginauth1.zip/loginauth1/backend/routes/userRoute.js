const express = require('express');
const demo = express.Router();
import {loginWithGoogle} from '../controller/userController'

const Info = require ("../controller/userController")

demo.post('/register',Info.createUser);
demo.post('/login',Info.loginUser)
demo.post('/login-with-google',loginWithGoogle)

module.exports = demo;