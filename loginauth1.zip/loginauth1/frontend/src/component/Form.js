import React, { useState } from 'react';
//import axios from 'axios';
import '../styles/form.css'
import "../component/Form.css"
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';

const CLIENT_ID = "763628572161-o81if92h5m3cp2f9qp51es8kmu88er9b.apps.googleusercontent.com";


const Form = () => {

    const handleLoginSuccess = async (response) => {
        const { credential } = response;
        try {
            const loginResponse = await axios.post('http://localhost:7365/api/userlogin-with-google', { token: credential });
            const { status, data } = loginResponse;

            if (status === 200 && data.token !== undefined && Object.keys(data.token).length) {
                //setUser(data);
                console.log("Login successful", data);
                localStorage.setItem('user_data', JSON.stringify(data));
                // history.push("/");
            }
        } catch (error) {
            console.error('Error during login:', error);
        }
    };

    const handleLoginFailure = (error) => {
        console.log('Login failed', error);
    };



    const [formData, setFormData] = useState({
        Username: '',
        Password: '',
    });
    const [error, setError] = useState(null);
    const navigate = useNavigate()

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const resp = await axios.post("http://localhost:7365/api/login", formData);
            console.log("form data submitted", resp.data)
            navigate("/")

        } catch (err) {
            setError('Login failed. Please check your credentials.');
        }
    };


    return (
        <div className='main-div'>
            <h2>Login</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Username:</label>
                    <input
                        type="username"
                        name="Username"
                        value={formData.Username}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="Password"
                        value={formData.Password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit">Login</button>
                <GoogleOAuthProvider clientId={CLIENT_ID}>
                    <GoogleLogin
                        onSuccess={handleLoginSuccess}
                        onError={handleLoginFailure}
                    />
                </GoogleOAuthProvider>
            </form>
        </div>
    );
};

export default Form;