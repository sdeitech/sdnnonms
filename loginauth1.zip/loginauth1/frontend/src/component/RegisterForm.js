import React,{ useState }  from 'react'
import '../styles/form.css'
import axios from 'axios';

const Register = () =>{

    const [formData, setFormData] = useState({
        Username: '',
        Password: '',
        Role:''
    });
    
    //const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
           const resp = await axios.post("http://localhost:7365/api/register",formData);
           console.log("form data submitted",resp.data)
            
        } catch (err) {
            //setError('Login failed. Please check your credentials.');
        }
    };  
    

    return (
        <div className='main-div'> 
            <h2>Register</h2>
            {/* {error && <p style={{ color: 'red' }}>{error}</p>} */}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Username:</label>
                    <input
                        type="text"
                        name="Username"
                        value={formData.Username}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="Password"
                        value={formData.Password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Role:</label>
                    <input
                        type="text"
                        name="Role"
                        value={formData.Role}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit">Register</button>
            </form>
        </div>
    );
};

export default Register;

