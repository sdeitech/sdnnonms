import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { Connection } from 'mongoose';

@Injectable()
export class MongoConnectionService implements OnModuleInit {
  private readonly logger = new Logger(MongoConnectionService.name);

  constructor(@InjectConnection() private readonly connection: Connection) {}

  async onModuleInit() {
    this.logger.log('MongoConnectionService initialized');

    // Listen to the connection events
    this.connection.on('connected', () => {
      this.logger.log('Successfully connected to MongoDB');
    });

    this.connection.on('error', (error) => {
      this.logger.error('MongoDB connection error:', error);
    });

    this.connection.on('disconnected', () => {
      this.logger.warn('MongoDB connection disconnected');
    });

    // Check the ready state of the connection
    if (this.connection.readyState === 1) {
      // If already connected, log immediately
      this.logger.log('MongoDB is already connected');
    } else {
      // If not connected, wait for the 'connected' event
      this.logger.log('MongoDB connection is being established...');
    }
  }
}
