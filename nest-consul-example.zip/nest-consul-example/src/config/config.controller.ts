import { Controller, Get, Query } from '@nestjs/common';
import { ConsulService } from '../consul/consul.service';

@Controller('config')
export class ConfigController {
  constructor(private readonly consulService: ConsulService) {}

  @Get('key')
  async getKey(@Query('key') key: string): Promise<string> {
    return this.consulService.getKey(key);
  }
}
