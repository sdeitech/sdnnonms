import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConsulService } from './consul/consul.service';
import { ConsulModule } from './consul/consul.module';
import { ConfigController } from './config/config.controller';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports:  [
    ConfigModule.forRoot({
      isGlobal: true, // Make it available throughout the app
    }),
    ConsulModule,
  ],
  controllers: [AppController, ConfigController],
  providers: [AppService, ConsulService],
})
export class AppModule {}



