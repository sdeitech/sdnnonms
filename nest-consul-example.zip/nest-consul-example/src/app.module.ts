import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConsulService } from './consul/consul.service';
import { ConsulModule } from './consul/consul.module';
import { ConfigController } from './config/config.controller';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { StudentModule } from './student/student.module';
import { MongoConnectionService } from './mongoconnection.service';
import { AuthorizationModule } from './authorization/authorization.module';
import { StaticModule } from './static/static.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Make it available throughout the app
    }),
    ConsulModule,
    MongooseModule.forRootAsync({
      imports: [ConsulModule],
      inject: [ConsulService],
      useFactory: async (consul: ConsulService) => {
        const mongoUri = await consul.getKey('mongodb/uri');
        // console.log('MongoDB URI:', mongoUri); // Log URI for debugging
        return {
          uri: mongoUri,
        };
      },
    }),
    StudentModule,
    AuthorizationModule,
    StaticModule,
  ],
  controllers: [AppController, ConfigController],
  providers: [AppService, ConsulService, MongoConnectionService],
})
export class AppModule {}
