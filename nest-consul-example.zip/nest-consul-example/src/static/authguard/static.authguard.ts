import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';

@Injectable()
export class AuthGuard implements CanActivate {
  private readonly logger = new Logger(AuthGuard.name);
  constructor(
    private readonly jwtService: JwtService,
    private readonly consulService: ConsulService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException(
        'Authorization header is missing or invalid',
      );
    }

    const token = authHeader.split(' ')[1]; // Extract token

    // Validate the token
    const jwtSecret = await this.consulService.getKey('JWT_SECRET');
    if (!jwtSecret) {
      throw new UnauthorizedException('JWT secret not found');
    }

    try {
      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw new UnauthorizedException('Invalid token');
      }
      return true; // Token is valid
    } catch (error) {
      if (error instanceof UnauthorizedException) {
        this.logger.warn('UnauthorizedException: Token verification failed');
        throw error;
      } else {
        const typedError = error as Error;
        this.logger.error('Error during token verification', typedError.stack);
        throw new UnauthorizedException('Token verification failed');
      }
    }
  }
}
