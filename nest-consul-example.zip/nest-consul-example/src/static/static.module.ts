import { Module } from '@nestjs/common';
import { StaticService } from './static.service';
import { StaticController } from './static.controller';
import { Statement, StatementSchema } from './schema/static.schema';
import { MongooseModule } from '@nestjs/mongoose';
import { ConsulModule } from 'src/consul/consul.module';
import { JwtModule } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Statement.name, schema: StatementSchema },
    ]),
    ConsulModule,
    JwtModule.registerAsync({
      imports: [ConsulModule],
      useFactory: async (consulService: ConsulService) => {
        const jwtSecret = await consulService.getKey('JWT_SECRET');
        const jwtExpiry = await consulService.getKey('EXPIRES_IN');

        if (!jwtSecret || !jwtExpiry) {
          throw new Error('JWT secret or expiry not found in Consul');
        }

        return {
          secret: jwtSecret,
          signOptions: { expiresIn: jwtExpiry },
        };
      },
      inject: [ConsulService],
    }),
  ],
  providers: [StaticService],
  controllers: [StaticController],
})
export class StaticModule {}
