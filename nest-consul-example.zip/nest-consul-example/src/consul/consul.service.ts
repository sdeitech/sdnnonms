import { Injectable, Logger } from '@nestjs/common';
import Consul from 'consul';

@Injectable()
export class ConsulService {
  private readonly consul: Consul;
  private readonly logger = new Logger(ConsulService.name);

  constructor() {
    this.consul = new Consul({
      host: process.env.CONSUL_HOST || 'localhost',
      port: Number(process.env.CONSUL_PORT) || 8500,
      secure: process.env.CONSUL_SECURE === 'true',
    });
  }

  async getKey(key: string): Promise<string> {
    try {
      const result = await this.consul.kv.get(key);
      if (!result || !result.Value) {
        throw new Error(`Key "${key}" not found`);
      }
      return result.Value.toString(); // Convert from Buffer to string
    } catch (error: unknown) {
      if (error instanceof Error) {
        this.logger.error(`Failed to fetch key "${key}"`, error.stack);  // Now TypeScript knows `error` is an `Error` object
      } else {
        this.logger.error(`Failed to fetch key "${key}"`, 'Unknown error occurred');
      }
      throw error;
    }
  }
}
