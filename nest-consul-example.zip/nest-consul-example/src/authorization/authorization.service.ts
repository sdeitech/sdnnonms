import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './schema/register.schema';
import { RegisterDto } from './dto/register.dto';
import { JwtService } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';

@Injectable()
export class AuthorizationService {
  private readonly logger = new Logger(AuthorizationService.name);
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    private jwtService: JwtService,
    private consulService: ConsulService,
  ) {}

  async registerUser(registerUserDto: RegisterDto): Promise<User> {
    const newUser = new this.userModel(registerUserDto);
    return newUser.save();
  }

  async generateToken(clientId: string, password: number): Promise<string> {
    try {
      // Step 1: Validate client ID and password
      const user = await this.userModel.findOne({ clientId }).exec();
      if (!user || user.password !== password) {
        this.logger.error('Invalid client ID or password');
        throw new UnauthorizedException('Invalid client ID or password');
      }

      // Step 2: Fetch JWT secret and expiry from Consul
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      const jwtExpiry = await this.consulService.getKey('EXPIRES_IN');

      if (!jwtSecret || !jwtExpiry) {
        this.logger.error('JWT credentials are not found in Consul');
        throw new Error('JWT credentials not found');
      }

      // Step 3: Generate a token
      const payload = { clientId: user.clientId }; // Adjust payload as needed
      const token = this.jwtService.sign(payload, {
        secret: jwtSecret,
        expiresIn: jwtExpiry,
      });

      return token;
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error('Error generating token', error.stack); // Properly handle the error type
      } else {
        this.logger.error('Error generating token: Unknown error occurred');
      }
      throw new Error('Failed to generate token');
    }
  }
}
