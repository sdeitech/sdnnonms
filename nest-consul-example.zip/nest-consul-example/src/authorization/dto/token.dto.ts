export class TokenDto {
  clientId: string;
  password: string;
}
