import {
  Body,
  Controller,
  HttpException,
  HttpStatus,
  Logger,
  Post,
} from '@nestjs/common';
import { RegisterDto } from './dto/register.dto';
import { AuthorizationService } from './authorization.service';

@Controller('authorization')
export class AuthorizationController {
  private readonly logger = new Logger(AuthorizationController.name);
  constructor(private readonly authorizationService: AuthorizationService) {}

  @Post('register')
  async register(@Body() registerUserDto: RegisterDto) {
    return this.authorizationService.registerUser(registerUserDto);
  }

  @Post('tokengeneration')
  async generateToken(@Body() body: { clientId: string; password: number }) {
    const { clientId, password } = body;

    try {
      const token = await this.authorizationService.generateToken(
        clientId,
        password,
      );
      return { token };
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error('Error generating token', error.stack); // Properly handle error stack
      } else {
        this.logger.error('Error generating token: Unknown error occurred');
      }

      // Return a meaningful error response
      throw new HttpException(
        'Failed to generate token',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
