import {
  BadRequestException,
  Body,
  Controller,
  HttpException,
  HttpStatus,
  InternalServerErrorException,
  Logger,
  Post,
  UnauthorizedException,
} from '@nestjs/common';
import { RegisterDto } from './dto/register.dto';
import { AuthorizationService } from './authorization.service';
import { ERROR_MESSAGES } from 'src/constants/constants';

@Controller('authorization')
export class AuthorizationController {
  private readonly logger = new Logger(AuthorizationController.name);
  constructor(private readonly authorizationService: AuthorizationService) {}

  @Post('register')
  async register(@Body() registerUserDto: RegisterDto) {
    return this.authorizationService.registerUser(registerUserDto);
  }

  @Post('tokengeneration')
  async generateToken(@Body() body: { clientId: string; password: number }) {
    const { clientId, password } = body;

    try {
      const token = await this.authorizationService.generateToken(
        clientId,
        password,
      );
      return { token };
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error(ERROR_MESSAGES.TOKEN_GENERATION_FAILED, error.stack);
      } else {
        this.logger.error(ERROR_MESSAGES.UNKNOWN_ERROR);
      }

      throw new HttpException(
        ERROR_MESSAGES.TOKEN_GENERATION_FAILED,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Post('verify-token')
  async verifyToken(@Body('token') token: string): Promise<{ valid: boolean }> {
    if (!token) {
      this.logger.warn(ERROR_MESSAGES.TOKEN_MISSING);
      throw new BadRequestException(ERROR_MESSAGES.TOKEN_MISSING);
    }

    try {
      const isValid = await this.authorizationService.verifyToken(token);
      return { valid: isValid };
    } catch (error) {
      this.logger.error(ERROR_MESSAGES.TOKEN_VERIFY_FAILED, error);

      if (error instanceof UnauthorizedException) {
        throw new UnauthorizedException(
          ERROR_MESSAGES.TOKEN_INVALID_OR_EXPIRED,
        );
      }

      throw new InternalServerErrorException(ERROR_MESSAGES.UNKNOWN_ERROR);
    }
  }
}
