import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Res,
  HttpException,
} from '@nestjs/common';
import { CreateStudentDto } from 'src/student/create-student.dto';
import { UpdateStudentDto } from 'src/student/update-student.dto';
import { StudentService } from 'src/student/student.service';

@Controller('student')
export class StudentController {
  constructor(private readonly studentService: StudentService) {}

  @Post()
  async createStudent(
    @Res() response,
    @Body() createStudentDto: CreateStudentDto,
  ) {
    try {
      const newStudent =
        await this.studentService.createStudent(createStudentDto);
      return response.status(HttpStatus.CREATED).json({
        message: 'Student has been created successfully',
        newStudent,
      });
    } catch (err) {
      // Check if the error is an instance of HttpException
      if (err instanceof HttpException) {
        return response.status(err.getStatus()).json(err.getResponse());
      } else {
        // Handle non-HttpException errors (e.g., server errors, etc.)
        return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: 500,
          message: 'Unexpected error occurred!',
          error: 'Internal Server Error',
        });
      }
    }
  }

  @Put('/:id')
  async updateStudent(
    @Res() response,
    @Param('id') studentId: string,
    @Body() updateStudentDto: UpdateStudentDto,
  ) {
    try {
      const existingStudent = await this.studentService.updateStudent(
        studentId,
        updateStudentDto,
      );
      return response.status(HttpStatus.OK).json({
        message: 'Student has been successfully updated',
        existingStudent,
      });
    } catch (err) {
      // Check if the error is an instance of HttpException
      if (err instanceof HttpException) {
        return response.status(err.getStatus()).json(err.getResponse());
      } else {
        // Handle non-HttpException errors (e.g., server errors, etc.)
        return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: 500,
          message: 'Unexpected error occurred!',
          error: 'Internal Server Error',
        });
      }
    }
  }

  @Get('/get')
  async getStudents(@Res() response) {
    try {
      const studentData = await this.studentService.getAllStudents();
      return response.status(HttpStatus.OK).json({
        message: 'All students data found successfully',
        studentData,
      });
    } catch (err) {
      // Check if the error is an instance of HttpException
      if (err instanceof HttpException) {
        return response.status(err.getStatus()).json(err.getResponse());
      } else {
        // Handle non-HttpException errors (e.g., server errors, etc.)
        return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: 500,
          message: 'Unexpected error occurred!',
          error: 'Internal Server Error',
        });
      }
    }
  }

  @Get('/:id')
  async getStudent(@Res() response, @Param('id') studentId: string) {
    try {
      const existingStudent = await this.studentService.getStudent(studentId);
      return response.status(HttpStatus.OK).json({
        message: 'Student found successfully',
        existingStudent,
      });
    } catch (err) {
      // Check if the error is an instance of HttpException
      if (err instanceof HttpException) {
        return response.status(err.getStatus()).json(err.getResponse());
      } else {
        // Handle non-HttpException errors (e.g., server errors, etc.)
        return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: 500,
          message: 'Unexpected error occurred!',
          error: 'Internal Server Error',
        });
      }
    }
  }

  @Delete('/:id')
  async deleteStudent(@Res() response, @Param('id') studentId: string) {
    try {
      const deletedStudent = await this.studentService.deleteStudent(studentId);
      return response.status(HttpStatus.OK).json({
        message: 'Student deleted successfully',
        deletedStudent,
      });
    } catch (err) {
      // Check if the error is an instance of HttpException
      if (err instanceof HttpException) {
        return response.status(err.getStatus()).json(err.getResponse());
      } else {
        // Handle non-HttpException errors (e.g., server errors, etc.)
        return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: 500,
          message: 'Unexpected error occurred!',
          error: 'Internal Server Error',
        });
      }
    }
  }
}
