from django.urls import path
from . import views

urlpatterns = [
        path('', views.Register.as_view(),name='register'),
        path('login/', views.Login.as_view(),name='login'),
        path('logout/',views.Logout.as_view(),name="logout"),  
        path('index/', views.Index.as_view(),name='index'),
        path('story/', views.story.as_view(),name='story'),
        path('products/', views.products.as_view(),name='products'),
        path('contact/', views.contact.as_view(),name='contact'),
        path('faqs/', views.faqs.as_view(),name='faqs'),
]
