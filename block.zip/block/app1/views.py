from django.shortcuts import render,redirect
from django.views import View
# from .models import Employee
# from django.core.paginator import Paginator
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_control
from django.contrib.auth.decorators import login_required,permission_required
from django.contrib import messages
User = get_user_model()

class Register(View):
    def get(self, request):
        return render(request,'register.html')
    
    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        age = request.POST.get('age')
        
        if User.objects.filter(email = email).exists():
            print("email already exist")
            messages.error(request,f"email exist")
            
        elif User.objects.filter(username = username).exists():
            print("username already exist")
            messages.error(request,f"username exist")   
            
        else:  
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                first_name=first_name,
                last_name=last_name,
                mobile=mobile_number,
                age=age
            )
            print("Registration succed please login")
            messages.success(request,"registration succed please login")
            return redirect("register")
        
   
        
        return render(request,"register.html")
    
class Login(View):
    def get(self, request):
        return render(request,'login.html')    
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not User.objects.filter(username=username).exists():
            return redirect("register")
        user = authenticate(username=username,password=password)
        print(user,"adsbndsbnbdns")
        
        
        if user is not None:
            login(request,user)
            return redirect("index")
        else:
            # print("username")
            return redirect("register")
        
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("register")         
        
# @method_decorator        
class Index(View):
    @method_decorator(login_required)
    # @cache_control(no_cache=True, must_revalidate=True, no_store=True)
    def get(self, request):
        return render(request,'index.html')
    
    
class story(View):
    def get(self, request):
        return render(request,'story.html')
    
class products(View):
    def get(self, request):
        return render(request,'products.html')        
    
    
class contact(View):
    def get(self, request):
        return render(request,'contact.html')        


class faqs(View):
    def get(self, request):
        return render(request,'faqs.html')        