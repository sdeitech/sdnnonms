from django.shortcuts import render,redirect
from django.views import View
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_control
from django.contrib.auth.decorators import login_required,permission_required
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.utils import timezone
from .models import ResetUuid
from django.core.mail import send_mail
from block import settings
from datetime import timedelta
import uuid , random , datetime          
User = get_user_model()


class Register(View):
    def get(self, request):
        return render(request,'register.html')
    
    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        age = request.POST.get('age')
        
        if User.objects.filter(email = email).exists():
            print("email already exist")
            messages.error(request,f"email exist")
            
        elif User.objects.filter(username = username).exists():
            print("username already exist")
            messages.error(request,f"username exist")   
            
        else:  
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                first_name=first_name,
                last_name=last_name,
                mobile=mobile_number,
                age=age
            )
            print("Registration succed please login")
            messages.success(request,"registration succed please login")
            return redirect("register")
        
   
        
        return render(request,"register.html")
    
    
    
class Login(View):
    def get(self, request):
        return render(request,'login.html')    
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not User.objects.filter(username=username).exists():
            return redirect("register")
        
        user = authenticate(username=username,password=password)
        print(user,"adsbndsbnbdns")
        
        
        if user is not None:
            
            login(request,user)
            return redirect("index")
        else:
            # print("username")
            return redirect("register")
  
    
    
class ForgotPassword(View):
    def get(self, request):
        return render(request, "forgot_password.html")

    def post(self, request):
        email = request.POST.get('email')
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email) 
             
            exp_date = datetime.datetime.now() + datetime.timedelta(hours=2) 
            # uuid_data = uuid.uuid1(random.randint [0,281474976710655])
            uuid_data = uuid.uuid4()  # Generate a random UUID
            
            forgot = ResetUuid.objects.create(UUID = uuid_data , user=user , expiry = exp_date)
            
            url = f"{settings.SITE_URL}/reset-password/{forgot.UUID}"
          
            
            if email:
                subject = "Password Reset Request"
                message = (
                    "To reset your password click the link below to get started \n"
                    f"reset your password \n\t{url}"
                )  
                
                try:
                    send_mail(subject,message,settings.EMAIL_HOST_USER,[email])
                    print(
                        f"\nSubject = {subject}\nmessage = {settings.EMAIL_HOST_USER}\nmail ={email} "
                        
                    )
                    
                    return redirect("/")
                except Exception as e:
                    return render(request,"forgot_password.html")
                
            else:
                return render(request,"forgot_password.html")    
                
        else:
            print(f"Invalid email address {email}")
        return render(request,"forgot_password.html")        
           


class ResetPassword(View):
    def get(self, request, uuid):
        print(f"UUID received: {uuid}")
        context = {"uuid": uuid}
        return render(request, "reset_password.html", context)

    def post(self, request, uuid):
        new_password = request.POST.get('newpassword')
        confirm_password = request.POST.get('confirmpassword')
        
        print(new_password, confirm_password)
        
        current_date_time = datetime.datetime.now()
        
        try:
            obj = ResetUuid.objects.get(UUID=uuid)
            print(obj, "obj")
        except ResetUuid.DoesNotExist:
            messages.error(request, "Invalid or expired link.")
            return redirect("/")

        user = obj.user
        current_time = current_date_time.astimezone(timezone('UTC'))
        
        if current_time < obj.expiry and new_password == confirm_password:
            user.set_password(new_password)
            user.save()
            messages.success(request, "Your password has been changed successfully.")
            return redirect("/")
        else:
            messages.error(request, "The link has expired or passwords do not match.")
            return redirect("/")
  
    
class changePassword(View):
    def get(self,request):
        return render(request,"change_password.html")    
            
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("register")   


        
                
        
# @method_decorator        
class Index(View):
    @method_decorator(login_required)
    # @cache_control(no_cache=True, must_revalidate=True, no_store=True)
    def get(self, request):
        return render(request,'index.html')
    
    
class story(View):
    def get(self, request):
        return render(request,'story.html')
    
class products(View):
    def get(self, request):
        return render(request,'products.html')        
    
    
class contact(View):
    def get(self, request):
        return render(request,'contact.html')        


class faqs(View):
    def get(self, request):
        return render(request,'faqs.html')        
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        age = request.POST.get('age')
        
        if User.objects.filter(email = email).exists():
            print("email already exist")
            messages.error(request,f"email exist")
            
        elif User.objects.filter(username = username).exists():
            print("username already exist")
            messages.error(request,f"username exist")   
            
        else:  
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                first_name=first_name,
                last_name=last_name,
                mobile=mobile_number,
                age=age
            )
            print("Registration succed please login")
            messages.success(request,"registration succed please login")
            return redirect("register")
        
   
        
        return render(request,"register.html")
    
    
    
class Login(View):
    def get(self, request):
        return render(request,'login.html')    
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not User.objects.filter(username=username).exists():
            return redirect("register")
        
        user = authenticate(username=username,password=password)
        print(user,"adsbndsbnbdns")
        
        
        if user is not None:
            
            login(request,user)
            return redirect("index")
        else:
            # print("username")
            return redirect("register")
  
    
    
class ForgotPassword(View):
    def get(self, request):
        return render(request, "forgot_password.html")

    def post(self, request):
        email = request.POST.get('email')
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email) 
             
            exp_date = datetime.datetime.now() + datetime.timedelta(hours=2) 
            # uuid_data = uuid.uuid1(random.randint [0,281474976710655])
            uuid_data = uuid.uuid4()  # Generate a random UUID
            
            forgot = ResetUuid.objects.create(UUID = uuid_data , user=user , expiry = exp_date)
            
            url = f"{settings.SITE_URL}/reset-password/{forgot.UUID}"
            
            if email:
                subject = "Password Reset Request"
                message = (
                    "To reset your password click the link below to get started \n"
                    f"reset your password \n\t{url}"
                )  
                
                try:
                    send_mail(subject,message,settings.EMAIL_HOST_USER,[email])
                    print(
                        f"\nSubject = {subject}\nmessage = {settings.EMAIL_HOST_USER}\nmail ={email} "
                        
                    )
                    
                    return redirect("/")
                except Exception as e:
                    return render(request,"forgot_password.html")
                
            else:
                return render(request,"forgot_password.html")    
                
        else:
            print(f"Invalid email address {email}")
        return render(request,"forgot_password.html")        
           
        
from pytz import timezone           
class ResetPassword(View):
    def get(self, request, uuid):
        print(f"UUID received: {uuid}")
        
        context = {"uuid":uuid}
        return render(request,"reset_password.html",context)

    def post(self, request, uuid):
            new_password = request.POST.get('newpassword')
            confirm_password = request.POST.get('confirmpassword')
            
            print(new_password,confirm_password)
            
            current_date_time = datetime.datetime.now()
            
            obj = ResetUuid.objects.get(UUID = uuid)
            print(obj,"obj")
            
            user = obj.user
            current_time = current_date_time.astimezone(timezone('UTC'))
            
            if current_time < obj.expiry and new_password==confirm_password:
                user.set_password(new_password)
                user.save()
                return redirect("/")
            
            else:
                print("Link expired")
                return redirect("/")
  
    
class changePassword(View):
    def get(self,request):
        return render(request,"change_password.html")    
            
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("register")   


        
                
        
# @method_decorator        
class Index(View):
    @method_decorator(login_required)
    # @cache_control(no_cache=True, must_revalidate=True, no_store=True)
    def get(self, request):
        return render(request,'index.html')
    
    
class story(View):
    def get(self, request):
        return render(request,'story.html')
    
class products(View):
    def get(self, request):
        return render(request,'products.html')        
    
    
class contact(View):
    def get(self, request):
        return render(request,'contact.html')        


class faqs(View):
    def get(self, request):
        return render(request,'faqs.html')        