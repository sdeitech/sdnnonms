from django.shortcuts import render,redirect
from django.views import View
# from .models import Employee
# from django.core.paginator import Paginator
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_control
from django.contrib.auth.decorators import login_required,permission_required
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.utils import timezone
from .models import ResetUuid
from django.core.mail import send_mail
import uuid
from datetime import timedelta
User = get_user_model()

class Register(View):
    def get(self, request):
        return render(request,'register.html')
    
    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        age = request.POST.get('age')
        
        if User.objects.filter(email = email).exists():
            print("email already exist")
            messages.error(request,f"email exist")
            
        elif User.objects.filter(username = username).exists():
            print("username already exist")
            messages.error(request,f"username exist")   
            
        else:  
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                first_name=first_name,
                last_name=last_name,
                mobile=mobile_number,
                age=age
            )
            print("Registration succed please login")
            messages.success(request,"registration succed please login")
            return redirect("register")
        
   
        
        return render(request,"register.html")
    
    
    
class Login(View):
    def get(self, request):
        return render(request,'login.html')    
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not User.objects.filter(username=username).exists():
            return redirect("register")
        
        user = authenticate(username=username,password=password)
        print(user,"adsbndsbnbdns")
        
        
        if user is not None:
            
            login(request,user)
            return redirect("index")
        else:
            # print("username")
            return redirect("register")
  
    
    
class ForgotPassword(View):
    def get(self, request):
        return render(request, "forgot_password.html")

    def post(self, request):
        email = request.POST.get('email')
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)       
            # Generate a unique reset token (UUID) and set expiry time (e.g., 1 hour)
            reset_token = ResetUuid.objects.create(
                user=user,
                expiry=timezone.now() + timedelta(hours=1)
            )
            
            # Generate the reset password URL
            reset_url = f"{request.scheme}://{request.get_host()}/reset-password/{reset_token.UUID}/"
            
            # Send the reset link via email (You can customize this part as needed)
            subject = 'Password Reset Request'
            message = f'Click the following link to reset your password: {reset_url}'
            from_email = 'your-email@example.com'  # Update with your sender email
            send_mail(subject, message, from_email, [email])

            messages.success(request, "Password reset link has been sent to your email.")
        else:
            messages.error(request, "No account found with that email address.")
        
        return redirect('forgotpassword')
        
           
class ResetPassword(View):
    def get(self, request, uuid):
        # Check if the token exists and is not expired
        reset_token = ResetUuid.objects.filter(UUID=uuid).first()

        if reset_token and not reset_token.is_expired():
            return render(request, 'reset_password.html', {'uuid': uuid})  # Render reset form with token
        else:
            messages.error(request, "The password reset link is invalid or expired.")
            return redirect('forgotpassword')

    def post(self, request, uuid):
        # Fetch the token and validate it
        reset_token = ResetUuid.objects.filter(UUID=uuid).first()

        if reset_token and not reset_token.is_expired():
            # Retrieve new password from POST data
            new_password = request.POST.get('newpassword')
            confirm_password = request.POST.get('confirmpassword')

            # Validate if the new passwords match
            if new_password != confirm_password:
                messages.error(request, "Passwords do not match.")
                return render(request, 'reset_password.html', {'uuid': uuid})

            # Update the user's password
            user = reset_token.user
            user.password = make_password(new_password)  # Hash the password before saving
            user.save()

            # Delete the reset token as it's no longer needed
            reset_token.delete()

            messages.success(request, "Your password has been reset successfully!")
            return redirect('login')  # Redirect to login page after successful reset
        else:
            messages.error(request, "The password reset link is invalid or expired.")
            return redirect('forgotpassword')    
    
class changePassword(View):
    def get(self,request):
        return render(request,"change_password.html")    
            
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("register")   


        
                
        
# @method_decorator        
class Index(View):
    @method_decorator(login_required)
    # @cache_control(no_cache=True, must_revalidate=True, no_store=True)
    def get(self, request):
        return render(request,'index.html')
    
    
class story(View):
    def get(self, request):
        return render(request,'story.html')
    
class products(View):
    def get(self, request):
        return render(request,'products.html')        
    
    
class contact(View):
    def get(self, request):
        return render(request,'contact.html')        


class faqs(View):
    def get(self, request):
        return render(request,'faqs.html')        