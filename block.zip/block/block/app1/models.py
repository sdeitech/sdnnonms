
from django.contrib.auth.models import AbstractUser,AbstractBaseUser
from django.db import models

# Create your models here.
class CustomUser(AbstractUser):
    mobile = models.CharField(max_length=10)
    age = models.CharField(max_length=10)
    
    def __str__(self):
        return self.username
    
class ResetUuid(models.Model):
    UUID = models.UUIDField(unique=True)
    user = models.ForeignKey(CustomUser,on_delete=models.CASCADE)
    expiry = models.DateTimeField()    
    
    