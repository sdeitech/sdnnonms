import { MESSAGE, STATUS_CODE } from "../config/constants"
import jwt from "jsonwebtoken"

export const verifyToken = (req, res, next) => {
    const token = req.headers["authorization"];

    if (!token) {
        return res.status(STATUS_CODE.FORBIDDETN).json({ message: MESSAGE.NOT_ATHORIZED })
    }

    try {
        const verifiedToken = jwt.verify(token, "KEY")
        if (verifiedToken) {
            next()
            // return res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.AUTHORIZED })
        }
    } catch (error) {
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })

    }
}