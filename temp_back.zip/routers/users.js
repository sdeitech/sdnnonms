import express from "express"
import { getUsers, registerUser, updateUser, userLogin } from "../controllers/users"
import { uploadMiddleware } from "../helpers/multer"
import { addUser } from "../controllers/subusers"
import { verifyToken } from "../middlewares/veryfyToken"
import bodyParser from "body-parser"
import { googleAuth } from "../controllers/googleAuth"
const userRouter = express.Router()

var urlencodedParser = bodyParser.urlencoded({ extended: false })

userRouter.post("/signup", uploadMiddleware, registerUser)
userRouter.post("/signin", userLogin)
userRouter.post("/user/:id", verifyToken, addUser)
userRouter.get("/user/:id", verifyToken, getUsers)
userRouter.put("/update/:id", uploadMiddleware, verifyToken, updateUser)
userRouter.post("/google/auth", googleAuth)



export default userRouter