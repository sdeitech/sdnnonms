import mongoose from "mongoose";
const Schema = mongoose.Schema

const UserSchema = new Schema({
    firstName: {
        type: String,
        trim: true,
        required: true
    },
    lastName: {
        type: String,
        trim: true,
        required: true
    },
    email: {
        type: String,
        trim: true,
        required: true
    },
    DOB: {
        type: Date,
        trim: true,
    },
    profile: {
        type: String,
    },
    
    google_img: {
        type: String
    },
    password: {
        type: String,
        trim: true,
        required: true
    },
    isMarried: {
        type: Boolean,
        trim: true,
        default: false
    },
    gender: {
        type: String,
        trim: true,
        enum: ["male", "female"],
    },
    users: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "subusers"
        }
    ]
    },
    {
        timestamps: true
    })

const Users = mongoose.model("users", UserSchema)
export default Users