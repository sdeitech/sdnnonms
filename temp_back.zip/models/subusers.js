import mongoose from "mongoose";
const Schema = mongoose.Schema

const SubUserSchema = new Schema({
    firstName: {
        type: String,
        trim: true,
        required: true
    },
    lastName: {
        type: String,
        trim: true,
        required: true
    },
    email: {
        type: String,
        trim: true,
        required: true
    }
    },
    {
        timestamps: true
    })

const Subusers = mongoose.model("subusers", SubUserSchema)
export default Subusers