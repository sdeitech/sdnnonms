const config = {
    local: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserManagement",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3002
    },
    stage: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserManagement",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3002
    },
    prod: {
        DB: {
            HOST: "",
            DB_PORT: 27017,
            DB_NAME: "UserManagement",
            USERNAME: "",
            PASSWORD: ""
        },
        API_PORT: 3002
    }
}

export default config