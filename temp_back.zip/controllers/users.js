import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"
import Users from "../models/users";
import { MESSAGE, STATUS_CODE } from "../config/constants";
import { sendMail } from "../helpers/nodeMailter"


// register user
export const registerUser = async (req, res) => {
    console.log(`register user`)
    try {
        // extracting filename
        const profile = req.file?.filename

        const { firstName, lastName, email, DOB, password, isMarried, gender } = req.body
        if (!firstName || !lastName || !email || !DOB || !password || !isMarried || !gender || !profile) {
            return res.status(STATUS_CODE.BAD_REQ).json({ message: MESSAGE.ALL_FILEDS_REQ })
        }

        const userExist = await Users.findOne({ email: email })

        if (userExist) {
            return res.status(STATUS_CODE.FORBIDDETN).json({ message: MESSAGE.ALREDY_EXISTS })
        }

        const hashedPassword = await bcrypt.hash(password, 10)

        const user = new Users({
            firstName,
            lastName,
            email,
            DOB,
            profile: profile,
            password: hashedPassword,
            isMarried,
            gender
        })

        const saved = await user.save()

        let text = `Hey ${firstName}
                    Your credentials are below
                    ID: ${email}
                    PASSWORD : ${password}`

        const EmailToUser = await sendMail(email, text)
        console.log(EmailToUser)

        res.status(STATUS_CODE.NEW_CREATED).json({ message: MESSAGE.USER_REGISTER, user: saved })

    } catch (error) {
        console.log(`Error while registering user ${error.message}`)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}

// login user
export const userLogin = async (req, res) => {
    try {
        const { email, password } = req.body
        if (!email || !password) {
            return res.status(STATUS_CODE.BAD_REQ).json({ message: MESSAGE.ALL_FILEDS_REQ })
        }

        const user = await Users.findOne({ email: email })
        console.log(user)

        if (!user) {
            return res.status(STATUS_CODE.NOT_FOUND).json({ message: MESSAGE.USER_NOT_FOUND })
        }

        const isMatch = await bcrypt.compare(password, user.password)
        console.log(isMatch)

        if (!isMatch) {
            return res.status(STATUS_CODE.FORBIDDETN).json({ message: MESSAGE.INVALID_CREDENTIALS })
        }

        const token = jwt.sign({ email, password }, "KEY", { expiresIn: "5hr" })
        if (isMatch) {
            return res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.LOGGEDIN, id: user._id, token: token })
        }

    } catch (error) {
        console.log(`Error while logging user ${error.message}`)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}


export const getUsers = async (req, res) => {
    try {
        const { search = "", page = 1, limit = 10 } = req.query;

        let pageNo = Number(page)
        let pageLimit = Number(limit)
        let skip = (pageNo - 1) * pageLimit

        const user = await Users.findById(req.params.id)

        if (!user) {
            return res.status(STATUS_CODE.NOT_FOUND).json({ message: MESSAGE.USER_NOT_FOUND })
        }
        const userDetails = await Users.findById(req.params.id).populate({
            path: "users",
            match: search.trim() ? { firstName: { $regex: search.trim(), $options: "i" } } : {},
            options: {
                skip: skip,
                limit: pageLimit,
            }
        })

        const userInfo = {
            firstName: userDetails?.firstName,
            lastName: userDetails?.lastName,
            email: userDetails?.email,
            gender: userDetails?.gender,
            isMarried: userDetails?.isMarried,
            DOB: userDetails?.DOB
        }

        const subUsers = userDetails?.users
        const totalRecord = user.users.length
        const totalPages = Math.ceil(totalRecord / pageLimit)
        // res.status(STATUS_CODE.SUCCESS).json({ user: userDetails, totalPages: totalPages, pageNo: pageNo })

        const pagination = {
            totalPages: totalPages,
            pageNo: pageNo
        }

        res.status(STATUS_CODE.SUCCESS).json({ userInfo: userInfo, subUsers: subUsers, pagination: pagination })

    } catch (error) {
        console.log(`Error while getting user ${error.message}`)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}

export const updateUser = async (req, res) => {
    // const profile = req.file.filename
    const profile = req.file?.filename

    const { firstName, lastName, email, DOB, password, isMarried, gender } = req.body

    try {
        const user = await Users.findByIdAndUpdate(req.params.id, {
            firstName: firstName,
            lastName: lastName,
            email: email,
            DOB: DOB,
            isMarried: isMarried,
            gender: gender,
            profile: profile

        }, { new: true })
        // console.log(user)
        if (!user) {
            return res.status(STATUS_CODE.NOT_FOUND).json({ message: MESSAGE.USER_NOT_FOUND })
        }
        user.save()
        res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.USER_UPDATED })

    } catch (error) {
        console.log(`Error while getting user ${error.message}`)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}