import { OAuth2Client } from "google-auth-library"
import jwt from "jsonwebtoken"
import { STATUS_CODE, MESSAGE } from "../config/constants"
import Users from "../models/users"
const client_id = `368841272750-bsgr39djulkqk32p6utco69sqsjj83mc.apps.googleusercontent.com`
const client = new OAuth2Client(client_id)

export const googleAuth = async (req, res) => {
    try {
        const { token } = req.body

        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: client_id,
            requiredAudience: client_id
        })
        console.log(ticket)

        const payload = ticket?.payload
        const email = payload?.email
        const pass = payload?.sub
        const firstName = payload?.given_name
        const lastName = payload?.family_name
        const profile = payload?.picture
        // const profile = payload.

        // console.log(email, pass)
        // // console.log(ticket)

        const existUser = await Users.findOne({ email: email })
        const tokenauth = jwt.sign({ email, pass }, "KEY", { expiresIn: "5hr" })


        if (existUser) {
            return res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.LOGGEDIN, id: existUser._id, token: tokenauth })
        }

        const user = new Users({
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: pass,
            google_img: profile,
            profile: ""

        })

        const data = await user.save()

        return res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.LOGGEDIN, id: data._id, token: tokenauth })


    } catch (error) {
        console.log(error.message)
    }
}