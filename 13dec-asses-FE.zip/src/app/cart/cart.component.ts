import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})

export class CartComponent implements OnInit {
  cart: Product[] = [];
  totalPrice: number = 0;
  discount: number = 0;
  finalPrice: number = 0;
  couponCode: string = '';
  validCoupons: string[] = ['DISCOUNT10'];
  cartCount: number = 0;


  ngOnInit() {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]');
    this.calculateTotal();

  }

  removeFromCart(product: Product) {
    this.cart = this.cart.filter(item => item.id !== product.id);
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  clearCart() {
    this.cart = [];
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  getimagepath(path:string){
    return 'http://127.0.0.1:8000'+path

  }


  calculateTotalPrice(): void {
    this.totalPrice = this.cart.reduce((total, product) => total + product.price, 0);
    this.finalPrice = this.totalPrice - this.discount;
  }

  calculateTotal() {
    this.totalPrice = this.cart.reduce((total, product) => total + product.price, 0);
    this.finalPrice = this.totalPrice - this.discount;  // Apply any discount
  }

  applyCoupon() {
    if (this.validCoupons.includes(this.couponCode)) {
      this.discount = this.totalPrice * 0.1;  // 10% discount
      this.calculateTotal();
      Swal.fire({
        title: 'Coupon Applied!',
        text: 'You have received a 10% discount.',
        icon: 'success',
      });
    } else {
      Swal.fire({
        title: 'Invalid Coupon',
        text: 'The coupon code you entered is invalid.',
        icon: 'error',
      });
    }
  }

}
