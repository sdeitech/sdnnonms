// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { CartComponent } from './cart.component';

// describe('CartComponent', () => {
//   let component: CartComponent;
//   let fixture: ComponentFixture<CartComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [CartComponent]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(CartComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });













import { Component, OnInit, ChangeDetectorRef } from '@angular/core';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: Product[] = [];
  totalPrice: number = 0;
  discount: number = 0;
  finalPrice: number = 0;

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    // Load cart from localStorage and calculate total price
    const storedCart = localStorage.getItem('cart');
    this.cart = JSON.parse(storedCart || '[]');
    this.calculateTotalPrice();
  }

  removeFromCart(product: Product) {
    this.cart = this.cart.filter(item => item.id !== product.id);
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.calculateTotalPrice();
  }

  clearCart() {
    this.cart = [];
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.calculateTotalPrice();
  }

  getimagepath(path: string): string {
    return 'http://127.0.0.1:8000' + path;
  }

  calculateTotalPrice(): void {
    this.totalPrice = this.cart.reduce((total, product) => total + product.price, 0);
    this.finalPrice = this.totalPrice - this.discount;
    this.cdr.detectChanges(); // Ensure the view updates
  }
}
