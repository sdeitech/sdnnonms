import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  imageUrl: string = 'https://images.pexels.com/photos/28891887/pexels-photo-28891887/free-photo-of-sleek-mercedes-benz-parked-at-modern-dealership.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1';
  welcomeMessage: string = 'Welcome to our website!';

}

