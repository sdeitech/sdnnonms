import "../../App.css";
import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/ReactToastify.css";
import { URLs } from "../constants/urlConstants";

const SignUp = () => {
  const [inputPara, setInputPara] = useState({
    firstName: "",
    lastName: "",
    email: "",
    dob: "",
    marriedStatus: false,
    gender: "",
    password: "",
  });
  const navigate = useNavigate();

  const onChangeHandle = (e) => {
    const { name, value, type, checked } = e.target;

    setInputPara((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const createUserHandle = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(URLs.AXIOS_GET, inputPara);
      localStorage.setItem("token", response.data?.token);
      toast.success("Successfully Registered....");
      navigate("/dashboard");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div>
        <h2 className="App-header">SignUp Form</h2>
      </div>
      <ToastContainer />
      <div>
        <form className="Show-body" onSubmit={createUserHandle}>
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter First Name"
            name="firstName"
            onChange={onChangeHandle}
            required
          />
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter Last Name"
            name="lastName"
            onChange={onChangeHandle}
            required
          />
          <input
            className="w3-input w3-border"
            type="email"
            placeholder="Enter email"
            pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$"
            name="email"
            onChange={onChangeHandle}
            required
          />
          <input
            className="w3-input w3-border"
            type="date"
            placeholder="Enter Date of Birth"
            name="dob"
            onChange={onChangeHandle}
            required
          />

          <input
            type="checkbox"
            label="Married"
            name="marriedStatus"
            checked={inputPara.marriedStatus}
            onChange={onChangeHandle}
          />
          <label>Married</label>
          <br />

          <select
            type="select"
            name="gender"
            className="form-control"
            onChange={onChangeHandle}
          >
            <option>Select Gender</option>
            <option>male</option>
            <option>female</option>
            <option>other</option>
          </select>

          <input
            className="w3-input w3-border"
            type="password"
            placeholder="Enter Password"
            name="password"
            onChange={onChangeHandle}
            required
          />
          <button type="submit">Submit</button>
          <Link to="/">Already User?</Link>
        </form>
      </div>
    </>
  );
};

export default SignUp;
