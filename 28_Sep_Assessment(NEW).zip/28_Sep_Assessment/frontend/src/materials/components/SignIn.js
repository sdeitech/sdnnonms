import axios from "axios";
import "../../App.css";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { URLs } from "../constants/urlConstants";

const SignIn = () => {
  const [inputPara, setInputPara] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  const onChangeHandle = (e) => {
    setInputPara({ ...inputPara, [e.target.name]: e.target.value });
  };

  const loginHandle = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(URLs.AXIOS_POST_LOGIN, inputPara);
      localStorage.setItem("token", result.data?.token);
      toast.success("WARM WELCOME!!");
      navigate("/Dashboard");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <div>
        <h2 className="App-header">SignIn Form</h2>
      </div>
      <ToastContainer />
      <div>
        <form className="Show-body" onSubmit={loginHandle}>
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter email"
            name="email"
            onChange={onChangeHandle}
            required
          />
          <input
            className="w3-input w3-border"
            type="password"
            placeholder="Enter Password"
            name="password"
            onChange={onChangeHandle}
            required
          />
          <button type="submit">Submit</button>
          <Link to="/signup">Not a User?</Link>
        </form>
      </div>
    </>
  );
};

export default SignIn;
