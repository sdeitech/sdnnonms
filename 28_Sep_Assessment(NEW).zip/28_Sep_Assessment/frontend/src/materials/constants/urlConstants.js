export const URLs = {
  // For Main Model
  AXIOS_GET_POST: "http://localhost:5000/user/api",
  AXIOS_POST_LOGIN: "http://localhost:5000/user/api/login",
  AXIOS_PUT: "http://localhost:5000/user/api/getReport",
  AXIOS_DELETE: "http://localhost:5000/user/api/getReport",

  // For Sub Model
  AXIOS_SUB_GET_POST: "http://localhost/5000/user/api/useData",
};
