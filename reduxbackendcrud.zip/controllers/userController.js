import Users from "../models/userModel"
import regsiUser from "../models/registrationModel"
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken"
import { OAuth2Client } from "google-auth-library";

const client_id="469359144145-0su1kkfikabj3tqbsvognfte227j3uot.apps.googleusercontent.com"
                //  469359144145-0su1kkfikabj3tqbsvognfte227j3uot.apps.googleusercontent.com 
const client = new OAuth2Client(client_id)

export const createUsers = async (req, res) => {
    const { name, email } = req.body;
    console.log(req.body, "jjjjjjj");

    try {

        if (name && email) {
            const newUser = Users(req.body);
            const savedUser = await newUser.save();
            if (savedUser) {
                return res.status(201).json(savedUser);
            }
            else {
                return res.status(400).json({ message: "something went wromng" });
            }
        }
    }
    catch (error) {
        return res.status(400).json(error);
    }
}


export const getusers = async (req, res) => {
    try {
        const getUser = await Users.find({
            CreatedBy: req.params.id,
            // firstname: { $regex: search, $options: "i" },
        });
       
        
        if (getUser) {
            return res.status(200).json(getUser);
        }
    }
    catch (error) {
      
        return res.status(400).json(error);
    }
    

}



export const updateUser = async (req, res) => {
    const { id } = req.params;
    console.log(req.body,"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");

    try {

        if (id) {
            console.log(id,"iddddddddddddddddd");

            const updateUser = await Users.findByIdAndUpdate(id, req.body);
            //    console.log(updateUser,"heyyyyyyyyyyyyy");

            return res.status(200).json(updateUser);


        }

        else {
            return res.status(400).json({ message: "id not found" });
        }
    }
    catch (error) {
        return res.status(400).json(error);
    }
};



export const deleteUser = async (req, res) => {
    const { id } = req.params;
    try {

        if (id) {
            const getDeletedData = await Users.findByIdAndDelete(id);
            return res.status(200).json(getDeletedData);
        }

        else {
            return res.status(400).json({ message: "id not found" });
        }
    }
    catch (error) {
        return res.status(400).json(error);
    }
};



///registration 

export const registerUser = async (req, res) => {
    try {
      const { firstname, lastname,age,email,password } = req.body;
      const profile = req.file?.filename;
      if (!firstname || !lastname || !age || !email || !password || !profile) {
        return res
          .status(400)
          .json({message:"all fields are required"})
  
      }
      //password bcrypting
      const pass = await bcrypt.hash(password, 10);
      const user = new regsiUser({
        firstname,
        lastname,
        age,
        email,
        password: pass,
        profile: profile,
     
      });
  
      await user.save();
      res.status(201).json({ msg: "user registered successfully" });
    } catch (error) {
      res.status(500).json({ msg: error.message });
    }
  };

//login

export const userLogin = async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res
          .status(400)
          .json({ message: "All fields are required"});
      }
      const existUser = await regsiUser.findOne({ email: email });
      // console.log(existUser);
  
      if (!existUser) {
        return res
          .status(400)
          .json({ msg: "user not found" });
      }
  
      //checking password entered by user and database user passsword
      const isMatch = await bcrypt.compare(password, existUser.password);
      console.log(isMatch, "Thankyou");
  
      //generating token for user
      if (isMatch) {
        console.log(existUser);
        // const dataToBeSend={
        //   id : existUser._id,
        //   email :existUser.email,
        //   firstname : existUser.firstname,
        //   lastname : existUser.lastname,
        //   DOB : existUser.DOB,
        //   gender : existUser.gender
          
        // }
        const token = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
        return res
          .status(200)
          .json({ msg: "user logged in successfully", token: token, email:email ,userId:existUser._id});
      } else {
        return res
          .status(400)
          .json({ msg: "invalid credentials" });
      }
    } catch (error) {
      console.error(error);
      return res
        .status(500)
        .json({ msg: error.message });
    }
  };


exports.googlelogin = async (req, res) => {
    try {
        const { token } = req.body
        console.log(token , "vcdscvhjdshjcgjhy")
  
        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: client_id
        })
        console.log(ticket);
        
  
        const payload = ticket?.payload
        const email = payload?.email
        const pass = payload?.sub
        const firstname = payload?.given_name
        const lastname = payload?.family_name
        console.log(email, pass)
        // console.log(ticket)
  
        const user = new regsiUser({
           firstname:firstname,
           lastname:lastname,
           email:email,
           password:pass
        })
  
        const data = await user.save()
        console.log(data)
  
    } catch (error) {
        console.log(error.message)
    }
  }
  
