export const config = {
    local: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "reactredux",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT:4565,
    },
    stagg: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "reactredux",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 4565,
    },
    prod: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "reactredux",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 4565,
    },
  };
  