import express from 'express';
import {createUsers,getusers,updateUser , deleteUser,registerUser,userLogin,googlelogin} from "../controllers/userController"
import { uploadMiddleware } from '../helper/multer';
const router = express.Router();

//all router are here


router.post("/adduser",createUsers);
router.get("/getuser/:id",getusers);
router.put("/updateuser/:id",updateUser);
router.delete("/deleteuser/:id",deleteUser);

//registration route

router.post("/registeruser",uploadMiddleware.single("profile"),registerUser)

//login

router.post("/userlogin",userLogin)

//login with google

router.post("/loginwithgoogle",googlelogin)

export default router