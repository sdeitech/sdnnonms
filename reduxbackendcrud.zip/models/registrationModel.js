import mongoose from "mongoose";
const Schema = mongoose.Schema;
 
//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  age: {
    type: Number,
  },
  email: {
    type: String,
  },
  password: {
    type: String,
  },
  profile: {
    type: String,
  }
});

const regisUser = mongoose.model("regisUser", UserSchema);
export default regisUser;