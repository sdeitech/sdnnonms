import mongoose from "mongoose";
const Schema = mongoose.Schema;
 
//user schema
const UserSchema = new Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
  },
  CreatedBy:{
    type:mongoose.Schema.Types.ObjectId
  }
});

const Users = mongoose.model("Users", UserSchema);
export default Users;