from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.hashers import make_password,check_password
from django.contrib.auth import login,authenticate
from django.core.mail import send_mail
from django.conf import settings

from . models import crudUser,Registration

# Create your views here.
def registerUser(request):
    if request.method=='POST':
        data=request.POST
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        age=data.get('age')
        gender=data.get('gender')
        email=data.get('email')
        password=data.get('password')
        profile=data.get('profile')
        
        newRegiter=Registration.objects.create(
            first_name=first_name,
            last_name=last_name,
            age=age,
            gender=gender,
            email=email,
            password=make_password(password),
            profile=profile
        )
        newRegiter.save()
        return redirect('login')
    else:
        return render(request,"register.html")
    
    
def loginUser(request):
    if request.method=='POST':
        data=request.POST
        email=data.get('email')
        password=data.get('password')
        
        userd = Registration.objects.get(email = email)
        
        passw = check_password(password,userd.password)
        
        
#        user = authenticate( request, email=email , password=passw)
        user = authenticate( request, email=email , password=passw)
        
        if userd.email == email and passw:
            return redirect('dashboard')
        # if user is not None:
        #     login(request,user)
        #     return redirect('create')
            
 
        else:
            return render(request,"login.html")
    else:
        return render(request, 'login.html')  
    
# def userlogout(request):
#     request.session.flush()  # Clear the session
#     return redirect('login')    
    
def createUser(request):
    if request.method=='POST':
        data=request.POST
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        age=data.get('age')
        # print(age , "age")
        gender=data.get('gender')
        
        newUser=crudUser.objects.create(
            first_name=first_name,
            last_name=last_name,
            age=age,
            gender=gender,  
           
        )
        return redirect ('dashboard')
        
    
    return render(request,'index.html')

def dashboard(request):
    allUser=crudUser.objects.all()
    context={'allUser':allUser}
    return render(request,'dashboard.html',context)

def deleteUser(request,id):
    crudUser.objects.get(id=id).delete()
        #   return redirect('/about')
    return redirect('/dashboard')

def updateUser(request,id):
    # updateduser = get_object_or_404(crudUser, id=id)  # Use get_object_or_404 for error handling
    
    if request.method=='POST':
        data=request.POST
        # print(data , "data")
        first_name=data.get('first_name')
        # print(first_name)
        last_name=data.get('last_name')
        age=data.get('age')
        # print(age , "age")
        gender=data.get('gender')
        
        newuser=crudUser.objects.get(id=id)
         
        # print(newuser.first_name ,"updateduser")
        # print(type(newuser))
        
        newuser.first_name = first_name
        # print(type(newuser.first_name ))
        newuser.last_name = last_name
        newuser.age=age
        newuser.gender =gender
        newuser.save()
        # print(newuser.first_name , "new")

        return redirect('/dashboard')
    else:
        updateduser=crudUser.objects.get(id=id)
        context={'updateduser':updateduser}
    return render(request, 'updateUser.html', context)
        
    # return redirect('/dashboard')

# Logout view (Optional)



# path('logout/', user_logout, name='logout'),  # Optional logout rout

#   <a href="{% url 'logout' %}" class="btn btn-danger">Logout</a>
    