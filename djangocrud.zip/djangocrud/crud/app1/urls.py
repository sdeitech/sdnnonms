
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('',views.registerUser,name="register"),
    path('login/',views.loginUser,name="login"),
    path('create/',views.createUser,name="create"),
    path('dashboard/',views.dashboard,name="dashboard"),
    path('deleteuser/<int:id>',views.deleteUser,name="delete"),
    path('updateuser/<int:id>',views.updateUser,name="update"), 
]