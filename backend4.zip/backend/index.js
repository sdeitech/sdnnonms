import express from 'express';
import cors from "cors";
import authRoute from "./route/auth.route"
import userRoute from "./route/user.route"
const app = express();

app.use(express.json())
app.use(cors({origin:"*"}))


app.use('/images', express.static('images'));
app.use('/api',authRoute);
app.use('/api',userRoute);




export default app;