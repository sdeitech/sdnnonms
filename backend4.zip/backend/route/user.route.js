import express from 'express';
import { addUser,getUser } from '../controller/user.controller';
const router = express.Router();
import {protect} from '../middleware/verifyjwt'

router.post('/add' ,addUser);
router.get('/get-user/:_id' , getUser);

export default router;