import express from 'express';
import { userRegister,userLogin,loginWithGoogle ,updateProfile} from '../controller/auth.controller';
import { uploadMiddleware } from '../helper/multer';
import {protect} from '../middleware/verifyjwt'

const router = express.Router();

router.post('/register',uploadMiddleware,userRegister);
router.post('/login',userLogin);
router.post('/glogin',loginWithGoogle);
router.put('/update' ,updateProfile);

export default router;