import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const userSchema = new Schema({
   firstName: {
      type: String,
      required: false
   },
   lastName: {
      type: String,
      required: false
   },
   email: {
      type: String,
      unique: true,
      required: false
   },
   user: {
      type: mongoose.Schema.Types.ObjectId
   }
});

const User = mongoose.model('User', userSchema)
export default User;