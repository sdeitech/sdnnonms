import jwt from 'jsonwebtoken';

export const protect = (req ,res ,next) =>{
    let token=req.header("Authorization");

    if(token && token.startsWith('Bearer')){
        token = token.split('')[1];
    }else{
        return res.status(400).json({message:'unauthorized access'});
    }

    try{
        const decoded = jwt.verify(jwt,'your_jwt_secret');
        req.user = decoded.userId;
        next();

    }catch(error){
        return res.status(401).json({message : "Invalid Token"})
    }

};