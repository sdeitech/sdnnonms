import User from '../model/user.model';

export const addUser = async (req, res) => {
    // const { firstName, lastName, email, user } = req.body;
    
    try {
        const newUser = new User(req.body);
        // console.log(req.body);
        console.log(newUser);
        await newUser.save();
        console.log(newUser);
        res.status(201).json(newUser);
    } catch (error) {
        res.status(500).json({ message: "Error in Adding User" });
    }

};

export const getUser = async (req, res) => {
    console.log(req.params._id);
    
    // console.log("id",req.body.user)
    try {
        const users = await User.find({ user: req.params._id});
        // console.log(users.length)
        res.status(200).json(users)
    } catch (error) {
        res.status(500).json({ message: "Error in Fetching the data" })
    }
};