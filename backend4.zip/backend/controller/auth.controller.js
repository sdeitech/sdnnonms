import jwt from 'jsonwebtoken'
import bcrypt from 'bcrypt'
import Auth from '../model/auth.model'
import { OAuth2Client } from 'google-auth-library';
import User from '../model/user.model';



const CLIENT_ID = "531162091657-a8l74t9nuhjjhgdln9bqd44tfng3bshi.apps.googleusercontent.com";
const client = new OAuth2Client(CLIENT_ID);

export const userRegister = async (req, res) => {
    try {
        const { firstName, lastName, email, password, DOB, isMarried, gender } = req.body;
        console.log(req.body)

        const hashedPassword = await bcrypt.hash(password, 10);

        let profilePicture = req.file ? req.file.filename : null;

        const newuser = new Auth({
            firstName,
            lastName,
            email,
            password: hashedPassword,
            DOB,
            isMarried,
            gender,
            profile: profilePicture
        });
        console.log(newuser);

        await newuser.save();
        res.status(200).json(newuser);

    } catch (err) {
        console.log(err)
        res.status(500).send("Error in Registration")
    }

};


export const userLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        console.log(req.body)

        const user = await Auth.findOne({ email });
        console.log(user)

        if (!user) return res.status(400).send("User not found");
        console.log(!user,"==========")

        const isMatch = await bcrypt.compare(password, user.password)
        console.log(isMatch ,"hfggf") 

        if (!isMatch) return res.status(400).send('Credntial Invalid');
        console.log(!isMatch,"1234344")


        const token = jwt.sign({ email: user.email, id: user._id }, 'your_jwt_secret', { expiresIn: '1h' });
        console.log(token);
        res.json({ token, user });
    } catch (err) {

        console.log(err);
        res.status(500).send("error logged In",err.message)
    }
};


// const CLIENT_ID = "531162091657-a8l74t9nuhjjhgdln9bqd44tfng3bshi.apps.googleusercontent.com";
// const client = new OAuth2Client(CLIENT_ID);

export const loginWithGoogle = async (req, res) => {
    const { token } = req.body;
    console.log("token", token);

    try {
        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: CLIENT_ID,
        });
        console.log("ticket", ticket);


        const payload = ticket.getPayload();
        console.log("payload", payload);


        const googleId = payload['sub'];
        const email = payload['email'];

        if (!email) {
            throw new Error('Email ID is missing from the token payload');
        }

        const username = email.split('@')[0];

        console.log("email___", email);

        let user = await Auth.findOne({ email: email });
        console.log("user", user)
        let savedNew;
        if (!user) {
            const saveuser = new Auth({
                email,
                username,
                password,
                DOB,
                isMarried,
                gender,
                profile: profilePicture
            });
            savedNew = await saveuser.save();
        }

        console.log("savedNew___", savedNew);

        const jwtToken = jwt.sign({ userId: savedNew?._id ? savedNew?._id : user?._id }, 'your-secret-key', { expiresIn: '6h' });


        user.tokens = [{ token: jwtToken }];
        await user.save();

        return res.status(200).json({ message: "Login with Google Successful", user, token: jwtToken });
    } catch (error) {
        console.error('Error during Google login:', error);
        res.status(401).json({ message: 'Unauthorized', error: error.message });
    }
};

export const updateProfile = async (req, res) => {
    const { firstName, lastName, email, DOB, isMarried, gender } = req.body;
    let profileImage = req.file ? req.file.path : null;

    try {
        const user = await Auth.findById(req.user);

        if (!user) {
            return res.status(500).json({ message: 'User not found' });
        }

        user.firstName = firstName || user.firstName;
        user.lastName = lastName || user.lastName;
        user.email = email || user.email;
        user.DOB = DOB || user.DOB;
        user.isMarried = isMarried || user.isMarried;
        user.gender = gender || user.gender
        if (profileImage) {
            user.profileImage = profileImage;
        }

        const updatedUser = await user.save();
        res.status(200).json(updatedUser);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};
