const config = {
    local:{
        DB:{
            HOST:"",
            DB_PORT:27017,
            DB_NAME: "DB"
        },
        API_PORT : 2003,
    },

    prod:{
        DB:{
            HOST: "",
            DB_PORT: 27017,
            DB_NAME:"DB",
        },
        API_PORT : 2003,
    },

    testing:{
        DB:{
            HOST: " ",
            DB_PORT: 27017,
            DB_NAME: "DB"
        },
        API_PORT :  2003
    },
};

export default config;