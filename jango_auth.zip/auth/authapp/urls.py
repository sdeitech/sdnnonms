from django.contrib import admin
from django.urls import path
from .views import RegisterUser,Dashboard,LoginUser,Logout

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",RegisterUser.as_view(),name="register"),
    path("dashboard/",Dashboard.as_view(),name="dashboard"),
    path("login/",LoginUser.as_view(),name="login"),
    path("logout/",Logout.as_view(),name="logout"),  
      
]