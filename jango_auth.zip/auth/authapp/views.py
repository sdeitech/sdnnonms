from django.shortcuts import render,redirect
from django.views import View
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.utils.decorators import method_decorator
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.decorators import login_required,permission_required
User = get_user_model()

class Dashboard(View):
    @method_decorator(login_required)  
    def get(self,request):
        return render(request,"dashboard.html")
    
class RegisterUser(View):
    def get(self,request):
        return render(request,"RegisterUser.html")
    
    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')

        if User.objects.filter(email=email).exists():
             messages.info(request, 'User alredy exists !')
             return redirect("/")
        
        context = {}

        address = email
        subject = "Login credentials"
        message = f"username : {username} password : {password}"

        if address and subject and message:
            try:
                send_mail(subject, message, settings.EMAIL_HOST_USER, [address])
                print("mail send")
                context['result'] = 'Email sent successfully'
            except Exception as e:
                print("mail send",e)
                context['result'] = f'Error sending email: {e}'
        else:
            print("mail send from else")
            context['result'] = 'All fields are required'

        user = User.objects.create_user(
            username=username,
            password=password,
            email=email,
            first_name=first_name,
            last_name=last_name,
            mobile=mobile_number
        )

        user.save()
        print(user)
        return redirect("/")
      
class LoginUser(View):
    def get(self,request):
        return render(request,"LoginUser.html")
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        
        if not User.objects.filter(username=username).exists():
            messages.info(request, 'Invalid credentials!')
            return redirect("login")
        
        user = authenticate(username=username,password=password)
        print(user.mobile,"user data")
        
        if user is not None:
            login(request,user)
            return redirect("dashboard")
        else:
            return redirect("register")
            
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("/")