from django.contrib import admin
from . import views
from django.views import View
from django.urls import path

urlpatterns =[
    path('',views.CreateEmployee.as_view(),name='index'),
    path('employee_list/',views.ShowEmployee.as_view(),name='employee_list'),
    path('employee_list/<int:id>',views.deleteEmployee.as_view(),name='deleteEmployee'),
    path('update/<int:id>',views.updateEmployee.as_view(),name='updateEmployee'),
    path('employee_detail/<int:id>',views.ViewEmployee.as_view(),name='getdata'),
]