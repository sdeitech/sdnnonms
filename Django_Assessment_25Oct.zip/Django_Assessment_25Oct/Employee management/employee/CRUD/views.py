from django.shortcuts import redirect, render
from django.views import View
from .models import Employee

class CreateEmployee(View):
    def get(self,request):
        return render(request,'employee_form.html')
    def post(self,request):
        employee_id = request.POST.get('employee_id')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        department = request.POST.get('department')
        position = request.POST.get('position')
        date_of_birth = request.POST.get('date_of_birth')
        date_joined = request.POST.get('date_joined')
        salary = request.POST.get('salary')
        is_full_time = request.POST.get('is_full_time')
        if is_full_time == "on":
            full_time = True
        else:
            full_time = False
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        last_performance_review = request.POST.get('last_performance_review')
 
        newobj = Employee(
            employee_id  = employee_id,
            first_name = first_name,
            last_name = last_name,
            department = department,
            position = position,
            date_of_birth = date_of_birth,
            date_joined = date_joined,
            salary = salary,
            is_full_time = full_time,
            email = email,
            phone_number = phone_number,
            address = address,
            city = city,
            state = state,
            last_performance_review = last_performance_review,
        )
        newobj.save()
        return redirect('employee_list/')
    
class ShowEmployee(View):
    def get(self,request):
        Employees = Employee.objects.all()
        return render(request,'employee_list.html',{'Employees':Employees})
    
class deleteEmployee(View):
     def get(self,request,id):
        obj=Employee.objects.get(id=id)
        obj.delete()
        return redirect('/employee_list')
     
class updateEmployee(View):
    def get(self,request,id):
            obj=Employee.objects.get(id=id)
            return render(request,'update.html',{'obj':obj})
            
    def post(self,request,id):
            obj=Employee.objects.get(id=id)
            employee_id = request.POST.get('employee_id')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            department = request.POST.get('department')
            position = request.POST.get('position')
            date_of_birth = request.POST.get('date_of_birth')
            date_joined = request.POST.get('date_joined')
            salary = request.POST.get('salary')
            is_full_time = request.POST.get('is_full_time')
            if is_full_time == "on":
                full_time = True
            else:
                full_time = False
            email = request.POST.get('email')
            phone_number = request.POST.get('phone_number')
            address = request.POST.get('address')
            city = request.POST.get('city')
            state = request.POST.get('state')
            last_performance_review = request.POST.get('last_performance_review')

            if employee_id:
                    obj.employee_id = employee_id

            if first_name:
                    obj.first_name = first_name

            if last_name:
                    obj.last_name = last_name

            if department:
                    obj.department = department

            if position:
                    obj.position = position

            if date_of_birth:
                    obj.date_of_birth = date_of_birth
            
            if date_joined:
                    obj.date_joined = date_joined

            if salary:
                    obj.salary = salary

            if is_full_time:
                obj.full_time = True
            else:
                obj.full_time=False

            if email:
                    obj.email = email
            
            if phone_number:
                    obj.phone_number = phone_number

            if address:
                    obj.address = address
            
            if city:
                    obj.city = city

            if state:
                    obj.state = state

            if last_performance_review:
                  obj.last_performance_review = last_performance_review


            obj.save()
            return redirect('/employee_list')

class ViewEmployee(View):
    def get(self,request,id):
        Emp = Employee.objects.get(id=id)
        return render(request,"employee_detail.html",context ={'Emp':Emp})
        