CREATE DATABASE ASSESSMENT

use ASSESSMENT;

CREATE TABLE Customer (
    CustomerId INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    PhoneNumber VARCHAR(15) DEFAULT 'N/A',
    Gender VARCHAR(10),
    Age INT CHECK (Age >= 18),  
    CreatedDate DATE NULL 
);

INSERT INTO Customer (FirstName, LastName, Email, Gender, Age)
VALUES
('Ramesh', 'Singh', 'john.doe@example.com', 'Male', 32),
('Sam', 'Smith', 'jane.smith@example.com', 'Female', 28),
('Kim', 'Kum', 'Kum.smith@example.com', 'Female', 28),
('Zam', 'Zum', 'Zum.smith@example.com', 'Female', 28),
('Suresh', 'Varma', 'Varma.smith@example.com', 'Female', 23),
('Mark', 'Liam', 'Liam.smith@example.com', 'Female', 21),
('Susan', 'Lee', 'Lee.smith@example.com', 'Female', 22),
('Kripan', 'Wagh', 'Wagh.smith@example.com', 'Female', 24),
('Lili', 'james', 'james.smith@example.com', 'Female', 25);

CREATE TABLE CustomerAddress (
    AddressId INT PRIMARY KEY AUTO_INCREMENT,
    CustomerId INT NOT NULL,
    AddressLine1 VARCHAR(100) NOT NULL,
    AddressLine2 VARCHAR(100),
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    PostalCode VARCHAR(10),
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId) 
);

INSERT INTO CustomerAddress (CustomerId, AddressLine1, City, State, PostalCode)
VALUES
(1, '123 Main St', 'New York', 'NY', '10001'),
(2, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(9, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(8, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(5, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(4, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(3, '456 Elm St', 'Los Angeles', 'CA', '90001'),
(7, '456 Elm St', 'Los Angeles', 'CA', '90001');

CREATE TABLE Product (
    ProductId INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL CHECK (Price > 0), 
    Stock INT DEFAULT 0 
);
INSERT INTO Product (ProductName, Price, Stock)
VALUES
('Laptop', 1200.00, 50),
('Smartphone', 800.00, 30),
('Telephone', 1200.00, 50),
('Watch', 800.00, 30),
('Mouse', 1000.00, 50),
('Monitor', 1400.00, 30),
('Bycycle', 6968.00, 50),
('TV', 3256.00, 30),
('AeroPlane', 858585.00, 50),
('Jet', 6598745.00, 30);

CREATE TABLE Orders(
    OrderId INT PRIMARY KEY AUTO_INCREMENT,
    CustomerId INT NOT NULL,
    OrderDate DATE NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL CHECK (TotalAmount > 0),
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerId) ON DELETE CASCADE
);

INSERT INTO Orders (CustomerId, OrderDate, TotalAmount)
VALUES
(1, '2024-01-15', 1500.00),
(2, '2024-01-16', 800.00),
(1, '2024-01-20', 250.00),
(3, '2024-01-18', 600.00),
(2, '2024-01-19', 450.00),
(5, '2024-02-20', 250.00),
(6, '2024-03-18', 600.00),
(7, '2024-04-19', 450.00),
(8, '2024-04-4', 250.00),
(7, '2024-03-18', 600.00),
(5, '2024-06-19', 450.00),
(5, '2024-08-8', 250.00),
(9, '2024-05-3', 600.00),
(9, '2024-01-31', 450.00);

CREATE TABLE OrderProduct (
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 1 CHECK (Quantity > 0),
    PRIMARY KEY (OrderId, ProductId),
    FOREIGN KEY (OrderId) REFERENCES Orders(OrderId) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Product(ProductId) ON DELETE CASCADE
);


INSERT INTO OrderProduct (OrderId, ProductId, Quantity)
VALUES
(1, 1, 2), 
(1, 2, 1), 
(1, 3, 1),
(2, 5, 3),
(2, 6, 4),
(7, 9, 2),
(7, 10, 2),
(8, 2, 1),
(9, 2, 1);
1)
 SELECT c.FirstName,c.LastName,o.TotalAmount FROM Customer AS c JOIN Orders AS  o on  c.CustomerId= o.CustomerId  

2)
SELECT 
c.FirstName,
c.LastName,
o.OrderDate,
o.TotalAmount  
FROM Customer AS c 
JOIN CustomerAddress AS ca
ON c.CustomerId=ca.CustomerId 
JOIN  Orders As o 
ON o.CustomerId=ca.CustomerId 
WHERE ca.City= 'Los Angeles';

3)
SELECT 
c.FirstName,
c.LastName,
ca.AddressLine1
FROM Customer AS c 
JOIN  CustomerAddress As ca 
On c.CustomerId=ca.CustomerId 
JOIN  Orders As o 
ON o.CustomerId=ca.CustomerId 
WHERE o.OrderDate>='2024-01-01' AND o.OrderDate<='2024-02-01' ;

4)
 SELECT 
	o.CustomerId,
	op.OrderId,
   SUM(op.Quantity)
   FROM Orders AS o
   JOIN OrderProduct AS op 
   ON  o.OrderId=op.OrderId
   GROUP BY op.OrderId; 
   
   5)
SELECT 
	c.CustomerId,
	c.FirstName,
	c.LastName,
	ca.City,
	ca.State
   FROM Customer AS c 
   JOIN CustomerAddress AS ca
   ON c.CustomerId=ca.CustomerId 
   WHERE EXISTS ( SELECT 1 FROM CustomerAddress where c.CustomerId=ca.CustomerId  )
  
  6)
 SELECT   
 c.FirstName,
c.LastName,
c.Email
  FROM Customer AS c 
  LEFT JOIN Orders As o 
  ON  o.CustomerId=c.CustomerId WHERE o.OrderId IS NULL;
  
  7)
SELECT   c.FirstName,
           c.LastName
  FROM Customer AS c 
  LEFT JOIN CustomerAddress AS ca
  ON  c.CustomerId=ca.CustomerId WHERE ca.PostalCode IS NULL;
   8)
SELECT 
c.FirstName ,
c.LastName ,
ca.AddressLine1 
FROM Customer AS c JOIN CustomerAddress AS ca
ON c.CustomerId=ca.CustomerId WHERE ca.AddressLine1 LIKE "%Elm%" ;

9)
SELECT FirstName , LastName ,Email FROM Customer WHERE  FirstName LIKE   'K%' AND 'n';

10)
SELECT 
c.FirstName , 
c.LastName , 
c.Age , 
ca.City 
FROM Customer AS c JOIN  CustomerAddress AS ca  
ON  c.CustomerId=ca.CustomerId WHERE  c.Age=28 OR ca.City='New York';

20)
   SELECT  
		  ProductName, 
		  Price , 
		  Stock 
	FROM Product  
	WHERE Price = 1200 OR Stock=50;
    
    
19)
SELECT  
  OrderId, 
  CustomerId , 
  OrderDate,
  TotalAmount
FROM Orders  
WHERE OrderDate BETWEEN '2024-01-15' AND '2024-03-18';

18)
SELECT c.FirstName,
c.LastName,
ca.City, 
ca.State 
FROM   Customer  AS c
JOIN CustomerAddress AS ca 
ON c.CustomerId=ca.CustomerId 
WHERE ca.City='New York' OR ca.City='Los Angeles';


          
   