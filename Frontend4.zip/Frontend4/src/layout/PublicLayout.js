import React from 'react'

export const PublicLayout = ({children}) => {
  return (
    <div>
        {children}
    </div>
    
  )
}
