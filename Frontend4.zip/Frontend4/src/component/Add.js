
import React ,{useState , useEffect}from 'react';
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


export const Add = () => {
    const [data , setData] = useState([]);
    const [postcontent, setPostContent] = useState({
        firstName:'',
        lastName: ' ',
        email:' ',
      });
      
     const navigate = useNavigate(); 

   
   useEffect(() => {
     const getUser = async () =>{
      const token = localStorage.getItem('authToken');
      const config ={
        headers:{
          Authorization : `Bearer ${token}`,
        },
      }
      const {data} = await axios.get('http://localhost:2003/api/get-user' , config);
      setData(data);

     };
  
    getUser();
  }, []);

  const createData = async (e) => {
    e.preventDefault();

        // // const token = localStorage.setItem('authToken');
        // const config = {
        //     headers:{
        //         Authorization: `Bearer ${token}`,
        //     }
        // }
        const response = await axios.post('http://localhost:2003/api/add', postcontent);
        console.log(response)
        setData([...data, response.data]);
        setPostContent({
          firstName:'',
          lastName: ' ',
          email:' '
        });
        navigate('/dashboard')
    
};

const handleInput = (e) => {
    const { name, value } = e.target;
    setPostContent({ ...postcontent, [name]: value });
};

  
  return (
    <div>Add
 
            {/* <Header/> */}
        {/* <p onClick={() => navigate('/dashboard')}>Dashboard</p> */}
            
        {/* {error && <p style={{ color: 'red' }}>{error}</p>} */}

            <form onSubmit={createData}>
                <div className="input-group">
                    <label>FirstName:
                        <input
                            type="text"
                            name="firstName"
                            value={postcontent.firstName}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>LastName:
                        <input
                            type="text"
                            name="lastName"
                            value={postcontent.lastName}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>
                        Email:
                        <input
                            type="text"
                            name="email"
                            value={postcontent.email}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <span>
                    <button type="submit">Submit</button>
                    {/* <button type="reset">Reset</button> */}
                    {/* <input type="reset" value="reset" /> */}
                </span>

            </form>
{/* 
            <table className='table-add'>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((info) => (
                        <tr key={info._id}>
                            <td>{info.firstName}</td>
                            <td>{info.lastName}</td>
                            <td>{info.email}</td>
                            <td>
                                {/* <button onClick={() => handleView(info._id)}>View</button> */}
                                {/* <button onClick={() => handleDelete(info._id)}>Delete</button> */}
                                {/* <button type="button">Delete</button> */}
{/* 
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table> */} 

    </div>
  )
}
