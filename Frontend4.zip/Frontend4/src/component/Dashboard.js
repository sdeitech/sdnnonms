
import { Link } from 'react-router-dom';
import React , {useEffect ,useState} from 'react'
import axios from 'axios';

const Dashboard = () => {
  const [data , setData] = useState([]);

  

   
  useEffect(() => {
    const getUser = async () =>{
     const token = localStorage.getItem('authToken');
     const config ={
       headers:{
         Authorization : `Bearer ${token}`,
       },
     }
     const {data} = await axios.get('http://localhost:2003/api/get-user' , config);
     setData(data);

    };
 
   getUser();
 }, []);

  return (
    <div>
      <h3 style={{
        alignContent:"center",
        textAlign:"center"
      }}>Dashboard</h3>
    <Link style={{
      backgroundColor:"lavender",
      textAlign:"center",
      marginLeft:"70%",
    }} to="/myprofile">Myprofile</Link>
    
    <button type="button"><Link to='/add'>Add</Link></button>

  
    <table className='table-add'>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((info) => (
                        <tr key={info._id}>
                            <td>{info.firstName}</td>
                            <td>{info.lastName}</td>
                            <td>{info.email}</td>
                            <td>
                                {/* <button onClick={() => handleView(info._id)}>View</button> */}
                                {/* <button onClick={() => handleDelete(info._id)}>Delete</button> */}
                                <button type="button">Delete</button>

                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
  
    </div>
  )
}

export default Dashboard;