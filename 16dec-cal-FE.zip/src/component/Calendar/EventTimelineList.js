// import * as React from "react";
// import { useState, useEffect } from "react";
// import Timeline from "@mui/lab/Timeline";
// import TimelineItem from "@mui/lab/TimelineItem";
// import TimelineSeparator from "@mui/lab/TimelineSeparator";
// import TimelineConnector from "@mui/lab/TimelineConnector";
// import TimelineContent from "@mui/lab/TimelineContent";
// import TimelineDot from "@mui/lab/TimelineDot";
// import Typography from "@mui/material/Typography";
// import { Avatar, Box, Paper, CircularProgress, Button, Grid } from "@mui/material";

// export default function EventTimelineList() {
//   const [events, setEvents] = useState([]); // State to store events data
//   const [loading, setLoading] = useState(true); // Loading state
//   const token = localStorage.getItem("token");

//   // Fetch data from API
//   useEffect(() => {
//     const fetchEvents = async () => {
//       try {
//         const response = await fetch("http://localhost:5000/apis/getEvent", {
//           headers: {
//             Authorization: `${token}`,
//             "Content-Type": "application/json",
//           },
//         });
//         if (!response.ok) {
//           throw new Error("Failed to fetch events data");
//         }
//         const data = await response.json(); // Assuming API returns a JSON array
//         setEvents(data); // Set events to state
//       } catch (error) {
//         console.error("Error fetching events:", error);
//       } finally {
//         setLoading(false); // Stop loading
//       }
//     };

//     fetchEvents();
//   }, []);

//   function convertTo24HourFormat(time) {
//     const [hours, minutes, modifier] = time
//       .match(/(\d+):(\d+)\s*(AM|PM)/i)
//       .slice(1);
//     let formattedHours = parseInt(hours, 10);

//     if (modifier.toUpperCase() === "PM" && formattedHours !== 12) {
//       formattedHours += 12;
//     } else if (modifier.toUpperCase() === "AM" && formattedHours === 12) {
//       formattedHours = 0;
//     }

//     return `${formattedHours.toString().padStart(2, "0")}:${minutes}`;
//   }

//   const [currentDate, setCurrentDate] = useState(new Date());

//   // Function to get dates of the current week
//   const getWeekDates = (date) => {
//     const startOfWeek = new Date(date);
//     startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay()); // Start from Sunday

//     return Array.from({ length: 7 }).map((_, idx) => {
//       const day = new Date(startOfWeek);
//       day.setDate(startOfWeek.getDate() + idx);
//       return day;
//     });
//   };

//   // Functions to navigate between weeks
//   const handlePrevWeek = () => {
//     const newDate = new Date(currentDate);
//     newDate.setDate(currentDate.getDate() - 7);
//     setCurrentDate(newDate);
//   };

//   const handleNextWeek = () => {
//     const newDate = new Date(currentDate);
//     newDate.setDate(currentDate.getDate() + 7);
//     setCurrentDate(newDate);
//   };

//   const weekDates = getWeekDates(currentDate);

//   return (
//     <Box sx={{ p: 2 }}>
//       {/* "Upcoming Meetings" Header and Calendar Navigation */}
//       <Box sx={{ mb: 3 }}>
//         <Typography variant="h6" sx={{ fontWeight: "bold", mb: 1 }}>
//           Upcoming Meetings
//         </Typography>

//         <Grid container alignItems="center" spacing={1}>
//       {/* Navigation Buttons */}
//       <Grid item xs={1} sx={{ textAlign: "center" }}>
//         <Button variant="outlined" size="small" onClick={handlePrevWeek}>
//           &lt;
//         </Button>
//       </Grid>

//       {/* Calendar Grid */}
//       <Grid item xs={10}>
//         <Box
//           sx={{
//             display: "flex",
//             justifyContent: "space-between",
//             bgcolor: "grey.100",
//             p: 1,
//             borderRadius: 2,
//             boxShadow: 1,
//           }}
//         >
//           {/* Days of the Week */}
//           {weekDates.map((date, idx) => (
//             <Box
//               key={idx}
//               sx={{
//                 textAlign: "center",
//                 p: 1,
//                 borderRadius: 1,
//                 bgcolor: idx === new Date().getDay() ? "primary.light" : "transparent", // Highlight today's day
//               }}
//             >
//               <Typography variant="body2" sx={{ fontWeight: "bold" }}>
//                 {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][idx]}
//               </Typography>
//               <Typography variant="body2" sx={{ fontWeight: "bold" }}>
//                 {date.getDate()} {/* Day of the month */}
//               </Typography>
//             </Box>
//           ))}
//         </Box>
//       </Grid>

//       {/* Navigation Buttons */}
//       <Grid item xs={1} sx={{ textAlign: "center" }}>
//         <Button variant="outlined" size="small" onClick={handleNextWeek}>
//           &gt;
//         </Button>
//       </Grid>
//     </Grid>
        
//       </Box>

//       {/* Timeline Component */}
//       {loading ? (
//         <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
//           <CircularProgress /> {/* Show loader while data is being fetched */}
//         </Box>
//       ) : (
//         <Timeline position="right">
//           {events.map((event, index) => (
//             <TimelineItem key={index}>
//               {/* Event Time */}
//               <Typography
//                 variant="body2"
//                 color="text.secondary"
//                 sx={{ minWidth: "80px", textAlign: "right" }}
//               >
//                 {event.time ? convertTo24HourFormat(event.time) : "N/A"}
//               </Typography>

//               <TimelineSeparator>
//                 <TimelineDot color={index === 1 ? "primary" : "grey"} />
//                 {index < events.length - 1 && <TimelineConnector />}
//               </TimelineSeparator>

//               {/* Event Content */}
//               <TimelineContent>
//                 <Paper
//                   elevation={3}
//                   sx={{
//                     p: 1.5,
//                     display: "flex",
//                     alignItems: "center",
//                     gap: 1,
//                     bgcolor: index === 1 ? "primary.light" : "grey.100",
//                   }}
//                 >
//                   <Avatar
//                     src={event.avatar || "https://i.pravatar.cc/50"}
//                     alt={event.name || "Event"}
//                   />
//                   <Box>
//                     <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
//                       {event.event_title || "Event Summary"}
//                     </Typography>
//                     <Typography variant="body2" color="text.secondary">
//                       {event.details || "No details available"}
//                     </Typography>
//                   </Box>
//                 </Paper>
//               </TimelineContent>
//             </TimelineItem>
//           ))}
//         </Timeline>
//       )}
//     </Box>
//   );
// }

/////////////////////////


import * as React from "react";
import { useState, useEffect } from "react";
import Timeline from "@mui/lab/Timeline";
import TimelineItem from "@mui/lab/TimelineItem";
import TimelineSeparator from "@mui/lab/TimelineSeparator";
import TimelineConnector from "@mui/lab/TimelineConnector";
import TimelineContent from "@mui/lab/TimelineContent";
import TimelineDot from "@mui/lab/TimelineDot";
import Typography from "@mui/material/Typography";
import { Avatar, Box, Paper, CircularProgress, Button, Grid } from "@mui/material";

export default function EventTimelineList() {
  const [events, setEvents] = useState([]); // Events data
  const [loading, setLoading] = useState(true); // Loading state
  const [currentDate, setCurrentDate] = useState(new Date()); // Current selected date
  const token = localStorage.getItem("token");

  // Function to fetch events from the backend
  const fetchEvents = async (date = null) => {
    setLoading(true);
    try {
      const query = date ? `?date=${date.toISOString().split("T")[0]}` : ""; // Query with date
      const response = await fetch(`http://localhost:5000/apis/getEventByDate${query}`, {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch events");
      }

      const data = await response.json();
      setEvents(data); // Update events state
    } catch (error) {
      console.error("Error fetching events:", error);
    } finally {
      setLoading(false); // Stop loading
    }
  };

  useEffect(() => {
    fetchEvents(currentDate); // Initial fetch for the current date
  }, []);

  // Function to navigate weeks
  const handlePrevWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() - 7);
    setCurrentDate(newDate);
    fetchEvents(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + 7);
    setCurrentDate(newDate);
    fetchEvents(newDate);
  };

  // Function to select a specific day
  const handleSelectDay = (date) => {
    setCurrentDate(date);
    fetchEvents(date);
  };

  // Generate week dates
  const getWeekDates = () => {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay()); // Start of the week (Sunday)

    return Array.from({ length: 7 }).map((_, idx) => {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + idx);
      return day;
    });
  };

  const weekDates = getWeekDates();

  return (
    <Box sx={{ p: 2 }}>
      {/* Calendar Navigation */}
      <Grid container alignItems="center" spacing={1}>
        <Grid item xs={1} sx={{ textAlign: "center" }}>
          <Button variant="outlined" size="small" onClick={handlePrevWeek}>
            &lt;
          </Button>
        </Grid>

        <Grid item xs={10}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              bgcolor: "grey.100",
              p: 1,
              borderRadius: 2,
              boxShadow: 1,
            }}
          >
            {weekDates.map((date, idx) => (
              <Box
                key={idx}
                onClick={() => handleSelectDay(date)} // Select day handler
                sx={{
                  textAlign: "center",
                  p: 1,
                  borderRadius: 1,
                  cursor: "pointer",
                  bgcolor: date.toDateString() === currentDate.toDateString() ? "primary.light" : "transparent",
                  "&:hover": { bgcolor: "grey.200" },
                }}
              >
                <Typography variant="body2" sx={{ fontWeight: "bold" }}>
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][idx]}
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: "bold" }}>
                  {date.getDate()}
                </Typography>
              </Box>
            ))}
          </Box>
        </Grid>

        <Grid item xs={1} sx={{ textAlign: "center" }}>
          <Button variant="outlined" size="small" onClick={handleNextWeek}>
            &gt;
          </Button>
        </Grid>
      </Grid>

      {/* Timeline Section */}
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Timeline position="right">
          {events.length > 0 ? (
            events.map((event, index) => (
              <TimelineItem key={index}>
                <Typography variant="body2" sx={{ minWidth: "80px", textAlign: "right" }}>
                  {event.event_startTime || "N/A"}
                </Typography>
                <TimelineSeparator>
                  <TimelineDot color="primary" />
                  {index < events.length - 1 && <TimelineConnector />}
                </TimelineSeparator>
                <TimelineContent>
                  <Paper elevation={3} sx={{ p: 1.5 }}>
                    <Avatar src={event.avatar || "https://i.pravatar.cc/50"} />
                    <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
                      {event.event_title}
                    </Typography>
                    <Typography variant="body2">{event.details || "No details available"}</Typography>
                  </Paper>
                </TimelineContent>
              </TimelineItem>
            ))
          ) : (
            <Typography sx={{ textAlign: "center", mt: 2 }}>No events for this day.</Typography>
          )}
        </Timeline>
      )}
    </Box>
  );
}


