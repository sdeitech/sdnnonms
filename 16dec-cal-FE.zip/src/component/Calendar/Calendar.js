import React, { useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import axios from "axios"; // Import axios for making API calls
import "react-big-calendar/lib/css/react-big-calendar.css";
import Sidebar from "./Sidebar";
import "./Sidebar.css";

const localizer = momentLocalizer(moment);

const Calender = () => {
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [events, setEvents] = useState([]);

  const [selectedEvent, setSelectedEvent] = useState(null);

  const token = localStorage.getItem("token");

  useEffect(() => {
    axios
      .get("http://localhost:5000/apis/getEvent", {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        const formattedEvents = response.data.map((event) => {
          // Parse from_date and to_date as base dates
          const startDate = new Date(event.from_date);
          const endDate = new Date(event.to_date);

          // Extract start and end times
          const [startHour, startMinute] = event.event_startTime.split(":");
          const [endHour, endMinute] = event.event_endTime.split(":");

          // Set hours and minutes to startDate and endDate
          startDate.setHours(parseInt(startHour), parseInt(startMinute), 0, 0);
          endDate.setHours(parseInt(endHour), parseInt(endMinute), 0, 0);

          // Return the event in the required format
          return {
            id: event._id, // Unique event ID
            title: event.event_title, // Event title
            start: startDate, // Start date-time
            end: endDate, // End date-time
            
          };
        });

        setEvents(formattedEvents); // Update state with formatted events
      })
      .catch((error) => {
        console.error("Error fetching events:", error);
      });
  }, []);

  const toggleOffcanvas = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  const handleAddEvent = (newEvent) => {
    axios
      .post("http://localhost:5000/apis", newEvent, {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        const createdEvent = response.data;
        setEvents([...events, createdEvent]);
        setShowOffcanvas(false);

        console.log("Event created, scheduling...");

        // Schedule event on Google Calendar
        return axios.post(
          "http://localhost:5000/apis/schedule-event",
          {
            ...createdEvent, // Pass the newly created event data, including its ID
            eventId: createdEvent._id,
          },
          {
            headers: {
              Authorization: `${token}`,
              "Content-Type": "application/json",
            },
          }
        );
      })
      .then((scheduleResponse) => {
        console.log("Event scheduled successfully:", scheduleResponse.data);
      })
      .catch((error) => {
        console.error("Error adding or scheduling event:", error);
      });
  };

  const handleEditEvent = (updatedEvent) => {
    console.log("Event ID to update:", updatedEvent.id);

    // First, update the event on the backend
    axios
      .put(
        `http://localhost:5000/apis/updateEvent/${updatedEvent.id}`,
        {
          eventId: updatedEvent.id, // Send the eventId to the backend
          event_title: updatedEvent.event_title,
          event_date: updatedEvent.event_date,
          event_startTime: updatedEvent.event_startTime,
          event_endTime: updatedEvent.event_endTime,
        },
        {
          headers: {
            Authorization: `${token}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((response) => {
        // Update the events state to reflect the updated event
        const updatedEvents = events.map((event) =>
          event.id === updatedEvent.id ? response.data : event
        );
        setEvents(updatedEvents);

        // Now that the event is updated, schedule it on Google Calendar or backend
        console.log("Event updated, scheduling...");
        return axios.put(
          `http://localhost:5000/apis/update-event/${selectedEvent.id}`,
          // response.data, // Send the updated event data to the schedule API
          {
            eventId: updatedEvent.id, // Directly send the eventId to the backend
            event_title: updatedEvent.event_title,
            event_date: updatedEvent.event_date,
            event_startTime: updatedEvent.event_startTime,
            event_endTime: updatedEvent.event_endTime,
          },
          {
            headers: {
              Authorization: `${token}`,
              "Content-Type": "application/json",
            },
          }
        );
      })
      .then((scheduleResponse) => {
        console.log("Event scheduled successfully:", scheduleResponse.data);
        setShowOffcanvas(false);
      })
      .catch((error) => {
        console.error("Error updating or scheduling event:", error);
      });
  };

  //for delete event from both DB and Google calendar
  const handleDeleteEvent = (id) => {
    axios
      .delete(`http://localhost:5000/apis/delete-event/${selectedEvent.id}`, {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      })
      .then(() => {
        // Remove the event from the local state
        setEvents(events.filter((event) => event.id !== id));
        setShowOffcanvas(false);

        console.log("Event deleted successfully");
      })
      .catch((error) => {
        console.error("Error deleting event:", error);
      });
  };

  // Sets the selected event when a user clicks on an event
  const handleSelectEvent = (event) => {
    setSelectedEvent(event);
    setShowOffcanvas(true);
  };

  const patients = [
    { _id: "1", name: "John Doe", email: "patient1@example.com" },
    { _id: "2", name: "Jane Smith", email: "patient2@example.com" },
  ];

  const teamMembers = [
    { _id: "101", name: "Dr. Alice Brown", email: "team1@example.com" },
    { _id: "102", name: "Nurse Bob White", email: "team2@example.com" },
  ];

  return (
    <div className="calender-container">
      <div className="btn-container">
        <button
          className="btn-event"
          onClick={() => {
            setSelectedEvent(null);
            toggleOffcanvas();
          }}
        >
          Add Event
        </button>
      </div>

      <Sidebar
        show={showOffcanvas}
        onHide={() => setShowOffcanvas(false)}
        onAddEvent={handleAddEvent}
        onEditEvent={handleEditEvent}
        onDeleteEvent={handleDeleteEvent}
        selectedEvent={selectedEvent}
        patients={patients}
        teamMembers={teamMembers}
      />

      <Calendar
        localizer={localizer}
        events={events} // Pass the formatted events to the Calendar
        startAccessor="start"
        endAccessor="end"
        style={{ height: "100vh" }}
        onSelectEvent={handleSelectEvent} // Handle event selection
      />
    </div>
  );
};

export default Calender;
