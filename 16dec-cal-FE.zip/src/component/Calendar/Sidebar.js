// import React, { useState, useEffect } from 'react';
// import './Sidebar.css';
// import moment from 'moment';

// const Sidebar = ({ show, onHide, onAddEvent, onEditEvent, onDeleteEvent, selectedEvent }) => {
//     console.log("selectedEvent---", selectedEvent);

//   const [eventTitle, setEventTitle] = useState('');
//   const [eventDate, setEventDate] = useState('');
//   const [eventStartTime, setEventStartTime] = useState('');
//   const [eventEndTime, setEventEndTime] = useState('');

//   useEffect(() => {
//     if (selectedEvent) {
//       setEventTitle(selectedEvent.title || '');
//       setEventDate(moment(selectedEvent.start).format('YYYY-MM-DD') || '');  // Matching event_date
//       setEventStartTime(selectedEvent.start ? moment(selectedEvent.start, 'HH:mm').format('HH:mm') : '');  // Matching event_startTime
//       setEventEndTime(selectedEvent.end ? moment(selectedEvent.end, 'HH:mm').format('HH:mm') : '');  // Matching event_endTime
//     } else {
//       setEventTitle('');
//       setEventDate('');
//       setEventStartTime('');
//       setEventEndTime('');
//     }
//   }, [selectedEvent]);

//   const handleSubmit = () => {
//     const newEvent = {
//       event_title: eventTitle,
//       event_date: moment(eventDate).set({ hour: eventStartTime.split(':')[0], minute: eventStartTime.split(':')[1] }).toDate(),  // Matching event_date
//       event_startTime: eventStartTime,
//       event_endTime: eventEndTime,
//     };

//     if (selectedEvent) {
//       // If an event is selected, update it
//       const updatedEvent = { ...selectedEvent, ...newEvent };
//       onEditEvent(updatedEvent);
//     } else {
//       // If no event is selected, create a new one
//       onAddEvent(newEvent);
//     }
//   };

//   const handleDelete = () => {
//     if (selectedEvent) {
//       onDeleteEvent(selectedEvent._id);  // Assuming _id is the event ID from the backend schema
//     }
//   };

//   const handleDateChange = (e) => {
//     const selectedDate = e.target.value;
//     const today = new Date().toISOString().split('T')[0];

//     if (selectedDate >= today) {
//       setEventDate(selectedDate);  // Renamed to match event_date
//     }
//   };

//   return (
//     <div className={`sidebar ${show ? 'show' : ''}`}>
//       <div className="sidebar-content">
//         <div className="sidebar-header">
//           <h3>{selectedEvent ? 'Edit Event' : 'Add Event'}</h3>
//           <button className="close-btn" onClick={onHide}>Close</button>
//         </div>
//         <div className="sidebar-body">
//           <label>Title</label>
//           <input
//             type="text"
//             placeholder="Event Title"
//             value={eventTitle}
//             onChange={(e) => setEventTitle(e.target.value)}  // Renamed to match event_title
//           />
//           <label>Date</label>
//           <input
//             type="date"
//             value={eventDate}
//             onChange={handleDateChange}
//           />
//           <label>Start Time</label>
//           <input
//             type="time"
//             value={eventStartTime}  // Renamed to match event_startTime
//             onChange={(e) => setEventStartTime(e.target.value)}  // Renamed to match event_startTime
//           />
//           <label>End Time</label>
//           <input
//             type="time"
//             value={eventEndTime}  // Renamed to match event_endTime
//             onChange={(e) => setEventEndTime(e.target.value)}  // Renamed to match event_endTime
//           />
//           <button className="btn btn-primary" onClick={handleSubmit}>{selectedEvent ? 'Update' : 'Submit'}</button>
//           {selectedEvent && <button className="btn btn-danger" onClick={handleDelete}>Delete</button>}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Sidebar;

//////////////////////

import React, { useState, useEffect } from "react";
import "./Sidebar.css";
import moment from "moment";

const Sidebar = ({
  show,
  onHide,
  onAddEvent,
  onEditEvent,
  onDeleteEvent,
  selectedEvent,
  patients, // List of patients (IDs and emails)
  teamMembers, // List of team members (IDs and emails)
}) => {
  console.log("selectedEvent---", selectedEvent);

  const [eventTitle, setEventTitle] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [eventStartTime, setEventStartTime] = useState("");
  const [eventEndTime, setEventEndTime] = useState("");
  const [patientId, setPatientId] = useState(""); // Patient dropdown value
  const [teamMemberId, setTeamMemberId] = useState(""); // Team member dropdown value

  useEffect(() => {
    if (selectedEvent) {
      // Extract and parse `start` and `end` from selectedEvent
      const startDate = moment(selectedEvent.start);
      const endDate = moment(selectedEvent.end);
  
      setEventTitle(selectedEvent.title || ""); // Map `title` to `event_title`
      setFromDate(startDate.format("YYYY-MM-DD")); // Extract and format the start date
      setToDate(endDate.format("YYYY-MM-DD")); // Extract and format the end date
      setEventStartTime(startDate.format("HH:mm")); // Extract and format the start time
      setEventEndTime(endDate.format("HH:mm")); // Extract and format the end time
      setPatientId(selectedEvent.patient_id || ""); // Ensure compatibility with your logic
      setTeamMemberId(selectedEvent.team_member_id || "");
    } else {
      // Clear all fields if no selectedEvent
      setEventTitle("");
      setFromDate("");
      setToDate("");
      setEventStartTime("");
      setEventEndTime("");
      setPatientId("");
      setTeamMemberId("");
    }
  }, [selectedEvent]);
  

  const handleSubmit = () => {
    const newEvent = {
      event_title: eventTitle,
      from_date: fromDate,
      to_date: toDate,
      event_startTime: eventStartTime,
      event_endTime: eventEndTime,
      patient_id: patientId,
      team_member_id: teamMemberId,
    };

    if (selectedEvent) {
      const updatedEvent = { ...selectedEvent, ...newEvent };
      onEditEvent(updatedEvent);
    } else {
      onAddEvent(newEvent);
    }
  };

  const handleDelete = () => {
    if (selectedEvent) {
      onDeleteEvent(selectedEvent._id);
    }
  };

  return (
    <div className={`sidebar ${show ? "show" : ""}`}>
      <div className="sidebar-content">
        <div className="sidebar-header">
          <h3>{selectedEvent ? "Edit Event" : "Add Event"}</h3>
          <button className="close-btn" onClick={onHide}>
            Close
          </button>
        </div>
        <div className="sidebar-body">
          <label>Title</label>
          <input
            type="text"
            placeholder="Event Title"
            value={eventTitle}
            onChange={(e) => setEventTitle(e.target.value)}
          />

          <label>From Date</label>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
          />

          <label>To Date</label>
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
          />

          <label>Start Time</label>
          <input
            type="time"
            value={eventStartTime}
            onChange={(e) => setEventStartTime(e.target.value)}
          />

          <label>End Time</label>
          <input
            type="time"
            value={eventEndTime}
            onChange={(e) => setEventEndTime(e.target.value)}
          />

          <label>Patient</label>
          <select
            value={patientId}
            onChange={(e) => setPatientId(e.target.value)}
          >
            <option value="">Select Patient</option>
            {patients.map((patient) => (
              <option key={patient._id} value={patient._id}>
                {patient.name} - {patient.email}
              </option>
            ))}
          </select>

          <label>Team Member</label>
          <select
            value={teamMemberId}
            onChange={(e) => setTeamMemberId(e.target.value)}
          >
            <option value="">Select Team Member</option>
            {teamMembers.map((member) => (
              <option key={member._id} value={member._id}>
                {member.name} - {member.email}
              </option>
            ))}
          </select>

          <button className="btn btn-primary" onClick={handleSubmit}>
            {selectedEvent ? "Update" : "Submit"}
          </button>
          {selectedEvent && (
            <button className="btn btn-danger" onClick={handleDelete}>
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
