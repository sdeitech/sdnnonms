import Users from "../models/userModel";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import Userlist from "../models/userList"
import { OAuth2Client } from "google-auth-library";

const client_id="368841272750-bsgr39djulkqk32p6utco69sqsjj83mc.apps.googleusercontent.com"
const client = new OAuth2Client(client_id)
//registraion 
export const registerUser = async (req, res) => {
  try {
    const { firstname, lastname,email, DOB,password,gender } = req.body;
    const profile = req.file?.filename;
    if (!firstname || !lastname || !email || !DOB || !gender || !profile || !password) {
      return res
        .status(400)
        .json({message:"all fields are required"})
        // .json({ message: MESSAGE.ALL_FILEDS_REQ });

    }

    //password bcrypting
    const pass = await bcrypt.hash(password, 10);
    const user = new Users({
      firstname,
      lastname,
      email,
      DOB,
      gender,
      profile: profile,
      password: pass,
    });

    await user.save();
    res.status(201).json({ msg: "user registered successfully" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};


//login
export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "All fields are required"});
    }
    const existUser = await Users.findOne({ email: email });
    // console.log(existUser);

    if (!existUser) {
      return res
        .status(400)
        .json({ msg: "user not found" });
    }

    //checking password entered by user and database user passsword
    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "Thankyou");

    //generating token for user
    if (isMatch) {
      console.log(existUser);
      const dataToBeSend={
        id : existUser._id,
        email :existUser.email,
        firstname : existUser.firstname,
        lastname : existUser.lastname,
        DOB : existUser.DOB,
        gender : existUser.gender
        
      }
      const token = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
      return res
        .status(200)
        .json({ msg: "user logged in successfully", token: token, email:email ,userId:existUser._id});
    } else {
      return res
        .status(400)
        .json({ msg: "invalid credentials" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ msg: error.message });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const users = await Users.find();
    res.json({ users: users, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.addUserInList = async (req, res) => {
   try {
    const newUser = new Userlist(req.body);
    await newUser.save();
    // const login = await Users.findByIdAndUpdate(req.params.id,{
    //   $push:{users:newUser}
    // })
    // await login.save();
    return res.status(201).json(newUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }

  // const {firstname,lastname,email,gender,phone,users}=req.body;
  // const userId=req.user.userId

  // console.log('userid',userId);
  // const user = new FileList({
  //   firstname:firstname,
  //   lastname:lastname,
  //   email:email,
  //   gender:gender,
  //   phone:phone,
  //   users:users

  // })
  // await user.save();
  //   return res.status(201).json(user);
  // } catch (error) {
  //   res.status(400).json({ error: error.message });
  // }
  
}

exports.getUserInList = async (req, res) => {
  try {
    const userId =req.query.userId
    const users = await Userlist.find(userId);
    res.json({ users: users, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
export const GetUsers = async (req, res) => {
  try {
      const { search = "", page = 1, limit = 4} = req.query;

      let pageNo = Number(page)

      let pageLimit = Number(limit)
      let skip = (pageNo - 1) * pageLimit

      // const user = await Users.find({})
      // if (!user) {
      //     return res.status(400).json({ message: "user not found" })
      const userDetail = await Userlist.find({userId:req.params.id})
      
      // }
      const userDetails = await Userlist.find({userId:req.params.id,firstname:{$regex:search,$options:"i"}}).skip(skip).limit(pageLimit)
      console.log(userDetails)
    

      const totalRecord = userDetail.length
      console.log(totalRecord)
      const totalPages = Math.ceil(totalRecord / pageLimit)
      res.status(200).json({ user: userDetails ,totalPages:totalPages,pageNo:pageNo})

  } catch (error) {
      console.log(`Error while getting user ${error.message}`)
      res.status(500).json({ message: error.message })
  }
}

//   const {searchText}=req.query;
//   const userId=req.user.userId
//   console.log('userId.........',userId);
  
//   let filter={};
//   filter.userId=userId;
//   if(searchText){
//     filter = {
//       $or:[
//         {firstname:{$regex:searchText,$options:'i'}},
//         {lastname:{$regex:searchText,$options:'i'}},

//       ]
//     };
//   }}
// };

exports.updateUserInList = async(req,res)=>{
  const{id}=req.params;
  console.log(id);
  
  try{
   
   if(id)
   {
     const updateUser = await Users.findByIdAndUpdate(id,req.body);
     return res.status(200).json(getUpdatedData);
      }
      
      else{
          return res.status(400).json({message:"id not found"});
      }
   }
   catch(error)
   {
      return res.status(400).json(error);
   }
  };

exports.getdatabyemail = async (req, res) => {
  try {
    const{email}=req.params;
    const users = await Users.findOne({email:email},{password:0});
    res.json({ users: users, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.updateUser = async(req,res)=>{
      const{id}=req.params;
      console.log(">......",id)
      try{
       
       if(id)  
       {
        console.log(req.body);
         const updateUser = await Users.findByIdAndUpdate(id,req.body);
         console.log(req.body);
         
         return res.status(200).json(updateUser);
          }
          
          else{
              return res.status(400).json({message:"id not found"});
          }
       }
       catch(error)
       {
          return res.status(400).json(error);
       }
};

exports.getRegisterUserById = async(req,res)=>{
  try{
    const {id}=req.params;
    const user =await Users.findById(id);

    if(!user){
      return res.status(404).json({message:"User not found"});

    }
    res.status(200).json(user);
  }catch(error){
    res.status(500).json
  }
}


exports.googleAuth = async (req, res) => {
  try {
      const { token } = req.body

      const ticket = await client.verifyIdToken({
          idToken: token,
          audience: client_id
      })
      console.log(ticket);
      

      const payload = ticket?.payload
      const email = payload?.email
      const pass = payload?.sub
      const firstname = payload?.given_name
      const lastname = payload?.family_name
      console.log(email, pass)
      // console.log(ticket)

      const user = new Users({
         firstname:firstname,
         lastname:lastname,
         email:email,
         password:pass
      })

      const data = await user.save()
      console.log(data)

  } catch (error) {
      console.log(error.message)
  }
}

