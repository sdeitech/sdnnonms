import express from "express";
import { getRegisterUserById,registerUser, userLogin,getUsers,getdatabyemail,addUserInList,getUserInList,updateUserInList,updateUser,googleAuth} from "../controllers/userController";
//  import {addUserInList,getUserInList,updateUserInList,updateUser} from "../controllers/usercontrollerforlist";
import { uploadMiddleware } from "../helper/multer";
import { verifyToken } from "../middleware/verifytoken";
const userRouter = express.Router();

//signup api call
userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);

//login api call
userRouter.post("/login", userLogin);

userRouter.get("/getdata",getUsers)

userRouter.post("/postdata", verifyToken , addUserInList)

userRouter.get("/getdataInList",verifyToken ,getUserInList)

userRouter.put("/updateUserInList/:id",updateUserInList)
userRouter.put("/updateUser/:id", uploadMiddleware.single("profile"),updateUser)
// userRouter.put("/updateUserInList",updateUserInList)

userRouter.get("/getdatausingemail/:email",getdatabyemail)
userRouter.get("/getRegisterUserById",getRegisterUserById)

userRouter.post("/googlelogin",googleAuth)


userRouter.post('/createUser/v1', verifyToken)


export default userRouter;