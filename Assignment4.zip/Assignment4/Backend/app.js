import express from "express";
import cors from "cors";
const app = express();

import userRouter from "./routes/userRoute";


app.use(express.json());
app.use(cors({ origin: "*" }));
app.use("/getimg", express.static("profiles"));

app.use("/api", userRouter);

export default app;