
// import React,{useEffect,useState} from "react";
// import Pagination from "@mui/material/Pagination";
// import Stack from "@mui/material/Stack";
// import axios from "axios";

// const Paginate = () => {

//     const [userdata,setUserdata] = useState([])
//     const [totalpage,setTotalpage] = useState(1)
//     const [currentpage,setCurrentpage] = useState(1)
//     const [search,setSearch] = useState("")
//     console.log(userdata,"hkjsahdd")
//     console.log(totalpage,currentpage)
//     const handlepage =(event,page) => {
//         setCurrentpage(page)


//     }

//     const fetchData =async () => {
//         try {
//             const res = await axios.get(`http://localhost:3214/api/getdataInList/66f7c1d55e3028ff8e4c941b?search=${search}&page=${currentpage}&limit=5`,{
//                 headers:{

//                     Authorization:localStorage.getItem("usertoken")
//                 }
//             })
//             console.log(res.data,"aryan")
//             setUserdata(res.data.user)
//             setTotalpage(res.data.totalPages)
//             setCurrentpage(res.data.pageNo)
//         } catch (error) {
//             console.log(error)
//         }
//     }
//     useEffect(() => {
//         fetchData()
//     },[currentpage,search])

// const handleSearch = ( e) => {
//     setSearch(e.target.value)
// }

//   return (
//     <div>
//     <input type="text" placeholder="search"
//     onChange={handleSearch}/>
//         <div>
//         <table
//           style={{
//             border: "5px solid",
//             marginLeft: "auto",
//             marginRight: "auto",
//             // marginTop: "10px",
//             width: "100%",
//             height: "50%",
//             alignItems: "center",
//             textAlign: "center",
//           }}
//         >
//           <thead style={{ border: "1px solid" }}>
//             <tr style={{ border: "1px solid" }}>
//               <th>firstname</th>
//               <th>lastname</th>
//               <th>email</th>
//               <th>Action</th>
//             </tr>
//           </thead>
//           <tbody style={{ border: "1px solid" }}>
//             {
//               userdata.map((item) => {
//                 return (
//                   <tr key={item._id}>
//                     <td>{item.firstname}</td>
//                     <td>{item.lastname}</td>
//                     <td>{item.email}</td>
//                     <td>
//                       <button onClick={() => Handleview(item)}>View</button>
//                     </td>
//                   </tr>
//                 );
//               })}
//           </tbody>
//         </table>
//         </div>
//       <Stack spacing={2}>
//         <Pagination 
//         count={totalpage} page ={currentpage}
//         onChange={handlepage}
//         variant="outlined" />
//       </Stack>
//     </div>
//   );
// };

// export default Paginate;