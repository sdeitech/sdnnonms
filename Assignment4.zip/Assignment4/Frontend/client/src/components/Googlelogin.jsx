import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google"
import axios from "axios"

const clientId = process.env.REACT_APP_CLIENT_ID

const Signgoogle= () => {
    console.log(clientId)

    const handleSubmit = async (response) => {
        const { credential } = response
        try {
            const res = await axios.post("http://localhost:3214/api/googlelogin", { token: credential })
            console.log(res)

        } catch (error) {
            console.log(error.message)
        }
    }

    const handleErrro = (error) => {
        console.log(error.message)

    }
    return (
        <div>
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={handleSubmit}
                    onError={handleErrro} />
            </GoogleOAuthProvider>
        </div>
    )
}

export default Signgoogle