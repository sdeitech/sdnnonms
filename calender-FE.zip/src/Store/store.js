import { configureStore } from "@reduxjs/toolkit";
import LoginSignUpReducer from '../Login SignUp/loginSignUpSlice'
                                   
export default configureStore( {                  
    reducer : {
       LoginR : LoginSignUpReducer
    }
})