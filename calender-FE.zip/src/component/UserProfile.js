import { useState, useEffect } from "react";
import {
    TextField,
    Button,
} from "@mui/material";
import Checkbox from '@mui/material/Checkbox';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import { Link } from "react-router-dom";
import axios from 'axios';

const UserProfile = () => {
    const user = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    const [data, setData] = useState([]);

    // Fetch user data from API
    const fetchUserById = async (user) => {
        try {
            const response = await axios.get(`http://localhost:5000/api/${user}`, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            setData(response.data);
        } catch (error) {
            setData([]);
        }
    };

    useEffect(() => {
        fetchUserById(user);
    }, [user]);


    // const handleChange = (e) => {
    //     const { name, value, type, checked } = e.target;
    //     setData((prevData) => ({
    //         ...prevData,
    //         [name]: type === 'checkbox' ? checked : value,
    //     }));
    // };

    const handleChange = (e) => {
        const { name, value, type, checked, files } = e.target;
        if (type === "file") {
            setData({ ...data, [name]: files[0] });
        } else if (type === "checkbox") {
            setData({ ...data, [name]: checked });
        } else {
            setData({ ...data, [name]: value });
        }
      };

    // const handleSubmit = async (e) => {
    //     e.preventDefault();
    //     try {
    //         await axios.put(`http://localhost:5000/api/${user}`, data, {
    //             headers: {
    //                 Authorization: `${token}`,
    //                 'Content-Type': 'application/json'
    //             }
    //         });
    //         Swal.fire('Success', 'User Updated Successfully', 'success');
    //     } catch (error) {
    //         console.error('Error Updating user data', error);
    //     }
    // };
    // console.log('gender-----------',data.gender)



    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:5000/api/${user}`, data, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'multipart/form-data'
                }
            });
            Swal.fire('Success', 'User Updated Successfully', 'success');
        } catch (error) {
            console.error('Error Updating user data', error);
        }
    };

    
    return (
        <form onSubmit={handleSubmit} className="form-container">
            <h1>User Profile</h1>

            <div className="profile">
                <p>Profile Picture</p>
                <img
                    // src={`http://localhost:5000/getimg/${data.photo}`}
                    src ={data.photo}
                    alt="photo"
                    height={100}
                    width={100}
                />
            </div>

            <div>
                <label>Profile Picture:</label>
                <input type="file" name="photo" 
                id="photo" onChange={handleChange} />
              </div>

            <TextField
                id="firstName"
                name="firstName"
                value={data.firstName}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />

            <TextField
                id="lastName"
                name="lastName"
                value={data.lastName}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />

            <TextField
                id="email"
                name="email"
                value={data.email}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />


            <FormControlLabel
                control={<Checkbox name="maritalStatus" checked= {!!data.maritalStatus} onChange={handleChange} />}
                label="Married"
            />

            <FormControl>
                <RadioGroup
                    aria-labelledby="gender-label"
                    name="gender"
                    value={data?.gender || ""}
                    onChange={handleChange}
                >
                    <FormControlLabel value="female" control={<Radio />} label="Female" />
                    <FormControlLabel value="male" control={<Radio />} label="Male" />
                    <FormControlLabel value="other" control={<Radio />} label="Other" />
                </RadioGroup>
            </FormControl>

            <Button variant="contained" color="primary" type="submit">
                Update
            </Button>

            <Button
                variant="outlined"
                color="secondary"
                sx={{ mt: 2 }}
            >
                <Link to="/change-password" style={{ textDecoration: 'none', color: 'inherit' }}>
                    Change Password
                </Link>
            </Button>

            <Button
                variant="outlined"
                color="secondary"
                sx={{ mt: 2 }}
            >
                <Link to="/students" style={{ textDecoration: 'none', color: 'inherit' }}>
                    Cancle
                </Link>
            </Button>
        </form>
    );
};

export default UserProfile;
