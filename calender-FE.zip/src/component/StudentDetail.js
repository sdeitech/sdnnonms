
import * as React from 'react';
import axios from 'axios';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Typography, Box } from "@mui/material";

export default function StudentDetails() {

    const [data, setData] = useState([])

    console.log('data-----', typeof data)

    const params = useParams()

    const token = localStorage.getItem('token')

    const fetchDataById = async (id) => {
        try {
            const response = await axios.get(`http://localhost:5000/apis/get-student/${id}`,{
                headers: {
                  Authorization: `${token}`, 
                  'Content-Type': 'application/json' 
              }
              })
            console.log(response.data)
            setData(response.data)
        } catch (error) {
            setData([])
        }
    }

    useEffect(() => {
        fetchDataById(params.id)
    }, [params.id])

    return (
        <Box 
            sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center', 
                p: 2, 
                backgroundColor: '#f9f9f9', 
                borderRadius: '8px', 
                boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
                maxWidth: '400px',
                margin: 'auto'
            }}
        >
            <Typography variant="h4" component="div" sx={{ mb: 2, fontWeight: 'bold' }}>
                Student Information
            </Typography>

            <Typography variant="h6" component="div" sx={{ mb: 1 }}>
                First Name: <span style={{ color: '#3f51b5' }}>{data.firstName}</span>
            </Typography>

            <Typography variant="h6" component="div" sx={{ mb: 1 }}>
                Last Name: <span style={{ color: '#3f51b5' }}>{data.lastName}</span>
            </Typography>

            <Typography variant="h6" component="div" sx={{ mb: 1 }}>
                Email: <span style={{ color: '#3f51b5' }}>{data.email}</span>
            </Typography>
        </Box>
    );
}

