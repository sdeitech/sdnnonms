import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Loginform from "../Login SignUp/loginform";
import SignUp from "../Login SignUp/SignUpForm";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Loginform /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    }
    
    
];
export default publicRoutes;
