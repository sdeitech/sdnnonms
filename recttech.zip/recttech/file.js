const express = require('express');
const Product = require('../models/Product');
const multer = require('multer');

const router = express.Router();

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Create product
router.post('/create', upload.single('image'), async (req, res) => {
  try {
    const { name, price, description } = req.body;
    const product = new Product({
      name,
      price,
      description,
      imageUrl: req.file ? `/uploads/${req.file.filename}` : ''
    });
    await product.save();
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Read all products
router.get('/', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update product
router.put('/update/:id', async (req, res) => {
  try {
    const { name, price, description } = req.body;
    const product = await Product.findByIdAndUpdate(req.params.id, { name, price, description }, { new: true });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete product
router.delete('/delete/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;


const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const productRoutes = require('./routes/productRoutes');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads')); // Serve image files statically

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Product Routes
app.use('/api/products', productRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import CreateProduct from './components/CreateProduct';
import ProductList from './components/ProductList';
import EditProduct from './components/EditProduct';
// frontend
const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/create-product" component={CreateProduct} />
        <Route path="/products" component={ProductList} />
        <Route path="/edit-product/:id" component={EditProduct} />
      </Switch>
    </Router>
  );
};

export default App;


import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const CreateProduct = () => {
  const [product, setProduct] = useState({ name: '', price: '', description: '' });
  const [image, setImage] = useState(null);
  const history = useHistory();

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', product.name);
    formData.append('price', product.price);
    formData.append('description', product.description);
    formData.append('image', image);

    try {
      await axios.post('http://localhost:5000/api/products/create', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      history.push('/products');
    } catch (err) {
      console.error('Error creating product', err);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="price" placeholder="Price" onChange={handleChange} />
      <textarea name="description" placeholder="Description" onChange={handleChange} />
      <input type="file" onChange={handleFileChange} />
      <button type="submit">Create Product</button>
    </form>
  );
};

export default CreateProduct;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const res = await axios.get('http://localhost:5000/api/products');
      setProducts(res.data);
    };
    fetchProducts();
  }, []);

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/api/products/delete/${id}`);
    setProducts(products.filter(product => product._id !== id));
  };

  return (
    <div>
      <Link to="/create-product">Add Product</Link>
      <ul>
        {products.map(product => (
          <li key={product._id}>
            {product.name} - ${product.price}
            <Link to={`/edit-product/${product._id}`}>Edit</Link>
            <button onClick={() => handleDelete(product._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductList;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';

const EditProduct = () => {
  const { id } = useParams();
  const history = useHistory();
  const [product, setProduct] = useState({ name: '', price: '', description: '' });

  useEffect(() => {
    const fetchProduct = async () => {
      const res = await axios.get(`http://localhost:5000/api/products/${id}`);
      setProduct(res.data);
    };
    fetchProduct();
  }, [id]);

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/api/products/update/${id}`, product);
      history.push('/products');
    } catch (err) {
      console.error('Error updating product', err);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Name" value={product.name} onChange={handleChange} />
      <input name="price" placeholder="Price" value={product.price} onChange={handleChange} />
      <textarea name="description" placeholder="Description" value={product.description} onChange={handleChange} />
      <button type="submit">Update Product</button>
    </form>
  );
};

export default EditProduct;


import axios from 'axios';

// Set the base URL for API
const API_URL = 'http://localhost:5000/api/products';

// Create a product (with file upload)
export const createProduct = async (productData) => {
  const formData = new FormData();
  formData.append('name', productData.name);
  formData.append('price', productData.price);
  formData.append('description', productData.description);
  if (productData.image) {
    formData.append('image', productData.image);
  }

  const response = await axios.post(`${API_URL}/create`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

// Get all products
export const getProducts = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

// Get a single product by ID
export const getProductById = async (id) => {
  const response = await axios.get(`${API_URL}/${id}`);
  return response.data;
};

// Update a product by ID
export const updateProduct = async (id, productData) => {
  const response = await axios.put(`${API_URL}/update/${id}`, productData);
  return response.data;
};

// Delete a product by ID
export const deleteProduct = async (id) => {
  const response = await axios.delete(`${API_URL}/delete/${id}`);
  return response.data;
};
