import React from 'react'
import {Link} from 'react-router-dom';

export const Dashboard = () => {
  return (
    <div>
        <Link to="/myprofile">My Profile</Link>
    </div>
  )
}
