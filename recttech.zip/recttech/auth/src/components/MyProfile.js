import { useRef,useState } from 'react'
import React from 'react'
import {Link} from 'react-router-dom'



export const MyProfile = () => {
     
  const inputRef =useRef(null);
  const [image , setImage] = useState(" ");

  const handleImageClick = () =>{
    inputRef.current.click();
  };

  const handleImageChange = (event) =>{
    const file = event.target.files[0];
    console.log(file)
    setImage(event.target.files[0]);
  }
   
    const userInfo = localStorage.getItem("info");
    const newUserInfo = JSON.parse(userInfo)
    console.log("xcdfd" ,newUserInfo);

  return (
    <div>
        <h1>My Profile</h1>
        <div onClick={handleImageClick}>
        <input type="file" ref={inputRef} onChange={handleImageChange}/>
          <img 
          style={{
            width: "200px",
            height: "200px",
            borderRadius: "50%",
            objectFit: "cover",
          }}
          src='../Shiv.png'
          alt=''

          />
        </div>
        <div>
            <p>FirstName:{newUserInfo.firstName}</p>
            <p>Last Name:{newUserInfo.lastName}</p>
            <p>Email:{newUserInfo.email}</p>
            <p>Date Of Birth:{newUserInfo.DOB}</p>
            <p>Gender:{newUserInfo.gender}</p>
            <p>Married:{newUserInfo.isMarried}</p>
            {/* <p>Profile:{newUserInfo.profile}</p>    */}
            <button type="submit">Update</button>
        </div>
        <Link to='/dashboard'>Dashboard</Link>
    </div>
  )
}
