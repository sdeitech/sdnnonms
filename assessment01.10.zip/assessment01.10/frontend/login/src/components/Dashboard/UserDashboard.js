import Container from 'react-bootstrap/Container';

import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from 'react-router-dom';

function DashboardNavbar() {
  const navigate = useNavigate();

  const logoutHandle = () => {
    localStorage.removeItem("token")
      navigate('/')
    
  }
 
  return (
    <>
      <Navbar bg="primary" data-bs-theme="dark">
        <Container className="justify-content-center">
          <Navbar.Brand href="#home" className="text-center">Dashboard</Navbar.Brand>
          <button type="button"  onClick={logoutHandle}>
                        logout</button>
        </Container>
      </Navbar>
      <br/>
    </>
  );
}

export default DashboardNavbar;
