import { useState } from 'react';
import axios from 'axios';
import './signup.css';
import { useNavigate } from 'react-router-dom';
import RegisterNavbar from '../components/RegNavbar';

function SignupPage() {
    const navigate = useNavigate();

    const [user1, setuser1] = useState({
        FirstName: "",
        LastName: "",
        Email: "",
        Password: "",
        DOB: "",
        Gender: "",
        IsMarried: false, // Initialize as false
    });

    const handlechange = (e) => {
        const { name, value, type, checked } = e.target;
        setuser1((prevUser) => ({
            ...prevUser,
            [name]: type === 'checkbox' ? checked : value, // Handle checkbox
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await axios.post("http://localhost:5000/toregister", user1);
            console.log("You signed up successfully", result.data.user1);
            navigate("/");
        } catch (error) {
            console.log("Error", error);
        }
    };

    return (
        <>
            <RegisterNavbar />
            <div><h1>Registration Form</h1></div>
            <div className="Signup-container">
                <form onSubmit={handleSubmit} className='Signup-form'>
                    <input type="text" name='FirstName' placeholder="First Name" onChange={handlechange} />
                    <input type="text" name='LastName' placeholder="Last Name" onChange={handlechange} />
                    <input type="email" name='Email' placeholder="Email" onChange={handlechange} />
                    <input type="password" name='Password' placeholder="Password" onChange={handlechange} />
                    <input type="date" name='DOB' placeholder="DOB" onChange={handlechange} />

                    <div className='gender'>
                        <label>Gender</label>
                        <label>Male</label>
                        <input type="radio" name='Gender' value="Male" checked={user1.Gender === "Male"} onChange={handlechange} />
                        <label>Female</label>
                        <input type="radio" name='Gender' value="Female" checked={user1.Gender === "Female"} onChange={handlechange} />
                    </div>

                    <label>Is Married</label>
                    <input type="checkbox" name='IsMarried' checked={user1.IsMarried} onChange={handlechange} />

                    <button type="submit" className='Signup-button'>
                        Submit
                    </button>
                    <div>
                        <button type="button" className='Signup-button' onClick={() => navigate('/')}>
                            Old User
                        </button>
                    </div>
                </form>
            </div>
        </>
    );
}

export default SignupPage;
