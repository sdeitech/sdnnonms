import './App.css';
// import UserDetails from './components/Dashboard/UserDetails';
import routes from "./Routers/routes";
import { RouterProvider } from "react-router-dom";
// import LoginPage from './components/LoginPage';
// import RegisterNavbar from './components/RegNavbars';
// import Routersforuse from './components/Routers';
// import SignupPage from './components/Signup';


function App() {
  return (
    <div className="App">
      {/* <RegisterNavbar /> */}
      <RouterProvider router={routes} />
      {/* <Routersforuse/> */}
      {/* < SignupPage/> */}
      {/* <LoginPage /> */}
      {/* < UserDetails/> */}
    </div>
  );
}

export default App;
