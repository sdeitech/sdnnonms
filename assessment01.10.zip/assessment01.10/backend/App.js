const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const db = require("./config/db");
const routerPath = require("./routers/routers");
const userPath = require("./routers/routers");
const { PORTNO } = require("./config/constants");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use("/", routerPath);
// app.use("/", userPath);


console.log(PORTNO);
app.listen(PORTNO, () => {
  console.log(`Server started on http://localhost:${PORTNO}`);
});