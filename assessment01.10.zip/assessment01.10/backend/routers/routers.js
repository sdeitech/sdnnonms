const express = require('express');
const router = express.Router();
const UserRegister = require('../controller/UserRegister')

router.post('/toregister',UserRegister.register);
router.post('/tologin',UserRegister.logIn); 
//this is to adduser
router.post('/tocreate',UserRegister.CreateUser);
// this is for get user
router.get('/togetdata',UserRegister.getUser);

router.put('/for/update/:id',UserRegister.updateUser);

module.exports = router;