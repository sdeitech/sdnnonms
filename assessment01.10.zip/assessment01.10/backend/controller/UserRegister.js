const bcrypt = require("bcrypt");
const user = require('../models/registermodel');
const jwt = require("jsonwebtoken");
const { BAD_REQUEST, NOT_FOUND, CREATED, RECORD_NOT_FOUND } = require("../config/constants");
const useradd= require('../models/CreateUsermodel')

exports.register = async (req, res) => {
    const { FirstName,LastName,Email, Password,DOB,Gender,IsMarried} = req.body;
    
    
    if (!( FirstName && LastName && Email && Password && DOB && Gender && IsMarried)) {
        return res
            .status(BAD_REQUEST)
            .json({ status: BAD_REQUEST, message: "all field are mandatoy" });
    }
    try {
        const olduser = await user.findOne({ email:Email });
    
        if (olduser) {
            return res
                .status(NOT_FOUND)
                .json({ status: NOT_FOUND, message: "user allready registered" });
        }

        const hashPassword = await bcrypt.hash(Password, 10);

        req.body.Password = hashPassword;
        console.log(hashPassword);
        
        const newUser = new user(req.body);
        // console.log(newUser);
                

         await newUser.save();
         console.log("new user created:",req.body);
         
        return res
            .status(CREATED)
            .json({
                status: CREATED,
                message: "user inserted succussfully",
                user: newUser,
            });


    } catch (error) {
        console.log(error.message);
        res
            .status(BAD_REQUEST)
            .json({
                status: CREATED,
                message: "faild to register user",
                error: error.message
            });
    }
};


exports.logIn = async (req, res) => {
    const { Email, Password } = req.body

    if (!(Email && Password)) {
        return res
            .status(BAD_REQUEST)
            .json({
                message: "all fields are mandatory",
                status: BAD_REQUEST
            })
    }
    
    try {
        const User = await user.findOne({ Email: Email })
        if (!user) {
            return res.status(BAD_REQUEST).json({ message: "user not exists" })
        }
    
        const isCorrect = await bcrypt.compare(Password, User.Password)
        console.log(Password);
        console.log(User.Password);
        
        // console.log(isCorrect);
        
    
        if (isCorrect) {
            console.log(Password);
            
            const token = jwt.sign({ Email }, "user token created");
            User.token = token
            await User.save()
            
            
            return res
                .status(200)
                .json({ message: "token gentrated succusssfully", token,User })
        }
        return res.status(BAD_REQUEST).json({ message: "incorrect password,login failed", status: BAD_REQUEST }
        )
    } catch (error) {
        res.status(BAD_REQUEST).json({ message: "loginfaield", error: error.message })
    }
}


exports.CreateUser = async (req,res) => {
     console.log("user create function is ready");
     const { FirstName,LastName,Email} = req.body;

     
     try {
        const newUser = new useradd(req.body)
        // console.log(newUser);
        
          const newone  = await newUser.save();
        console.log(newone);
        
        res.status(200).json(newUser);
        // console.log(newUser);
        
        console.log("user added succussfully");
        console.log(newUser);
        
        
     } catch (error) {
      res.status(BAD_REQUEST).json({error:error.message});

     }

};

exports.getUser = async (req,res) => {
    try {
    const { page=1,limit=10,search= ""} = req.query;
    let pageNo =Number(page);
    let limitNo = Number(limit);
    let skip = (pageNo-1)*limitNo;
   
       const UserDetail = await user.findById(req.params.id).populate({
        path:"user",
        match:search.trim() ?{FirstName:{$regex:search.trim(),$options: "i"}}:{},
        options:{
            skip:skip,
            limit:limitNo
        }
       })

    } catch (error) {
        res.status(BAD_REQUEST).json({error:error.message});
    }
}

export const updateUser = async (req, res) => {
    try {
        const newuser = await user.findByIdAndUpdate(req.params.id, req.body, { new: true })
        if (!newuser) {
            return res.status(NOT_FOUND).json({ message:RECORD_NOT_FOUND })
        }
        res.status(CREATED).json({ message: "updated"})


    } catch (error) {
        console.log(`Error while getting user ${error.message}`)
        // res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}



