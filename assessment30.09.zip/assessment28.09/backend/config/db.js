import mongoose from "mongoose";
import constants from "./constants";


mongoose.connect(constants.DBURL);
const db = mongoose.connection;

db.on("error", console.error.bind("Conection Failed "));
db.once("open", () => {
  console.log("DB Server is connected to server");
});

module.exports = db;