const bcrypt = require("bcrypt");
const user = require('../models/registermodel');
const jwt = require("jsonwebtoken");
const { BAD_REQUEST, NOT_FOUND, CREATED } = require("../config/constants");
const useradd= require('../models/CreateUsermodel')

exports.register = async (req, res) => {
    const { FirstName,LastName,Email, Password,DOB,Gender,IsMarried} = req.body;
    
    
    if (!( FirstName && LastName && Email && Password && DOB && Gender && IsMarried)) {
        return res
            .status(BAD_REQUEST)
            .json({ status: BAD_REQUEST, message: "all field are mandatoy" });
    }
    try {
        const olduser = await user.findOne({ email:Email });
    
        if (olduser) {
            return res
                .status(NOT_FOUND)
                .json({ status: NOT_FOUND, message: "user allready registered" });
        }

        const hashPassword = await bcrypt.hash(Password, 10);

        req.body.Password = hashPassword;
        console.log(hashPassword);
        
        const newUser = new user(req.body);
        // console.log(newUser);
                

         await newUser.save();
         console.log("new user created:",req.body);
         
        return res
            .status(CREATED)
            .json({
                status: CREATED,
                message: "user inserted succussfully",
                user: newUser,
            });


    } catch (error) {
        console.log(error.message);
        res
            .status(BAD_REQUEST)
            .json({
                status: CREATED,
                message: "faild to register user",
                error: error.message
            });
    }
};


exports.logIn = async (req, res) => {
    const { Email, Password } = req.body

    if (!(Email && Password)) {
        return res
            .status(BAD_REQUEST)
            .json({
                message: "all fields are mandatory",
                status: BAD_REQUEST
            })
    }
    
    try {
        const User = await user.findOne({ Email: Email })
        if (!user) {
            return res.status(BAD_REQUEST).json({ message: "user not exists" })
        }
    
        const isCorrect = await bcrypt.compare(Password, User.Password)
        console.log(Password);
        console.log(User.Password);
        
        // console.log(isCorrect);
        
    
        if (isCorrect) {
            console.log(Password);
            
            const token = jwt.sign({ Email }, "user token created");
            User.token = token
            await User.save()
            return res
                .status(200)
                .json({ message: "token gentrated succusssfully", token })
        }
        return res.status(BAD_REQUEST).json({ message: "incorrect password,login failed", status: BAD_REQUEST }
        )
    } catch (error) {
        res.status(BAD_REQUEST).json({ message: "loginfaield", error: error.message })
    }
}


exports.CreateUser = async (req,res) => {
     console.log("user create function is ready");
     const { FirstName,LastName,Email} = req.body;

     
     try {
        const newUser = new useradd(req.body)
        // console.log(newUser);
        
          const newone  = await newUser.save();
        console.log(newone);
        
        res.status(200).json(newUser);
        // console.log(newUser);
        
        console.log("user added succussfully");
        console.log(newUser);
        
        
     } catch (error) {
      res.status(BAD_REQUEST).json({error:error.message});

     }

};


exports.getUser = async (req,res) => {
    const { page = 1,limit = 50,search= ""} = req.body;
    const pageNo =Number(page);
    const limitNo = Number(limit);
    const skip = (pageNo-1)*limitNo;
    try {
        const searchRegex = new RegExp(search,"i");
        const query = {
            $or:[
                {FirstName:{$regex:searchRegex}},
                {LastName:{$regex:searchRegex}},
                {Email:{$regex:searchRegex}},
            ]
        }
        const userData= await useradd.find(query).skip().limit(limitNo);
        const totalNoOfRecords = await useradd.countDocuments(query);
        const totalPages =Math.ceil(totalNoOfRecords/limitNo);
        res.json({totalNoOfRecords,totalPages,pageNo,userData})
        console.log("users are in the database:");
        
    } catch (error) {
        res.status(BAD_REQUEST).json({error:error.message});
    }
}



