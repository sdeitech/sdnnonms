import mongoose from 'mongoose';

const UseraddSchema = new mongoose.Schema({
    FirstName: { type: String, required: true },
    LastName: { type: String, required: true },
    Email: { type: String, required: true },
    }
);


const useradd = mongoose.model('Usersadd', UseraddSchema);
module.exports = useradd;