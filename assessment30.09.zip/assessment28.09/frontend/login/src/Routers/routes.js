import publicRoutes from "./PublicRoutes";
import privateRoutes from "./PrivateRouters";
import { createBrowserRouter} from "react-router-dom";

const routers = createBrowserRouter([
	...publicRoutes,
	...privateRoutes
]);

export default routers;