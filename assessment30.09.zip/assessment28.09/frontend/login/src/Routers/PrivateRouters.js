import React from 'react'
import PrivateLayout from '../layout/Privatelayout'
// import Dashboard from '../components/Dashboard'
// import AddUser from '../components/AddUser'

const PrivateRoute = [
    {
        path: "/user",
        exact: true,
        element: <PrivateLayout></PrivateLayout>
    },
    {
        path: "/add/user",
        exact: true,
        element: <PrivateLayout></PrivateLayout>
    }
]

export default PrivateRoute