import axios from "axios";
import { useState, useEffect } from "react";
import { Table } from "react-bootstrap";
import DashboardNavbar from "./UserDashboard";
import ViewModal from "./viewdetails";

function UserDetails() {
    const [showForm, setShowForm] = useState(false);
    const [show,setShow] = useState(false);
    const [users, setUsers] = useState([]);
    const [viewUser,setviewuser] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    // const [currentPage, setCurrentPage] = useState(1);
    // const [itemsPerPage] = useState(5);
    const [user, setUser] = useState({
        FirstName: "",
        LastName: "",
        Email: "",
    });
    // console.log(users);
    // console.log(viewUser,"bbbbbb");
    const handleAddUserClick = () => {
        setShowForm(!showForm);
    };

    const handleChange = (e) => {
        setUser({
            ...user,
            [e.target.name]: e.target.value,
        });
    };
    // const filteredData = users.filter(user => 
    //     user.FirstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    //     user.LastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    //     user.Email.toLowerCase().includes(searchTerm.toLowerCase()) 
    //   );
    
    //   const indexOfLastItem = currentPage * itemsPerPage;
    //   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    //   const currentItems = filteredData.slice(indexOfFirstItem, indexOfLastItem);
    
    //  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/tocreate', user);
            console.log("User data posted to database:", response.data);
            window.location.reload()
            setUsers(response.data)
            // setUser([...user, user]);
            // setUser({ FirstName: "", LastName: "", Email: "" }); 
            // setShowForm(false);
        } catch (error) {
            console.error("Error posting user data:",);
        }
    };
    
// For Modal View Handler
const handelShow = (ele) => {
    setShow(true);
    // console.log(viewUser);
    
    setviewuser(ele);

  };

  const handleClose = () => {
    setShow(false);
  };

    const getData = async () => {
        try {
            const response = await axios.get('http://localhost:5000/togetdata');
            setUsers(response.data.userData); // Update state with fetched users
            console.log("Fetched user data:", response.data.userData);
        } catch (error) {
            console.error("Failed to fetch data:", error);
        }
    };

    useEffect(() => {
        getData(); 
    }, []);

    return (
        <>
        <div style={{ marginBottom: '10px' }}>
        <input 
          type='text' 
          placeholder='Search...' 
          value={searchTerm} 
          onChange={(e) => setSearchTerm(e.target.value)} 
        />
      </div>
            <DashboardNavbar />
            <ViewModal
          show={show}
          viewUser={viewUser}
          handleClose={handleClose}
        />
            <button type="button" onClick={handleAddUserClick}>
                {showForm ? 'Close Form' : 'Add User'}
            </button>
            {showForm && (
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>First Name:</label>
                        <input
                            type="text"
                            name="FirstName"
                            value={user.FirstName}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Last Name:</label>
                        <input
                            type="text"
                            name="LastName"
                            value={user.LastName}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Email:</label>
                        <input
                            type="email"
                            name="Email"
                            value={user.Email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <button type="submit">Submit</button>
                    </div>
                </form>
            )}
            <div>
                <Table striped bordered hover variant="grey">
                    <thead>
                        <tr>
                            <th>SR No.</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                        users?.map((ele,index) => (

                            <tr key={index}>
                                <td>{index+1}</td>
                                <td>{ele.FirstName}</td>
                                <td>{ele.LastName}</td>
                                <td>{ele.Email}</td>
                                <td>
                                    <button onClick={()=>handelShow(ele)}>view</button>
                                    </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
            <ViewModal />
            {/* <div style={{ marginTop: '10px' }}>
        {Array.from({ length: totalPages }, (_, index) => (
          <button 
            key={index + 1} 
            className={`btn ${currentPage === index + 1 ? 'btn-secondary' : 'btn-outline-primary'}`} 
            onClick={() => setCurrentPage(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div> */}
        </>
    );
}

export default UserDetails;
