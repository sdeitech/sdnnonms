import { useState } from 'react';
import axios from 'axios';
import './LoginPage.css';
import {  useNavigate } from 'react-router-dom'; // Assuming you want to use a separate CSS file

function LoginPage() {

    const navigate = useNavigate();
    const [user, setUser] = useState({
        email: "",
        password: ""
    });

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await axios.post("h http://localhost:5000/tologin", user);
            localStorage.setItem("token", result.data.token);
            console.log("You logged in successfully", result.data.user);
            console.log(result.data.token);
            
        } catch (error) {
            console.log("Error", error);
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleSubmit} className="login-form">
                <input 
                    type="email" 
                    name="email" 
                    placeholder="Enter email" 
                    onChange={handleChange} 
                    required 
                />
                <input 
                    type="password" 
                    name="password" 
                    placeholder="Password" 
                    onChange={handleChange} 
                    required 
                />
                <button type="submit" className="login-button" onClick={() => navigate('dashboard')} >Submit</button>
                <div><div>
                <button type="submit" className="newuser-button" onClick={() => navigate('/signUp')}>New User</button>
                </div></div>
            </form>
        </div>
    );
}

export default LoginPage;
