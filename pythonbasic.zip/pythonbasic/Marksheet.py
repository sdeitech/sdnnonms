from ce.firstsem import input_marks

def getMarksheet_1():
    total_max, total_marks, max_practical, max_internal, max_theory, practical_mark, internal_marks, theory_marks=input_marks()
    