

def studentDetails():
    firstName=str(input("enter the firstName :: "))    
    lastName=str(input("enter the lastName :: "))    
    mother_name=str(input("enter the mother Name :: "))
    rollNumber=int(input("enter the roll Number :: "))
    collegeCode=int(input("enter the college code:: "))
    college_name=str(input("Enter the college name::  "))
    return firstName,lastName,mother_name,rollNumber,collegeCode,college_name

def showModel():
    firstName,lastName,mother_name,rollNumber,collegeCode,college_name=studentDetails()

    print("=============================================================================================================")
    print(f"|firstName    : {firstName}                                                                roll No: {rollNumber}         |")     
    print(f"|lastName     : {lastName}                                                                 college code:{collegeCode}     |")
    print(f"|mother name  : {mother_name}                                                                                       |")
    print(f"|college Name : {college_name}                                                                                    |")
    print("==============================================================================================================")