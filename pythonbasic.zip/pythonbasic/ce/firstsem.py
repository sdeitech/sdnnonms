subjects = {
    "M1": {"max_theory": 80, "max_practical": 0, "max_internal": 20},
    "Physics": {"max_theory": 70, "max_practical": 10, "max_internal": 20},
    "Chemistry": {"max_theory": 70, "max_practical": 10, "max_internal": 20},
    "English": {"max_theory": 80, "max_practical": 0, "max_internal": 20},
    "EG": {"max_theory": 70, "max_practical": 10, "max_internal": 20}
}

def input_valid_marks(prompt, max_marks):
    """Takes input for marks and ensures they are valid."""
    while True:
        try:
            marks = float(input(prompt))
            if marks < 0 or marks > max_marks:
                print("Invalid marks! Please enter marks between 0 and {max_marks}.")
            else:
                return marks
        except ValueError:
            print("Invalid input! Please enter a numeric value.")

def input_marks( subjects) :
    total_obtained = 0
    total_max = 0

    for subject_name, marks in subjects.items():
        print(f"\nEnter marks for {subject_name}:")
        max_theory = marks["max_theory"]
        max_practical = marks["max_practical"]
        max_internal = marks["max_internal"]

        theory_marks = input_valid_marks(f"Enter theory marks (out of {max_theory}): ", max_theory)

        practical_mark=0
        if(max_practical>0):
            practical_mark=input_valid_marks(f"Enter practical mark (out of {max_practical}): ",max_practical)

        internal_marks=input_valid_marks(f"Enter  internal marks (out of {max_internal}): ",max_internal)

        total_max=max_theory+max_internal+max_practical
        total_obtained=theory_marks+practical_mark+internal_marks
        
        return total_max, total_obtained

def generate_marksheet():
    """Generates the marksheet based on predefined subjects and user input."""
    total_obtained, total_max = input_marks(subjects)

   
    percentage = (total_obtained / total_max) * 100 if total_max > 0 else 0
    print(f"\nTotal Marks Obtained: {total_obtained}/{total_max}")
    print(f"Overall Percentage: {percentage:.2f}%")


generate_marksheet()