subjects = {
    "M1": {"max_theory": 80, "max_practical": 0, "max_internal": 20},
    "Physics": {"max_theory": 70, "max_practical": 10, "max_internal": 20},
    "Chemistry": {"max_theory": 70, "max_practical": 10, "max_internal": 20},
    "English": {"max_theory": 80, "max_practical": 0, "max_internal": 20},
    "EG": {"max_theory": 70, "max_practical": 10, "max_internal": 20}
}

obtained_marks = []
final_marks = []

def input_valid_marks(prompt, max_marks):
    """Takes input for marks and ensures they are valid."""
    while True:
        try:
            marks = float(input(prompt))
            if marks < 0 or marks > max_marks:
                print(f"Invalid marks! Please enter marks between 0 and {max_marks}.")
            else:
                return marks
        except ValueError:
            print("Invalid input! Please enter a numeric value.")

def input_marks(subjects):
    for subject_name, marks in subjects.items():
        print(f"\nEnter marks for {subject_name}:")
        max_theory = marks["max_theory"]
        max_practical = marks["max_practical"]
        max_internal = marks["max_internal"]

        theory_marks = input_valid_marks(f"Enter theory marks (out of {max_theory}): ", max_theory)

        practical_mark = 0
        if max_practical > 0:
            practical_mark = input_valid_marks(f"Enter practical mark (out of {max_practical}): ", max_practical)

        internal_marks = input_valid_marks(f"Enter internal marks (out of {max_internal}): ", max_internal)

        total_max = max_theory + max_internal + max_practical
        total_obtained = theory_marks + practical_mark + internal_marks

        final_marks.append([total_max, max_theory, max_practical, max_internal])
        obtained_marks.append([total_obtained, theory_marks, practical_mark, internal_marks])

def generate_marksheet():
    input_marks(subjects)

    total_obtained_sum = 0
    total_max_sum = 0

    print("\nMarksheet:")
    print(f"{'Subject':<12} {'Theory (Obtained/Max)':<25} {'Practical (Obtained/Max)':<30} {'Internal (Obtained/Max)':<30}     {'Status':<10}")

    print("-----------------------------------------------------------------------------------------------------------------------------------")
    

    for i in range(len(subjects)):
        subjects_name=list(subjects.keys())[i]
        total_obtained=obtained_marks[i][0]
        total_max=final_marks[i][0]

        theory_obtained = obtained_marks[i][1]
        practical_obtained = obtained_marks[i][2]
        internal_obtained = obtained_marks[i][3]

        theory_max = final_marks[i][1]
        practical_max = final_marks[i][2]
        internal_max = final_marks[i][3]

        theory_pass_marks = 0.35 * theory_max
        practical_pass_marks = 0.4 * practical_max if practical_max > 0 else 0
        internal_pass_marks = 0.35 * internal_max

        status = "Pass"
        if (theory_obtained < theory_pass_marks or
            practical_obtained < practical_pass_marks or
            internal_obtained < internal_pass_marks):
            status = "Fail"

        total_obtained_sum += total_obtained
        total_max_sum += total_max

        print(f"{subjects_name:<12} "  f"{theory_obtained} / {theory_max:<25} "
              f"{practical_obtained} / {practical_max:<25}"
              f"{internal_obtained } / {internal_max:<22} "
              f"{status:<10} ")
    # Calculate percentage
    percentage = (total_obtained_sum / total_max_sum) * 100
    print(f"\nTotal Marks Obtained: {total_obtained_sum}/{total_max_sum}")
    print(f"Overall Percentage: {percentage:.2f}%")


