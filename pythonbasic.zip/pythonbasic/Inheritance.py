# # single level inheritance
# class parent:
#     def car(self):
#         print("this is car")
# class child(parent):
#     def toy(self):
#         print("this is toy")

#     def car(self):
#         print("this is childs car")

# obj=child()
# obj.toy()
# obj.car()

'''calling parent class method''' 

class parent:
    def car(self):
        print("this is parent method")

class child(parent):
    def car(self):
        print("this is the child method")

        # accessing parent method with classname
        
        parent.car(self)
        # accessing parent method with super() keyword
        super().car()
    
   
obj=child()
obj.car()

