import ce.firstsem
from getModel import showModel


while True:
    sem = int(input("Enter the semester (1 to 8): "))
    
    if sem < 1:
        print("Please enter a valid semester number (1 or higher).")
    elif sem > 8:
        print("There are only 8 semesters. Please enter a number between 1 and 8.")
    else:
        break  
    
    # semester


if sem==1:
    
    import ce
    showModel()
    ce.firstsem.generate_marksheet()
    # from ce.firstsem import generate_marksheet
    # generate_marksheet()
    
from ce.secondsem import generate_marksheet
if sem==2:
    showModel()
        
