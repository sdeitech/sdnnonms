from ce.secondsem import *
name=str(input("enter the name ::"))
mother_name=str(input("enter the name ::"))
rollNumber=int(input("enter the name ::"))

while True:
    sem = int(input("Enter the semester (1 to 8): "))
    
    if sem < 1:
        print("Please enter a valid semester number (1 or higher).")
    elif sem > 8:
        print("There are only 8 semesters. Please enter a number between 1 and 8.")
    else:
        break  

# this is to render each semester
if sem==1:
    pass
elif sem==2:
    pass
