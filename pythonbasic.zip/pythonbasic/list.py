# list

# list is mutable or changeable order sequence of element
# we can update it
#  [1,2,3,4,'a','b']

# a=[1,2,3,4,5]
# # 1
# print(len(a))
# # 2
# a.pop()
# print(a)
# # 3
# a.pop(2)
# print(a)
# # 4
# a.append(12)
# print(a)
# # 5
# print(type(a))
# # 6


# a.append(12,2)  //append method takes only one argument
# print(a)



# solving example of w3resource
a=[1,2,4,5,6]
# 1. Write a Python program to sum all the items in a list.
print(sum(a))

# 2. Write a Python program to multiply all the items in a list.
mul=1
for i in a:
    mul=mul*i
print(mul)

# 3. Write a Python program to get the largest number from a list
large=a[0]
for i in a:
    if large < i:
        large=i
print(large)

# 4. Write a Python program to get the smallest number from a list.
small=a[0]
for i in a:
    if small > i:
        small=i
print(small)