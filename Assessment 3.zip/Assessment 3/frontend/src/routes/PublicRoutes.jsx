import SignIn from "../components/SignIn";
import SignUp from "../components/SignUp";
import PublicLayout from "../layout/PublicLayout";

const PublicRoutes = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignIn />
        {/* <SignUp/> */}
      </PublicLayout>
    ),
  },
  {
    path: "/signup",
    // path: "/login",
    element: (
      <PublicLayout>
        <SignUp />
        {/* <SignIn/> */}
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />
        {/* <SignUp/> */}
      </PublicLayout>
    ),
  },
];
export default PublicRoutes;
