import AddUser from "../components/AddUser";
import DataTable from "../components/DataTable";
import SignUp from "../components/SignUp";
import UpdateUser from "../components/UpdateUser";
import PrivateLayout from "../layout/PrivateLayout";

const PrivateRoutes = [
  {
    // path: "/dashboard",
    path:"/datatable",
    element: (
      <PrivateLayout>
        {/* <Dashboard /> */}
        <DataTable/>
      </PrivateLayout>
    ),
  },
  {
    path:"/adduser",
    element: (
      <PrivateLayout>
        <AddUser/>
      </PrivateLayout>
    ),
  },
  {
    path:"/myprofile",
    element: (
      <PrivateLayout>
        <UpdateUser/>
      </PrivateLayout>
    ),
  },
];


export default PrivateRoutes;
