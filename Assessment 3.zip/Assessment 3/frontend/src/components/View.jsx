const View = ({curruntUser,showview,setshowview}) => {

    
    return (
      <div style={{border:"solid 1px",backgroundColor:"white",position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:"400px", color:"black",margin:"auto",textAlign:"center"}}>   
      <p>firstname :{curruntUser?.firstname}</p>
      <p>lastname :{curruntUser?.lastname}</p>
      <p>Email :{curruntUser?.email}</p>
      <p>DOB: {curruntUser?.DOB}</p>
      <p>gender:{curruntUser?.gender}</p>

      <button onClick={()=>
  
          {setshowview(!showview)}
      }>close</button>
      </div>
    )
  }
  
  export default View