import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";


function AddUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    email: "",
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    const myToken = JSON.parse(localStorage.getItem("token"))
    console.log(myToken,"hddde")
    e.preventDefault();
    user["userId"] = myToken.id;
    try {
      const response = await axios.post("http://localhost:8000/add/postdata" ,user);

      console.log("user data submitted :", response.user);
      navigate("/datatable");
    } catch (err) {
      console.error("Error in submitting form:", err.message);
    }
    // console.log("user data submitted :", user);

    setUser({
      firstname: "",
      lastname: "",
      email: "",
    });
  };

  // function add() {
  //   // HERE is the change, you need to keep the previous values
  //   setAddNew([...addNew, <NewUser />]);
  // }

  return (
    <div
      style={{
        border: "3px solid",
        marginLeft: "auto",
        marginRight: "auto",
        marginTop: "10px",
        width: "50%",
        height: "50%",
        alignItems: "center",
      }}
    >
      <div style={{ border: "2px solid", backgroundColor:"#007bff" }}>
      <h2 style={{color:"white"}}>Add User</h2>
      <form onSubmit={handleSubmit} >
        <div>
          <label>firstname:</label>
          <input
            type="text"
            name="firstname"
            value={user.firstname}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>lastname:</label>
          <input
            type="text"
            name="lastname"
            value={user.lastname}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>email:</label>
          <input
            type="email"
            name="email"
            value={user.email}
            onChange={handleInputChange}
            required
          />
          <button type="submit">Submit</button>
          {/* {/ navigate("/dashboard"); /} */}
        </div>
      </form>
      </div>
    </div>
  );
}

export default AddUser;

 