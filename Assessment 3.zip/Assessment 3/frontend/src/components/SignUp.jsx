import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import validateUser from "./validate";

// const apiUrl = process.env.REACT_APP_API_URL;

const SignUp = () => {
  const [image,setImage] = useState("")

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    DOB: "",
    password: "",
    profile: null,
  });

  const [errors,setErrors] = useState("")
  const apiUrl = "http://localhost:8000/api";

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
        
      },
    setImage(URL.createObjectURL(files[0])));
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateUser(formData);
    if (Object.keys(validationErrors).length === 0) {


    try {
      const res = await axios.post(`${apiUrl}/signup`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      navigate("/login");
      console.log(res.data);
    } catch (error) {
      console.log(error.message);
    }
  }};

  return (
    <div
      style={{
        justifyContent: "center",
        display: "flex",
        alignItems: "center",
        border: "solid 3px",
        padding: "20px",
        flexDirection: "column",
        width: "500px",
        margin: "auto",
        marginTop: "50px",
        borderRadius: "10px",
      }}
    >
      {
        image && <img src={image} height={70} width={70} alt="" style={{borderRadius:"50%", border:"1px solid black"}}/>
      }
      <h1>Registration Form</h1>
      <form
        onSubmit={handleSubmit}
        style={{ display: "flex", flexDirection: "column", width: "100%" }}
      >
        <input
          type="text"
          name="firstname"
          placeholder="Enter firstname"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        {errors.firstname && <p className="error">{errors.firstname}</p>}

        <input
          type="tel"
          name="lastname"
          placeholder="Enter lastname"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        {errors.lastname && <p className="error">{errors.lastname}</p>}

        <input
          type="text"
          name="email"
          placeholder="Enter email"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        {errors.email && <p className="error">{errors.email}</p>}

        <input
          type="date"
          name="DOB"
          placeholder="Enter DOB"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        <input
          type="password"
          name="password"
          placeholder="Enter password"
          onChange={handleChnage}
          style={{
            padding: "10px",
            marginBottom: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100%",
          }}
        />
        {errors.password && <p className="error">{errors.password}</p>}

        <label>
          <input type="checkbox" />
          Married
        </label>
        <div
          style={{
            marginBottom: "10px",
            display: "flex",
            justifyContent: "space-around",
          }}
        >
          <label>
            Male
            <input
              type="radio"
              name="gender"
              value="male"
              checked={formData.gender === "male"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
          <label>
            Female
            <input
              type="radio"
              name="gender"
              value="female"
              checked={formData.gender === "female"}
              onChange={handleChnage}
              style={{ marginLeft: "5px" }}
            />
          </label>
        </div>
        <input
          type="file"
          name="profile"
          onChange={handleChnage}
          style={{ marginBottom: "10px", border: "none" }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            borderRadius: "5px",
            backgroundColor: "#007bff",
            color: "#fff",
            border: "none",
            cursor: "pointer",
          }}
          //   onClick={() => navigate("/login")}
        >
          Register
        </button>
      </form>
      <p style={{ marginTop: "10px" }}>
        Already have an account?{" "}
        <Link
          to={"/login"}
          style={{ color: "#007bff", textDecoration: "none" }}
        >
          <span>click here</span>
        </Link>
      </p>
    </div>
  );
};

export default SignUp;
