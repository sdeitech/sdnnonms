import React, { useEffect, useState } from "react";
import axios from "axios";
import View from "./View";
import { Link } from "react-router-dom";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
// import AddUser from "./AddUser";

const DataTable = () => {
  const [data, setData] = useState([]);
  const fetchData = async () => {
    try {
      const myToken = JSON.parse(localStorage.getItem("token"));

      const response = await axios.get(
        `http://localhost:8000/add/getdata?userid=${myToken.id}`
      );
      console.log("jhgjghjghyhgb", response.data.newUser);

      setData(response.data.newUser);
      console.log(response.data.newUser, "hey");
    } catch (error) {
      console.log("error fetching data");
    }
  };

  // export const getregisterbyid = async (id) => {
  //   try{
  //     const response = await axios.get()
  //   }
  // }
  // const [updatedata,setupdatedata] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const [curruntUser, setcurruntUser] = useState(null);

  // const update = (user) => {
  //   setshowupdate(!showupdate);
  //   console.log(update);
  //   setcurruntUser(user)
  // };

  const [showview, setshowview] = useState(false);

  const Handleview = (data) => {
    setshowview(!showview);
    setcurruntUser(data);
  };
  const handleLogout = () => {
    localStorage.clear();
  };



//Pagination

const [currentPage,setCurrentPage]=useState(1);
const [recordsPerPage] =useState(5);


const indexOfLastRecord = currentPage*recordsPerPage;
const indexOfFirstRecord=indexOfLastRecord-recordsPerPage;

const currentRecords = data.slice(indexOfFirstRecord,indexOfLastRecord)
console.log(currentPage)
const nPages = Math.ceil(data.length/recordsPerPage);

const pageNumbers = [...Array(nPages+1).keys()].slice(1);

const goToNextPage =()=>{
  if(currentPage!==nPages)
    setCurrentPage(currentPage+1);
}

const goToPrevPage =()=>{
  if(currentPage!==1)
    setCurrentPage(currentPage-1)
}



  return (
    <>
      <h1 style={{ textAlign: "center" }}>Dashboard</h1>
  <div style={{display : "flex" , width :"50%" , background :"#007bff" , justifyContent : "space-evenly", margin:"0 auto"}}>
  <Link to={"/adduser"}>
        <button
          style={{ textAlign: "center", margin: "0", position: "absolute"}}
        >
          Add User
        </button>
      </Link>


      <Link to={"/myprofile"}>
        <button>My Profile</button>
      </Link>
      <Link to={"/login"}>
        {" "}
        <button onClick={handleLogout}>Logout</button>
      </Link>
  </div>
      <div>
        <table
          style={{
            border: "3px solid",
            marginLeft: "auto",
            marginRight: "auto",
            // marginTop: "10px",
            width: "50%",
            height: "50%",
            alignItems: "center",
            textAlign: "center",
          }}
        >
          <thead>
            <tr>
              <th>firstname</th>
              <th>lastname</th>
              <th>email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords &&
              currentRecords.map((item) => {
                return (
                  <tr key={item._id}>
                    <td>{item.firstname}</td>
                    <td>{item.lastname}</td>
                    <td>{item.email}</td>
                    <td>
                      <button onClick={() => Handleview(item)}>View</button>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
        <div style={{ width: "100%", display: "flex", justifyItems: "center" }}>
        </div>
        {showview && (
          <View
            curruntUser={curruntUser}
            showview={showview}
            setshowview={setshowview}
          />
        )}
      </div>




      <nav>
           <ul className="pagination justify-content-center">
              <li className="page-item">
                <a className="page-link" 
                onClick={goToPrevPage}
                href="#"
                >Previous
                  
                </a>

              </li>

               {pageNumbers.map(pgNumbers=>(
                <li key={pgNumbers} 
                className={`page-item ${currentPage==pgNumbers ? 'active':''}`}
                >
                  <a onClick={()=>setCurrentPage(pgNumbers)}
                    className="page-link"
                    href="#" > 
                    {pgNumbers}
                    
                       </a>
                </li>
               ))}

                <li className="page-item">
                <a className="page-link" 
                onClick={goToNextPage}
                href="#"
                >Next
                  
                </a>

              </li>

            </ul>
           </nav>
    </>
  );
};

export default DataTable;
