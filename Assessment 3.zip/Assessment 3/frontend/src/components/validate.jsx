
const validateUser = (values) => {
    let errors = {};

    if (!values.firstname) {
        errors.firstname = "FirstName is required";
    }

    if (!values.lastname) {
        errors.lastname = "LastName is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";

    }if (!values.password) {
        errors.password = "password is required";
    

    }
    return errors;
};

export default validateUser;
