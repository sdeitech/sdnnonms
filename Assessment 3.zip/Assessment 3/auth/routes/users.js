import express from "express";
import { getUsers,GetUsers, registerUser, userLogin, updateUserInList, getRegisterUserById } from "../controllers/users";
import { uploadMiddleware } from "../helpers/multer";
// import Users from "../models/users";
const userRouter = express.Router();

userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);
userRouter.post("/login", userLogin);
userRouter.get("/get", getUsers)
userRouter.put("/put/:id", updateUserInList)
userRouter.get('/getuser/:id',getRegisterUserById)
// userRouter.post("/postdata",addUserInList)
// userRouter.get("/getdata",getUserInList)
userRouter.get("/GetUsers/:page/:limit/:search?",GetUsers)


export default userRouter;
