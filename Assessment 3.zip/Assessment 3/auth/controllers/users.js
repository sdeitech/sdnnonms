import Users from "../models/users";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import Userlist from "../models/adduser";
// const User = require("../models/users")
const Joi = require('joi')

// Joi validation schema for registration
const registrationSchema = Joi.object({
    userName: Joi.string().min(3).max(30).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required()
});

// Joi validation schema for login
const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required()
});

export const registerUser = async (req, res) => {
  try {
    const { firstname, lastname,email, DOB,password,gender } = req.body;
    const profile = req.file?.filename;
    if (!firstname || !lastname || !email || !DOB || !gender || !password) {
      return res
        .status(400)
        .json({message:"all fields are required"})

    }

    const pass = await bcrypt.hash(password, 10);
    const user = new Users({
      firstname,
      lastname,
      email,
      DOB,
      gender,
      profile: profile,
      password: pass,
    });

    await user.save();
    res.status(201).json({ msg: "user registered successfully" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};



export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    // console.log(req.body,"hey");
    
    
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "All fields are required"});
    }
    const existUser = await Users.findOne({ email: email });

    if (!existUser) {
      return res
        .status(400)
        .json({ msg: "user not found" });
    }

    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "compare");

    if (isMatch) {
      console.log(existUser);
      const dataToBeSend = {
        id : existUser._id,
        email :existUser.email,
        firstname : existUser.firstname,
        lastname : existUser.lastname,
        DOB : existUser.DOB,
        gender : existUser.gender
        
      }
      
      const token = jwt.sign( dataToBeSend, "KEY", { expiresIn: "5hr" });
      return res
        .status(200)
        .json({ msg: "user logged in successfully", id:existUser._id,token: dataToBeSend });
    } else {
      return res
        .status(400)
        .json({ msg: "invalid credentials" });
    }
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ msg: error.message });
  }
};

export const getUsers = async (req, res) => {
  
  try {
    const user= await Users.find();
    res.json({ user: user, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const addUserInList = async (req, res) => {

  console.log("aghjdg",req.body)
  try {
    const newUser = new Userlist(req.body);
    // console.log(newUser,"hey")
    await newUser.save();
    return res.status(201).json({newUser});
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


export const getUserInList = async (req,res) => {
  try {

    const userId = req.query.userid
    // console.log(userId,"heyyyyy")
    const newUser = await Userlist.find({userId});
    res.json({newUser}) 
  } catch (error) {
    res.status(500).json({error:error.message})
  }
};

export const updateUserInList = async(req,res)=>{
  const{id}=req.params;
  try{
   
   if(id)
   {
     const updateUser = await Userlist.findByIdAndUpdate(id,req.body);
     return res.status(200).json(getUpdatedData);
      }
      
      else{
          return res.status(400).json({message:"id not found"});
      }
   }
   catch(error)
   {
      return res.status(400).json(error);
   }
  };


  export const getRegisterUserById = async (req,res) => {
    try {
      const {id} = req.params;
      const user = await Users.findById(id);

      if(!user) {
        return res.status(404).json({message:"user not found"});
      }
      res.status(200).json(user);
    } catch (error) {
      res.status(500).json({message:error.message});
      
    }
  }


  export const GetUsers = async (req, res) => {
    try {
        const { search = "", page = 1, limit = 2 } = req.params;

        let pageNo = Number(page)
        let pageLimit = Number(limit)
        let skip = (pageNo - 1) * pageLimit

        const user = await Users.find({})
        if (!user) {
            return res.status(400).json({ message: "user not found" })
        }
        const userDetails = await Users.findById(req.params.id).populate({
            path: "users",
            match: search.trim() ? { firstName: { $regex: search.trim(), $options: "i" } } : {},
            options: {
                skip: skip,
                limit: pageLimit,
            }
        })

        const totalRecord = user.users.length
        const totalPages = Math.ceil(totalRecord / pageLimit)
        res.status(200).json({ user: userDetails ,totalPages:totalPages,pageNo:pageNo})

    } catch (error) {
        console.log(`Error while getting user ${error.message}`)
        res.status(500).json({ message: error.message })
    }
}
