export const config = {
  local: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "Register",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 8000,
  },
  stagg: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "Register",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 8000,
  },
  prod: {
    DB: {
      HOST: "",
      DB_HOST: 27017,
      DB_NAME: "Register",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: 8000,
  },
};
