import { createSlice} from "@reduxjs/toolkit"


let initialState ={
    users:[],
    name:"demo user",
    cardList : {
        cart:[],
        totalCard:0
    }
}

export const listSlice = createSlice({
    name:"list",
    initialState:initialState,
    reducers:{
        addProduct:(state,action)=>{
            // state.users=[...state.users,action.payload]
            state.users.push(action.payload)
        },
        removeProduct:(state,action)=>{
            state.users.pop(action.payload)
        },
        // editProduct:(state,action)=>{
        //     state.users
        // }
        addToCart:(state,action)=>{
            if(!action.payload){
                state.cardList.cart.push(action.payload)
                state.cardList.totalCard++
            }else{
                state.cardList.totalCard++

            }
           

        }

    }
})
export const {addProduct,removeProduct,addToCart}=listSlice.actions
export default listSlice.reducer