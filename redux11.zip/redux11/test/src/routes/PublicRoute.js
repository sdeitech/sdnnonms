import PublicLayout from "../layout/PublicLayout"
import ViewofForm from "../components/ViewofForm"
import Form from "../components/Form";
const PublicRoute = [
    {
        path: "/",
        element: (
          <PublicLayout>
       <Form/>
           
          </PublicLayout>
        ),
      },
    {
      path: "/view",
      element: (
        <PublicLayout>
     <ViewofForm/>
         
        </PublicLayout>
      ),
    },
];
export default PublicRoute