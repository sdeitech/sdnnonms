import PrivateLayout from "../layout/PrivateLayout"
import ViewofForm from "../components/ViewofForm"
const PrivateRoute =[
    {
    path:"/view",
    element:(
        <PrivateLayout>
            <ViewofForm/>
        </PrivateLayout>
    )
    }
];
export default PrivateRoute