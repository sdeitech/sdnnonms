import React from 'react'
import { removeProduct,addToCart } from '../reduxcompo/Slice'
import { useDispatch, useSelector } from 'react-redux'

const ViewofForm = () => {
    const dispatch = useDispatch()
    const products = useSelector(state => state.listUsers.users)
    const cart = useSelector(state => state.listUsers.cart)
    console.log(cart,"rrrrtrtggggggggggggggggggggg");
    

    console.log(products)

    const handleDelete = (product) => {
        dispatch(removeProduct(product))
    }
    const handleAddToCard = (p) =>{
dispatch(addToCart(p))
    }
    return (



        <div>
            {products?.map((ele, i) => {
                return (
                    <div key={i}>
                        <p>product :{ele.product}</p>
                        <p>price :{ele.price}</p>
                        <button onClick={() => {
                            handleDelete(ele.name)
                        }}>delete</button>
                <button onClick={()=>{
                    handleAddToCard(ele)
                }}>add to card</button>
                    </div>
                )

            })}






        </div>
    )
}



export default ViewofForm




