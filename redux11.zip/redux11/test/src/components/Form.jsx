import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addProduct } from "../reduxcompo/Slice";
import { useNavigate } from "react-router-dom";

const Form = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const [formData, setFormData] = useState({
        product: "",
        price: ""
    })
    const handleChange = (e) => {
        console.log(e.target);
        const { name, value } = e.target
        setFormData({ ...formData, [name]: value })
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(addProduct(formData))
        navigate("/view");
    }

    return (

        <>
            <form onSubmit={handleSubmit}>
                <input type="text" name="product" onChange={handleChange} placeholder='enter product' />
                <input type="Number" name="price" onChange={handleChange}  placeholder='enter price'/>
                <button type="submit">submit</button>
               
            </form>


        </>
    )
}
export default Form;
