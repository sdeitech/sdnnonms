
// import React from 'react'
// import { removeProduct } from '../reduxcompo/Slice'
// import { useDispatch, useSelector } from 'react-redux'

//  const Listing = () => {
//     const dispatch = useDispatch()
//     const products = useSelector(state => state.listUsers.users)
//     console.log(products)

//     const handleDelete=(product)=>{
//         dispatch(removeProduct(product))
//     }
//   return (
    
//     <div>
//         {products?.map((ele,i)=>{
//             return(
//                 <div key={i}>
//                     <p>product :{ele.product}</p>
//                     <p>price :{ele.price}</p>
//                     <button onClick={()=>{
//                         handleDelete(ele.name)
//                     }}>delete</button>
//             </div>
//             )

//         })}






//     </div>
//   )
// }
// export default Listing
