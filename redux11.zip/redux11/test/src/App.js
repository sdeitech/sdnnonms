// import logo from './logo.svg';
import './App.css';
//mport  Form from './components/Form';
//import Listing from './components/Listing';
// import { Count } from './components/Count';
// import { useDispatch } from 'react-redux';
import { RouterProvider } from 'react-router-dom';
import Routes from './routes/routes';
function App() {
  // const dispatch = useDispatch();
  return (
    <div className="App">
      {/* <button onClick={(e) => dispatch({ type: "INCREMENT" })}>increment</button>
      <Count />
      <button onClick={(e) => dispatch({ type: "DECREMENT" })}>decrement</button>
    */}
    {/* <Form/>
    <Listing/> */}
    <RouterProvider router={Routes} />
    </div> 
  );
}

export default App;
