from rest_framework import serializers
from .models import Product
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
import re

class ProductSerializer(serializers.ModelSerializer):
    image = serializers.ImageField(use_url=True)  # Ensure the image URL is returned

    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'image']




User = get_user_model()

class CustomUserSerializer(serializers.ModelSerializer):
    # Adding the required fields here
    email = serializers.EmailField(required=True)
    first_name = serializers.CharField(max_length=30, required=True)
    last_name = serializers.CharField(max_length=30, required=True)
    address = serializers.CharField(max_length=255, required=True)
    postal_code = serializers.CharField(max_length=20, required=True)
    contact_number = serializers.CharField(max_length=15, required=True)

    class Meta:
        model = User
        fields = ['email', 'first_name', 'last_name', 'address', 'postal_code', 'contact_number', 'username', 'password']

    def validate_postal_code(self, value):
        """Validate postal code (example format validation)"""
        if not re.match(r'^\d{5}(-\d{4})?$', value):
            raise serializers.ValidationError("Invalid postal code format.")
        return value

    def validate_contact_number(self, value):
        """Validate contact number (example format validation)"""
        if not re.match(r'^\+?1?\d{9,15}$', value):
            raise serializers.ValidationError("Invalid contact number format.")
        return value

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user
