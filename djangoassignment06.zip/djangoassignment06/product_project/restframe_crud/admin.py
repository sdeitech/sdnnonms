from django.contrib import admin

# Register your models here.
# products/admin.py

from django.contrib import admin
from .models import Product
from .models import Coupon


admin.site.register(Product)

admin.site.register(Coupon)
