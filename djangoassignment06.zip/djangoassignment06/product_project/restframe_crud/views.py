from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import NotFound
from .models import Product
from .serializers import ProductSerializer,CustomUserSerializer
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

class ProductListCreate(APIView):
    def get(self, request):
        # List all products
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Create a new product
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProductRetrieveUpdateDelete(APIView):
    def get(self, request, pk):
        # Retrieve a single product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product)
        return Response(serializer.data)

    def put(self, request, pk):
        # Update a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        serializer = ProductSerializer(product, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        # Delete a product
        try:
            product = Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise NotFound("Product not found.")
        
        product.delete()
        return Response({"detail": "Product deleted successfully."}, status=status.HTTP_204_NO_CONTENT)


class RegisterUserView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({"message": "User registered successfully!"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class CustomLoginView(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return Response({"error": "Email and password are required."}, status=status.HTTP_400_BAD_REQUEST)

        # Authenticate user with email and password
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # Generate token for the user
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                "message": "Login successful.",
                "token": token.key  # Return the authentication token
            }, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)




# views.py
from rest_framework import status
from .models import Coupon
from .serializers import CouponSerializer
from django.utils.timezone import now
from datetime import timedelta

class ValidateCouponView(APIView):
    def post(self, request):
        # Add static coupons if they don't exist
        self.add_static_coupons()

        # Get the coupon code from the request
        code = request.data.get('code')

        try:
            # Check if the coupon exists in the database
            coupon = Coupon.objects.get(code=code)
            
            # Check if the coupon is valid
            if coupon.is_valid():
                return Response({
                    'valid': True,
                    'discount_percentage': coupon.discount_percentage
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'valid': False,
                    'message': 'Coupon has expired'
                }, status=status.HTTP_400_BAD_REQUEST)
        except Coupon.DoesNotExist:
            return Response({
                'valid': False,
                'message': 'Invalid coupon code'
            }, status=status.HTTP_400_BAD_REQUEST)

    def add_static_coupons(self):
        """Add static coupons if they don't already exist"""
        if not Coupon.objects.filter(code='WELCOME').exists():
            Coupon.objects.create(
                code='WELCOME',
                discount_percentage=10,
                valid_until=now() + timedelta(days=365)  # Valid for 1 year
            )
        
        if not Coupon.objects.filter(code='FIRSTORDER').exists():
            Coupon.objects.create(
                code='FIRSTORDER',
                discount_percentage=15,
                valid_until=now() + timedelta(minutes=2)  # Valid for 1 year
            )
           
            
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import Order

class CreateOrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Place a new order. If no shipping address is provided, use the user's registered address.
        """
        user = request.user
        shipping_address = request.data.get('shipping_address')
        payment_method = request.data.get('payment_method')
        total_amount = request.data.get('total_amount')

        # Default to the user's registered address if no shipping address is provided
        if not shipping_address:
            shipping_address = user.address  # Use the registered address
            if not shipping_address:
                return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        if not payment_method or not total_amount:
            return Response({"error": "All fields are required"}, status=status.HTTP_400_BAD_REQUEST)

        # Create a new order
        order = Order.objects.create(
            user=user,
            shipping_address=shipping_address,
            payment_method=payment_method,
            total_amount=total_amount
        )

        return Response(
            {"message": "Order placed successfully", "order_id": order.id, "shipping_address": shipping_address},
            status=status.HTTP_201_CREATED
        )

    def get(self, request):
        """
        Fetch the user's default shipping address (registered address).
        """
        user = request.user
        shipping_address = user.address  # Fetch the registered address

        if not shipping_address:
            return Response({"message": "No address found. Please provide one."}, status=status.HTTP_404_NOT_FOUND)

        return Response({"shipping_address": shipping_address}, status=status.HTTP_200_OK)

    def patch(self, request):
        """
        Update the user's shipping address.
        """
        user = request.user
        new_shipping_address = request.data.get('shipping_address')

        if not new_shipping_address:
            return Response({"error": "Shipping address is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Update the user's registered address
        user.address = new_shipping_address
        user.save()

        return Response({"message": "Address updated successfully", "new_shipping_address": new_shipping_address}, status=status.HTTP_200_OK)
