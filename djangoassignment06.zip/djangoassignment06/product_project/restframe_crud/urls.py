from django.urls import path

from product_project import settings
from .views import ProductListCreate, ProductRetrieveUpdateDelete
from django.conf.urls.static import static
urlpatterns = [
    path('products/', ProductListCreate.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductRetrieveUpdateDelete.as_view(), name='product-retrieve-update-delete'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)