import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import {readfile1} from './filesystem.js';

import fileuploadroute from './route/route.js';

const app = express();

app.use(cors({ origin:"*"}));

//middleware for parsing json

app.use(express.json({limit : "50mb"}));
console.log("entry")
app.use(bodyParser.urlencoded({ limit : "50mb" , extended :false}));

app.use("/",express.static("profile_picture"));
console.log("1")
app.use("/api",fileuploadroute)
console.log("2")



readfile1()

export default app;