//helper/multer.js

import multer from 'multer';
import path from 'path';
import {messages} from '../config/constant';

const storage = multer.diskStorage({
    destination: './profilepicture/',
    filename : function (req,file,cb){
        cb(null,Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const allowedtypes = ['image/png','image/jpeg','image/jpg'];
    console.log(".....file......",file)
    if(!allowedtypes.includes(file.mimetype)){
        return cb(new Error(messages.imageType));//adjust error message here as needed
    }
    cb(null,true);
};

export const uploadMiddleware = multer({
    storage : storage,
    fileFilter : fileFilter,
    limits : {fileSize:5 * 1024 *1024}  //optional limit file size to 5mb
});