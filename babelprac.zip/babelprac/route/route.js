import express from 'express';
import {uploadimage} from '../controller/upload.js';
import {uploadMiddleware} from '../helper/multer.js';
import readfile from '../filesystem.js';

const fileuploadroute = express.Router();

fileuploadroute.post("/image",uploadMiddleware.single('image'),uploadimage);
fileuploadroute.post("/images",uploadMiddleware.array('images',6),uploadimage);
//ileuploadroute.post("/images", fileupload.array('images', 5), uploadImages);
//fileuploadroute.get("/read",readfile);


export default fileuploadroute;