require('dotenv/config');

export const messageID = {
    "test":"xyzw"
}
export const messages = {
    imageType : "xyzw"
}