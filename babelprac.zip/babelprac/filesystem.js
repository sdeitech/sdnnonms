import fs from 'fs';

export const readfile1 = () => {
    console.log("first")

    // Reading or displaying the data in input.txt file
    //Asynchronouslly 
    fs.readFile('input.txt', function (err, data) {
        if (err) {
            return console.error(err);
        }
        console.log("Asynchoronous read :" + data.toString());
    });

//     //Synchronously  In these case synchronous will run first because asynchronous will be blocked 
//     //when the fs.readFileSync() method is called the original node program stops executing. 

    var data = fs.readFileSync('input.txt');
    console.log("Synchronous read", data.toString());
    console.log("Program ended");

//     // Deleting the input file which we are created by fs.unlink
//     //  fs.unlink('input.txt',()=>{

//     //  })



    //create a writable stream= It will create the output.txt file in directory

    const writeableStream = fs.createWriteStream('output.txt');

    //write data to the stream= It will write the data in output.txt file whichever we want to write

    writeableStream.write('Hello,world\n')
    writeableStream.write('This is a writable stream')


//     //update the stream

    fs.appendFile('input.txt', ' This is my text.', function (err) {
        if (err) throw err;
        console.log('Updated!');
     });
    fs.writeFile('input.txt','hey there i am here',function(err){
        if(err) throw err;
        console.log('updatedto')
    })

//     //Rename

    // fs.rename('renamefile.txt','input.txt',function(err){
    //     if(err) throw err;
    //     console.log('Renamed')
    // })

    // end the stream
    //     writeableStream.end(()=>{
    //         console.log('Finished writting to the file.')
    //     })
}