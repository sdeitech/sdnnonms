// const mongoose = require('mongoose');

// const userSchema = new mongoose.Schema({
//     firstName : {type: String, required: true },
//     lastName : {type: String, required: true },
//     email: { type: String, required: true },
//     password: { type: String, required: true },
//     dob: { type: Date, required: true },
//     maritalStatus : {type: String, required: true },
//     gender : {type: String, required: true },
//     photo : {type: String,}
// });

// const User = mongoose.model('User', userSchema);

// module.exports = User;


// const { required } = require('joi');
// const mongoose = require('mongoose');

// const userSchema = new mongoose.Schema({
//     firstName : {type: String, required: true },
//     lastName : {type: String, required: true },
//     email: { type: String, required: true },
//     password: { type: String, required: true },
//     dob: { type: Date, required: true },
//     maritalStatus : {type: String,required: true},
//     gender : {type: String, enum : ["male", "female"], required: true },
//     photo : {type: String,}
// });

// const User = mongoose.model('User', userSchema);

// module.exports = User;

const { required } = require('joi');
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    firstName : {type: String},
    lastName : {type: String },
    email: { type: String},
    password: { type: String},
    dob: { type: Date},
    maritalStatus : {type: String},
    gender : {type: String, enum : ["male", "female"]},
    photo : {type: String,}
});

const User = mongoose.model('User', userSchema);

module.exports = User;