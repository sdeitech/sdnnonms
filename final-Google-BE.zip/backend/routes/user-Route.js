import express from "express";
import { uploadMiddleware } from "../helper/multer";
const router = express.Router();
const userController = require('../controller/user-Controller')

// router.post('/register', userController.registerUser)
router.post('/register',[uploadMiddleware.single('photo')], userController.registerUser)

router.post('/login', userController.loginUser)
router.get('/', userController.getUser)
router.get('/:id', userController.getUserById)
router.put('/:id', userController.updateUserById)
router.post('/loginwithgoogle', userController.loginWithGoogle)



module.exports = router;