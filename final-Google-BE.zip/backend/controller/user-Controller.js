const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const User = require('../model/user-Model');
import { OAuth2Client } from 'google-auth-library';

const client = new OAuth2Client('1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com')

const registerUser = async (req, res) => {
    try {
        const { firstName, lastName, email, password, dob, maritalStatus, gender,} = req.body;
        console.log(req.body)
        const profile = req.file?.filename
        let hashed = await bcrypt.hash(password, 10)

        const user = new User({
            firstName : firstName,
            lastName : lastName,
            email : email,
            password : hashed,
            dob : dob,
            maritalStatus : maritalStatus,
            gender : gender,
            photo : profile,
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}  

const loginUser = async (req, res) => {

    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email })

        if (!user) {
            return res.status(400).json({ message: "User not found" })
        }

        const isMatch = await bcrypt.compare(password, user.password)

        if (isMatch) {
            const token = jwt.sign({ email , userId: user._id}, "an123idjk", { "expiresIn": "2h" })
            console.log('token-----', token)

            return res.status(201).json({ message: "Logged In", "token": token , 'userId' : user._id})
        } else {
            return res.status(401).json({ message: "Invalid Credentials" })

        }
    } catch (error) {
        res.status(401).json({ Error: error.message })
    }
}

const getUser = async (req, res) => {
    try {
        const { searchText } = req.query;

        let filter = {};

        if (searchText) {
            filter = {
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        const users = await User.find(filter)
            .select('firstName lastName email password maritalStatus dob gender')
            .skip(skip)
            .limit(limit);
        const totalCount = await User.countDocuments(filter);

        const response = {
            users: users,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getUserById = async (req, res) => {
    try {
        const { id } = req.params
        const user = await User.findById(id)
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const updateUserById = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

//  const loginWithGoogle = async (req, res) => {
//     try {
//       const { token } = req.body;
  
//       // Verify Google token
//       const ticket = await client.verifyIdToken({
//         idToken: token,
//         audience: "1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com",
//       });
//       const payload = ticket.getPayload();
//       const { email, name, sub: googleId } = payload;
  
//       // Check if user exists, otherwise create a new one
//       let user = await User.findOne({ email });
//       if (!user) {
//         user = new User({
//           firstname: name.split(" ")[0],
//           lastname: name.split(" ")[1] || "",
//           email: email,
//           googleId,
//           password: "",  
//         });
//         await user.save();
//       }
  
//       const jwtToken = jwt.sign({ email }, "KEY", { expiresIn: "5hr" });
  
//       return res.status(200).json({ id: user._id, token: jwtToken });
//     } catch (error) {
//       console.error(error);
//       res.status(500).json({ msg: "Google Login Failed" });
//     }
//   };


export const loginWithGoogle = async (req, res) => {
    const { token } = req.body;
    try {
        // Verify the ID token
        const ticket = await client.verifyIdToken({
            idToken: token,  // Token from frontend
            audience: '1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com',  // Should match CLIENT_ID
        });

        const payload = ticket.getPayload();

        // Extract user details from the token payload
        const googleId = payload['sub']; // Google user ID
        const email_id = payload['email']; // User email from Google

        // Check if email_id is defined
        if (!email_id) {
            throw new Error('Email ID is missing from the token payload');
        }

        const username = email_id.split('@')[0]; // Assign default username

        // Check if the user exists in the database
        let user = await User.findOne({ email_id });
        if (!user) {
            user = new User({
                email_id,
                googleId,
                username,
                role: 'user',
                password: googleId,
                tokens: [],
            });
            await user.save();
        }

        // Generate a JWT token
        const jwtToken = jwt.sign({ email:email_id , userId: user._id}, "an123idjk", { "expiresIn": "2h" })

        // const jwtToken = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '6h' });

        // Store the token in the user object
        user.tokens = [{ token: jwtToken }];
        await user.save();
        return res.status(201).json({ message: "Logged In", "token": jwtToken , 'userId' : user._id})

        // res.status(200).json({ message: "Login with Google Successful", user, token: jwtToken });
    } catch (error) {
        console.error('Error during Google login:', error);
        res.status(401).json({ message: 'Unauthorized', error: error.message });
    }
};

module.exports = { registerUser, loginUser, getUser, getUserById, updateUserById, loginWithGoogle}