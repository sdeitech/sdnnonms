// import React, { useState, useEffect } from 'react';
// import './Sidebar.css';
// import moment from 'moment';

// const Sidebar = ({ show, onHide, onAddEvent, onEditEvent, onDeleteEvent, selectedEvent }) => {
//     console.log("selectedEvent---", selectedEvent);

//   const [eventTitle, setEventTitle] = useState('');
//   const [eventDate, setEventDate] = useState('');
//   const [eventStartTime, setEventStartTime] = useState('');
//   const [eventEndTime, setEventEndTime] = useState('');

//   useEffect(() => {
//     if (selectedEvent) {
//       setEventTitle(selectedEvent.event_title || '');
//       setEventDate(moment(selectedEvent.event_date).format('YYYY-MM-DD') || '');  // Matching event_date
//       setEventStartTime(selectedEvent.event_startTime ? moment(selectedEvent.event_startTime, 'HH:mm').format('HH:mm') : '');  // Matching event_startTime
//       setEventEndTime(selectedEvent.event_endTime ? moment(selectedEvent.event_endTime, 'HH:mm').format('HH:mm') : '');  // Matching event_endTime
//     } else {
//       setEventTitle('');
//       setEventDate('');
//       setEventStartTime('');
//       setEventEndTime('');
//     }
//   }, [selectedEvent]);

//   const handleSubmit = () => {
//     const newEvent = {
//       event_title: eventTitle,
//       event_date: moment(eventDate).set({ hour: eventStartTime.split(':')[0], minute: eventStartTime.split(':')[1] }).toDate(),  // Matching event_date
//       event_startTime: eventStartTime,
//       event_endTime: eventEndTime,
//     };

//     if (selectedEvent) {
//       // If an event is selected, update it
//       const updatedEvent = { ...selectedEvent, ...newEvent };
//       onEditEvent(updatedEvent);
//     } else {
//       // If no event is selected, create a new one
//       onAddEvent(newEvent);
//     }
//   };

//   const handleDelete = () => {
//     if (selectedEvent) {
//       onDeleteEvent(selectedEvent._id);  // Assuming _id is the event ID from the backend schema
//     }
//   };

//   const handleDateChange = (e) => {
//     const selectedDate = e.target.value;
//     const today = new Date().toISOString().split('T')[0];

//     if (selectedDate >= today) {
//       setEventDate(selectedDate);  // Renamed to match event_date
//     }
//   };

//   return (
//     <div className={`sidebar ${show ? 'show' : ''}`}>
//       <div className="sidebar-content">
//         <div className="sidebar-header">
//           <h3>{selectedEvent ? 'Edit Event' : 'Add Event'}</h3>
//           <button className="close-btn" onClick={onHide}>Close</button>
//         </div>

//         <div className="sidebar-body">
//           <label>Title</label>
//           <input
//             type="text"
//             placeholder="Event Title"
//             value={eventTitle}
//             onChange={(e) => setEventTitle(e.target.value)}  // Renamed to match event_title
//           />
//           <label>Date</label>
//           <input
//             type="date"
//             value={eventDate}
//             onChange={handleDateChange}
//           />
//           <label>Start Time</label>
//           <input
//             type="time"
//             value={eventStartTime}  // Renamed to match event_startTime
//             onChange={(e) => setEventStartTime(e.target.value)}  // Renamed to match event_startTime
//           />
//           <label>End Time</label>
//           <input
//             type="time"
//             value={eventEndTime}  // Renamed to match event_endTime
//             onChange={(e) => setEventEndTime(e.target.value)}  // Renamed to match event_endTime
//           />
//           <button className="btn btn-primary" onClick={handleSubmit}>{selectedEvent ? 'Update' : 'Submit'}</button>
//           {selectedEvent && <button className="btn btn-danger" onClick={handleDelete}>Delete</button>}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Sidebar;













import React, { useState, useEffect } from 'react';
import './Sidebar.css';
import moment from 'moment';
import axios from 'axios'

const Sidebar = ({ show, onHide, onAddEvent, onEditEvent, onDeleteEvent, selectedEvent }) => {
    console.log("selectedEvent---", selectedEvent);

  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventStartTime, setEventStartTime] = useState('');
  const [eventEndTime, setEventEndTime] = useState('');

  useEffect(() => {
    if (selectedEvent) {
      setEventTitle(selectedEvent.event_title || '');
      setEventDate(moment(selectedEvent.event_date).format('YYYY-MM-DD') || '');  // Matching event_date
      setEventStartTime(selectedEvent.event_startTime ? moment(selectedEvent.event_startTime, 'HH:mm').format('HH:mm') : '');  // Matching event_startTime
      setEventEndTime(selectedEvent.event_endTime ? moment(selectedEvent.event_endTime, 'HH:mm').format('HH:mm') : '');  // Matching event_endTime
    } else {
      setEventTitle('');
      setEventDate('');
      setEventStartTime('');
      setEventEndTime('');
    }
  }, [selectedEvent]);

  // const handleSubmit = () => {
  //   const newEvent = {
  //     event_title: eventTitle,
  //     event_date: moment(eventDate).set({ hour: eventStartTime.split(':')[0], minute: eventStartTime.split(':')[1] }).toDate(),  // Matching event_date
  //     event_startTime: eventStartTime,
  //     event_endTime: eventEndTime,
  //   };

  //   if (selectedEvent) {
  //     // If an event is selected, update it
  //     const updatedEvent = { ...selectedEvent, ...newEvent };
  //     onEditEvent(updatedEvent);
  //   } else {
  //     // If no event is selected, create a new one
  //     onAddEvent(newEvent);
  //   }
  // };

  const token = localStorage.getItem('token')

  const handleSubmit = () => {
    const newEvent = {
      event_title: eventTitle,
      event_date: moment(eventDate).format('YYYY-MM-DD'),
      event_startTime: eventStartTime,
      event_endTime: eventEndTime,
    };
  
    // Save to local database
    if (selectedEvent) {
      const updatedEvent = { ...selectedEvent, ...newEvent };
      onEditEvent(updatedEvent);
    } else {
      onAddEvent(newEvent);
    }
  
    // Schedule event in Google Calendar
    axios
      .post('http://localhost:5000/apis/schedule-event', newEvent ,{
        headers: {
          Authorization: `${token}`, 
          'Content-Type': 'application/json' 
      }
      })
      .then((response) => {
        console.log('Event scheduled in Google Calendar:', response.data);
        alert('Event scheduled in Google Calendar successfully!');
      })
      .catch((error) => {
        console.error('Error scheduling event in Google Calendar:', error);
      });
  };



  const handleDelete = () => {
    if (selectedEvent) {
      onDeleteEvent(selectedEvent._id);  // Assuming _id is the event ID from the backend schema
    }
  };

  const handleDateChange = (e) => {
    const selectedDate = e.target.value;
    const today = new Date().toISOString().split('T')[0];

    if (selectedDate >= today) {
      setEventDate(selectedDate);  // Renamed to match event_date
    }
  };

  return (
    <div className={`sidebar ${show ? 'show' : ''}`}>
      <div className="sidebar-content">
        <div className="sidebar-header">
          <h3>{selectedEvent ? 'Edit Event' : 'Add Event'}</h3>
          <button className="close-btn" onClick={onHide}>Close</button>
        </div>

        <div className="sidebar-body">
          <label>Title</label>
          <input
            type="text"
            placeholder="Event Title"
            value={eventTitle}
            onChange={(e) => setEventTitle(e.target.value)}  // Renamed to match event_title
          />
          <label>Date</label>
          <input
            type="date"
            value={eventDate}
            onChange={handleDateChange}
          />
          <label>Start Time</label>
          <input
            type="time"
            value={eventStartTime}  // Renamed to match event_startTime
            onChange={(e) => setEventStartTime(e.target.value)}  // Renamed to match event_startTime
          />
          <label>End Time</label>
          <input
            type="time"
            value={eventEndTime}  // Renamed to match event_endTime
            onChange={(e) => setEventEndTime(e.target.value)}  // Renamed to match event_endTime
          />
          <button className="btn btn-primary" onClick={handleSubmit}>{selectedEvent ? 'Update' : 'Submit'}</button>
          {selectedEvent && <button className="btn btn-danger" onClick={handleDelete}>Delete</button>}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;



