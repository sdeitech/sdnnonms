// import React, { useState, useEffect } from "react";
// import { Calendar, momentLocalizer } from "react-big-calendar";
// import moment from "moment";
// import axios from "axios"; // Import axios for making API calls
// import "react-big-calendar/lib/css/react-big-calendar.css";
// import Sidebar from "./Sidebar";
// import "./Sidebar.css";

// const localizer = momentLocalizer(moment);

// const Calender = () => {
//   const [showOffcanvas, setShowOffcanvas] = useState(false);
//   const [events, setEvents] = useState([]);
//   console.log("events----", events);

//   const [selectedEvent, setSelectedEvent] = useState(null);

//   const token = localStorage.getItem("token");

//   useEffect(() => {
//     axios
//       .get("http://localhost:5000/apis/getEvent", {
//         headers: {
//           Authorization: `${token}`,
//           "Content-Type": "application/json",
//         },
//       })
//       .then((response) => {
//         const formattedEvents = response.data.map((event) => {
//           const startDate = new Date(event.event_date);
//           const [startHour, startMinute] = event.event_startTime.split(":");
//           const [endHour, endMinute] = event.event_endTime.split(":");

//           // Set the correct start and end time by adjusting the hours and minutes
//           startDate.setHours(startHour, startMinute); // Set the start time
//           const endDate = new Date(startDate); // Copy the start date to the endDate
//           endDate.setHours(endHour, endMinute); // Set the end time

//           return {
//             id: event._id, // Use _id from the API response
//             title: event.event_title,
//             start: startDate,
//             end: endDate,
//           };
//         });

//         setEvents(formattedEvents); // Store the formatted events in the state
//       })
//       .catch((error) => {
//         console.error("Error fetching events:", error);
//       });
//   }, []);

//   const toggleOffcanvas = () => {
//     setShowOffcanvas(!showOffcanvas);
//   };

//   // Adds a new event by sending a POST request to the backend
//   const handleAddEvent = (newEvent) => {
//     axios
//       .post("http://localhost:5000/apis", newEvent, {
//         headers: {
//           Authorization: `${token}`,
//           "Content-Type": "application/json",
//         },
//       })
//       .then((response) => {
//         setEvents([...events, response.data]); // Add the newly created event to the state
//         setShowOffcanvas(false);
//       })
//       .catch((error) => {
//         console.error("Error adding event:", error);
//       });
//   };

//   // Edits an existing event by sending a PUT request to the backend
//   const handleEditEvent = (updatedEvent) => {
//     axios
//       .put(
//         `http://localhost:5000/apis/update-event/${updatedEvent.id}`,
//         updatedEvent
//       ) // Replace with your API endpoint
//       .then((response) => {
//         const updatedEvents = events.map((event) =>
//           event.id === updatedEvent.id ? response.data : event
//         );
//         setEvents(updatedEvents);
//         setShowOffcanvas(false);
//       })
//       .catch((error) => {
//         console.error("Error updating event:", error);
//       });
//   };

//   // Deletes an event by sending a DELETE request to the backend
//   const handleDeleteEvent = (id) => {
//     axios
//       .delete(`http://localhost:5000/apis/delete-event/${id}`) // Replace with your API endpoint
//       .then(() => {
//         setEvents(events.filter((event) => event.id !== id));
//         setShowOffcanvas(false);
//       })
//       .catch((error) => {
//         console.error("Error deleting event:", error);
//       });
//   };

//   // Sets the selected event when a user clicks on an event
//   const handleSelectEvent = (event) => {
//     setSelectedEvent(event);
//     setShowOffcanvas(true);
//   };

//   return (
//     <div className="calender-container">
//       <div className="btn-container">
//         <button
//           className="btn-event"
//           onClick={() => {
//             setSelectedEvent(null);
//             toggleOffcanvas();
//           }}
//         >
//           Add Event
//         </button>
//       </div>

//       <Sidebar
//         show={showOffcanvas}
//         onHide={() => setShowOffcanvas(false)}
//         onAddEvent={handleAddEvent}
//         onEditEvent={handleEditEvent}
//         onDeleteEvent={handleDeleteEvent}
//         selectedEvent={selectedEvent}
//       />
//       <Calendar
//         localizer={localizer}
//         events={events} // Pass the formatted events to the Calendar
//         startAccessor="start"
//         endAccessor="end"
//         style={{ height: "100vh" }}
//         onSelectEvent={handleSelectEvent} // Handle event selection
//       />
//     </div>
//   );
// };

// export default Calender;

import React, { useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import axios from "axios"; // Import axios for making API calls
import "react-big-calendar/lib/css/react-big-calendar.css";
import Sidebar from "./Sidebar";
import "./Sidebar.css";
import { GoogleLogin } from "@react-oauth/google";

const localizer = momentLocalizer(moment);

const Calender = () => {
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [events, setEvents] = useState([]);
  console.log("events----", events);

  const [selectedEvent, setSelectedEvent] = useState(null);

  const token = localStorage.getItem("token");

  useEffect(() => {
    axios
      .get("http://localhost:5000/apis/getEvent", {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        const formattedEvents = response.data.map((event) => {
          const startDate = new Date(event.event_date);
          const [startHour, startMinute] = event.event_startTime.split(":");
          const [endHour, endMinute] = event.event_endTime.split(":");

          // Set the correct start and end time by adjusting the hours and minutes
          startDate.setHours(startHour, startMinute); // Set the start time
          const endDate = new Date(startDate); // Copy the start date to the endDate
          endDate.setHours(endHour, endMinute); // Set the end time

          return {
            id: event._id, // Use _id from the API response
            title: event.event_title,
            start: startDate,
            end: endDate,
          };
        });

        setEvents(formattedEvents); // Store the formatted events in the state
      })
      .catch((error) => {
        console.error("Error fetching events:", error);
      });
  }, []);

  const toggleOffcanvas = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  // Adds a new event by sending a POST request to the backend
  const handleAddEvent = (newEvent) => {
    axios
      .post("http://localhost:5000/apis", newEvent, {
        headers: {
          Authorization: `${token}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        setEvents([...events, response.data]); // Add the newly created event to the state
        setShowOffcanvas(false);
      })
      .catch((error) => {
        console.error("Error adding event:", error);
      });
  };

  // Edits an existing event by sending a PUT request to the backend
  const handleEditEvent = (updatedEvent) => {
    axios
      .put(
        `http://localhost:5000/apis/update-event/${updatedEvent.id}`,
        updatedEvent
      ) // Replace with your API endpoint
      .then((response) => {
        const updatedEvents = events.map((event) =>
          event.id === updatedEvent.id ? response.data : event
        );
        setEvents(updatedEvents);
        setShowOffcanvas(false);
      })
      .catch((error) => {
        console.error("Error updating event:", error);
      });
  };

  // Deletes an event by sending a DELETE request to the backend
  const handleDeleteEvent = (id) => {
    axios
      .delete(`http://localhost:5000/apis/delete-event/${id}`) // Replace with your API endpoint
      .then(() => {
        setEvents(events.filter((event) => event.id !== id));
        setShowOffcanvas(false);
      })
      .catch((error) => {
        console.error("Error deleting event:", error);
      });
  };

  // Sets the selected event when a user clicks on an event
  const handleSelectEvent = (event) => {
    setSelectedEvent(event);
    setShowOffcanvas(true);
  };

  const handleGoogleLoginSuccess = (credentialResponse) => {
    // Send the authorization code to the backend for token exchange
    axios
  .post(`http://localhost:5000/apis/redirect-url?code=${credentialResponse.credential}`)
  .then((response) => {
    console.log("Google Calendar connected:", response.data);
    alert("Google Calendar connected successfully!");
  })
  .catch((error) => {
    console.error("Error connecting Google Calendar:", error);
  });
  };

  const handleGoogleLoginError = () => {
    alert("Google Login failed. Please try again.");
  };

  return (
    <div className="calender-container">
      <div className="btn-container">
        <button
          className="btn-event"
          onClick={() => {
            setSelectedEvent(null);
            toggleOffcanvas();
          }}
        >
          Add Event
        </button>
      </div>

      <GoogleLogin
      
        onSuccess={handleGoogleLoginSuccess}
        onError={handleGoogleLoginError}
        useOneTap
      />

      <Sidebar
        show={showOffcanvas}
        onHide={() => setShowOffcanvas(false)}
        onAddEvent={handleAddEvent}
        onEditEvent={handleEditEvent}
        onDeleteEvent={handleDeleteEvent}
        selectedEvent={selectedEvent}
      />
      <Calendar
        localizer={localizer}
        events={events} // Pass the formatted events to the Calendar
        startAccessor="start"
        endAccessor="end"
        style={{ height: "100vh" }}
        onSelectEvent={handleSelectEvent} // Handle event selection
      />
    </div>
  );
};

export default Calender;
