import './App.css';
import routers from "./router/routes";
import { RouterProvider } from "react-router-dom";
import { GoogleOAuthProvider } from '@react-oauth/google';

function App() {
  return (
    <GoogleOAuthProvider clientId="1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com">
    <div className="App">
      <RouterProvider router={routers} />
    </div>
    </GoogleOAuthProvider>
  );
}

export default App;
