import { Component } from '@angular/core';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrl: './contacts.component.css'
})
export class ContactsComponent {
  heading: string = "Contact Us";

  description: string = "Please fill out the form below to get in touch with us.";
  contactForm = {
    name: '',
    subject: '',
    email:'',
    message: ''
  };

  onSubmit() {
    console.log('Contact Form Submitted:', this.contactForm);
    // Reset form after submission
    this.contactForm = { name: '', subject: '', message: '' ,email:''};
  }

}
