import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Import HttpClient
import Swal from 'sweetalert2';

interface Product {
  name: string;
  price: number;
  image: string;
  quantity?: number; 
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getProducts(); 
  }

  // Fetch products from the API
  getProducts(): void {
    const apiUrl = 'http://127.0.0.1:8000/api/products/';
    
    this.http.get<Product[]>(apiUrl).subscribe({
      next: (response) => {
        console.log('Fetched products:', response);  // Log the API response
        this.products = response;
      },
      error: (error) => {
        console.error('Error fetching products:', error);
        Swal.fire({
          title: 'Error',
          text: 'There was an error loading products.',
          icon: 'error'
        });
      }
    });
  }
  

  // Add product to cart
  addToCart(product: Product): void {
    let cart: Product[] = JSON.parse(localStorage.getItem('cart') || '[]');
    
    // Check if the product already exists in the cart
    const existingProduct = cart.find(item => item.name === product.name);
    
    if (existingProduct) {
      // If the product exists, increase its quantity
      existingProduct.quantity = (existingProduct.quantity || 1) + 1;
    } else {
      // If the product doesn't exist, add it with quantity 1
      product.quantity = 1;
      cart.push(product);
    }
    
    // Save the updated cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
  
    // Show success message
    Swal.fire({
      title: 'Good job!',
      text: `${product.name} added to cart.`,
      icon: 'success'
    });
  
    console.log(`${product.name} added to cart.`);
  }

  imageshow(path:string){
    return 'http://127.0.0.1:8000'+path
  }
}
