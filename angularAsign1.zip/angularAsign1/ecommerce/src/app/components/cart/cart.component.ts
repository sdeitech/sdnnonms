import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { CouponService } from '../../coupon.service';
import { Router } from '@angular/router';  // Import Router

interface Product {
  id?: number;
  tittle: string;
  description: string;
  price: number;
  image: string;
  quantity?: number;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Product[] = [];
  couponCode: string = '';
  totalPrice: number = 0;
  discount: number = 0;
  finalPrice: number = 0;
  cartCount: number = 0;

  constructor(private couponService: CouponService, private router: Router) {}

  ngOnInit(): void {
    this.loadCart();
    this.calculateTotalPrice();
  }

  loadCart(): void {
    const savedCart = localStorage.getItem('cart');
    this.cart = savedCart ? JSON.parse(savedCart).map((item: Product) => ({
      ...item,
      quantity: item.quantity || 1
    })) : [];

    this.updateCartCount();
  }

  updateCartCount(): void {
    this.cartCount = this.cart.reduce((count, product) => count + (product.quantity || 1), 0);
  }

  calculateTotalPrice(): void {
    this.totalPrice = this.cart.reduce(
      (total, product) => total + (product.price * (product.quantity || 1)),
      0
    );

    this.finalPrice = this.totalPrice - this.discount;
  }

  applyCoupon(): void {
    if (!this.couponCode.trim()) {
      Swal.fire({
        title: 'No Coupon Code Entered',
        text: 'Please enter a coupon code to apply.',
        icon: 'info'
      });
      return;
    }

    this.couponService.validateCoupon(this.couponCode).subscribe(
      (response: any) => {
        if (response.valid) {
          this.discount = (this.totalPrice * response.discount_percentage) / 100;
          this.finalPrice = this.totalPrice - this.discount;

          Swal.fire({
            title: 'Coupon Applied!',
            text: `You got a ${response.discount_percentage}% discount.`,
            icon: 'success'
          });
        } else {
          Swal.fire({
            title: 'Invalid Coupon',
            text: response.message || 'The coupon code you entered is not valid or has expired.',
            icon: 'error'
          });
          this.discount = 0;
          this.finalPrice = this.totalPrice;
        }
      },
      (error) => {
        Swal.fire({
          title: 'Error',
          text: 'There was a problem validating your coupon. Please try again later.',
          icon: 'error'
        });
        console.error('Error applying coupon:', error);
      }
    );
  }

  checkout(): void {
    // Pass the final price and discount to the Order page
    const checkoutData = {
      cart: this.cart,
      finalPrice: this.finalPrice,
      discount: this.discount,
    };

    // Save the data to localStorage or pass it via routing
    localStorage.setItem('checkoutData', JSON.stringify(checkoutData));

    // Navigate to the Order page
    this.router.navigate(['/orders']);
  }

  removeFromCart(product: Product): void {
    const index = this.cart.findIndex(item => item.id === product.id);

    if (index !== -1) {
      if (this.cart[index].quantity && this.cart[index].quantity! > 1) {
        this.cart[index].quantity! -= 1;
      } else {
        this.cart.splice(index, 1);
      }

      localStorage.setItem('cart', JSON.stringify(this.cart));
      this.updateCartCount();
      this.calculateTotalPrice();

      Swal.fire({
        title: 'Removed!',
        text: `${product.tittle} has been removed from cart`,
        icon: 'info'
      });
    }
  }

  clearCart(): void {
    Swal.fire({
      title: 'Clear Cart?',
      text: 'Are you sure you want to remove all items from your cart?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, clear it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.cart = [];
        localStorage.removeItem('cart');
        this.updateCartCount();
        this.calculateTotalPrice();

        Swal.fire('Cleared!', 'Your cart has been emptied.', 'success');
      }
    });
  }

  getimagepath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `http://127.0.0.1:8000${path.startsWith('/') ? path : '/' + path}`;
  }
}
