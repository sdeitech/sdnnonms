import { Component, OnInit } from '@angular/core';

interface Product {
  name: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: Product[] = [];
  couponCode: string = '';  
  discountApplied: boolean = false; 

  ngOnInit() {
    // Fetch cart items from localStorage
    const storedCart = localStorage.getItem('cart');
    this.cartItems = storedCart ? JSON.parse(storedCart) : [];
  }

  // Method to remove an item from the cart
  removeFromCart(index: number) {
    // Remove the item from the cart
    this.cartItems.splice(index, 1);

    // Update the cart in localStorage
    localStorage.setItem('cart', JSON.stringify(this.cartItems));
  }

  // Method to show the image URL
  imageshow(path: string) {
    return 'http://127.0.0.1:8000' + path;
  }

  // Method to calculate the total price of items in the cart
  getTotalPrice() {
    const total = this.cartItems.reduce((sum, item) => sum + item.price,0);
    return this.discountApplied ? total * 0.9 : total;  // Apply 10% discount if coupon is applied
  }

  // Method to apply coupon code
  applyCoupon() {
    if (this.couponCode === 'FIRSTORDER') {
      this.discountApplied = true;  // Apply discount
    } else {
      this.discountApplied = false;  // Reset discount if code is invalid
      alert('Invalid Coupon Code');
    }
  }
}
