import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { OrderService } from './order.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  shippingAddress: string = ''; // User's default address
  editableAddress: string = ''; // Editable version of the address
  paymentMethod: string = ''; // Holds the selected payment method
  finalPrice: number = 0; // Final price for the order
  discount: number = 0; // Discount applied to the order

  constructor(private router: Router, private orderService: OrderService) {}

  ngOnInit(): void {
    // Retrieve checkout data from localStorage
    const checkoutData = JSON.parse(localStorage.getItem('checkoutData') || '{}');
    this.finalPrice = checkoutData.finalPrice || 0;
    this.discount = checkoutData.discount || 0;

    // Fetch the user's registered address as the default shipping address
    this.orderService.getShippingAddress().subscribe(
      (response: any) => {
        this.shippingAddress = response.shipping_address || '';
        this.editableAddress = this.shippingAddress; // Set editable address to the fetched address
      },
      (error) => {
        console.error('Error fetching shipping address:', error);
        Swal.fire({
          title: 'Error',
          text: 'Unable to fetch shipping address.',
          icon: 'error'
        });
      }
    );
  }

  // Save the updated shipping address
  saveShippingAddress(): void {
    if (!this.editableAddress.trim()) {
      Swal.fire({
        title: 'Invalid Address',
        text: 'Shipping address cannot be empty.',
        icon: 'warning'
      });
      return;
    }

    this.orderService.updateShippingAddress(this.editableAddress).subscribe(
      (response: any) => {
        Swal.fire({
          title: 'Address Saved!',
          text: 'Your shipping address has been updated successfully.',
          icon: 'success'
        });
        this.shippingAddress = this.editableAddress; // Update the displayed address
      },
      (error) => {
        Swal.fire({
          title: 'Error',
          text: 'There was an issue saving your address. Please try again.',
          icon: 'error'
        });
        console.error('Error updating address:', error);
      }
    );
  }

  // Select a payment method
  selectPaymentMethod(method: string): void {
    this.paymentMethod = method;
  }

  // Place the order
  placeOrder(): void {
    if (!this.shippingAddress.trim()) {
      Swal.fire({
        title: 'No Shipping Address',
        text: 'Please provide a valid shipping address before proceeding.',
        icon: 'warning'
      });
      return;
    }

    if (!this.paymentMethod) {
      Swal.fire({
        title: 'No Payment Method',
        text: 'Please select a payment method before proceeding.',
        icon: 'warning'
      });
      return;
    }

    // Prepare the order data
    const orderData = {
      shipping_address: this.shippingAddress,
      payment_method: this.paymentMethod,
      total_amount: this.finalPrice
    };

    // Call the backend API to place the order
    this.orderService.placeOrder(orderData).subscribe(
      (response: any) => {
        Swal.fire({
          title: 'Order Placed!',
          text: `Your order has been placed successfully! Total: ${this.finalPrice} with ${this.discount}% discount.`,
          icon: 'success'
        });

        // Redirect to the order confirmation page or home page
        this.router.navigate(['/']);
      },
      (error) => {
        Swal.fire({
          title: 'Error',
          text: 'There was an issue placing your order. Please try again.',
          icon: 'error'
        });
        console.error('Error placing order:', error);
      }
    );
  }
}
