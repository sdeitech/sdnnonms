import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private apiUrl = 'http://127.0.0.1:8000/create-order/';  // Update this URL with your actual backend URL

  constructor(private http: HttpClient) {}

  // Fetch shipping address
  getShippingAddress(): Observable<any> {
    const token = localStorage.getItem('authToken'); 
    const shippingAddress = localStorage.getItem('shippingAddress');// Assuming you store the auth token in localStorage
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.get(`${this.apiUrl}get-address/`, { headers });
  }

  // Update shipping address
  updateShippingAddress(newAddress: string): Observable<any> {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.patch(`${this.apiUrl}update-address/`, { shipping_address: newAddress }, { headers });
  }

  placeOrder(orderData: any): Observable<any> {
    const token = localStorage.getItem('authToken'); // Assuming you store the auth token in localStorage
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.post(this.apiUrl, orderData, { headers });
  }
}
