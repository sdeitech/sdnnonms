import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private baseUrl = 'http://127.0.0.1:8000/api/'; // Base API URL

  constructor(private http: HttpClient) {}

  // Function to retrieve headers with the token
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token'); // Ensure the key matches your localStorage
    if (!token) {
      throw new Error('Authentication token is missing from localStorage');
    }
    return new HttpHeaders({
      'Authorization': `Token ${token}`,
      'Content-Type': 'application/json'
    });
  }

  // Fetch the logged-in user's default shipping address
  getShippingAddress(): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.baseUrl}create-order/get-address/`, { headers });
  }

  // Update the logged-in user's shipping address
  updateShippingAddress(newAddress: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.patch(
      `${this.baseUrl}create-order/update-address/`,
      { shipping_address: newAddress },
      { headers }
    );
  }

  // Place an order
  placeOrder(orderData: any): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.post(`${this.baseUrl}create-order/`, orderData, { headers });
  }
}
