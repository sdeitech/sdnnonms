import { Component } from '@angular/core';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  onSubmit() {
    Swal.fire({
      title: "Good job!",
      text: "Registration successfull",
      icon: "success"
    });
    console.log('Registration form submitted');

  }

}
