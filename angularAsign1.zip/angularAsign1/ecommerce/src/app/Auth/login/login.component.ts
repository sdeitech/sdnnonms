import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private http: HttpClient) {}

  onSubmit(loginForm: any) {
    // Prepare the login credentials
    const loginData = {
      email: loginForm.value.email,
      password: loginForm.value.password
    };

    // API request to login
    this.http.post('http://localhost:8000/api/login/', loginData).subscribe(
      (response: any) => {
        // If login is successful, store the token in localStorage
        if (response.token) {
          localStorage.setItem('token', response.token);

          // Show success alert
          Swal.fire({
            title: "Good job!",
            text: "Login successful",
            icon: "success"
          });
        } else {
          Swal.fire({
            title: "Error!",
            text: "Login failed, please try again",
            icon: "error"
          });
        }
      },
      (error) => {
        // Handle error
        Swal.fire({
          title: "Error!",
          text: "Something went wrong. Please try again later.",
          icon: "error"
        });
      }
    );

    // Handle the login form logic here
    console.log('Login form submitted');
  }
}
