import { Component } from '@angular/core';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  onSubmit() {
    Swal.fire({
      title: "Good job!",
      text: "login successfull",
      icon: "success"
    });

    // Handle the login logic here

    console.log('Login form submitted');

  }

}
