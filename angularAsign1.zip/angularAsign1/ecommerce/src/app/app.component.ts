import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Your Application';
  showModal: boolean = false;

  constructor(private router: Router) {}

  // Check if the user is logged in by verifying if a token exists in localStorage
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token'); // Returns true if token exists
  }

  // Logout functionality
  logout(): void {
    // Clear the token from localStorage
    localStorage.removeItem('token');

    // Optionally clear other user-related data from localStorage
    localStorage.removeItem('user');

    // Redirect the user to the login page
    this.router.navigate(['/login']);
  }

  // Handle cart button click
  handleCartClick(): void {
    if (this.isLoggedIn()) {
      // If the user is logged in, navigate to the cart page
      this.router.navigate(['/cart']);
    } else {
      // If the user is not logged in, show the login prompt modal
      this.showModal = true;
    }
  }

  // Close the modal
  closeModal(): void {
    this.showModal = false;
  }
}
