const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const User = require('../model/user-Model');
import { OAuth2Client } from 'google-auth-library';
import sendMailwhileLogin from '../helper/mail';

const client = new OAuth2Client('1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com')

const registerUser = async (req, res) => {
    try {
        const { firstName, lastName, email, password, dob, maritalStatus, gender, } = req.body;
        console.log(req.body)
        const profile = req.file?.filename
        let hashed = await bcrypt.hash(password, 10)

        const user = new User({
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: hashed,
            dob: dob,
            maritalStatus: maritalStatus,
            gender: gender,
            photo: profile,
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

const loginUser = async (req, res) => {

    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email })

        if (!user) {
            return res.status(400).json({ message: "User not found" })
        }

        const isMatch = await bcrypt.compare(password, user.password)

        if (isMatch) {
            const token = jwt.sign({ email, userId: user._id }, "an123idjk", { "expiresIn": "2h" })
            console.log('token-----', token)

            return res.status(201).json({ message: "Logged In", "token": token, 'userId': user._id })
        } else {
            return res.status(401).json({ message: "Invalid Credentials" })

        }
    } catch (error) {
        res.status(401).json({ Error: error.message })
    }
}

const getUser = async (req, res) => {
    try {
        const { searchText } = req.query;

        let filter = {};

        if (searchText) {
            filter = {
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        const users = await User.find(filter)
            .select('firstName lastName email password maritalStatus dob gender')
            .skip(skip)
            .limit(limit);
        const totalCount = await User.countDocuments(filter);

        const response = {
            users: users,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getUserById = async (req, res) => {
    try {
        const { id } = req.params
        const user = await User.findById(id)
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const updateUserById = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

export const loginWithGoogle = async (req, res) => {
    const { token } = req.body;
    try {
        // Verify the ID token
        const ticket = await client.verifyIdToken({
            idToken: token,  // Token from frontend
            audience: '1029995414463-62q6qm9ucrmvbf7ompsvao514kegh4b7.apps.googleusercontent.com',  // Should match CLIENT_ID
        });

        const payload = ticket.getPayload();
        const { email } = payload
        console.log(payload);


        // Extract user details from the token payload
        const googleId = payload.sub; // Google user ID
        const email_id = payload.email; // User email from Google

        // Check if email_id is defined
        if (!email_id) {
            throw new Error('Email ID is missing from the token payload');
        }

        const username = email_id.split('@')[0]; // Assign default username

        // Check if the user exists in the database
        let user = await User.findOne({ email: email_id });
        if (!user) {
            const randomPassword = Math.random().toString(36).slice(-10)
            const hasshedPassword = await bcrypt.hash(randomPassword, 10)


            user = new User({
                email: payload.email,
                googleId,
                firstName: payload.given_name,
                lastName: payload.family_name,
                // username,
                // role: 'user',
                // password: googleId,
                password: hasshedPassword,
                tokens: [],
            });

            const subject = "Your Tempory Password";
            const text = `Welcome your temporary Password is ${randomPassword}. please change your pass from profile`
            await sendMailwhileLogin(email, subject, text)
            await user.save();

            return res.status(200).json({
                id: user._id,
                token: jwt.sign({ email }, "an123idjk", { expiresIn: "5h" }),
                newUser: true,
            });
        } else {

            const jwtToken = jwt.sign({ email: email_id, userId: user._id }, "an123idjk", { "expiresIn": "2h" })

            // Store the token in the user object
            user.tokens = [{ token: jwtToken }];
            await user.save();
            return res.status(201).json({ message: "Logged In", "token": jwtToken, 'userId': user._id, newUser: false })

            //     const jwtToken = jwt.sign({ email }, "an123idjk", { expiresIn: "5h" });

            //     return res.status(200).json({
            //       id: user._id,
            //       token: jwtToken,
            //       newUser: false, 
            //     });
        }



        // Generate a JWT token


    } catch (error) {
        console.error('Error during Google login:', error);
        res.status(401).json({ message: 'Unauthorized', error: error.message });
    }
};

module.exports = { registerUser, loginUser, getUser, getUserById, updateUserById, loginWithGoogle }



