import 'dotenv/config.js';

export const config = {
  DB: {
    HOST: process.env.MONGO_DB_HOST || "127.0.0.1",
    PORT: process.env.MONGO_DB_PORT || "27017",
    DATABASE: process.env.MONGO_DATABASE || "dbname",
  },
  PORT: process.env.PORT,
  
  JWT_SECRET: process.env.JWT_SECRET || "mysecretkey",
  JWT_EXPIRATION_IN_MINUTES: process.env.JWT_EXPIRATION_IN_MINUTES || 1440,
  OTP_EXPIRATION: process.env.OTP_EXPIRATION || 5,
  NODE_ENV: process.env.NODE_ENV || "local",
};
