import mongoose from "mongoose";
import 'dotenv/config'
const config = require("./config")
const { DB } = config.config

const MONGOURI= `mongodb://${DB.HOST}:${DB.PORT}/${DB.DATABASE}`

export const initiateMongoConnection = async()=>{
    try{
        await mongoose.connect(MONGOURI);
        console.log("Connected to DB");
    } catch(e){
        throw e
    }
}