from django.shortcuts import redirect, render
from .models import Subjects
def input(request):
    if request.method == 'POST':
        Subject_name = request.POST.get('Subject_name')
        Theory_marks = request.POST.get('Theory_marks')
        Internal_marks = request.POST.get('Internal_marks')
        Theory_marks = int(Theory_marks)
        Internal_marks = int(Internal_marks)

        total_marks = Theory_marks + Internal_marks
        percentage = (total_marks / 500) * 100 

        status = 'Pass' if total_marks >=35 else 'fail'
       
        newobj = Subjects(
            Subject_name = Subject_name,
            Theory_marks = Theory_marks,
            Internal_marks =  Internal_marks,
            total_marks =total_marks,
            percentage=percentage,
            status=status
        )
        newobj.save()
        return redirect('/')
    else:
        obj= Subjects.objects.all()
        context = {'obj': obj,}
        return render(request,'input.html',context)




