from django.db import models

# class Subjects(models.Model):
#      Subject_name = models.CharField(max_length=50)
#      computer_application= models.IntegerField()
#      computer_application_internal= models.IntegerField()
#      engineering_physics = models.IntegerField()
#      engineering_physics_internal = models.IntegerField()
#      engineering_mathematics = models.IntegerField()
#      engineering_mathematics_internal = models.IntegerField()
#      basic_electrical_electonics = models.IntegerField()  
#      basic_electrical_electonics_internal = models.IntegerField()
#      engineering_physics_practical = models.IntegerField()
#      engineering_drawing = models.IntegerField()


class Subjects(models.Model):
    Subject_name = models.CharField(max_length=50)
    Theory_marks = models.IntegerField()
    Internal_marks = models.IntegerField()
    total_marks = models.IntegerField()
    percentage = models.FloatField()
    status = models.CharField(max_length=10)

     
# class ExamDetails(models.Model):
#     exam = models.CharField(max_length=50)
#     center = models.IntegerField()
#     semester = models.IntegerField()
#     name = models.IntegerField()
#     registration_number = models.IntegerField()

