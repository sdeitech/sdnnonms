def uniqueCharacters(str):
     
    for i in range(len(str)):
        for j in range(i + 1,len(str)): 
            if(str[i] == str[j]):
                return False;
    return True;
 
str = is_unique = input("Enter Unique Character : ")
 
if(uniqueCharacters(str)):
    print("The character are Unique");
else:
    print("There are repeated Character ");