num = input("Enter Positive Integer: ")
sum = 0

for i in num:
    sum = sum + int(i)

print(sum)