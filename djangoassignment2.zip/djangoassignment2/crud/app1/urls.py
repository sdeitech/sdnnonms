from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
   
    path('', views.postGet.as_view(),name='employe_form'),
    path('employee_list/', views.getdata.as_view(),name='employee_list'),
    path('delete/<int:id>', views.delete.as_view(),name='delete'),
    path('update/<int:id>', views.update.as_view(),name='update'),
    path('view/<int:id>', views.viewEmployeedetail.as_view(),name='view'),
    path('search/', views.search.as_view(),name='search'),
    
    
]