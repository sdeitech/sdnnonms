
from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from django.views import View
from .models import Employee
from django.core.paginator import Paginator

class postGet(View):
    def get(self, request):
        return render(request,'employee_form.html')
    
    def post(self,request):
        data=request.POST
        employee_id=data.get('employee_id')
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        department=data.get('department')
        position=data.get('position')
        date_of_birth=data.get('date_of_birth')
        date_joined=data.get('date_joined')
        salary=data.get('salary')
        is_full_time=bool(data.get('is_full_time'))
        email=data.get('email')
        phone_number=data.get('phone_number')
        address=data.get('address')
        city=data.get('city')
        state=data.get('state')
        last_performance_review=data.get('last_performance_review')
        
        
         
        newUser=Employee.objects.create(
            employee_id=employee_id,
            first_name=first_name,
            last_name=last_name,
            department=department,
            position=position,  
            date_of_birth=date_of_birth,
            date_joined=date_joined,
            salary=salary,
            is_full_time=is_full_time,
            email=email,
            phone_number=phone_number,
            address=address,
            city=city,
            state=state,
            last_performance_review=last_performance_review,
            
           
        )
        newUser.save()
        return redirect("/employee_list")
        
       
        
class getdata(View):
    def get(self,request):
        allUser=Employee.objects.all()
        paginator=Paginator(allUser,2)
        page_number = request.GET.get('page')
        allUserFinal = paginator.get_page(page_number)
        totalpage = allUserFinal.paginator.num_pages
        data = {"users" : allUserFinal,
                "lastpage":totalpage,
                "totalPagelist":[n+1 for n in range(totalpage)]
               }
        return render(request,'employee_list.html',data)
        
         
    
    
class delete(View):
    def get(self,request,id):
        print("delete")
        Employee.objects.get(id=id).delete()
        return redirect('/employee_list')
            
class update(View):
    def get(self,request,id):
        print("update")
        users = Employee.objects.get(id=id)
        date = str(users.date_of_birth)
        joined=str(users.date_joined)
        lastperformed=str(users.last_performance_review)
        return render(request,'employee_update.html',{'update':users,'date':date,'joined':joined,'lastperformed':lastperformed})
   
    
    
    def post(self,request,id):
        data=request.POST
        employee_id=data.get('employee_id')
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        department=data.get('department')
        position=data.get('position')
        date_of_birth=data.get('date_of_birth')
        date_joined=data.get('date_joined')
        salary=data.get('salary')
        is_full_time=bool(data.get('is_full_time'))
        email=data.get('email')
        phone_number=data.get('phone_number')
        address=data.get('address')
        city=data.get('city')
        state=data.get('state')
        last_performance_review=data.get('last_performance_review')
          
        newuser=Employee.objects.get(id=id)
          
        newuser.employee_id = employee_id
          
        newuser.first_name = first_name
        newuser.last_name = last_name
        newuser.department=department
        newuser.position =position
        newuser.date_of_birth =date_of_birth
        newuser.date_joined =date_joined
        newuser.salary =salary
        newuser.is_full_time =is_full_time
         
        if is_full_time == "on":
            newuser.is_full_time = True
        else:
             newuser.is_full_time = False
        newuser.email =email
        newuser.phone_number =phone_number
        newuser.address =address
        newuser.city =city
        newuser.state =state
        newuser.last_performance_review =last_performance_review
        
        
        newuser.save()

        return redirect('/employee_list')    
    
class viewEmployeedetail(View):
    def get(self,request,id):
        profile =get_object_or_404(Employee,id=id)
        context={"employee":profile}
        return render(request,"employee_details.html",context)


class search(View):
    def  get(self,request):
        return HttpResponse('this is serach') 