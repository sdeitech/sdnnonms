require("dotenv/config");

export const messageID = {
  tesrt: "dghd",
};
export const messages = {
  imageType:
    "The Image type you have provided is not an valid type!! Try with .jpeg, .jpg or .png files only...",
};
