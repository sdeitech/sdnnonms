from django.urls import path
from . views import showStudents

urlpatterns = [
    path('', showStudents.as_view(), name='home')
]
