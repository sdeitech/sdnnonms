import Users from "../models/userModel"



export const createUsers = async (req, res) => {
    const { name, email } = req.body;
    console.log(req.body,"jjjjjjj");
    
    try {

        if (name && email) {
            const newUser = Users({
                name: name,
                email: email,
            });
            const savedUser = await newUser.save();
            if (savedUser) {
                return res.status(201).json(savedUser);
            }
            else {
                return res.status(400).json({ message: "something went wromng" });
            }
        }
    }
    catch (error) {
        return res.status(400).json(error);
    }
}


export const getusers = async (req, res) => {
    try {
        const getUser = await Users.find({});
        if (getUser) {
            return res.status(200).json(getUser);
        }
    }
    catch (error) {
        return res.status(400).json(error);
    }
}

export const updateUser = async(req,res)=>{
    const{id}=req.params;
    console.log(req.body,"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
    
    try{
     
     if(id)
     {
        console.log(id,"iddddddddddddddddd");
        
       const updateUser = await Users.findByIdAndUpdate(id,req.body);
       console.log(updateUser,"heyyyyyyyyyyyyy");
       
       return res.status(200).json(updateUser);
       
       
        }
        
        else{
            return res.status(400).json({message:"id not found"});
        }
     }
     catch(error)
     {
        return res.status(400).json(error);
     }
    };