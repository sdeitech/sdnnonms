import express from 'express';
import {createUsers,getusers,updateUser} from "../controllers/userController"

const router = express.Router();

//all router are here


router.post("/adduser",createUsers);
router.get("/getuser",getusers);
// router.get("/users/single/:id",userController.getSingleUsers);
router.put("/updateuser/:id",updateUser);
// router.delete("/users",userController.deleteUsers);

export default router