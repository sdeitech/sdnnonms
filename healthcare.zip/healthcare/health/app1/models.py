from django.db import models

# Create your models here.


class PatientLogin(models.Model):
    email=models.EmailField(max_length=50)
    password=models.IntegerField()
    
class PatientDetails(models.Model):
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)           
    age = models.DateField()
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    contact_number = models.CharField(max_length=15, null=True, blank=True)
    disease = models.CharField(max_length=100)
    description = models.TextField()

    
class Doctor(models.Model):
    name = models.CharField(max_length=100)
    specialization = models.ForeignKey(PatientDetails, on_delete=models.SET_NULL, null=True, blank=True)  # One disease for simplicity
    contact_number = models.CharField(max_length=15)
    
class Appointmet_Slot(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    start_time = models.TimeField()
    end_time = models.TimeField()
               
    
class Appointment(models.Model):
    patient = models.ForeignKey(PatientDetails, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    appointment_date = models.DateField()
    slot = models.ForeignKey(Appointmet_Slot, on_delete=models.CASCADE)



#Doctor Model


class DoctorLogin(models.Model):
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)
    email = models.EmailField()
    password = models.IntegerField()
    

class Appointment_List(models.Model):
    Patient = models.ForeignKey(to = PatientDetails,)
    currentSlot = models.ForeignKey(to=Appointmet_Slot,)
    
class Medicine_List(models.Model):
    patient = models.ForeignKey(to=Appointment_List)
    Medicine_name = models.CharField(max_length=50)
    Medecine_dose = models.IntegerField()
    Intake_days = models.DateField()
 
 
# pateint dashboard for medecine given by doctor
         
class List_of_Medicine(models.Model):
    patient = models.ForeignKey(to=PatientDetails)
    Doctor=models.ForeignKey(to=DoctorLogin)   
    Appointment = models.ForeignKey(to=Appointment_List) 
    medicine = models.ForeignKey(to=Medicine_List)
