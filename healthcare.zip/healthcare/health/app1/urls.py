from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('',views.home.as_view(),name='home' ),
    # path('', views.postGet.as_view(),name='create'),
    
    
]