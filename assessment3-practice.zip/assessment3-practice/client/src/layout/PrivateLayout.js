import React, { useEffect } from "react";
import { useNavigate } from "react-router";


const PrivateLayout = ({ children }) => {
    let token = "sgfsergsrgbs"
    let navigate = useNavigate();
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token, navigate]);

    return (
        <div className="layout">
            <div className="content">
                {children}
            </div>
        </div>
    );
};

export default PrivateLayout;
