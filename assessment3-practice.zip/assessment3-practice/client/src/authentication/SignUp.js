
import '../authentication/signUp.css'
import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input, FormGroup, Row, Col } from 'reactstrap';
import axios from "axios";
import validation from "../validate/validation";
import {Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';


function SignUp() {

    const [signUp, setsignUp] = useState([]);
    const navigate = useNavigate()
  
    useEffect(() => {
      fetchProduct();
    }, []);
  

    const fetchProduct = async () => {
      try {
        const response = await axios.post(`http://localhost:5000/api/register'`);
        setsignUp(response.data);
      } catch (error) {
        console.error("error fetching data", error);
      }
    };
  

  const [formData, setFormData] = useState({
    userName: '',
    lastName: '',
    email: '',
    password: '',

  });

  const [errors, setErrors] = useState({});


  useEffect(() => {
    if (signUp) {
      setFormData({
        userName: signUp.userName,
        email: signUp.email,
        password: signUp.password,

      });
    } else {
      setFormData({
        userName: '',

        email: '',
        password: '',

      });
    }
  }, [signUp]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validation(formData);
        if (Object.keys(validationErrors).length === 0) {
            console.log('Form data submitted:', formData);
            navigate('/signup')

            
        } else {
            setErrors(validationErrors);
        }

    if (signUp){
        try {
            const response = await axios.post(`http://localhost:5000/api/register`, formData);
            setsignUp(prevData => [...prevData, response.data]);
            console.log(response.data, "submit")
          
          } catch (error) {
            console.error("Error signing in", error);
          }
        
    }
      
    // Clear the form and edit state
    setFormData({
      userName: '',
      lastName: '',
      email: '',
      password: '',

    });
    setsignUp(null);
  };


  return (
    <div>
     
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="userName">First Name</Label>
              <Input
                id="userName"
                name="userName"
                value={formData.userName}
                onChange={handleInputChange}
                type="text"
                required
              />
              {errors.userName && <p className="error">{errors.userName}</p>}

            </FormGroup>
          </Col>
         
        </Row>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="email">Email</Label>
              <Input
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                type="email"
              />
              {errors.email && <p className="error">{errors.email}</p>}

            </FormGroup>
            <FormGroup>
              <Label for="password">Password</Label>
              <Input
                id="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                type="password"
              />
              {errors.password && <p className="error">{errors.password}</p>}

            </FormGroup>
          </Col>
        </Row>
        <Button className="me-2" type="submit">{'Submit'}</Button>
      </Form>
      <p>Already a User?
    <Link to="/">Click here</Link>
    </p>
    </div>
  );
}

export default SignUp;