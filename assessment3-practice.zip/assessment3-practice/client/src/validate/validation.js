const validation = (values) => {
    let errors = {};

    if (!values.firstName) {
        errors.firstName = "Name is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";
    }

    if (!values.password) {
        errors.password = "Password is required";
    } else if (values.password.length < 6) {
        errors.password = "Password needs to be more than 5 characters";
    }

    if (!values.lastName) {
        errors.lastName = "last name is required";
    }



    return errors;
};

export default validation;