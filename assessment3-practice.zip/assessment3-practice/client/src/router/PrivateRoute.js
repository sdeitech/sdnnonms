import {React} from "react";
import PrivateLayout from "../layout/PrivateLayout";
import SignUp from '../authentication/SignUp'
const privateRoutes = [
	{
		path: "/signup",
		exact: true,
		element: <PrivateLayout><div><SignUp/></div></PrivateLayout>
	},
	
];
export default privateRoutes;
