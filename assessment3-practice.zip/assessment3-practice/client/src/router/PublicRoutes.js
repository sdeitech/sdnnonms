import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Login from "../authentication/Login";
import SignUp from "../authentication/SignUp";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Login /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    }
];
export default publicRoutes;
