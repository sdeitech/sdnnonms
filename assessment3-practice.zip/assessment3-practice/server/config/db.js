import mongoose from "mongoose";
import 'dotenv/config'
const config = require("./config")
const { DB } = config.config

/**
 * @type {object}
 * @property {string} user
 * @property {string} pass
 */
var options = {
    user: DB.USERNAME,
    pass: DB.PASSWORD,
}
/**
 * @type {string}
 */
const MONGOURI= `mongodb://${DB.HOST}:${DB.PORT}/${DB.DATABASE}`

/**
 * @returns {Promise<void>} 
 * @throws {Error} 
 */
export const initiateMongoConnection = async()=>{
    try{
        await mongoose.connect(MONGOURI,options);
        console.log("Connected to DB");
    } catch(e){
        throw e
    }
}