import Dashboard from "../components/pages/Dashboard";
import PrivateLayout from "../layout/PrivateLayout";

const PrivateRoutes = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },
];
export default PrivateRoutes;
