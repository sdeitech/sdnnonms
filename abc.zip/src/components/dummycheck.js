// const dispatch = useDispatch();

//   const navigate = useNavigate();
//   const [toastShown, setToastShown] = useState(false);

//   const data = useSelector((state) => state.loginUser);

//   console.log(data, "userdata");

//   const signInData = {
//     email: "",
//     password: "",
//   };

//   const { formData, handleChange } = useForm(signInData);

//   const handleSignIn = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await axios.post(
//         `http://localhost:3002/api/signin`,
//         formData
//       );
//       setToastShown(true);

//       dispatch(loginSuccess(res.data));

//       setTimeout(() => {
//         navigate("/dashboard");
//       }, 1000);
//       console.log(res.data);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   useEffect(() => {
//     if (toastShown) {
//       toast.success("Login successful!");
//       setToastShown(false);
//     }
//   }, [toastShown]);
