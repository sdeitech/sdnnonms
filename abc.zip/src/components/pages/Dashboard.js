import React, { useEffect, useState } from "react";
import { getregisterbyid, getPeginatedData } from "../../api"; 
import UserProfileModal from "./UserProfileModal"; 
import AddUserModal from "./AddUserModal"; 
import { useNavigate } from "react-router-dom";
import './Dashboard.css'; 
import View from "./View";

const Dashboard = () => {
  const [userData, setUserData] = useState(null);
  const [error, setError] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false); 
  const [usersList, setUsersList] = useState([]); 
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  const userId = localStorage.getItem('id'); 
console.log(userId, "check======")
  const loadUserProfile = async () => {
    try {
      const userId = localStorage.getItem('id'); 
      if (!userId) {
        throw new Error("No user ID found, please log in again.");
      }
      const response = await getregisterbyid(userId); 
      setUserData(response);
    } catch (error) {
      console.error("Error fetching user data:", error.message);
      setError("Failed to load user profile");
      navigate("/"); 
    }
  };

  const loadUsersList = async (page = 1, search = "") => {
    try {
      const response = await getPeginatedData(page, search, userId); 
      setUsersList(response.data.user);
      setTotalPages(response.data.totalPages);
      setCurrentPage(page);
    } catch (error) {
      console.error("Error fetching users list:", error.message);
      setError("Failed to load users list");
    }
  };

  useEffect(() => {
    loadUserProfile();
    loadUsersList(currentPage, searchTerm); 
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("id");
  navigate("/");
    }

  const handleSearch = async (e) => {
    const searchValue = e.target.value;
    setSearchTerm(searchValue);
    await loadUsersList(1, searchValue); 
  };

  const handlePageChange = async (page) => {
    setCurrentPage(page);
    await loadUsersList(page, searchTerm);
  };

  const handleShowProfile = () => {
    setShowProfile(true); 
  };

  const handleShowAddUser = () => { 
    setShowAddUser(true); 
  };

  const [result, setResult] = useState(null);
  const [showview, setShowView] = useState(false);

  return (
    <div className="dashboard">
      <button onClick={handleLogout}>Logout
 
      </button>
      <button className="button" onClick={handleShowProfile}>View My Profile</button>
      <button className="button" onClick={handleShowAddUser}>Add User</button>

      <UserProfileModal userData={userData} setUserData = {setUserData} show={showProfile} onClose={() => setShowProfile(false)} />
      <AddUserModal show={showAddUser} onClose={() => setShowAddUser(false)} setUsersList={setUsersList} currentUserId={userData?.id} /> {/* Pass current user ID */}

      {error && <p className="error">{error}</p>}

      <h3>Users List</h3>
      <div className="seachbutton">
      <input
        type="text"
        placeholder="Search by first name"
        value={searchTerm}
        onChange={handleSearch}
        className="search-input"
      />
      </div>
      
      <table className="user-table">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {usersList.map((user, index) => (
            <tr key={index}>
              <td>{user.firstname}</td>
              <td>{user.lastname}</td>
              <td>{user.email}</td>
              <td><button className="view-button" onClick={() => {
                                        setShowView(!showview);
                                        setResult(user);
                                    }}>
                                        View
                                    </button></td>
            </tr>
          ))}
        </tbody>
      </table>
      {showview && <View result={result} />}
      {/* Pagination Controls */}
      <div className="pagination">
        {Array.from({ length: totalPages }, (_, index) => (
          <button
            key={index + 1}
            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
            onClick={() => handlePageChange(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;