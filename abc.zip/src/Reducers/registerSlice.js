import { createSlice } from "@reduxjs/toolkit";
import signInData  from "../dummytest"

const initialState = {
  userId: null,
  token: null,
};
const LoginUserSlice = createSlice({
  name: "loginDetails",
  initialState: initialState,
  reducers: {
    loginSuccess: (state, action) => {
      console.log(action.payload);
      state.userId = action.payload.id;
      state.token = action.payload.token;
    },
    logoutUser: (state) => {
      state.userId = null;
      state.userData = null;
      state.token = null;
    },
  },
});

export const { loginSuccess, logoutUser } = LoginUserSlice.actions;
export default LoginUserSlice.reducer;
