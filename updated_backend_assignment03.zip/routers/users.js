import express from "express"
import { getUsers, registerUser, updateUser, userLogin } from "../controllers/users"
import { uploadMiddleware } from "../helpers/multer"
import { addUser } from "../controllers/subusers"
const userRouter = express.Router()

userRouter.post("/signup", uploadMiddleware, registerUser)
userRouter.post("/signin", userLogin)
userRouter.post("/user/:id", addUser)
userRouter.get("/user/:id", getUsers)
userRouter.put("/update/user/:id", updateUser)



export default userRouter