import nodemailer from "nodemailer"


const transaport = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "abhishekdhole60@gmail.com",
        pass: "usqwmkdrnwrrmkam"
    }
})


export const sendMail = async (usermail, text) => {
    const mailOptions = {
        from: "abhishekdhole60@gmail.com",
        to: usermail,
        subject: "Your credentials",
        text: text
    }
    try {
        let info = await transaport.sendMail(mailOptions)
        return { status: true }

    } catch (error) {
        return { status: false }
        console.log(`Error while sending mail ${error.message}`)
    }
}

