import express from "express"
import cors from "cors"

const app = express()

// routes
import userRouter from "./routers/users"

app.use(express.json())
app.use(cors({ origin: "*" }))

app.use("/api", userRouter)
app.use("/get/profile", express.static("profiles"))


export default app