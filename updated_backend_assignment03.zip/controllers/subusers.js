import Users from "../models/users";
import Subusers from "../models/subusers";
import { MESSAGE, STATUS_CODE } from "../config/constants";

export const addUser = async (req, res) => {
    try {
        const { firstName, lastName, email } = req.body
        const { id } = req.params

        // const finduser = await Subusers.findOne({ email: email })
        // if (finduser) {
        //     return res.status(STATUS_CODE.FORBIDDETN).json({ message: MESSAGE.ALREDY_EXISTS })
        // }

        const existuser = await Users.findById(id)
        if (!existuser) {
            return res.status(STATUS_CODE.NOT_FOUND).json({ message: MESSAGE.NOT_FOUND })
        }
        const subuser = new Subusers({
            firstName,
            lastName,
            email
        })
        await subuser.save()

        const user = await Users.findByIdAndUpdate(id, {
            $push: { users: subuser }
        })

        res.status(STATUS_CODE.SUCCESS).json({ message: MESSAGE.SUB_USER_ADDED })

    } catch (error) {
        console.log(error.message)
        res.status(STATUS_CODE.INTERNAL_SERVER_ERR).json({ message: MESSAGE.INTERNAL_SERVER_ERR })
    }
}