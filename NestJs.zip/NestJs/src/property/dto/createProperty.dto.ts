import { IsInt, IsString, Length } from 'class-validator';

export class CreatePropertyDto {
  @IsString({ always: true })
  @Length(2, 10, { message: 'error on length' })
  name: string;

  @IsString()
  @Length(2, 10, { groups: ['create'] })
  @Length(1, 10, { groups: ['update'] })
  description: string;
  @IsInt({ always: true })
  area: number;
}
