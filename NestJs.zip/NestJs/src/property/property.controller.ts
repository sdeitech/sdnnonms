import {
  Body,
  Controller,
  Get,
  Headers,
  HttpCode,
  Param,
  ParseBoolPipe,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  UsePipes,
} from '@nestjs/common';
import { CreatePropertyDto } from './dto/createProperty.dto';
import { ZodValidationPipe } from './pipes/zodValidationPipe';
import { createPropertySchema } from './dto/createPropertyZod.dto';

@Controller('property')
export class PropertyController {
  @Get()
  findAll() {
    return 'This is a property controller';
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id, @Query('sort', ParseBoolPipe) sort) {
    console.log(typeof id);
    console.log(typeof sort);
    return `This is a property controller with id: ${id}`;
  }

  @Post()
  @UsePipes(new ZodValidationPipe(createPropertySchema))
  @HttpCode(700)
  create(@Body() body: CreatePropertyDto) {
    return body;
  }

  @Patch(':id')
  update(@Body() body: CreatePropertyDto, @Headers() header) {
    return header;
  }
}
