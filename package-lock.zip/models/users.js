import mongoose from "mongoose";
const Schema = mongoose.Schema;

const UserSchema = new Schema(
  {
    email: {
      type: String,
      required: true,
      trim: true,
    },
    gender: {
      type: String,
      required: true,
      enum: ["male", "female"],
    },
    term: {
      type: Boolean,
      required: true,
      default: false,
    },
    DBO: {
      type: Date,
      required: true,
    },
    profile: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
  },
  {
    timeseries: true,
  }
);

const Users = mongoose.model("Users", UserSchema);
export default Users;
