import express from "express";
const app = express();
import userRouter from "./router/users";

app.use(express.json());
app.use("/api", userRouter);
app.get("/", (req, res) => {
  res.send("Hello Node");
});

export default app;
