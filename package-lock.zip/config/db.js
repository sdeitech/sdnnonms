import mongoose from "mongoose";

const InitiateDbConnection = async () => {
  try {
    const db = await mongoose.connect(`mongodb://localhost:27017/TestDb`);
    console.log(`app is connectedd to db`);
  } catch (error) {
    console.log(`getting error while connecting to db ${error.message}`);
  }
};

module.exports = InitiateDbConnection;
