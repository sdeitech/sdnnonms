const config = {
  local: {
    DB: {
      HOST: "",
      PORT: "",
      DATABASE: "",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: "",
  },
  stage: {
    DB: {
      HOST: "",
      PORT: "",
      DATABASE: "",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: "",
  },
  prod: {
    DB: {
      HOST: "",
      PORT: "",
      DATABASE: "",
      USERNAME: "",
      PASSWORD: "",
    },
    API_PORT: "",
  },
};
