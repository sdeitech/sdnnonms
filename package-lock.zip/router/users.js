import express from "express";
import { uploadMiddleware } from "../helters/multer";
import { registerUser } from "../controllers/users";
const userRouter = express.Router();

userRouter.post("/user", uploadMiddleware.single("profile"), registerUser);

export default userRouter;
