import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "",
    pass: "",
  },
});

const sendMailToUser = async (to, subject, text) => {
  const mailOptions = {
    from: "",
    to: to,
    subject: subject,
    text: text,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("mail sent");
    return { status: true };
  } catch (error) {
    console.log(error.message);
    console.log({ status: false });
  }
};

export default sendMailToUser;
