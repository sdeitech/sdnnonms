import Users from "../models/users";
import bcrypt from "bcrypt";
import sendMailToUser from "../helters/nodemailer";

const registerUser = async (req, res) => {
  console.log("register controller getting called");
  const { email, gender, term, DBO, password } = req.body;
  const profile = req.file ? req.file.filename : null;
  if (!email || !gender || !term || !DBO || !profile || !password) {
    return res.json({ msg: "All fileds are required" });
  }
  try {
    const hashedPass = await bcrypt.hash(password, 10);
    const filename = req.file.filename;
    const user = new Users({
      email: email,
      gender: gender,
      term: term,
      DBO: DBO,
      profile: filename,
      password: hashedPass,
    });

    const subject = "Registration Credentials";
    const text = `Your ID : ${email} and password : ${password}`;
    const emailSend = await sendMailToUser(email, subject, text);
    console.log("data = ", emailSend);
    const userData = await user.save();
    if (emailSend.status) {
      res.json({ msg: "User is created and email sent", userData });
    }
  } catch (error) {
    res.json({ msg: error.message });
  }
};

const getPeginatedData = async (req, res) => {
  try {
    const { search = "", page = 1, limit = 4 } = req.query;
    const pageNo = Number(page);
    const pageLimit = Number(limit);
    const skip = (pageNo - 1) * pageLimit;
    const query = { email: { $regex: search, $options: "i" } };

    const users = await Users.find(query).skip(skip).limit();

    const totalRecord = await Users.countDocuments();
    const totalPages = Math.ceil(totalRecord / pageLimit);
    res.json({ users, totalRecord, totalPages, pageNo });
  } catch (error) {
    res.json({ msg: error.message });
  }
};

export { registerUser, getPeginatedData };
