import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { ERROR_MESSAGES } from 'src/constants/constants';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  // Error mapping using constants
  private readonly errorMapping = {
    TOKEN_MISSING: {
      statusCode: HttpStatus.BAD_REQUEST,
      message: ERROR_MESSAGES.TOKEN_MISSING,
    },
    VALIDATION_ERROR: {
      statusCode: HttpStatus.BAD_REQUEST,
      message: ERROR_MESSAGES.VALIDATION_ERROR,
    },
    UNAUTHORIZED_ACCESS: {
      statusCode: HttpStatus.UNAUTHORIZED,
      message: ERROR_MESSAGES.UNAUTHORIZED_ACCESS,
    },
    JWT_SECRET_NOT_FOUND: {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: ERROR_MESSAGES.JWT_SECRET_NOT_FOUND,
    },
    TOKEN_INVALID: {
      statusCode: HttpStatus.UNAUTHORIZED,
      message: ERROR_MESSAGES.TOKEN_INVALID,
    },
    CLIENT_ID_NOT_FOUND: {
      statusCode: HttpStatus.NOT_FOUND,
      message: ERROR_MESSAGES.CLIENT_ID_NOT_FOUND('Unknown Client ID'),
    },
    INTERNAL_ERROR: {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: ERROR_MESSAGES.UNKNOWN_ERROR,
    },
    INVALID_CLIENT_ID_PASSWORD: {
      statusCode: HttpStatus.UNAUTHORIZED,
      message: ERROR_MESSAGES.INVALID_CLIENT_ID_PASSWORD,
    },
    JWT_CREDENTIALS_NOT_FOUND: {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: ERROR_MESSAGES.JWT_CREDENTIALS_NOT_FOUND,
    },
    TOKEN_GENERATION_FAILED: {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: ERROR_MESSAGES.TOKEN_GENERATION_FAILED,
    },
    TOKEN_VERIFY_FAILED: {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: ERROR_MESSAGES.TOKEN_VERIFY_FAILED,
    },
  };

  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    const exceptionResponse =
      exception instanceof HttpException
        ? exception.getResponse()
        : exception.message;

    const errorKey =
      typeof exceptionResponse === 'string'
        ? exceptionResponse
        : exceptionResponse?.['key']; // Assume error key can be passed in exception response

    const errorDetails = this.errorMapping[errorKey] || {
      statusCode: status,
      message:
        typeof exceptionResponse === 'string'
          ? exceptionResponse
          : exceptionResponse?.['message'] || ERROR_MESSAGES.UNKNOWN_ERROR,
    };

    // Log the error
    this.logger.error(
      `Error occurred for request ${request.method} ${request.url}`,
      exception.stack,
    );

    // Send the response
    response.status(errorDetails.statusCode).json({
      success: false,
      statusCode: errorDetails.statusCode,
      error: errorDetails.message,
      timestamp: new Date().toISOString(),
      path: request.url,
    });
  }
}
