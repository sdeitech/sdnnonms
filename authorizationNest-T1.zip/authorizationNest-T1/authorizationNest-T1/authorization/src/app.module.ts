import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConsulService } from './consul/consul.service';
import { ConsulModule } from './consul/consul.module';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthorizationModule } from './authorization/authorization.module';
import { ConfigModule } from '@nestjs/config';
import { SmsService } from './sms/sms.service';
import { SmsModule } from './sms/sms.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Make it available throughout the app
    }),
    ConsulModule,
    MongooseModule.forRootAsync({
      imports: [ConsulModule],
      inject: [ConsulService],
      useFactory: async (consul: ConsulService) => {
        const mongoUri = await consul.getKey('mongodb/DATABASE_URL');
        // console.log('MongoDB URI:', mongoUri); // Log URI for debugging
        return {
          uri: mongoUri,
        };
      },
    }),

    AuthorizationModule,

    SmsModule,
  ],
  controllers: [AppController],
  providers: [AppService, ConsulService, SmsService],
})
export class AppModule {}
