import { Injectable, Logger } from '@nestjs/common';
import Twilio from 'twilio';
import { ConsulService } from 'src/consul/consul.service'; // Import your ConsulService

@Injectable()
export class SmsService {
  private twilioClient: Twilio.Twilio;
  private readonly logger = new Logger(SmsService.name);

  constructor(private readonly consulService: ConsulService) {
    this.initializeTwilioClient();
  }

  private async initializeTwilioClient() {
    try {
      // Fetch the Twilio credentials from Consul
      const sid = await this.consulService.getKey('twilio/sid');
      const authToken = await this.consulService.getKey('twilio/authToken');

      // Initialize the Twilio client with the fetched credentials
      this.twilioClient = Twilio(sid, authToken);

      // Log the successful initialization
      this.logger.log('Twilio client initialized successfully');
    } catch (error) {
      this.logger.error('Error initializing Twilio client', error);
      throw new Error('Failed to initialize Twilio client');
    }
  }

  async sendSms(mobileNumber: string, name: string): Promise<void> {
    const twilioPhoneNumber =
      await this.consulService.getKey('twilio/phoneNumber');
    try {
      // Ensure the phone number is in the correct format (E.164 format)
      const formattedNumber = mobileNumber.startsWith('+')
        ? mobileNumber
        : `+91${mobileNumber}`;

      const message = `Your mobile number ${mobileNumber} is registered with us, ${name}.`;

      // Send the SMS using the Twilio client
      await this.twilioClient.messages.create({
        body: message,
        from: twilioPhoneNumber, // Fetch the Twilio phone number from Consul
        to: formattedNumber, // The formatted mobile number
      });

      this.logger.log(`SMS sent to ${formattedNumber}`);
    } catch (error) {
      this.logger.error('Error sending SMS:', error);
      throw new Error('Failed to send SMS');
    }
  }
}
