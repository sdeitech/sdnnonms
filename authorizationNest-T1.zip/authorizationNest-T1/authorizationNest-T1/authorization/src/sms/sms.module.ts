import { Module } from '@nestjs/common';
import { SmsService } from './sms.service';
import { ConsulService } from 'src/consul/consul.service';

@Module({
  providers: [SmsService, ConsulService],
  exports: [SmsService], // Export SmsService so it can be used in other modules
})
export class SmsModule {}
