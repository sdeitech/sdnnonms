import {
  Controller,
  Post,
  Body,
  BadRequestException,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiResponse, ApiBody } from '@nestjs/swagger';
import { RegisterDto } from './dto/register.dto'; // Assuming RegisterDto is already defined
import { AuthorizationService } from './authorization.service';
import { ERROR_MESSAGES } from 'src/constants/constants';
import { TokenGenerationDto } from './dto/token.dto';
import { VerifyTokenDto } from './dto/verifytoken.dto';

@ApiTags('Authorization') // Swagger group tag
@Controller('authorization')
export class AuthorizationController {
  constructor(private readonly authorizationService: AuthorizationService) {}

  @Post('register')
  @ApiResponse({ status: 201, description: 'User registered successfully.' })
  @ApiResponse({ status: 400, description: 'Bad request, validation errors.' })
  @ApiBody({ type: RegisterDto }) // Use RegisterDto here
  async register(@Body() registerUserDto: RegisterDto) {
    return this.authorizationService.registerUser(registerUserDto);
  }

  @Post('tokengeneration')
  @ApiResponse({ status: 200, description: 'Token generated successfully.' })
  @ApiResponse({
    status: 500,
    description: 'Internal Server Error during token generation.',
  })
  @ApiBody({ type: TokenGenerationDto }) // Use TokenGenerationDto for the body
  async generateToken(@Body() body: TokenGenerationDto) {
    try {
      const token = await this.authorizationService.generateToken(body.clientId, body.password);
      return { token };
    } catch (error) {
      throw new HttpException(ERROR_MESSAGES.TOKEN_GENERATION_FAILED, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Post('verify-token')
  @ApiResponse({ status: 200, description: 'Token is valid.' })
  @ApiResponse({ status: 400, description: 'Token missing or invalid.' })
  @ApiResponse({
    status: 500,
    description: 'Internal Server Error during token verification.',
  })
  @ApiBody({ type: VerifyTokenDto }) // Use VerifyTokenDto for the body
  async verifyToken(@Body('token') token: string) {
    if (!token) {
      throw new BadRequestException(ERROR_MESSAGES.TOKEN_MISSING);
    }
    try {
      const isValid = await this.authorizationService.verifyToken(token);
      return { valid: isValid };
    } catch (error) {
      throw new HttpException(ERROR_MESSAGES.TOKEN_VERIFY_FAILED, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}
