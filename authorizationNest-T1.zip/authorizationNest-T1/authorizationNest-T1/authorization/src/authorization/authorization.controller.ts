import { Controller, Post, Body, BadRequestException } from '@nestjs/common';
import { ApiTags, ApiResponse, ApiBody } from '@nestjs/swagger';
import { RegisterDto } from './dto/register.dto';
import { AuthorizationService } from './authorization.service';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';
import { TokenGenerationDto } from './dto/token.dto';
import { VerifyTokenDto } from './dto/verifytoken.dto';

@ApiTags('Authorization')
@Controller('authorization')
export class AuthorizationController {
  constructor(private readonly authorizationService: AuthorizationService) {}

  @Post('register')
  @ApiResponse({ status: 201, description: SUCCESS_MESSAGES.USER_REGISTERED })
  @ApiResponse({ status: 400, description: ERROR_MESSAGES.VALIDATION_ERROR })
  @ApiBody({ type: RegisterDto })
  async register(@Body() registerUserDto: RegisterDto) {
    return this.authorizationService.registerUser(registerUserDto);
  }

  @Post('tokengeneration')
  @ApiResponse({ status: 200, description: SUCCESS_MESSAGES.TOKEN_GENERATED })
  @ApiResponse({
    status: 500,
    description: ERROR_MESSAGES.INTERNAL_ERROR_DURING_TOKEN,
  })
  @ApiBody({ type: TokenGenerationDto })
  async generateToken(@Body() body: TokenGenerationDto) {
    const token = await this.authorizationService.generateToken(
      body.clientId,
      body.password,
    );
    return { token };
  }

  @Post('verify-token')
  @ApiResponse({ status: 200, description: SUCCESS_MESSAGES.TOKEN_VALID })
  @ApiResponse({ status: 400, description: ERROR_MESSAGES.TOKEN_MISSING })
  @ApiResponse({
    status: 500,
    description: ERROR_MESSAGES.INTERNAL_ERROR_DURING_TOKEN,
  })
  @ApiBody({ type: VerifyTokenDto })
  async verifyToken(@Body('token') token: string) {
    if (!token) {
      throw new BadRequestException(ERROR_MESSAGES.TOKEN_MISSING);
    }
    const isValid = await this.authorizationService.verifyToken(token);
    return { valid: isValid };
  }
}
