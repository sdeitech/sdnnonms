import { ApiProperty } from '@nestjs/swagger';

export class TokenGenerationDto {
  @ApiProperty({
    description: 'The client ID for token generation',
    example: 'user123',
  })
  clientId: string;

  @ApiProperty({
    description: 'The password of the client for token generation',
    example: 123456,
  })
  password: string;
}
