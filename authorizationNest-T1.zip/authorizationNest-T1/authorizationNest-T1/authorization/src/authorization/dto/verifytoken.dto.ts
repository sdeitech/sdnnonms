import { ApiProperty } from '@nestjs/swagger';

export class VerifyTokenDto {
  @ApiProperty({
    description: 'The JWT token to be verified',
    example: 'some-jwt-token',
  })
  token: string;
}
