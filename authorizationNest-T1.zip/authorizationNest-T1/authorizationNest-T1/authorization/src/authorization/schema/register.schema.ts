import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { v4 as uuidv4 } from 'uuid';

@Schema()
export class User {
  @Prop()
  name: string;

  @Prop()
  email: string;

  @Prop()
  password: string;

  @Prop({
    unique: true,
    default: () => uuidv4(),
  })
  clientId: string;

  @Prop()
  mobileNumber: string; // Changed to number
}

export const UserSchema = SchemaFactory.createForClass(User);
