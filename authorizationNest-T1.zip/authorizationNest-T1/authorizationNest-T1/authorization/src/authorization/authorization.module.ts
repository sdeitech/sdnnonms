import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from './schema/register.schema';
import { AuthorizationController } from './authorization.controller';
import { AuthorizationService } from './authorization.service';
import { ConsulModule } from 'src/consul/consul.module';
import { JwtModule } from '@nestjs/jwt';
import { EmailService } from './email.service';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    JwtModule.register({}),
    ConsulModule,
  ],
  providers: [AuthorizationService, EmailService],
  controllers: [AuthorizationController],
})
export class AuthorizationModule {}
