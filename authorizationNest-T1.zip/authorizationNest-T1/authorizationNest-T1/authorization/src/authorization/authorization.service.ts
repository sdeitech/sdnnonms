import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './schema/register.schema';
import { RegisterDto } from './dto/register.dto';
import { JwtService } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';
import { EmailService } from './email.service';
import { SmsService } from 'src/sms/sms.service';

@Injectable()
export class AuthorizationService {
  private readonly logger = new Logger(AuthorizationService.name);

  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    private jwtService: JwtService,
    private consulService: ConsulService,
    private emailService: EmailService,
    private readonly smsService: SmsService,
  ) {}

  async registerUser(registerUserDto: RegisterDto): Promise<User> {
    // Map all fields from RegisterDto explicitly
    const newUser = new this.userModel({
      name: registerUserDto.name,
      email: registerUserDto.email,
      password: registerUserDto.password,
      mobileNumber: registerUserDto.mobileNumber, // Ensure mobileNumber is passed
    });

    this.logger.log(SUCCESS_MESSAGES.USER_REGISTERED);

    const savedUser = await newUser.save(); // Save the user to the database

    // Log to confirm SMS is being sent
    this.logger.log(`Sending SMS to ${savedUser.mobileNumber}...`);

    try {
      // Send SMS to the registered mobile number
      await this.smsService.sendSms(savedUser.mobileNumber, savedUser.name);
      this.logger.log(`SMS sent to ${savedUser.mobileNumber}`);
    } catch (error) {
      this.logger.error(
        `Error sending SMS to ${savedUser.mobileNumber}`,
        error,
      );
    }

    // Try to send email after SMS
    try {
      await this.emailService.sendEmail(savedUser.email, savedUser.clientId); // Send the email
      this.logger.log(`Email sent to ${savedUser.email} with clientId.`);
    } catch (error) {
      this.logger.error(ERROR_MESSAGES.ERROR_SENDING_EMAIL, error);
    }

    return savedUser; // Return the saved user, including mobileNumber
  }
  async generateToken(clientId: string, password: string): Promise<string> {
    try {
      const user = await this.userModel.findOne({ clientId }).exec();
      if (!user || user.password !== password) {
        throw { key: 'INVALID_CLIENT_ID_PASSWORD' }; // Let the filter handle this
      }

      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      const jwtExpiry = await this.consulService.getKey('EXPIRES_IN');

      if (!jwtSecret || !jwtExpiry) {
        throw { key: 'JWT_CREDENTIALS_NOT_FOUND' }; // Let the filter handle this
      }

      const payload = { clientId: user.clientId };
      const token = this.jwtService.sign(payload, {
        secret: jwtSecret,
        expiresIn: jwtExpiry,
      });

      this.logger.log(SUCCESS_MESSAGES.TOKEN_GENERATED);
      return token;
    } catch (error) {
      throw { key: 'TOKEN_GENERATION_FAILED' }; // Let the filter handle this
    }
  }

  async verifyToken(token: string): Promise<boolean> {
    try {
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      if (!jwtSecret) {
        throw { key: 'JWT_SECRET_NOT_FOUND' }; // Let the filter handle this
      }

      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw { key: 'TOKEN_INVALID' }; // Let the filter handle this
      }

      const user = await this.userModel
        .findOne({ clientId: decoded.clientId })
        .exec();
      if (!user) {
        throw { key: 'CLIENT_ID_NOT_FOUND' }; // Let the filter handle this
      }

      return true;
    } catch (error) {
      throw { key: 'TOKEN_VERIFY_FAILED' }; // Let the filter handle this
    }
  }
}
