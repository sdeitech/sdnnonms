import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './schema/register.schema';
import { RegisterDto } from './dto/register.dto';
import { JwtService } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';
import { EmailService } from './email.service';

@Injectable()
export class AuthorizationService {
  private readonly logger = new Logger(AuthorizationService.name);

  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    private jwtService: JwtService,
    private consulService: ConsulService,
    private emailService: EmailService,
  ) {}

  async registerUser(registerUserDto: RegisterDto): Promise<User> {
    const newUser = new this.userModel(registerUserDto);
    this.logger.log(SUCCESS_MESSAGES.USER_REGISTERED);
    const savedUser = await newUser.save();
    try {
      await this.emailService.sendEmail(savedUser.email, savedUser.clientId); // Send the email
      this.logger.log(`Email sent to ${savedUser.email} with clientId.`);
    } catch (error) {
      this.logger.error(ERROR_MESSAGES.ERROR_SENDING_EMAIL, error);
    }
    return savedUser; // Return raw object; interceptor handles wrapping
  }

  async generateToken(clientId: string, password: string): Promise<string> {
    try {
      const user = await this.userModel.findOne({ clientId }).exec();
      if (!user || user.password !== password) {
        this.logger.error(ERROR_MESSAGES.INVALID_CLIENT_ID_PASSWORD);
        throw new UnauthorizedException(
          ERROR_MESSAGES.INVALID_CLIENT_ID_PASSWORD,
        );
      }

      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      const jwtExpiry = await this.consulService.getKey('EXPIRES_IN');

      if (!jwtSecret || !jwtExpiry) {
        this.logger.error(ERROR_MESSAGES.JWT_CREDENTIALS_NOT_FOUND);
        throw new Error(ERROR_MESSAGES.JWT_CREDENTIALS_NOT_FOUND);
      }

      const payload = { clientId: user.clientId };
      const token = this.jwtService.sign(payload, {
        secret: jwtSecret,
        expiresIn: jwtExpiry,
      });

      this.logger.log(SUCCESS_MESSAGES.TOKEN_GENERATED);
      return token;
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error(ERROR_MESSAGES.TOKEN_GENERATION_FAILED, error.stack);
      } else {
        this.logger.error(ERROR_MESSAGES.TOKEN_GENERATION_FAILED);
      }
      throw new Error(ERROR_MESSAGES.TOKEN_GENERATION_FAILED);
    }
  }

  async verifyToken(token: string): Promise<boolean> {
    try {
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      if (!jwtSecret) {
        this.logger.error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
        throw new Error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
      }

      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        this.logger.error(ERROR_MESSAGES.TOKEN_INVALID);
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }

      const user = await this.userModel
        .findOne({ clientId: decoded.clientId })
        .exec();
      if (!user) {
        this.logger.error(ERROR_MESSAGES.CLIENT_ID_NOT_FOUND(decoded.clientId));
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }

      return true;
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error(ERROR_MESSAGES.TOKEN_VERIFY_FAILED, error.stack);
      } else {
        this.logger.error(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
      }
      throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
    }
  }
}
