import { Injectable, Logger } from '@nestjs/common';
import nodemailer from 'nodemailer';
import { ConsulService } from 'src/consul/consul.service';

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);

  constructor(private readonly consulService: ConsulService) {}

  private async getEmailCredentials(): Promise<{ user: string; pass: string }> {
    try {
      const user = await this.consulService.getKey('email/username');
      const pass = await this.consulService.getKey('email/password');
      return { user, pass };
    } catch (error) {
      this.logger.error('Failed to fetch email credentials from Consul', error);
      throw new Error('Unable to fetch email credentials');
    }
  }

  private async createTransporter(): Promise<nodemailer.Transporter> {
    const { user, pass } = await this.getEmailCredentials();

    return nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user,
        pass,
      },
    });
  }

  async sendEmail(to: string, clientId: string): Promise<void> {
    try {
      const transporter = await this.createTransporter();

      const mailOptions = {
        from: 'no-reply@yourdomain.com', // Use a no-reply email
        to, // Receiver address
        subject: 'Welcome to Our Service',
        text: `Hello! Your client ID is: ${clientId}`,
      };

      await transporter.sendMail(mailOptions);
      this.logger.log(`Email sent to ${to}`);
    } catch (error) {
      this.logger.error('Error sending email:', error);
      throw new Error('Email sending failed');
    }
  }
}
