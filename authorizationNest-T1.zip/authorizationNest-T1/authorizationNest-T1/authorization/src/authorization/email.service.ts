import { Injectable } from '@nestjs/common';
import nodemailer from 'nodemailer';

@Injectable()
export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    // Configure Nodemailer transport (using SMTP for example)
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'mdayank7786@gmail.com',
        pass: 'ekcnnsnkhupofcre',
      },
    });
  }

  async sendEmail(to: string, clientId: string): Promise<void> {
    const mailOptions = {
      from: 'mdayank7786@gmail.com',
      to, // Receiver address
      subject: 'Welcome to Our Service',
      text: `Hello! Your client ID is: ${clientId}`,
    };

    try {
      await this.transporter.sendMail(mailOptions);
    } catch (error) {
      console.error('Error sending email:', error);
      throw new Error('Email sending failed');
    }
  }
}
