import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConsulService } from './consul/consul.service';
import { ConsulModule } from './consul/consul.module';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthorizationModule } from './authorization/authorization.module';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Make it available throughout the app
    }),
    ConsulModule,
    MongooseModule.forRootAsync({
      imports: [ConsulModule],
      inject: [ConsulService],
      useFactory: async (consul: ConsulService) => {
        const mongoUri = await consul.getKey('mongodb/DATABASE_URL');
        // console.log('MongoDB URI:', mongoUri); // Log URI for debugging
        return {
          uri: mongoUri,
        };
      },
    }),

    AuthorizationModule,
  ],
  controllers: [AppController],
  providers: [AppService, ConsulService],
})
export class AppModule {}
