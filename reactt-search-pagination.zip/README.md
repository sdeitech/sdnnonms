### `npm install`

Run the above command to install the necessary packages for the project.
