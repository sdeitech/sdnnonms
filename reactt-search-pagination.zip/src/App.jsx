import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Records from './components/Records';
import Pagination from './components/Pagination';
import { records } from './data';

function App() {
    const [newdata, setData] = useState(records);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [recordsPerPage] = useState(10);

    // Uncomment this if you want to fetch data from a remote source
    // useEffect(() => {
    //     axios.get('MOCK_DATA.json')
    //         .then(res => {
    //             setData(res.data);
    //             setLoading(false);
    //         })
    //         .catch(() => {
    //             alert('There was an error while retrieving the data');
    //         });
    // }, []);

    const indexOfLastRecord = currentPage * recordsPerPage;
    const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
    const currentRecords = newdata.slice(indexOfFirstRecord, indexOfLastRecord);
    const nPages = Math.ceil(newdata.length / recordsPerPage);

    const handleSearch = (data) => {
        setSearch(data);
    };

    const filteredRecords = currentRecords.filter((data) =>
        data?.firstName.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className='container mt-5'>
            <h2>Simple Pagination Example in React</h2>
            <Records data={filteredRecords} search={search} handleSearch={handleSearch} />
            <Pagination
                nPages={nPages}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
            />
        </div>
    );
}

export default App;
