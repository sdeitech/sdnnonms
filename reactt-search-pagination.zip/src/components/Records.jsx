import React, { Fragment } from 'react';

const Records = ({ data, handleSearch, search }) => {
  return (
    <Fragment>
      <input
        value={search}
        onChange={(e) => handleSearch(e.target.value)} // Updated to pass the value correctly
        placeholder="Search by first name"
      />
      <table className="table">
        <thead>
          <tr>
            <th scope='col'>ID</th>
            <th scope='col'>First Name</th>
            <th scope='col'>Last Name</th>
            <th scope='col'>City</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}> {/* Added key prop */}
              <td>{item.id}</td>
              <td>{item.firstName}</td>
              <td>{item.lastName}</td>
              <td>{item.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Fragment>
  );
};

export default Records;
