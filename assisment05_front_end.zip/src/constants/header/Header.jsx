// import React from "react";
// import Icons from "../../assets/assets";
// import { useDispatch, useSelector } from "react-redux";
// import { logoutUser } from "../../context/Reducers/LoginUser";
// import { Link, useNavigate } from "react-router-dom";
// import toast, { Toaster } from "react-hot-toast";
// import { clearUsers, searchData } from "../../context/Reducers/userSlice";
// import { persistore } from "../../context/store"; // Corrected to persistore

// const Header = () => {
//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   const userData = useSelector((state) => state.userData?.userInfo);

//   const handleChange = (e) => {
//     clearTimeout(typingTimer);
//     const value = e.target.value;
//     typingTimer = setTimeout(() => {
//       dispatch(searchData(value));
//     }, 300); // Adjust the delay as needed
//   };

//   const handleLogout = () => {
//     toast.success("Logged Out");
//     setTimeout(() => {
//       persistore.purge(); // This will clear all persisted data
//       dispatch(logoutUser());
//       dispatch(clearUsers());
//       localStorage.clear();
//       navigate("/");
//     }, 1000);
//   };

//   return (
//     <div className="bg-gray-400 mt-0 flex flex-row justify-between px-6 py-4">
//       <div className="flex items-center gap-3">
//         <div>
//           <p>{userData?.firstName}</p>
//         </div>
//         <div className="h-10 rounded-md">
//           <input
//             type="text"
//             placeholder="Search user" // Fixed placeholder typo
//             name="search"
//             onChange={handleChange}
//             className="h-10 rounded-md w-60 px-2 focus:outline-none"
//           />
//         </div>
//       </div>
//       <div className="flex flex-row items-center justify-center gap-6">
//         <Link to={"/adduser"}>
//           <button>Add user</button>
//         </Link>
//         <Link to={"/profile"}>
//           <div className="rounded-full border-2 border-gray-900">
//             {!userData?.profile ? (
//               <div className="rounded-full h-10 w-10 border-2 border-gray-500 p-1">
//                 <img
//                   src={Icons.profile}
//                   alt="Profile"
//                   height={30}
//                   width={30}
//                   className="rounded-full h-full w-full object-cover"
//                 />
//               </div>
//             ) : (
//               <div className="rounded-full h-10 w-10 border-2 border-gray-500">
//                 <img
//                   src={`http://localhost:3002/get/profile/${userData.profile}`}
//                   alt="Profile"
//                   height={30}
//                   width={30}
//                   className="rounded-full h-full w-full object-cover"
//                 />
//               </div>
//             )}
//           </div>
//         </Link>
//         <button
//           className="bg-black text-white px-3 py-1 rounded-sm font-medium"
//           onClick={handleLogout}
//         >
//           Logout
//         </button>
//       </div>
//       <Toaster />
//     </div>
//   );
// };

// export default Header;

import React, { useState, useEffect, useRef, useContext } from "react";
import Icons from "../../assets/assets";
import { useDispatch, useSelector } from "react-redux";
import { logoutUser } from "../../context/Reducers/LoginUser";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import { clearUsers, searchData } from "../../context/Reducers/userSlice";
import { store, persistore } from "../../context/store";
import { userContext } from "../../context/AppContext/AppContext";

const Header = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { search, setSearch } = useContext(userContext)

  const userData = useSelector((state) => state.userData?.userInfo);

  const handleChange = (e) => {
    setSearch(e.target.value)
  };

  console.log(search, "from context search =============================>>>>>>>>>")

  const handleLogout = () => {
    toast.success("Logged Out");
    setTimeout(() => {
      persistore.purge();
      dispatch(logoutUser());
      dispatch(clearUsers());
      localStorage.clear();
      navigate("/");
    }, 1000);
  };

  return (
    <div className="bg-gray-400 mt-0 flex flex-row justify-between px-6 py-4">
      <div className="flex items-center gap-3 ">
        <div>
          <p>{userData?.firstName}</p>
        </div>
        <div className="h-10 rounded-md">
          <input
            type="text"
            placeholder="Search user"
            name="search"
            onChange={handleChange}
            className="h-10 rounded-md w-60 px-2 focus:outline-none"
          />
        </div>
      </div>
      <div className="flex flex-row items-center justify-center gap-6">
        <Link to={"/adduser"}>
          <div>
            <button>Add user</button>
          </div>
        </Link>
        <Link to={"/profile"}>
          <div className="rounded-full border-2 border-gray-900">
            {!userData?.profile ? (
              <div className="rounded-full h-10 w-10 border-2 border-gray-500 p-1">
                <img
                  src={Icons.profile}
                  alt=""
                  height={30}
                  width={30}
                  className="rounded-full h-full w-full object-cover"
                />
              </div>
            ) : (
              <div className="rounded-full h-10 w-10 border-2 border-gray-500">
                <img
                  src={`http://localhost:3002/get/profile/${userData.profile}`}
                  alt=""
                  height={30}
                  width={30}
                  className="rounded-full h-full w-full object-cover"
                />
              </div>
            )}
          </div>
        </Link>
        <div>
          <button
            className="bg-black text-white px-3 py-1 rounded-sm font-medium"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <Toaster />
    </div>
  );
};

export default Header;
