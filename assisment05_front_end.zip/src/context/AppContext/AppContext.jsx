import React, { createContext, useState } from 'react'

const userContext = createContext()

const AppContext = ({ children }) => {

    //pagination data 
    const [totalPage, setTotalPage] = useState(1)
    const [currPage, setCurrPage] = useState(1)
    const [search, setSearch] = useState("")

    // state to update state
    const [updateState, setUpdateState] = useState(false)

    const values = {
        search, setSearch
    }
    return (
        <userContext.Provider value={values}>{children}</userContext.Provider>
    )
}

export { AppContext, userContext }
