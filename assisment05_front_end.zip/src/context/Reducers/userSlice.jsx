import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "userData",
  initialState: {
    userInfo: null,
    subUsers: [],
    pagination: {
      totalPages: 1,
      pageNo: 1,
      search: "",
    },
  },
  reducers: {
    saveUserData: (state, action) => {
      console.log(action.payload, "payload from userslice");
      state.userInfo = action.payload.userInfo;
      state.subUsers = action.payload.subUsers;
      state.pagination = action.payload.pagination;
    },
    updateUserInfo: (state, action) => {
      state.userInfo = action.payload;
    },
    addSubUser: (state, action) => {
      state.subUsers.push(action.payload);
    },
    changePage: (state, action) => {
      console.log(action.payload, "from payload");
      state.pagination.pageNo = action.payload;
    },
    searchData: (state, action) => {
      console.log("dispaching earch");
      state.pagination.search = action.payload;
    },
    clearUsers: (state) => {
      state.userData = null;
      state.userInfo = null;
      state.subUsers = null;
      state.pagination = {
        totalPages: 1,
        pageNo: 1,
        search: "",
      };
    },
  },
});

export const {
  saveUserData,
  clearUsers,
  updateUserInfo,
  addSubUser,
  changePage,
  searchData,
} = userSlice.actions;
export default userSlice.reducer;
