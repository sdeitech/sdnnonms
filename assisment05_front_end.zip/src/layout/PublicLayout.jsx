import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const PublicLayout = ({ children }) => {
  // const navigate = useNavigate();
  // const token = useSelector((state) => state.loginUser?.token);

  // useEffect(() => {
  //   if (token) {
  //     navigate("/dashboard");
  //   }
  // }, [navigate, token]);
  return (
    <div>
      <div>{children}</div>
    </div>
  );
};

export default PublicLayout;
