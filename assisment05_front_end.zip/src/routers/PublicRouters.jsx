import React from "react";
import PublicLayout from "../layout/PublicLayout";
import SignIn from "../pages/SignIn";
import SignUp from "../pages/SignUp";
import ForgetPassword from "../pages/ForgetPassword";

const PublicRouters = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignUp />
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />
      </PublicLayout>
    ),
  },

  {
    path: "/forget",
    element: (
      <PublicLayout>
        <ForgetPassword />
      </PublicLayout>
    ),
  },
];

export default PublicRouters;
