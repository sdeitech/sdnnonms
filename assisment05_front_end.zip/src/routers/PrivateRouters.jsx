import React from "react";
import PrivateLayout from "../layout/PrivateLayout";
import Dashboard from "../pages/Dashboard";
import AddUser from "../pages/AddUser";
import UpdateUserProfile from "../pages/UpdateUserProfile";
import ChangePassword from "../pages/ChangePassword";

const PrivateRouters = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },

  {
    path: "/adduser",
    element: (
      <PrivateLayout>
        <AddUser />
      </PrivateLayout>
    ),
  },

  {
    path: "/profile",
    element: (
      <PrivateLayout>
        <UpdateUserProfile />
      </PrivateLayout>
    ),
  },

  {
    path: "/changepass",
    element: (
      <PrivateLayout>
        <ChangePassword />
      </PrivateLayout>
    ),
  },
];

export default PrivateRouters;
