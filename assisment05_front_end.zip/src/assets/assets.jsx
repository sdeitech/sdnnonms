import { CgProfile } from "react-icons/cg";
import { RxCross2 } from "react-icons/rx";
import { IoCaretBackSharp } from "react-icons/io5";
import profile from "../assets/images/default-profile.webp";
const Icons = {
  profile,
  crossIcon: RxCross2,
  profileIcon: CgProfile,
  back: IoCaretBackSharp
};

export default Icons;
