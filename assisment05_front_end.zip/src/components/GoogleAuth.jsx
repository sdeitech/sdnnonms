import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import axios from "axios";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { loginSuccess } from "../context/Reducers/LoginUser";

const clientId = `368841272750-bsgr39djulkqk32p6utco69sqsjj83mc.apps.googleusercontent.com`;

const GoogleAuth = () => {
  console.log(clientId);
  const dispatch = useDispatch()

  const navigate = useNavigate();

  const handleSubmit = async (response) => {
    const { credential } = response;
    console.log(response);
    try {
      const res = await axios.post("http://localhost:3002/api//google/auth", {
        token: credential,
      });
      dispatch(loginSuccess(res.data));

      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
    } catch (error) {
      console.log(error.message);
    }
    console.log(credential);
  };

  const handleErrro = (error) => {
    console.log(error.message);
  };
  return (
    <div>
      <GoogleOAuthProvider clientId={clientId}>
        <GoogleLogin onSuccess={handleSubmit} onError={handleErrro} />
      </GoogleOAuthProvider>
    </div>
  );
};

export default GoogleAuth;
