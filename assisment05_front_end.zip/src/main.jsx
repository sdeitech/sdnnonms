import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { store, persistore } from "./context/store.js";
import { AppContext } from "./context/AppContext/AppContext.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistore}>
        <AppContext>
          <App />
        </AppContext>
      </PersistGate>
    </Provider>
  </StrictMode>
);
