import axios from "axios";
import React, { useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveUserData } from "../context/Reducers/userSlice";
import { Card, Typography } from "@material-tailwind/react";
import Icons from "../assets/assets";
import PaginationRound from "./PaginationRound";
import { userContext } from "../context/AppContext/AppContext";
import DownloadCsv from "../components/DownloadCsv";
import UploadCsv from "../components/UploadCsv";
const TABLE_HEAD = ["Profile", "First Name", "Last Name", "Email", "Action"];

const Dashboard = () => {
  const uid = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);
  const { search } = useContext(userContext)

  const userData = useSelector((state) => state.userData.subUsers);
  const pagination = useSelector((state) => state.userData.pagination) || {}; // Default empty object to avoid errors
  const pageNo = pagination.pageNo || 1; // Default page number
  // const search = pagination.search || ""; // Default search term

  console.log(pagination, "76666666666666666666666666666666");

  const dispatch = useDispatch();

  // Fetch user data
  const fetchUser = async () => {
    try {
      const res = await axios.get(
        `http://localhost:3002/api/user/${uid}/?page=${pageNo}`,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      dispatch(saveUserData(res.data));
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const { handleFile, users } = UploadCsv()

  useEffect(() => {
    if (uid && pageNo) {
      fetchUser();
    }
  }, [uid, pageNo, users]);


  console.log(users, "dhgfdjsgfkbv hfewhfioeqwhj")

  return (
    <>
      <div className="h-96 mb-4">
        <div className=" float-end mx-10 flex gap-5 " >
          <label for="csv" className="bg-black text-white px-4 py-1 rounded-sm  cursor-pointer">Upload Csv</label>
          <div>
            <input type="file" accept=".csv" id="csv"
              style={{ display: "none" }}
              onChange={handleFile}
            />
          </div>

          <button onClick={() => {
            DownloadCsv(userData)
          }} className="bg-black text-white px-4 py-1 rounded-sm " >Download Csv</button>
        </div>
        <div className="w-5/6 mx-auto mt-8">
          <Card className="h-full w-full overflow-scroll">
            <table className="w-full min-w-max table-auto text-left">
              <thead>
                <tr>
                  {TABLE_HEAD.map((head) => (
                    <th
                      key={head}
                      className="border-b border-blue-gray-100 bg-blue-gray-50 p-4"
                    >
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal leading-none opacity-70"
                      >
                        {head}
                      </Typography>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {userData?.map(({ _id, firstName, lastName, email }) => (
                  <tr key={_id} className="even:bg-blue-gray-50/50">
                    <td className="p-4">
                      <img
                        src={Icons.profile}
                        alt="Profile"
                        height={40}
                        width={40}
                        className="rounded-full"
                      />
                    </td>
                    <td className="p-4">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {firstName}
                      </Typography>
                    </td>
                    <td className="p-4">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {lastName}
                      </Typography>
                    </td>
                    <td className="p-4">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {email}
                      </Typography>
                    </td>
                    <td className="p-4">
                      <Typography
                        as="a"
                        href="#"
                        variant="small"
                        color="blue-gray"
                        className="font-medium"
                      >
                        View
                      </Typography>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </div>
      </div >
      <div className="mx-28">
        <PaginationRound pagination={pagination} />
      </div>
    </>
  );
};

export default Dashboard;
