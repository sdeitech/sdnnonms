import * as React from "react";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { useDispatch } from "react-redux";
import { changePage } from "../context/Reducers/userSlice";

const PaginationRound = ({ pagination }) => {
  const dispatch = useDispatch();
  const handlePage = (event, page) => {
    dispatch(changePage(page));
  };
  return (
    <Stack spacing={2}>
      <Pagination
        count={pagination?.totalPages}
        page={pagination?.pageNo}
        onChange={handlePage}
        variant="outlined"
        shape="rounded"
      />
    </Stack>
  );
};

export default PaginationRound;
