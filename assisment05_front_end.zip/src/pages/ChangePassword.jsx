import React, { useEffect, useState } from "react";
import useForm from "../costomHooks/useForm";
import toast, { Toaster } from "react-hot-toast";
import axios from "axios";
import { useSelector } from "react-redux";

const ChangePassword = () => {
  const uid = useSelector((state) => state.loginUser?.userId);

  const changePasswordData = {
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
  };

  const [toastShown, setToastShown] = useState(false);
  const { formData, handleChange, resetForm } = useForm(changePasswordData);

  console.log(formData)

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (formData.newPassword !== formData.confirmNewPassword) {
      toast.error("New passwords do not match");
      return;
    }

    try {
      const res = await axios.put(
        `http://localhost:3002/api/update/password/${uid}`,
        {
          oldPassword: formData.currentPassword,
          newPassword: formData.newPassword
        }
      );
      console.log(res.data, "updated password")
      setToastShown(true);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
      toast.error("Failed to change password");
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Password changed successfully!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="border border-gray-300 py-10 px-6 rounded-2xl shadow-xl w-96 flex flex-col items-center mx-auto mt-20">
      <div className="text-2xl mb-6 ">
        <p>Change Password</p>
      </div>
      <form onSubmit={handleChangePassword} className="flex flex-col gap-5 ">
        <div className="border border-gray-400 rounded-md">
          <input
            type="password"
            name="currentPassword"
            onChange={handleChange}
            placeholder="Enter your current password"
            className="focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600"
          />
        </div>

        <div className="border border-gray-400 rounded-md">
          <input
            type="password"
            name="newPassword"
            onChange={handleChange}
            placeholder="Enter your new password"
            className="focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600"
          />
        </div>

        <div className="border border-gray-400 rounded-md">
          <input
            type="password"
            name="confirmNewPassword"
            onChange={handleChange}
            placeholder="Confirm your new password"
            className="focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600"
          />
        </div>

        <div className="text-white bg-black text-center px-4 py-2 rounded-md mx-auto">
          <button type="submit">Change Password</button>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default ChangePassword;
