import axios from "axios";
import React, { useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Icons from "../assets/assets";
import { addSubUser } from "../context/Reducers/userSlice";
import useForm from "../costomHooks/useForm";

const AddUser = () => {
  const dispatch = useDispatch();
  const id = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);
  const [updateState, setUpdateState] = useState(false);

  const addUserData = {
    firstName: "",
    lastName: "",
    email: "",
  };
  const { formData, handleChange, resetForm } = useForm(addUserData);

  console.log(formData);

  const handleAddUserSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/user/${id}`,
        formData,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      toast.success("user added ");
      setUpdateState(!updateState);
      dispatch(addSubUser(res.data.user));
      console.log(res.data, "user addeed");
      resetForm();
    } catch (error) {
      toast.error("failed to add user!");
      console.log(error);
    }
  };

  return (
    <div>
      <form onSubmit={handleAddUserSubmit}>
        <div className="w-96 border border-gray-200 shadow-lg p-4 flex flex-col  gap-6 items-center mx-auto mt-10 rounded-md ">
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="firstName"
              onChange={handleChange}
              placeholder="Enter your first name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
              required
            />
          </div>
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="lastName"
              onChange={handleChange}
              placeholder="Enter your last name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
              required
            />
          </div>
          <div className="border border-gray-400 rounded-md ">
            <input
              type="email"
              name="email"
              onChange={handleChange}
              placeholder="Enter your email"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
              required
            />
          </div>

          <div className="bg-black text-white px-4 py-2 rounded-md">
            <button type="submit">Add</button>
          </div>
          <Link to={"/dashboard"}>
            <div className="bg-gray-300 p-2 rounded-full">
              <Icons.crossIcon />
            </div>
          </Link>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default AddUser;
