const Validations = (formData) => {
  let errors = {};

  // First name validation
  if (!formData.firstName.trim()) {
    errors.firstName = "First name is required.";
  }

  // Last name validation
  if (!formData.lastName.trim()) {
    errors.lastName = "Last name is required.";
  }

  // Email validation
  if (!formData.email) {
    errors.email = "Email is required.";
  } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
    errors.email = "Email address is invalid.";
  }

  // Password validation
  if (!formData.password) {
    errors.password = "Password is required.";
  } else if (formData.password.length < 6) {
    errors.password = "Password must be at least 6 characters long.";
  }

  // Gender validation
  if (!formData.gender) {
    errors.gender = "Please select a gender.";
  }

  // Date of Birth validation
  if (!formData.DOB) {
    errors.DOB = "Date of birth is required.";
  }

  // Profile picture validation
  if (!formData.profile) {
    errors.profile = "Profile picture is required.";
  }

  // Return errors object
  return errors;
};

export default Validations;
