import { Radio } from "@material-tailwind/react";
import axios from "axios";
import React, { useEffect, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { updateUserInfo } from "../context/Reducers/userSlice";
import useForm from "../costomHooks/useForm";
import { Link, useNavigate } from "react-router-dom";
import Icons from "../assets/assets"

const UpdateUserProfile = () => {
  // const userData = useSelector((state) => state.userData?.userData?.user);
  const userData = useSelector((state) => state.userData.userInfo);

  const uid = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);

  const dispatch = useDispatch();

  const updateData = {
    firstName: userData?.firstName,
    lastName: userData?.lastName,
    email: userData?.email,
    gender: userData?.gender,
    isMarried: userData?.isMarried,
    DOB: userData?.DOB?.split("T")[0],
    profile: userData?.profile,
  };

  console.log(updateData.profile);

  const [toastShown, setToastShown] = useState(false);

  const { formData, previewImg, handleChange, resetForm } = useForm(updateData);

  console.log(formData, "update form data");

  const UpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put(
        `http://localhost:3002/api/update/${uid}`,
        formData,
        {
          headers: {
            Authorization: token,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      toast.success("Profile updated");
      dispatch(updateUserInfo(res.data?.userInfo));
      console.log(res.data, "response");
    } catch (error) {
      console.log(error, "update error");
    }
  };

  // console.log(userData?.google_img, "gogleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
  const googleImage = userData.google_img
  
  useEffect(() => {
    if (toastShown) {
      toast.success("Registration successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className=" py-10 px-6 rounded-2xl shadow-xl flex flex-col items-center mx-auto border border-gray-200 w-1/2 ">
      <div className="text-2xl mb-6">
        <p>Profile</p>
      </div>

      <div className="mb-6">
        {userData.profile ? (
          <div className="rounded-full h-20 w-20 border-2 border-gray-500 p-1">
            <img
              src={`http://localhost:3002/get/profile/${formData.profile}`}
              alt="Profile Preview"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        ) : (
          <div className="rounded-full h-20 w-20 border-2 border-gray-500 p-1">
            <img
              src={googleImage}
              alt="Default Profile"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        )}
      </div>

      <form onSubmit={UpdateProfile}>
        <div
          className="lg:grid lg:grid-cols-2 lg:grid-rows-4 lg:gap-4 
        md:flex md:flex-col md:gap-5 
        "
        >
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="firstName"
              onChange={handleChange}
              placeholder="Enter your first name"
              value={formData?.firstName}
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="lastName"
              onChange={handleChange}
              value={formData?.lastName}
              placeholder="Enter your last name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="email"
              onChange={handleChange}
              value={formData?.email}
              placeholder="Enter your email"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 gap-8">
            <Radio
              name="gender"
              label="Male"
              value="male"
              checked={formData.gender === "male"}
              onChange={handleChange}
            />
            <Radio
              name="gender"
              label="Female"
              value="female"
              checked={formData.gender === "female"}
              onChange={handleChange}
            />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 ">
            <input
              type="date"
              name="DOB"
              value={formData?.DOB}
              onChange={handleChange}
            />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 gap-6">
            <label>Is married ?</label>
            <input
              type="checkbox"
              name="isMarried"
              checked={formData.isMarried}
              onChange={handleChange}
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
            />
          </div>

          <div>
            <label
              htmlFor="profile"
              className="cursor-pointer bg-gray-300 px-4 py-2 rounded-md"
            >
              Upload Profile
            </label>
            <input
              type="file"
              id="profile"
              name="profile"
              onChange={handleChange}
              style={{ display: "none" }}
            />
          </div>
          {previewImg && (
            <a href={previewImg} target="_blank" className="text-blue-600">
              View Profile
            </a>
          )}
        </div>
        <Link to={"/changepass"}>
          <p className="text-black">chnage password</p>
        </Link>
        <div className="flex  flex-col items-center mt-4 gap-3">
          <div className=" text-white bg-black text-center py-2 w-28 rounded-md mx-auto">
            <button type="submit">Update</button>
          </div>
        </div>

        <Link to={"/dashboard"}>
          <p>Dashboard</p>
        </Link>
      </form>
      <Toaster />
    </div>
  );
};

export default UpdateUserProfile;
