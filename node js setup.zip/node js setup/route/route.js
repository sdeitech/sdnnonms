
import express from 'express';
import { uploadimage } from '../controllers/upload.js'; // Ensure the correct path
import { uploadMiddleware } from '../helper/multer2.js'; // Ensure the correct path

const fileuploadroute = express.Router();

fileuploadroute.post("/image", uploadMiddleware.single('image'), uploadimage);

export default fileuploadroute;
