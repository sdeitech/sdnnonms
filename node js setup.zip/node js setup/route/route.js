
import express from 'express';
import { uploadimage ,uploadMultipleImages} from '../controllers/upload.js'; // Ensure the correct path
import { uploadMiddleware } from '../helper/multer.js'; // Ensure the correct path

const fileuploadroute = express.Router();

fileuploadroute.post("/image", uploadMiddleware.single('image'), uploadimage);

fileuploadroute.post('/images', uploadMiddleware.array('images'), uploadMultipleImages);

export default fileuploadroute;
