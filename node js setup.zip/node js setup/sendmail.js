const nodemailer=require('nodemailer');

const transporter=nodemailer.createTransport({
    host:'smtp.gmail.com',
    port:587,
    secure:false,
    auth:{
        user:"dikshaladke12@gmail.com",
        pass:"xark rbut bdgt ihbc"
    }
});
async function main()
{
    const information=await transporter.sendMail({
        from:'<dikshaladke12@gmail.com',
        to:'dikshal.ce20@stvincentngp.edu.in,dikshaladke12@gmail.com,flfjdsfhsakdhfsadf',
        subject:'hello there !!',
        text:'hii this is diksha ladke',
        html:'<p>hii this is diksha ladke</p>'
    });
    // console.log("messagesend:%s",information.messageId);
    console.log(information);
    // console.log("messageEnvelope=%s",information.envelope);
    console.log("rejected Id :%s",information.rejected);

    
    console.log(response)
    
    
}
main().catch(console.error);