import multer from 'multer';
import path from 'path';
import {message} from '../config/constant';

const storage =multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,"new_images");
    },
    filename:function(req,file,cb){
        cb(Date.now);
    }
})

const fileFilter=(req,file,cb)=>
{
    const allowedTypes=["image.jpg","image.jpeg","image.png"];
    if(!allowedTypes.includes(file.mimetype))
    {
        console.log("image type is not allowed ")
        return cb(new Error(message.imageType));

    }
    cb(null,true);
}

export const uploadMiddleware=multer({
    storage:storage,
    filefilter:fileFilter,
    limit:{fileSize: 5*1024*1024}
});