//streams
import fs from 'fs';
import stream from 'stream';

/*
writable stream*/ 
const writestream=fs.createWriteStream("output.txt");
writestream.write("hellow this ir the writable stream");
writestream.e

   