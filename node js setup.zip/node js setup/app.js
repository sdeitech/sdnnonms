import express from "express";
import bodyParser from "body-parser";
import cors from "cors";

import fileuploadroute  from './route/route.js';

const app = express();

app.use(cors({ origin: "*" }));
// Middleware for parsing JSON (if needed)
app.use(express.json({ limit: "50mb" }));

app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));


//where file nedd to be submitted
app.use("/", express.static("profile_picture"));

app.use("/api",fileuploadroute)

export default app;

