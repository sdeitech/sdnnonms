
import fs from 'fs';
// fs.readFile('input.txt', { encoding: 'utf-8', flag: "r" }, function (error, data) {
//     if (error) {
//         return console.log("error while reading file..")
//     }
//     console.log(data);
// })


/**
 * writefile
 * / 
// fs.writeFile('input.txt',"this is the new data throgh writefile method",(error)=>{
//     if(error)
//     {
//         console.log("errorss")
//     }
// })



/**
 * file open
*/
// fs.open("input.txt",'w',function (error,data){
//     console.log("saved!!!")
//     fs.writeFile('input.txt',"fsdfjshfjsfhkasj",(error)=>{
//         console.log('errors');
//     })
// })


/**
 * Unlink
 */

// fs.unlink("./file/file.js",(error)=>{
//     if(!error)
//     {
//         return console.log('file deleted')
//     }
//     console.log("file not deleted");
// });

/**
 * truncate file*/

// fs.truncate("./file/file.txt",2,(error)=>{
//     if(!error)
//     {
//         return console.log("file truncated")
//     }
//     console.log("file is not truncated")
// })


/*
 fs stats
*/

// fs.stat('./file/file.txt',(error,stats)=>
// {
//     if(!error)
//     {
//         return console.log('this is the stats of the file',stats.isDirectory());
//     }
//     console.log("error");
// })


/**
 * fs.readdir*/

fs.readdir('./file',(error,files)=>{
    if(error)
    {
        return console.log(error,"errorss");
    }
    console.log(files)

})