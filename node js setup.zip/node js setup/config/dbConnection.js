import mongoose from 'mongoose'

require('dotenv/config');

const NODE_ENV ="local"; //local

const config = require('../config/config.js');

const configuration=config.config.NODE_ENV;

const MONGOURI = `mongodb://${configuration.DB.HOST}:${DB.PORT}/${DB.DATABASE}`;
console.log(MONGOURI, "MONGOURI");
const InitiateMongoServer = async () => {
    try {
        console.log(MONGOURI, "MONGOURI");
        mongoose.set('strictQuery', true);
        await mongoose.connect(MONGOURI, options);
        console.log("Connected to pharmacy DB !!", MONGOURI);
    } catch (e) {
        console.log(e);
        throw e;
    }
};

module.exports = InitiateMongoServer;
