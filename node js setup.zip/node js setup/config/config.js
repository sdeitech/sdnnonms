require('dotenv/config');

export const config = 
{
  "local": {
    DB: {
      HOST: "localhost",
      PORT: "27017",
      DATABASE: "test",
      USERNAME: "",
      PASSWORD: "",
    },
    apiPort: "4000"
  }
}


