require('dotenv/config');


export const messageID = {
"test":"dghd"
}
export const messages = {
    imageType:"dghd"

} 