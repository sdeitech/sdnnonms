// const { required } = require('joi');
// const mongoose = require('mongoose');

// const userSchema = new mongoose.Schema({
//     firstName : {type: String},
//     lastName : {type: String },
//     email: { type: String},
//     password: { type: String},
//     dob: { type: Date},
//     maritalStatus : {type: String},
//     gender : {type: String, enum : ["male", "female"]},
//     photo : {type: String,}
// });

// const User = mongoose.model('User', userSchema);

// module.exports = User;


const { required } = require('joi');
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    firstName : {type: String},
    lastName : {type: String },
    email: { type: String, unique : true},
    password: { type: String},
    dob: { type: Date},
    maritalStatus : {type: String},
    gender : {type: String, enum : ["male", "female"]},
    photo : {type: String,}
});

const User = mongoose.model('User', userSchema);

module.exports = User;