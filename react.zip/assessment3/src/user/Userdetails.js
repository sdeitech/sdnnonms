import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../Style/listing.css'
import { View } from './View';
// import Pagination from '@mui/material/Pagination';
// import Stack from '@mui/material/Stack';

import Paginate from './paginate';
// import TablePagination from '@mui/material/TablePagination';
export const Userdetails = () => {
    const [data, setData] = useState([]);
    const [viewDetails, setViewdetails] = useState(false);
    const [user, setUser] = useState(null);
    const [showProfile, setShowProfile] = useState(false); //to profile of the user
    const [showModal, setShowModal] = useState(false);
    const [searchValue, setSearchValue] = useState('');
    const navigate = useNavigate();


    // //for pagination
    const [dataPerPage, setDataperPage] = useState(5);
    const [currentPage, setCurrentPage] = useState(1);
    ///login use deatails
    const userData = localStorage.getItem("data");
    const newUserData = JSON.parse(userData);

    const fetchData = async () => {
        try {
            const response = await axios.get(`http://localhost:5000/users`);
            setData(response.data.Users);
            // console.log(response.data.Users, "dfsdf")

        } catch (error) {
            console.log("error")
        }
    }

    const totalPages = Math.ceil(data.length / dataPerPage);
    const startIndex = (currentPage - 1) * dataPerPage;
    const endIndex = startIndex + dataPerPage;
    const currentItems = data.slice(startIndex, endIndex);

    // const handleSearch = () => {
    //     if (searchValue === '') {
    //         setData(data);
    //         return;
    //     }
    //     const filterBysearch = currentItems.filter((item) => {
    //         if (item.toLowerCase().includes(searchValue.toLowerCase())) {
    //             return item;
    //         }
    //         setData(filterBysearch)
    //     })

    // }
    useEffect(() => {
        fetchData();
    });

    return (
        <div>
            <div className='table-content'>
                <div>Welcome {newUserData.firstName}!
                    <span style={{ float: 'right' }}
                        onClick={(e) => { setShowProfile(!showProfile) }}
                    >my porfile
                    </span>

                    <br></br>
                </div>
                {showProfile && navigate('/viewprofile')}
                <br></br>

                <div className="topnav">
                    <div className="search-container">
                         <input
                            type="search"
                            placeholder="Search.."
                            name="search"
                           // onChange={(e) => setSearchValue(e.target.value)}
                        />
                        {/* <button onClick={handleSearch}>search</button>  */}
                        <button variant="success" onClick={(e) => { setShowModal(true) }}> Add User</button>
                    </div>
                </div>
                <div className='content'>
                    <table className='striped bordered hover variant="dark"'>
                        <thead className='thead-dark'>
                            <tr>

                                <th>Sr. No.</th>
                                <th>First Name</th>
                                <th>Last Name </th>
                                <th>Email</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>{currentItems.map((value, index) =>
                            <tr key={index} >

                                <td>{index + 1}</td>
                                <td>{value.firstName}</td>
                                <td>{value.lastName}</td>
                                <td>{value.email}</td>
                                <td>
                                    <button onClick={(e) => {
                                        setViewdetails(true)
                                        setUser(value)
                                    }}>View</button>
                                </td>
                            </tr>)}
                        </tbody>
                    </table>
                    <Paginate 
                        totalPages={totalPages}
                        currentPage={currentPage}
                        setCurrentPage={setCurrentPage}
                    />
                    {viewDetails && <View data={user} show={viewDetails} />}
                </div>

                {showModal && navigate('/addsuser')}

            </div>

        </div>
    )
}
