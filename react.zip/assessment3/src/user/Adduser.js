import React, { useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom"

const Adduser = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        dob: '',
        password: '',
        gender: '',
        married: false,
        role: ''

    });

    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handlesubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/user/register', formData);
            console.log("registration successfull")
            alert(`registration successfull`);
            navigate('/userDetails');
        }
        catch (err) {
            setError('change password');
            console.log("not registered")
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    }

    return (
        <div>
            <div className="container login-container">
                <form className="login-form" onSubmit={handlesubmit}>
                    <h2 className="text-center">Add New User</h2>
                    <div className="form-group">
                        <label for="firstName">first Name:</label>
                        <input
                            type="text"
                            name="firstName"
                            className="form-control"
                            value={formData.firstName}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="lastName">Last Name:</label>
                        <input
                            type="text"
                            name="lastName"
                            className="form-control"
                            value={formData.lastName}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="email">Email:</label>
                        <input
                            type="email"
                            name="email"
                            className="form-control"
                            value={formData.email}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="dob">dob:</label>
                        <input
                            type="date"
                            name="dob"
                            className="form-control"
                            value={formData.dob}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="password">password:</label>
                        <input
                            type="password"
                            name="password"
                            className="form-control"
                            value={formData.password}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="gender">gender:</label>
                        <select
                            type="select"
                            name="gender"
                            className="form-control"
                            value={formData.gender}
                            onChange={handleChange}
                            error={error}
                        >
                            <option>male</option>
                            <option>female</option>
                            <option>other</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label for="married">married:</label>
                        <input
                            type="checkbox"
                            value={formData.married}
                            onChange={handleChange}
                        />
                    </div>

                    <div>
                        <lable>Role:</lable>
                        <input
                            type="text"
                            name="role"
                            className="form-control"
                            value={formData.role}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <br></br>
                    <button type="submit" className="btn btn-primary btn-block" variant="success">
                        add user
                    </button>&nbsp;
                    <div>
                        <span style={{ color: "red" }} onClick={() => navigate('/userdetails')}>back to dashboard</span>
                    </div>

                </form>
            </div>
        </div>
    );
};

export default Adduser;
