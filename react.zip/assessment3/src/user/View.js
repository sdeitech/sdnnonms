import React from 'react'

export const View = ({ data ,show}) => {
    return (
        <div>

            <table style={{ border: "1px solid black" }}>
                <h3 style={{alignContent:"center"}}>MY PROFILE</h3>
                <p>Name:{data.firstName} {data.lastName}</p>
                <p>DOB: {data.dob}</p>
                <p>Email: {data.email}</p>
                <p>Gender: {data.gender}</p>
            </table>
        </div>
    )
}
