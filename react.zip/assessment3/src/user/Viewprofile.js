import React from 'react'
import { useNavigate } from 'react-router-dom';

export const Viewprofile = () => {
    ///login use deatails
    const userData = localStorage.getItem("data");
    const newUserData = JSON.parse(userData);

    const navigate=useNavigate();

    return (
        <div>
            <div style={{ border: "1px solid black" }}>
                <h3 style={{ alignContent: "center" }}>MY PROFILE</h3>
                <p>Name:{newUserData.firstName} {newUserData.lastName}</p>
                <p>DOB:{newUserData.dob}</p>
                <p>Email:{newUserData.email}</p>
                <p>Gender:{newUserData.gender}</p>
                <div>
                    <button> Update </button>
                </div>
                <span onClick={(e)=>navigate('/userdetails')}><b>back to dashboard</b></span>
            </div>
        </div>
    )
}
