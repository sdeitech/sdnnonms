import React, { useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom"

const SignUp = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        dob: '',
        password: '',
        gender: '',
        image: '',
        married: false,
        role: ''
    });

    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const HandleImageChange = (e) => {
        const file = e.target.files[0];    
    }

    const handlesubmit = async (e) => {
        console.log(e);

        // console.log(e.target.value);
        
        e.preventDefault();
        //  const file = e.target.files[0];  
        const userData = new FormData();
        userData.append("firstName",formData.firstName)
        userData.append("lastName",formData.lastName)
        userData.append("email",formData.email)
        userData.append("dob",formData.dob)
        userData.append("password",formData.password)
        userData.append("gender",formData.gender)
        userData.append("married",formData.married)
        userData.append("role",formData.role)
        userData.append("image",formData.image);
        console.log(formData.image)
        console.log("userData___",userData);
        
        try {
            const response = await axios.post('http://localhost:5000/user/register',userData, {
                headers: {
                    "Content-Type": 'multipart/form-data'
                }
            });
            console.log("registration successfull")
            alert(`registration successfull`);
            navigate('/');
        }
        catch (err) {
            setError('change password');
            console.log("not registered")
        }
    };


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    }

    return (
        <div>
            <div className="container login-container">
                <form className="login-form" onSubmit={handlesubmit}>
                    <h2 className="text-center">Admin Registration</h2>
                    <div className="form-group">
                        <label for="firstName">first Name:</label>
                        <input
                            type="text"
                            name="firstName"
                            className="form-control"
                            value={formData.firstName}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="lastName">Last Name:</label>
                        <input
                            type="text"
                            name="lastName"
                            className="form-control"
                            value={formData.lastName}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="email">Email:</label>
                        <input
                            type="email"
                            name="email"
                            className="form-control"
                            value={formData.email}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="dob">dob:</label>
                        <input
                            type="date"
                            name="dob"
                            className="form-control"
                            value={formData.dob}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="password">password:</label>
                        <input
                            type="password"
                            name="password"
                            className="form-control"
                            value={formData.password}
                            onChange={handleChange}
                            error={error}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label for="gender">gender:</label>
                        <select
                            type="select"
                            name="gender"
                            className="form-control"
                            value={formData.gender}
                            onChange={handleChange}
                            error={error}
                        >
                            <option>male</option>
                            <option>female</option>
                            <option>other</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Image :</label>
                        <input
                            type='file'
                            onChange={HandleImageChange}
                        />

                    </div>
                    <div className="form-group">
                        <label for="married">married:</label>
                        <input
                            type="checkbox"
                            value={formData.married}
                            onChange={handleChange}
                        />
                    </div>

                    <div>
                        <lable>Role:</lable>
                        <input
                            type="text"
                            name="role"
                            className="form-control"
                            value={formData.role}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <br></br>
                    <button type="submit" className="btn btn-primary btn-block" variant="success">
                        Register
                    </button>&nbsp;
                    <div>
                        <span style={{ color: "red" }} onClick={() => navigate('/')}>Back to login</span>
                    </div>

                </form>
            </div>
        </div>
    );
};

export default SignUp;
