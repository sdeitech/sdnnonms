import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import '../Style/Signin.css'
import axios from 'axios'
export const Signin = () => {

    const [formData, setFromData] = useState({
        email: '',
        password: ''
    });

    const [show, setShow]=useState(false);
    const [Error, setError] = useState(null);
    const navigate=useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/user/login", formData);
            const { data } = response;
            localStorage.setItem("token", response.data.token);
            // console.log("data",response.data)
            //setUserDetails(response.data.User);
            localStorage.setItem("data",JSON.stringify(response.data.newUser));

            // console.log("response.data.newuser",response.data.newUser)
            console.log("login Success");
            navigate('/userdetails');

        }
        catch (error) {
            setError("Invalid Credentials ! please SignUp");
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFromData((prev) => ({
            ...prev, [name]: value
        }))
    }
    const handleSignUp=()=>
    {
        setShow(true);
        navigate('/signup')
    }
    return (
        <div className='conatainer form-data'>
            <div className='container login-container'>
                
                <form className='login-form' onSubmit={handleSubmit}>
                <h3>Admin Login</h3>

                    {Error && <p style={{ color: 'red' }}>{Error}</p>}

                    <div className='form-group'>
                        <label>Email:</label>
                        <input
                            className='form-control'
                            type="email"
                            name="email"
                            onChange={handleChange}
                            value={formData.email}
                            required
                        />
                    </div>
                    <br></br>
                    <div className='form-group'>
                        <label>Password:</label>
                        <input
                            className='form-control'
                            type="password"
                            name="password"
                            onChange={handleChange}
                            value={formData.password}
                            required
                        />
                    </div>
                    <br></br>
                    <div>
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                        >SignIn
                        </button> &nbsp;
                        <button
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={handleSignUp}
                        >
                            {show}SignUp
                        </button>
                    </div>
                </form>
            </div>

        </div>
    )
}
