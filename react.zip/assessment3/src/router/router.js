import privaterouter from "./privaterouter";
import publicrouter from "./publicrouter";
import {createBrowserRouter} from 'react-router-dom';
const router=createBrowserRouter([
    ...publicrouter,
    ...privaterouter,
])

export default router;