import react from 'react';
import { Publiclayout } from "../layout/Publiclayout";
import { Signin } from "../user/Signin.js";
import  SignUp  from '../user/Signup.js';
const publicrouter=[
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Signin/></Publiclayout>
    },
    {
        path:'/signup',
        exact:true,
        element:<Publiclayout><SignUp/></Publiclayout>
    }
]
export default publicrouter;