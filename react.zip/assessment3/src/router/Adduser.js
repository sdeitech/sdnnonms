import React from 'react'

export const Adduser = () => {
  return (
    <div>Adduser</div>
  )
}
