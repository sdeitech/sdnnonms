import react from 'react'
import { Privatelayout } from "../layout/Privatelayout";
import { Userdetails } from '../user/Userdetails';
import Adduser from '../user/Adduser';
import { Viewprofile } from '../user/Viewprofile';

const privaterouter=[
    {
        path:'/userdetails',
        exact:true,
        element:<Privatelayout><Userdetails/></Privatelayout>
    },
    {
        path:'/addsuser',
        exact:true,
        element:<Privatelayout><Adduser /></Privatelayout>
    }
    ,
    {
        path:'/viewprofile',
        exact:true,
        element:<Privatelayout><Viewprofile /></Privatelayout>
    }
]

export default privaterouter;