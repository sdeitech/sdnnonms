const express = require('express');
const bodyParser = require('body-parser');
const ProductRoutes = require('./routes/Productsroutes');
const cors = require('cors')
const db = require("./db/Productsdb");

const app = express();
const PORT = 4000;
app.use (cors())
app.use (bodyParser.json());
app.use ('/',ProductRoutes);
app.listen (PORT,() => {
    console.log(`Server is running on http://localhost:${PORT}`);
}
);