const express = require('express');
const router = express.Router();
const Productscontroller = require('../controller/Productscontroller');
console.log("your router file is getting ready");

// router.post('/api/product',Productscontroller.createProduct);
router.get('/api/product',Productscontroller.getProduct); 
// router.get('/api/product/:id',Productscontroller.getProductbyid);
// router.put('/api/product',Productscontroller.updateProduct);
// router.put('/api/product/:id',Productscontroller.updateProductbyid); 
// router.delete('/api/product/:id',Productscontroller.deleteProduct); 

module.exports = router;