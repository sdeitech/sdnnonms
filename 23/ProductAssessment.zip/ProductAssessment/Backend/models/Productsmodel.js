const mongoose = require('mongoose');
const ProductSchema = new mongoose.Schema({
    Name: { type: String, required: true },
    description: { type: String, required: true },
    Quantity: { type: Number , required: true},
    ExpiryDate: { type: String , required: true},
    Manufacturer: { type: String , required: true}
    }
);
console.log("your model is ready");

const products = mongoose.model('products', ProductSchema);
module.exports = products;