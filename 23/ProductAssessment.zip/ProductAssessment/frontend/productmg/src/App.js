// import './App.css';
import TextLinkExample from "./components/navbar"
import Example from './components/model';
function App() {
  return (
    <div className="App">
     <TextLinkExample/>
     <Example/>
    </div>
  );
}

export default App;
