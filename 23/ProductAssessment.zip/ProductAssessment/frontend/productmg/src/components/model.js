import { useState, useEffect } from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';

function Example() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const [Data, setData] = useState({
        name: "",
        description: "",
        quantity: "",
        expirydate: "",
        manufacturur: ""
    })
    const handleChange = (Data) => {
        const [ name, value ] = Data.target.value;
        setData({
            ...Data, [name]: value,
        })
    }

    //fetch data
    // const fetchData = async () => {
    //     try {
    //         const res = await axios.get("http://localhost:4000/api/product", { Data });
    //         // console.log(res);
    //         setData(res.Data)
    //     } catch (error) {
    //         setData([])
    //     }
    // }
    // useEffect(() => {
    //     fetchData();
    // }, []);

    const postDataHandler = async () => {
        try {
            const response = await axios.post('https://jsonplaceholder.typicode.com/posts',Data);

            // Append the new post to the existing data
            setData(prevData => [response.Data, ...Data]);
            // setPostError(null);
            // setPostContent(''); // Clear the input field
        } catch (error) {
            console.log("failed to post data");
        }
    };



    const handleShow = () => setShow(true);
    return (
        <>
            <Button variant="primary" onClick={handleShow}>
                Products management
            </Button>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Products</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                value={Data.name}
                                placeholder="Name"
                                autoFocus
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                        </Form.Group>
                    </Form>
                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                type="text"
                                autoFocus
                                value={Data.description}
                                placeholder="Describe about prouct"
                            // onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                        </Form.Group>
                    </Form>

                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Quantity</Form.Label>
                            <Form.Control
                                type="Number"
                                value={Data.quantity}
                                placeholder="0-9"
                                autoFocus
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                        </Form.Group>
                    </Form>

                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>ExpiryDate</Form.Label>
                            <Form.Control
                                type="Date"
                                value={Data.expirydate}
                                placeholder="DD-MM-YYY"
                                autoFocus
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                        </Form.Group>
                    </Form>

                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Manufacturer</Form.Label>
                            <Form.Control
                                type="Text"
                                value={Data.manufacturur}
                                placeholder="smart-data"
                                autoFocus
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                        </Form.Group>
                    </Form>


                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary"
                        onClick={postDataHandler}
                        type="text"
                        placeholder="Post title" >
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}
export default Example;