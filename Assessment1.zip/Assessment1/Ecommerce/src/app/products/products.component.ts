
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    const apiUrl = 'http://127.0.0.1:8000/products/';
    
    this.http.get<Product[]>(apiUrl).subscribe(
      (data) => {
        console.log(data);
        this.products = data;
      },
      (error) => {
        console.error('There was an error fetching the products!', error);
      }
    );
  }

  addToCart(product: Product) {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));

    Swal.fire({
      title: 'Added Successfully!',
      text: `Added ${product.name} to cart`,
      icon: 'success',
    });
  }

  getimagepath(path:string){
    return 'http://127.0.0.1:8000'+path
  }
}


// import { Component, OnInit } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import Swal from 'sweetalert2';

// interface Product {
//   id: number;
//   name: string;
//   price: number;
//   image: string;
// }

// @Component({
//   selector: 'app-products',
//   templateUrl: './products.component.html',
//   styleUrls: ['./products.component.css'],
// })
// export class ProductsComponent implements OnInit {
//   products: Product[] = [];
//   cart: Product[] = [];
//   totalPrice: number = 0;
//   discount: number = 0;  // Store the discount amount
//   couponCode: string = '';  // User input for coupon

//   constructor(private http: HttpClient) {}

//   ngOnInit(): void {
//     this.getProducts();
//     this.loadCart();  // Load cart from local storage when component initializes
//   }

//   getProducts(): void {
//     const apiUrl = 'http://127.0.0.1:8000/products/';
    
//     this.http.get<Product[]>(apiUrl).subscribe(
//       (data) => {
//         this.products = data;
//       },
//       (error) => {
//         console.error('There was an error fetching the products!', error);
//       }
//     );
//   }

//   addToCart(product: Product) {
//     this.cart.push(product);
//     localStorage.setItem('cart', JSON.stringify(this.cart));  // Save to local storage

//     this.calculateTotal();  // Recalculate total whenever a new product is added

//     Swal.fire({
//       title: 'Added Successfully!',
//       text: `Added ${product.name} to cart`,
//       icon: 'success',
//     });
//   }

//   loadCart() {
//     const savedCart = localStorage.getItem('cart');
//     if (savedCart) {
//       this.cart = JSON.parse(savedCart);
//       this.calculateTotal();  // Recalculate total when loading the cart
//     }
//   }

//   calculateTotal() {
//     this.totalPrice = this.cart.reduce((total, product) => total + product.price, 0);

//     // Apply discount if valid coupon is entered
//     if (this.discount > 0) {
//       this.totalPrice = this.totalPrice - this.discount;
//     }
//   }

//   applyCoupon() {
//     const validCoupons = ['DISCOUNT10'];  // Predefined valid coupon codes

//     if (validCoupons.includes(this.couponCode)) {
//       // Apply 10% discount
//       this.discount = this.totalPrice * 0.1;  // 10% of the total price
//       this.calculateTotal();  // Recalculate total with discount

//       Swal.fire({
//         title: 'Coupon Applied!',
//         text: 'You have received a 10% discount.',
//         icon: 'success',
//       });
//     } else {
//       // Show error if the coupon is invalid
//       Swal.fire({
//         title: 'Invalid Coupon',
//         text: 'The coupon code you entered is invalid.',
//         icon: 'error',
//       });
//     }
//   }
// }
