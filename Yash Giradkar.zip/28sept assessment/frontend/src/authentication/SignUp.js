import React, { useState } from 'react';
import axios from 'axios';
import styles from '../authentication/signUp.module.css'; // Updated import
import { useNavigate,Link } from 'react-router-dom';

const SignUp = () => {
    const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    dateofBirth: '',
    password: '',
    married: '',
    gender: '',
    });
    const [error, setError] = useState(null);
    const [formErrors, setFormErrors] = useState({});
    const navigate = useNavigate();

    const [checkbox, setCheckBox] = useState("");
    const [selectedOption, setSelectedOption] = useState('option1');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
        setFormErrors((prevErrors) => ({ ...prevErrors, [name]: null })); 
    };

    function onChangeValue(event) {
        setSelectedOption(event.target.value);
      }

    // const validateForm = () => {
    //     const errors = {};
    //     const {firstName, lastName, email, dateofBirth, password, married, gender} = formData;

    //     if (!firstName) {
    //         errors.firstName = 'Name is required';
    //     }
      
    //     if (!lastName) {
    //       errors.lastName = 'Last Name is required';
    //   }
      
    //   if (!dateofBirth) {
    //     errors.dateofBirth = 'date of birth is required';
    //   }
    //   if (!gender) {
    //     errors.gender = 'gender is required';
    //   }
    //   if (!married) {
    //     errors.married = 'married field is required';
    //   }
    //     if (!email) {
    //         errors.email = 'Email is required';
    //     } else if (!/\S+@\S+\.\S+/.test(email)) {
    //         errors.email = 'Email address is invalid';
    //     }
      
    //     if (!password) {
    //         errors.password = 'Password is required';
    //     } else if (password.length < 6) {
    //         errors.password = 'Password must be at least 6 characters';
    //     }
    //     return errors;
    // };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // const validationErrors = validateForm();
        // if (Object.keys(validationErrors).length > 0) {
        //     setFormErrors(validationErrors);
        //     return; 
        // }

        console.log('Form data:', formData);
        try {
            const response = await axios.post('http://localhost:5000/api/register', formData);
            console.log(formData, "register")
            localStorage.setItem('token', response.data.token);
            console.log("register", response.data)
            navigate('/dashboard');
        } catch (err) {
            setError('Login failed. Please try again.');
        }
    };

    return (
        <div className={styles.container}>
            <h2>Sign Up</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>First Name:</label>
                    <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                    />
                    {formErrors.firstName && <p style={{ color: 'red' }}>{formErrors.userName}</p>}
                </div>
                <div>
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleChange}
                        required
                    />
                    {formErrors.lastName && <p style={{ color: 'red' }}>{formErrors.lastName}</p>}
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    {formErrors.email && <p style={{ color: 'red' }}>{formErrors.email}</p>}
                </div>
                <div>
                    <label>Date of Birth:</label>
                    <input
                        type="date"
                        name="dateofBirth"
                        value={formData.dateofBirth}
                        onChange={handleChange}
                        required
                    />
                    {formErrors.dateofBirth && <p style={{ color: 'red' }}>{formErrors.dateofBirth}</p>}
                </div>
                
                
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                    {formErrors.password && <p style={{ color: 'red' }}>{formErrors.password}</p>}
                </div>
                <h1></h1>
                <div>
                    <label>Gender</label>
                    <div onChange={onChangeValue} value={formData.gender}>
                    <input type="radio" value="Male" name="gender" /> Male
                    <input type="radio" value="Female" name="gender" /> Female
                    <input type="radio" value="Other" name="gender" /> Other
                </div>
                    {/* {formErrors.gender && <p style={{ color: 'red' }}>{formErrors.gender}</p>} */}
                </div>
                <h1></h1>
                <div>
                    <label>Married</label>
                    <input type="checkbox" defaultChecked="true" value={formData.married} onChange={handleChange} />
                   
                </div>
                <h1></h1>
                <div>
                    
                </div>
                <button type="submit" >Sign Up</button>
                <div className="text-center">
                    Have an account? <Link to="/login">Login</Link>
                </div>
            </form>
        </div>
    );
};

export default SignUp;
