import {React} from "react";
import PublicLayout from "../layout/publicLayout";
import SignUp from '../authentication/SignUp'
import Login from "../authentication/Login";

const publicRoutes = [
    {
        path: "/login",
        exact: true,
        element: <PublicLayout><Login/></PublicLayout>
    },
    {
        path: "/",
        exact: true,
        element: <PublicLayout><SignUp/></PublicLayout>
    }
];
export default publicRoutes;