import {React } from "react"
import PrivateLayout from "../layout/privateLayout"
import Dashboard from "../components/dashboard";

const privateRoutes = [
    {
        path: "/dashboard",
        exact: true,
        element: <PrivateLayout><Dashboard/></PrivateLayout>
    },
];

export default privateRoutes;