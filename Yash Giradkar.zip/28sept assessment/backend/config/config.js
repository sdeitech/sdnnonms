import 'dotenv/config.js';

export const config = {
  DB: {
    HOST: process.env.MONGO_DB_HOST || "127.0.0.1",
    PORT: process.env.MONGO_DB_PORT || "27017",
    DATABASE: process.env.MONGO_DATABASE || "Profile",
  },
  PORT: process.env.PORT,
  
  JWT_SECRET: process.env.JWT_SECRET || "mysecretkey",

  NODE_ENV: process.env.NODE_ENV || "local",

};
