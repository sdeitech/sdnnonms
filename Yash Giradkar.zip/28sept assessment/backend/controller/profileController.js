const User = require('../model/user-Model')
const bcrypt = require("bcrypt");
import jwt from "jsonwebtoken";

const registerUser = async (req, res) => {
    try {
        const { firstName, email, password, lastName, married, gender, dateofBirth } = req.body;


        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            firstName: firstName,
            lastName: lastName,
            email: email,
            married: married,
            gender: gender,
            dateofBirth: dateofBirth,
            password: hashedPassword,
        });

        await user.save();
        res.status(201).json(user);
    } catch (error) {
        console.log(error);
        res.status(500).json({ Error: error.message });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (isMatch) {
            const token = jwt.sign({ email }, "an123idjk", { expiresIn: "8h" });

            return res.status(200).json({ message: "Logged In", token });
        } else {
            return res.status(401).json({ message: "Incorrect Credentials" });
        }
    } catch (error) {
        res.status(500).json({ Error: error.message });
    }
};

module.exports = { registerUser, loginUser };