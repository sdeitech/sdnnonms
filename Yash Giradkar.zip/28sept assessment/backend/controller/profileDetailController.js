
const User = require('../model/user-Model')

const createUser = async(req,res) => {
    try{
        const newUser = new User(req.body);
        await newUser.save();
        res.status(201).json(newUser);
    } catch(error){
        res.status(400).json({error: error.message});
    }
};

// const getUser = async(req,res) => {
  
//     try{
//         const user = await User.find();
//         res.json(user);
//     } catch (error){
//         res.status(400).json({error: error.message});
//     }
// }

//get user profile
const getUserId = async(req,res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ message: 'profile not found' });
        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getUser = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 8;
        const skip = (page - 1) * limit;

        const user = await User.find().skip(skip).limit(limit);
        const totalCount = await User.countDocuments();

        const response = {
            user: user,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit)
            }
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const updateUser = async(req,res) => {

    try{
        const user = await User.findByIdAndUpdate(req.params.id, req.body, {new: true});

        if(!user){
            return res.status(404).json({error: 'user not found'});
        }
        res.json(user);
    } catch(error){
        console.log(error,"error");
        res.status(400).json({error: error.message});
    }
}

const deleteUser = async(req,res) => {
    try{
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if(!deletedUser) return res.status(404).json({message: 'user not found'});
            res.status(204).send();
            res.status(200).json(response);
    } catch(error){
        res.status(500).json({message: error.message});
    }
}

module.exports = { createUser, getUser, getUserId, updateUser, deleteUser };