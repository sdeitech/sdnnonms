import React from 'react';
import Table from 'react-bootstrap/Table';

const ProductList = ({product, viewProduct, updateProduct, deleteProduct}) => {
    return (
        <div>
            <h2>Product List</h2>
            <Table striped>
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Description</th>
          <th>Quantity</th>
          <th>Expiry Date</th>
          <th>Manufacturer Name</th>
        </tr>
      </thead>
      <tbody>
        {product.length && product.map(product => (
            <tr key={product._id}>
                <td>{product.productName}</td>
                <td>{product.description}</td>
                <td>{product.quantity}</td>
                <td>{product.expiryDate}</td>
                <td>{product.manufacturerName}</td>
            <button onClick={() => viewProduct(product)}>View</button>
            <button onClick={() => updateProduct(product._id)}>Edit</button>
            <button onClick={() => deleteProduct(product._id)}>Delete</button>
            </tr>
        ))}
    </tbody>
    </Table>
        </div>
    );
};
export default ProductList;

