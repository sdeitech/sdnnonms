import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { addUser } from '../app/Slices'

const Form = () => {
    const dispatch = useDispatch()

    const [formData, setFormData] = useState({
        name: "",
        email: ""
    })
    const handleChange = (e) => {
        console.log(e.target)
        const { name, value } = e.target
        setFormData({ ...formData, [name]: value })
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(addUser(formData))
    }
    return (
        <div>
            <form onSubmit={handleSubmit} >

                <input type="text" name='name' onChange={handleChange} placeholder='enter name' />
                <input type="text" name='email' onChange={handleChange} placeholder='enter email' />
                <button type='submit'>submit</button>

            </form>
        </div>
    )
}

export default Form