import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { removeUser } from '../app/Slices'

const Listing = () => {
    const dispatch = useDispatch()
    const users = useSelector(state => state.listUsers.users)
    console.log(users)

    const handleDelete = (name) => {
        dispatch(removeUser(name))
    }
    return (
        <div>
            {
                users?.map((ele, i) => {
                    return (
                        <div key={i}>
                            <p>Name : {ele.name}</p>
                            <p>Email : {ele.email}</p>
                            <button onClick={() => {
                                handleDelete(ele.name)
                            }}>delete</button>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default Listing