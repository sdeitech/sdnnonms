import { configureStore } from "@reduxjs/toolkit"
import { listSlice } from "./Slices"

const store = configureStore({
    reducer: {
        listUsers: listSlice.reducer
    }
})

export default store