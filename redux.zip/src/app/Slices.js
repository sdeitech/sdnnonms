import { createSlice } from "@reduxjs/toolkit";


let initialState = {
    users: [],
    name: "demo user"
}

export const listSlice = createSlice({
    name: "listing",
    initialState: initialState,
    reducers: {
        addUser: (state, action) => {
            // state.users = [...state.users, action.payload]
            state.users.push(action.payload)
        },
        removeUser: (state, action) => {
            // state.users = state.users.filter(user => user.name !== action.payload)
            state.users.pop(action.payload)
        }

    }
})

export const { addUser, removeUser } = listSlice.actions
export default listSlice.reducer