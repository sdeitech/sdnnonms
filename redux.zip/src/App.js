import './App.css';
import Form from './components/Form';
import Listing from './components/Listing';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Form />
        <Listing />
      </header>
    </div>
  );
}

export default App;
