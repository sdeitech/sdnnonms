import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import store, { persistor } from './store/index'; // import persistor
import './index.css';
import App from './App';

ReactDOM.render(
  <Provider store={store}>
    {/* PersistGate delays the rendering of the app until rehydration is complete */}
    <PersistGate loading={null} persistor={persistor}>
      <App />
    </PersistGate>
  </Provider>,
  document.getElementById('root')
);
