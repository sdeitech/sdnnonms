import { useEffect, useState } from 'react';
import './App.css';
import MyForm from './components/Form';
import ProductDetail from './components/ProductDetail';
import ProductList from './components/ProductList';
import axios from 'axios';


function App() {
  const [product, setProduct] = useState([]);
  const [selector, setSelector] = useState(null);
  const [updateSelector, setUpdateSelector]= useState();

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchProduct = async() => {
    try{
      const response = await axios.get(`http://localhost:8080/api/product`);
      setProduct(response.data);
    } catch(error){
      console.error("error fetching data", error);
    }
  };

  // const addProduct = async(product) => {
  //   try{
  //     const response = await axios.post(`http://localhost:8080/api/product`,{
  //       productName: 'milton',
  //       description: 'this',
  //       quantity: 12,
  //       expiryDate: '12-02-2023',
  //       manufacturerName: 'milton pvt ltd'
  //     });
  //     setProduct(prevData => [response.data, ...data]);
  //     const data = await response.json();
  //     setProduct([...product,data]);
  //     window.location.reload()
  //   } catch(error){
  //     console.error('error fetching data', error);
  //   }
  // }

  const updateProduct = async(productId) => {
    try{
      const response = await axios.put(`http://localhost:8080/api/product/${productId}`);
      // fetchProduct()
      setProduct(prevData => prevData.map(product => (productId === updateProduct._id ? response.data : product)));
      console.log("update data", productId);
      console.log(updateProduct, "updated product");
      const updateProduct = product.map((product) => 
        productId === updateProduct.id ? updateProduct : product
    );
    setProduct(updateProduct);
    console.log(product, "testing update")
    setSelector(null);
    } catch(error){
      console.error('error updating data', error);
    }
  };

  const deleteProduct = async (productId) => {
    try {
      console.log(productId, "testing delete")
      await axios.delete(`http://localhost:8080/api/product/${productId}`);
      // setProduct(product.filter(product => product._id !== productId));
      // setProduct(deleteProduct);
      fetchProduct()
      
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

    return (
      <div>
          <MyForm/>
    
      <ProductList product={product} viewProduct={setSelector} updateProduct={updateProduct} deleteProduct={deleteProduct} />
      {selector ? (
        <div>
        <div>
        <ProductDetail product={selector}/></div>
        </div>
      ) : null}
    </div>
    );
}

export default App;