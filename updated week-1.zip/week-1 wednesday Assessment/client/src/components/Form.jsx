import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input,FormGroup, Row, Col} from 'reactstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
// import ProductList from "./ProductList";
// import validateUser from "../constant/validation";

function MyForm() {
  const [errors, setErrors] = useState({});
  const [FormData, setFormData] = useState({
    productName: '',
    description: '',
    quantity: '',
    expiryDate: '',
    manufacturerName: ''
  });
  const [product, setProduct] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editProduct, setEditProduct] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if(isEditing){
          try{
            const response = await axios.put(`http://localhost:8080/api/product/${editProduct}`, FormData);
            console.log(FormData, "updated form")
            setProduct(product.map(product => (product._id === editProduct ? response.data : product)));
            setIsEditing(false);
            setEditProduct(null);
            setFormData({productName: '', description: '', quantity: '', expiryDate: '', manufacturerName: ''});
          } catch(error){
            console.error("error updating", error);
          }
        } else{
          try{
            const response = await axios.post(`http://localhost:8080/api/product`,FormData);
            setProduct(prevProduct => [...prevProduct, response.data]);
            setFormData({productName: '', description: '', quantity: '', expiryDate: '', manufacturerName: ''});
          } catch(error){
            console.error("erro adding user", error);
          }
        }
    };

    const handleEdit = (product) => {
      setIsEditing(true);
      setEditProduct(product._id);
      setFormData({
            productName: product.productName,
            description: product.description,
            quantity: product.quantity,
            expiryDate: product.expiryDate,
            manufacturerName: product.manufacturerName
        });
    };

    const handleInputChange =(e) => {
      const {name, value} = e.target;
      setFormData({
          ...FormData,
          [name]: value,
      });
  };

    return (        
        <div>
            <h1>Product Registration Form</h1>
          <Form onSubmit={handleSubmit}>
  <Row>
    <Col md={6}>
      <FormGroup>
        <Label for="Productname">
          Product Name
        </Label>
        {errors.productName && <p className="error">{errors.productName}</p>}
        <Input
          id="productName"
          name="productName"
          placeholder="Enter your Product Name"
          value={FormData.productName}
          onChange={handleInputChange}
          type="text"
          required
          // {...errors.name && <p className="error">{errors.name}</p>}
        />
      </FormGroup>
    </Col>
    <Col md={6}>
      <FormGroup>
        <Label for="description">
          Description
        </Label>
        {errors.description && <p className="error">{errors.description}</p>}

        <Input
          id="description"
          name="description"
          placeholder="Enter Description"
          value={FormData.description}
          onChange={handleInputChange}
          type="text"
        />
      </FormGroup>
    </Col>
  </Row>
  <Row>
    <Col md={6}>
    <FormGroup>
    <Label for="quantity">
      Quantity
    </Label>
    {errors.quantity && <p className="error">{errors.quantity}</p>}

    <Input
      id="quantity"
      name="quantity"
      placeholder="Enter Quantity"
      value={FormData.quantity}
      onChange={handleInputChange}
      type="number"
    />
  </FormGroup>
      <FormGroup>
        <Label for="expiryDate">
          Expiry Date
        </Label>
        {errors.expiryDate && <p className="error">{errors.expiryDate}</p>}

        <Input
          id="expiryDate"
          name="expiryDate"
          placeholder="Enter Expiry Date"
          value={FormData.expiryDate}
          onChange={handleInputChange}
          type="date"
        />
      </FormGroup>
    </Col>
    <Col md={4}>
      <FormGroup>
        <Label for="manufacturerName">
          Manufacturer Name
        </Label>
        {errors.manufacturerName&& <p className="error">{errors.manufacturerName}</p>}

        <Input
          id="manufacturerName"
          name="manufacturerName"
          placeholder="Enter Manufacturer Name"
          value={FormData.manufacturerName}
          onChange={handleInputChange}
        />
      </FormGroup>
    </Col>
  </Row>

  <Button type="submit">{isEditing ? 'Update Product' : 'Add Product'}</Button>
</Form>
</div>
    );
}

export default MyForm;


