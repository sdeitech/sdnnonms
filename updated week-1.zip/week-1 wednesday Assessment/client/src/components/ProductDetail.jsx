import React from 'react';

const ProductDetail = ({ product }) => {
  return (
    <div>
      <h2>Product Detail</h2>
      <p>Product Name: {product.productName}</p>
      <p>Description: {product.description}</p>
      <p>Quantity: {product.quantity}</p>
      <p>Expiry Date: {product.expiryDate}</p>
      <p>Manufacturer Name: {product.manufacturerName}</p>
    
    </div>
  );
};

export default ProductDetail;