const express = require('express');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/product.route');
const database = require('./database');
const port = 8080;
const app = express();
const cors = require('cors');

app.use(cors({origin: "*"}));
app.use(bodyParser.json());
app.use('/api', productRoutes);

app.listen(port,() => {
    console.log(`server is running on ${port}`);
});