const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false');

const database = mongoose.connection;
database.on('errot',console.error.bind(console, 'connection error'));
database.once('open',() => {
    console.log('connected successfully');
});

module.exports = database;