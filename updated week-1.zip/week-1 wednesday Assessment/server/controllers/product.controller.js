const Product = require('../models/product.model');
var mongoose = require('mongoose');

exports.createProduct = async(req,res) => {
    try{
        const newproduct = new Product(req.body);
        await newproduct.save();
        res.status(201).json(newproduct);
    } catch(error){
        res.status(400).json({error: error.message});
    }
};

exports.getProduct = async(req,res) => {
    try{
        const newproduct = await Product.find();
        await res.json(newproduct);
    } catch(error){
        res.status(400).json({error: error.message});
    }
};

exports.getProductById = async(req,res) => {
    try{
        const newproduct = Product.findById(req.params.id);
        console.log(req.params.id,"this is req");
        console.log(res.params.id, "this is response");

        await res.json(newproduct);
    } catch(error){
        res.status(400).json({error: error.message});
    }
};

exports.updateProduct = async(req,res) => {

    try{
        console.log(req.params, "this is response");
        // console.log(updateProduct, "updated product");
        // console.log(res.params.id,"id updated")
        const newproduct = await Product.findByIdAndUpdate(req.params.id, req.body, {new: true});
       
   

        if(!newproduct){
            return res.status(404).json({error: 'item not found'});
        }
        res.json(newproduct);
    } catch(error){
        console.log(error,"error");
        res.status(400).json({error: error.message});
    }
}

exports.deleteProduct = async(req,res) => {
    try{
        const newproduct = await Product.findByIdAndDelete(req.params.id);

        if(!newproduct){
            return res.status(404).json({error:'item not found'});
        }
        res.json({message: 'item deleted'});
    } catch(error){
        console.log("error",error)
        res.status(400).json({error: error.message});
    }
};