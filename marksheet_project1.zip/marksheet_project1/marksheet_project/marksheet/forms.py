from django import forms
from .models import Subject

class SubjectForm(forms.ModelForm):
    class Meta:
        model=Subject
        fields=['name','theory_marks','internal_marks'] 
        # author = models.ForeignKey(Subject, on_delete=models.CASCADE)
        