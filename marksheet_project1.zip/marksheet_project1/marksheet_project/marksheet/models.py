# from django.db import models

# # Create your models here.
# class Subject(models.Model):
   
#     name=models.CharField(max_length=100)
#     theory_marks=models.IntegerField(default=0)
#     internal_marks=models.IntegerField(default=0)
    
#     def total_marks(self):
#         return self.theory_marks+self.internal_marks
    
#     def is_pass(self):
#         return self.total_marks()>=35
#     def __str__(self):
#         return self.name
# class StudentInfo(models.Model):
#     student_name=models.CharField(max_length=50,default=True)
#     last_name=models.CharField(max_length=50,default=True)
#     roll_no=models.IntegerField(max_length=20,default=True)
#     subjects = models.ManyToManyField(Subject)  # Link to multiple subjects

#     def __str__(self):
#         return f"{self.student_name} {self.last_name} (Roll No: {self.roll_no})"
    
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
from django.db import models
from django import forms

# Create your models here.
class Subject(models.Model):
    name = models.CharField(max_length=100)
    theory_marks = models.IntegerField(default=0)
    internal_marks = models.IntegerField(default=0)

    def total_marks(self):
        return self.theory_marks + self.internal_marks

    def is_pass(self):
        return self.total_marks() >= 35

    def __str__(self):
        return self.name


class StudentInfo(models.Model):
    student_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    roll_no = models.IntegerField()  # Removed max_length as it's not valid for IntegerField
    subjects = models.ManyToManyField(Subject)  # Link to multiple subjects

    def __str__(self):
        return f"{self.student_name} {self.last_name} (Roll No: {self.roll_no})"


# Form classes for input
class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ['name', 'theory_marks', 'internal_marks']


class StudentInfoForm(forms.ModelForm):
    class Meta:
        model = StudentInfo
        fields = ['student_name', 'last_name', 'roll_no', 'subjects']  # Include subjects for selection

                 
        