from django.contrib import admin

# # Register your models here.
# # from django.contrib import admin
# from .models import StudentInfo, Subject

# # Register the models with custom admin
# class SubjectInline(admin.TabularInline):
#     model = StudentInfo.subjects.through  # Through relationship for ManyToMany field

# class StudentInfoAdmin(admin.ModelAdmin):
#     list_display = ('student_name', 'last_name', 'roll_no')
#     inlines = [SubjectInline]  # Inline subjects under StudentInfo

# class SubjectAdmin(admin.ModelAdmin):
#     list_display = ('name', 'theory_marks', 'internal_marks', 'total_marks', 'is_pass')

# admin.site.register(StudentInfo, StudentInfoAdmin)
# admin.site.register(Subject, SubjectAdmin)