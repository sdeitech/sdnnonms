# from django.shortcuts import render,redirect
# # from .forms import SubjectForm
# from .models import Subject,StudentInfo

# # Create your views here.

# def input_marks(request):
#     if request.method=='POST':
#         Subject.objects.all().delete()
#         data = request.POST
#         # student_name=data.getlist('Student_Name')
#         # last_name=data.getlist('Student_LastName')
#         # roll_no=data.getlist('Roll_No')
#         name=data.getlist('subject')
#         theory_marks=data.getlist('theory')
#         internal_marks=data.getlist('internal')
        
#         # print("student_name",student_name)
#         # print("last_name",last_name)
#         # print("roll_no",roll_no)
#         print("name",name)
#         print("theory_marks",theory_marks)
#         print("internal_marks",internal_marks)
#         for sub,th,inter in zip(name,theory_marks,internal_marks):
        
#             newuser =Subject(    
#             name=sub,
#             theory_marks=th,
#             internal_marks=inter
#         )
#             print(newuser,"hhhhhhhhhhhhhh")
#             newuser.save()
     

#         return redirect('marksheet')
#     else:
#          return render(request,"input_marks.html")    

# def display_marksheet(request):
#     subjects=Subject.objects.all()
#     students=StudentInfo.objects.all()
#     total_marks=sum(subject.total_marks() for subject in subjects)
#     max_marks=len(subjects)*100
#     overall_pass=all(subject.is_pass() for subject in subjects)
#     percentage=(total_marks/300)*100
#     return render(request,"displaymarksheet.html",{
#         'students':students,
#         'subjects':subjects,
#         'total_marks':total_marks,
#         'max_marks':max_marks,
#         'overall_pass':overall_pass,
#         "percentage":percentage
#     })

from django.shortcuts import render, redirect
from .models import Subject, StudentInfo

# View to handle input of student info and marks
def input_marks(request):
    if request.method == 'POST':
        # Clearing out the previous subjects (optional, depending on use case)
        Subject.objects.all().delete()

        # Get student details from form data
        student_name = request.POST.get('Student_Name')
        last_name = request.POST.get('Student_LastName')
        roll_no = request.POST.get('Roll_No')

        # Create a new student entry
        student = StudentInfo.objects.create(
            student_name=student_name,
            last_name=last_name,
            roll_no=roll_no
        )

        # Get subject details from form data
        subject_names = request.POST.getlist('subject')
        theory_marks = request.POST.getlist('theory')
        internal_marks = request.POST.getlist('internal')

        # Loop through subjects and create associated subjects
        for name, theory, internal in zip(subject_names, theory_marks, internal_marks):
            subject = Subject.objects.create(
                name=name,
                theory_marks=theory,
                internal_marks=internal
            )

            # Add the subject to the student
            student.subjects.add(subject)

        return redirect('marksheet')  # Redirect to marksheet after saving
    else:
        return render(request, "input_marks.html")

# View to display marksheet
def display_marksheet(request):
    # Assuming you want to display marks for the most recently added student
    student = StudentInfo.objects.last()  # Get the most recent student

    # If there's no student data yet
    if not student:
        return render(request, "displaymarksheet.html", {
            'students': [],
            'subjects': [],
            'total_marks': 0,
            'max_marks': 0,
            'overall_pass': False,
            "percentage": 0
        })

    subjects = student.subjects.all()
    total_marks = sum(subject.total_marks() for subject in subjects)
    max_marks = len(subjects) * 100  # Assuming max 100 per subject
    overall_pass = all(subject.is_pass() for subject in subjects)
    percentage = (total_marks / max_marks) * 100 if max_marks > 0 else 0

    return render(request, "displaymarksheet.html", {
        'student': student,
        'subjects': subjects,
        'total_marks': total_marks,
        'max_marks': max_marks,
        'overall_pass': overall_pass,
        "percentage": percentage
    })
   