import { Button } from "react-bootstrap";
import TableView from "./Tableviewdata";

const Dashboard = () => {
  return (
    <>
      <div>
        <Button>Add User</Button>
      </div>
      <div>
        <TableView />
      </div>
    </>
  );
};

export default Dashboard;