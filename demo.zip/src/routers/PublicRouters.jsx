import React from 'react'

const PublicRouters = [
    {}
]

export default PublicRouters