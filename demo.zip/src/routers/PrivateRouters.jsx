import React from 'react'

const PrivateRouters = [
    {}
]

export default PrivateRouters