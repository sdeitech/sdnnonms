import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Footer from '../constants/footer/Footer'

const PrivateLayout = ({ children }) => {
    const navigate = useNavigate()
    const token = localStorage.getItem("token")
    useEffect(() => {
        if (!token) {
            navigate("/dashboard")
        }
    }, [navigate, token])
    return (
        <div>
            <Headers />
            <div>
                {children}
            </div>
            <Footer />
        </div>
    )
}

export default PrivateLayout