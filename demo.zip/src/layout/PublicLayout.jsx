import React from 'react'

const PublicLayout = ({ children }) => {
    return (
        <div>
            <div>
                {children}
            </div>
        </div>
    )
}

export default PublicLayout