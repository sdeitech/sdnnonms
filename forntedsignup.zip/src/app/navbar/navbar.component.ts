import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavComponent implements OnInit {
  cartItemsCount: number = 0;
  isLoggedIn: boolean = false;

  constructor(private cartService: CartService, private authService: AuthService) {}

  cartCount: number = 0;

  ngOnInit(): void {
    this.cartService.getCartCount().subscribe(count => {
      this.cartCount = count;
    });
    this.isLoggedIn = this.authService.isAuthenticated();
  }

  navigateToCart(): void {
    if (!this.authService.isAuthenticated()) {
      Swal.fire({
        title: 'Not Logged In',
        text: 'Please log in to access the cart.',
        icon: 'warning',
        confirmButtonText: 'Login',
      }).then(() => {
        window.location.href = '/login'; // Redirect to login page
      });
    } else {
      window.location.href = '/cart'; // Redirect to cart page
    }
  }

  logout(): void {
    this.authService.logout();
    this.isLoggedIn = false;
  }
}
