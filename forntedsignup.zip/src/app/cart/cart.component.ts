import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent {
  cartItems: any[] = [];
  totalPrice: number = 0;
  cartCount: number = 0;


couponCode: string = '';
couponMessage: string = '';

applyCoupon() {
  if (this.couponCode === 'DISCOUNT10') {
    this.totalPrice *= 0.9; 
    this.couponMessage = 'Coupon applied successfully!';
  } else {
    this.couponMessage = 'Invalid coupon code.';
  }
}



  constructor(private cartservice:CartService) {
    this.fetchData();
    this.fetchTotal();
    this.cartservice.getCartCount().subscribe(count => {
      this.cartCount = count;
    });
  }

  fetchData = () => {
    this.cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
    console.log(this.cartItems, 'cart data is ');
  };

  fetchTotal = () => {
    this.totalPrice = this.cartItems.reduce((acc, item) => {
      return acc + item.price * item.quantity;
    }, 0);
  };

  checkout = () => {};

  removeItem = (item: any) => {
    console.log('removing item');
    let data = this.cartItems.filter((p) => p.id != item.id);
    let temp = JSON.stringify(data);
    localStorage.setItem('cart', temp);
    console.log(data, 'data');
    this.fetchData();
    console.log(this.cartItems);
    this.fetchTotal();

    const newCartCount = this.cartCount - 1;
    this.cartservice.updateCartCount(newCartCount);
  };

  increaseQuantity = (item: any) => {
    let idx = this.cartItems.findIndex((p) => p.id === item.id);
    console.log(idx);
    this.cartItems[idx].quantity += 1;
    let data = JSON.stringify(this.cartItems);
    localStorage.setItem('cart', data);
    this.fetchTotal();
  };

  decreaseQuantity = (item: any) => {
    let idx = this.cartItems.findIndex((p) => p.id === item.id);
    console.log(idx);

    if (this.cartItems[idx].quantity === 1) {
      this.cartItems.splice(idx, 1);
      let data = JSON.stringify(this.cartItems);
      localStorage.setItem('cart', data);
      this.fetchTotal();
    }

    this.cartItems[idx].quantity -= 1;
    let data = JSON.stringify(this.cartItems);
    localStorage.setItem('cart', data);
    this.fetchTotal();
  };
}
