import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignupComponent {
  first_name: string = '';
  last_name: string = '';
  address: string = '';
  email: string = '';
  postal_code: number = 0;
  password: string = '';
  contact_number: number = 0

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    this.authService.signup(this.first_name, this.last_name, this.address, this.contact_number, this.postal_code , this.email, this.password).subscribe(
      (response) => {
        Swal.fire({
          title: 'Registration Successful!',
          text: response.msg,
          icon: 'success',
          confirmButtonText: 'Proceed to Login'
        }).then(() => {
          this.router.navigate(['/login']); // Redirect to login page
        });
      },
      (error) => {
        Swal.fire({
          title: 'Registration Failed',
          text: error.error.error,
          icon: 'error',
          confirmButtonText: 'Try Again'
        });
      }
    );
  }
}
