import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { isPlatformBrowser } from '@angular/common'; // Import the helper function

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = 'http://127.0.0.1:8000/apis'; // Replace with your Django API URL

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: Object) {}

  signup(
    first_name: string,
    last_name: string,
    address: string,
    postal_code: number,
    contact_number: number,
    email: string,
    password: string
  ): Observable<any> {
    return this.http.post(`${this.baseUrl}/signup/`, {
      first_name,
      last_name,
      address,
      postal_code,
      contact_number,
      email,
      password,
    });
  }

  login(email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/login/`, { email, password });
  }

  saveToken(token: string): void {
    if (isPlatformBrowser(this.platformId)) {
      // Ensure that we are on the browser before accessing localStorage
      localStorage.setItem('token', token);
    }
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      // Ensure that we are on the browser before accessing localStorage
      localStorage.removeItem('token');
    }
  }

  isAuthenticated(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      // Ensure that we are on the browser before accessing localStorage
      return !!localStorage.getItem('token');
    }
    return false;
  }
}
