import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';  // Import the helper function

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private apiUrl = 'http://127.0.0.1:8000/api/products/';
  private cartCountSubject: BehaviorSubject<number>;

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: Object) {
    let initialCartCount = 0;

    if (isPlatformBrowser(this.platformId)) {
      // Ensure that we are on the browser before accessing localStorage
      initialCartCount = Number(localStorage.getItem('cartCount')) || 0;
    }

    this.cartCountSubject = new BehaviorSubject<number>(initialCartCount);
  }

  getProducts(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  getCartCount(): Observable<number> {
    return this.cartCountSubject.asObservable();
  }

  updateCartCount(count: number): void {
    this.cartCountSubject.next(count);

    if (isPlatformBrowser(this.platformId)) {
      // Ensure that we are on the browser before accessing localStorage
      localStorage.setItem('cartCount', count.toString());
    }
  }
}
