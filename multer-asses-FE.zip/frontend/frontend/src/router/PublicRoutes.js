import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Loginform from "../Login SignUp/loginform";
import SignUp from "../Login SignUp/SignUpForm";
import UserProfile from "../component/UserProfile";


const publicRoutes = [
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Loginform /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    },
    {
    	path: "/userProfile",
    	exact: true,
    	element: <PublicLayout><UserProfile/></PublicLayout>
    },
    
    
];
export default publicRoutes;
