import React, { useState } from 'react';
import './User.css';

export default function FormComponent() {
    // State to hold form data
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        address: '',
        city: '',
        gender: '',
        termsAccepted: false,
    });

    const [errors, setErrors] = useState({});

    // Handle input changes
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value,
        });
    };

    // Handle form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Form data submitted:', formData);
    };
    
    return (
        <>
            <form className="form-container" onSubmit={handleSubmit}>
                <h2>Register Form</h2>

                <div className="form-group">
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                </div>

                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                    />
                </div>

                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                    />
                    {errors.password && <p className="error">{errors.password}</p>}
                </div>

                <div className="form-group">
                    <label>Address:</label>
                    <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        rows="4"
                        cols="34"
                    />
                     {errors.address && <p className="error">{errors.address}</p>}
                </div>

                <div className="form-group">
                    <label>City:</label>
                    <select
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                    >
                        <option value="">Select your city</option>
                        <option value="nagpur">Nagpur</option>
                        <option value="bhandara">Bhandara</option>
                        <option value="wardha">Wardha</option>
                        <option value="amravati">Amravati</option>
                        <option value="akola">Akola</option>
                    </select>
                </div>

                <div className="form-group">
                    <label>Gender:</label>
                    <div>
                        <input
                            type="radio"
                            name="gender"
                            value="male"
                            checked={formData.gender === 'male'}
                            onChange={handleChange}
                        /> Male
                        <input
                            type="radio"
                            name="gender"
                            value="female"
                            checked={formData.gender === 'female'}
                            onChange={handleChange}
                        /> Female
                    </div>
                </div>

                <div className="form-group">
                    <label>
                        <input
                            type="checkbox"
                            name="termsAccepted"
                            checked={formData.termsAccepted}
                            onChange={handleChange}
                        /> I accept the terms and conditions
                    </label>
                    
                </div>

                <div className="form-group">
                    <button type="submit" className="submit-button">Submit</button>
                </div>
            </form>
        </>
    );
}
