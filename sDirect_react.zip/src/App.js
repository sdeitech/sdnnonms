import './App.css';
// import NavComponent from './component/NavComponent';
import FormDesign from './view/User/FormDesign';

function App() {
    return (
        <div className="App">
            <div className='container'>
                {/* <NavComponent /> */}
                <FormDesign />
            </div>
        </div>
    );
}

export default App;
