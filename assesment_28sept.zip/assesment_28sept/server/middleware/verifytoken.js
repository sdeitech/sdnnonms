import jwt from 'jsonwebtoken';
import User from '../model/user.m';
import { Response } from './response';
import { messages } from '../config/constant';

const authenticate = async (req,res,next) => {
    const token = req.headers['authorization'];

    if(!token){
        return (
            Response._401(res, {
                status: false,
                message: messages.toKen,
                body: null,
            })
        )
    }
    try {
        const decode = jwt.verify(token,process.env.JWT_SECRET);
        req.user = await User.findById(decode.id);

        if(!req.user){
            return (
                Response._401(res, {
                    status: false,
                    message: messages.userNotfound,
                    body: null,
                })
            )
        }
        next();
    } catch (error) {
        Response._401(res, {
            status: false,
            message: messages.expiredToken,
            body: null,
        })
    }
}

module.exports = authenticate;