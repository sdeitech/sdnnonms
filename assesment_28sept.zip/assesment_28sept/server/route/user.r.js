import express from "express";
import {registerUser, loginUser, getUser} from '../controller/user.c'
import {addData, viewData} from '../controller/userdata.c'
const router = express.Router();
import authenticate from '../middleware/verifytoken';

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/view', getUser);
router.use (authenticate);

router.post('/userdata',(req,res)=>{res.send(addData)});
router.get('/userview',(req,res)=>{res.send(viewData)});





module.exports = router;