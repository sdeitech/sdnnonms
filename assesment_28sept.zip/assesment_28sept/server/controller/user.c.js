import User from '../model/user.m';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { messages } from '../config/constant';
import { Response } from '../middleware/response';
import 'dotenv/config'
const config = require("../config/config")
const { TOKENS } = config.config
const registerUser = async (req, res) => {
    try {
        const { firstName, lastName, email, pass, dob, gender, isMarried } = req.body;


        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return Response._400(res, {
                status: false,
                message: messages.userExist,
                body: null,
            });
        }


        const hashPassword = await bcrypt.hash(pass, 10);

        const newUser = new User({
            firstName,
            lastName,
            email,
            pass: hashPassword,
            dob,
            gender,
            isMarried,
        });


        await newUser.save();



        await newUser.save();
        return Response._201(res, {
            status: true,
            message: messages.userRegistered,
            body: { userId: newUser._id, email: newUser.email },
        });

    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, pass } = req.body;
        const user = await User.findOne({ email }).select('pass');

        if (!user) {
            return (
                Response._401(res, {
                    status: false,
                    message: messages.userNotfound,
                    body: null,
                })
            )
        }

        const isMatch = await bcrypt.compare(pass, user.pass);

        if (isMatch) {
            const token = jwt.sign({ email, pass }, TOKENS.JWT_SECRET, {
                expiresIn: TOKENS.JWT_EXPIRATION_IN_MINUTES,
            });

            user.token = token;
            await user.save();

            return (
                Response._201(res, {
                    status: false,
                    message: messages.logIn,
                    token: token,
                })
            )
        } else {
            return (
                Response._401(res, {
                    status: false,
                    message: messages.userNotfound,
                    body: null,
                })
            )
        }
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}

const getUser = async (req, res) => {
    try {
        const Users = await User.find()
        res.send(Users)
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        })
    }
}
module.exports = {
    registerUser,
    loginUser,
    getUser
}