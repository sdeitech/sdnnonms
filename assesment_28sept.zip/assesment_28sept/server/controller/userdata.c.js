import User from '../model/user.m';
import { Response } from '../middleware/response';
import { messages } from '../config/constant';

const createUser = async (req, res) => {
    try {
        const newData = new User({
            ...req.body,
            user: req.user._id, 
        });
        console.log(req.body)
        await newData.save();
        return Response._201(res, {
            status: true,
            message: messages.userRegistered,
            body: { token, userId: newUser._id, email: newUser.email },
        });
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};


const getUser = async (req, res) => {
    try {
        const data = await User.find({ user: req.user._id }); // Only get logged-in user's data
        Response._200(res,{
            status: true,
            message : messages.datfetched,
            body: data,
        })
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};

const updateUser = async (req, res) => {
    try {
        const updatedData = await User.findOneAndUpdate(
            { _id: req.params.id, user: req.user._id }, 
            req.body,
            { new: true }
        );
        if (!updatedData) return res.status(404).json({ message: 'Data not found' });
        Response._200(res,{
            status: true,
            message : messages.add,
            body: updatedData,
        })
    } catch (error) {
        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};

module.exports ={
    createUser,
    getUser,
    updateUser,
}