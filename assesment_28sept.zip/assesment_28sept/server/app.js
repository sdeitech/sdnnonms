import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import { startConnection } from "./config/dbConnection";
import router from "./route/user.r"

const app = express();

startConnection();

app.use(cors());
app.use(bodyParser.json())
app.use('/user', router)


export default app;