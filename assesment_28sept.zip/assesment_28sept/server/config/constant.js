export const messages ={
    createuser: "Your Account is Succesfully created!!",
    failCreate :"Unable to create Account Please try again",
    logIn: "Login Succesfull!!",
    toKen: "No Token Found!!",
    expiredToken: "Token is Expired!!",
    userExist : "UserName already Existed",
    userNotfound: "User Not Found!!",
    dataNotound: "No Data Found !!",
    datfetched: "Data Fetch !!",
    add : "Data Added Succesfully",
    update: "Data update Success!!",
}

export const messageID = {
    successCode: 200,
    badRequest: 400,
    newResourceCreated: 201,
    unAuthorizedUser: 401,
    forbidden: 403,
    internalServerError: 500,
}