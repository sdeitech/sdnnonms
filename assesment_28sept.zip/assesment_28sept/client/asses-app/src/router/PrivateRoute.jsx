import {React} from "react";

import NotFound from "../component/NotFound";

import PrivateLay from "../layout/PrivateLay";
import Dashboard from "../component/Dashboard";
import AddForm from "../component/Add";

const PrivateRoute = [
	{
		path: "/users",
		exact: true,
		element: <PrivateLay><Dashboard/></PrivateLay>
	},
    {
		path: "/add",
		exact: true,
		element: <PrivateLay><AddForm/></PrivateLay>
	},
	{ path: "/*", element: <NotFound/> }
];
export default PrivateRoute;
