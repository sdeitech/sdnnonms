import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../style/table.css';

function Dashboard() {

    const [userData, setuserData] = useState([]);



    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await axios.get('http://localhost:5000/user/userview');
                setuserData(res.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, []);
    return (
        <>
            <table>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Gender </th>
                        <th>Actions </th>
                    </tr>
                </thead>
                <tbody>
                    {userData.map((userDat) => (
                        <tr key={userDat._id}>
                            <td>{userDat.name}</td>
                            <td>{userDat.lastName}</td>
                            <td>{userDat.age}</td>
                            <td>{userDat.gender}</td>
                            <td>
                                <button onClick={''}>View</button>
                                <button onClick={''}>Update</button>
                            </td>
                        </tr>
                    ))}

                </tbody>        
            </table >
        </>
    )
}


export default Dashboard;