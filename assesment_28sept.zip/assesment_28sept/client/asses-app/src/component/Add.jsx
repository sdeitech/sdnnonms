import React, { useState } from 'react'; 
import axios from 'axios'; 
import Button from 'react-bootstrap/Button'; 
import Col from 'react-bootstrap/Col'; 
import Form from 'react-bootstrap/Form'; 
import Row from 'react-bootstrap/Row';
import validate from './validate';

function AddForm() {
    const [userData, setUserData] = useState({
        firstName: '',
        lastName: '',
        age: '',
        dob:'',
        gender:'',
        isMarried: '',
    });

    const [error, setError] = useState({})

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({
            ...userData,
            [name]: value,
        });
    };

    console.log(userData);

    const handleSubmit = async (e) => {
        e.preventDefault();


        const validationErrors = validate(userData);
        if (Object.keys(validationErrors).length === 0){
            try {
                const response = await axios.post(
                    "http://localhost:5000/user/userdata",
                    userData
                );
                console.log("userData data submitted:", response.data);
            } catch (err) {
                console.error("Error submitting Data:", err.message);
            }
        }else{
            setError(validationErrors);
        }


    };

    const clearuserData = () => {
        setUserData({
            firstName: '',
            lastName: '',
            age: '',
            dob:'',
            gender:'',
            isMarried: '',
        });
    };

    return (
        <Form onSubmit={handleSubmit}>
            <Row className="mb-3">
                <Form.Group as={Col}>
                    <Form.Label>First Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter Name" name="firstName" onChange={handleChange} value={userData.name} />

                </Form.Group>

                <Form.Group as={Col}>
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter Last Name" name="lastName" onChange={handleChange} value={userData.lastName} />
                </Form.Group>
            </Row>

            <Form.Group className="mb-3">
                <Form.Label>age</Form.Label>
                <Form.Control type="number" placeholder="Enter AGE" name="age" onChange={handleChange} value={userData.age} />

            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Date of Birth </Form.Label>
                <Form.Control type="text" placeholder="Date of Birth"name="dob" onChange={handleChange} value={userData.dob} />

            </Form.Group>

            <Row className="mb-2">
                <Form.Group as={Col}>
                    <Form.Label>Married</Form.Label>
                    <Form.Control type='text' placeholder="Married"name="isMarried" onChange={handleChange} value={userData.isMarried} />

                </Form.Group>

                <Form.Group as={Col}>
                    <Form.Label>Gender</Form.Label>
                    <Form.Control type='text'placeholder="Enter gender" name="gender" onChange={handleChange} value={userData.gender} />

                </Form.Group>
            </Row>
            <Button variant="primary" type="submit">
                Submit
            </Button>
            <Button variant="secondary" onClick={clearuserData} className="ms-2">
                Reset
            </Button>
        </Form>
    );
}

export default AddForm;










