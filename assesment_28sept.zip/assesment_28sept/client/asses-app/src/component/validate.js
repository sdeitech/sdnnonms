const validate = (values) => {
    let error = {};

    if (!values.firstName) {
        error.firstName = "First Name is required!!";
    }
    if (!values.lastName) {
        error.lastName = "Last Name is required!!";
    }
    if (!values.email) {
        error.email = "Email ID  is required!!";
    }

    if (!values.gender) {
        error.gender = "Gender is required !!";
    }


    return error;
};

export default validate;