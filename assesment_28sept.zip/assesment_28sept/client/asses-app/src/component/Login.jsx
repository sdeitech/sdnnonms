import React, { useState } from 'react';
import axios from 'axios';
import {
  MDBContainer,
  MDBInput,
  MDBBtn,
} from 'mdb-react-ui-kit';

function Login() {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();


    if (!email || !pass) {
      setError('Please enter both email and password');
      return;
    }

    setError('');

    try {
      const response = await axios.post("http://localhost:5000/user/login", {
        email,
        pass,
      });

      const { token } = response.data;
      localStorage.setItem('token', token);
      window.location.href = '/users'; 
    } catch (err) {
      if (err.response && err.response.data) {
        setError(err.response.data.message || 'Invalid email or password');
      } else {
        setError('An unexpected error occurred. Please try again later.');
      }
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
      <h2 className="text-center mb-4">Sign In</h2>

      {error && <div className="alert alert-danger">{error}</div>}

      <MDBInput
        wrapperClass='mb-4'
        label='Email address'
        id='form1'
        type='email'
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <MDBInput
        wrapperClass='mb-4'
        label='Password'
        id='form2'
        type='password'
        value={pass}
        onChange={(e) => setPass(e.target.value)}
      />

      <MDBBtn 
        className="mb-4" 
        onClick={handleLogin} 
        disabled={loading}
      >
        {loading ? 'Signing in...' : 'Sign in'}
      </MDBBtn>

      <div className="text-center">
        <p>Not a member? <a href="/register">Register</a></p>
      </div>
    </MDBContainer>
  );
}

export default Login;
