import React from "react";

const PublicLay = ({ children }) => {
    return (
        <>
            {children}
        </>
    );
};

export default PublicLay;
