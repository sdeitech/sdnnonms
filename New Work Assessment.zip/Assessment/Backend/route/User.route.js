import express from 'express';
const router = express.Router();
import Usercontroller from '../controllers/User.controller';
// import {TokenVerification} from '../middleware/authentication';

router.get('/get', Usercontroller.getUser);
router.post('/post',  Usercontroller.createUser);
router.get('/paginate',Usercontroller.paginateUser);
router.get('/view/:id', Usercontroller.viewData);
router.put('/update', Usercontroller.updateUser);

module.exports= router;