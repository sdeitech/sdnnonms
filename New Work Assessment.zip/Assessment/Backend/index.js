import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import userRoutes from './route/User.route';
import LoginRoutes from './route/LoginandRegister.route';
import InitiateMongoServer from './config/db';
import path from "path"


const app=express();
InitiateMongoServer()
app.use(cors({ origin: "*" }));
app.use(bodyParser.json());

app.use('/users',userRoutes);
app.use('/auth', LoginRoutes);

app.use(express.json({limit:"50mb"}));
app.use(bodyParser.urlencoded({limit:"50mb", extended:false}));
app.use("/",express.static('profile_picture'));
// app.use('/', express.static(path.join('profile_picture')));


export default app;


