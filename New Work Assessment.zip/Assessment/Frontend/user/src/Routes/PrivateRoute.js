import {React} from "react";
import PrivateLayout from "../Layouts/PrivateLayout";
import Userdetail from '../components/Userdetail';


const PrivateRoute=[
    {
        path:"/user",
        exact:true,
        element:<PrivateLayout><Userdetail/></PrivateLayout>
    }
];
export default PrivateRoute;