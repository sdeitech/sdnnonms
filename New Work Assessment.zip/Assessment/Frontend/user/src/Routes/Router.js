import PublicRoute from "./PublicRoute";
import PrivateRoute from "./PrivateRoute";
import {createBrowserRouter} from "react-router-dom";

const Router=createBrowserRouter([
    ...PublicRoute,
    ...PrivateRoute
]);
export default Router;