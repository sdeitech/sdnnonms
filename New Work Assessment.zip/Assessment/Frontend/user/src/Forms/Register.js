
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
    const navigate = useNavigate();
    const [data, setdata] = useState([]);
    const [regformData, setRegFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        DOB: '',
        password: '',
        gender: '',
        profile: null,
        married: false,

    });

    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setRegFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const fileonchange = (e) => {
        const file = e.target.files[0];
        setRegFormData((prevData)=>({ ...prevData, profile:file, }));
    };



    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const formdata = new FormData();

            formdata.append('firstname', regformData.firstname);
            formdata.append('lastname', regformData.lastname);
            formdata.append('email', regformData.email);
            formdata.append('password', regformData.password);
            formdata.append('DOB', regformData.DOB);
            formdata.append('gender', regformData.gender);
            formdata.append('image', regformData.profile);
            
            const response = await axios.post('http://localhost:4000/auth/register', formdata, {
                headers:{
                    'Content-Type':'multipart/form-data',
                },
            });
            setdata([...data, response.data]);
            setRegFormData({
                firstname: '',
                lastname: '',
                email: '',
                DOB: '',
                password: '',
                gender: '',
                profile: 'image',
                married: false,

            });

            localStorage.setItem('userdata', JSON.stringify(response.data.newuser))
            setError('You Registered Successfully! Now please click on Login');
            console.log("Registered successfully!");
        } catch (err) {
            setError('Registration Failed!');
        }

    };
    const GotoLogin = () => {
        navigate("/")
    }
    return (
        <div>
            <h2>Registration</h2>

            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form className="form-container" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>First Name:</label>
                    <input
                        type="text"
                        name="firstname"
                        value={regformData.firstname}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lastname"
                        value={regformData.lastname}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={regformData.email}
                        onChange={handleChange}
                        required
                    /></div>

                <div className="form-group">
                    <label>DOB:</label>
                    <input
                        type="date"
                        name="DOB"
                        value={regformData.DOB}
                        onChange={handleChange}
                        required
                    /></div>


                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={regformData.password}
                        onChange={handleChange}
                        required
                    /></div>
                <div className='form-group'>
                    <label>Gender:</label>
                    <div>
                        <input
                            type="radio"
                            name='gender'
                            value="male"
                            checked={regformData.gender === 'male'}
                            onChange={handleChange} />Male
                        <input
                            type='radio'
                            name='gender'
                            value="female"
                            checked={regformData.gender === 'female'}
                            onChange={handleChange} />Female
                    </div>
                </div>
                <div className='form-group'>
                <label>Married</label>
                <input
                    type="checkbox"
                    name='Married'
                    value="Married"
                    onChange={handleChange}
                />
                </div>
                <div className='form-group'>
                <label>Select Profile Picture: </label>
                <input
                    type="file"
                    name="profile"
                    // value={regformData.profile}
                    onChange={fileonchange} />
                </div>

                <div className="form-group">
                    <button type="submit" className='submit-button' >Register </button>
                </div>
                <div className="form-group">
                    <button type="submit" className='submit-button' onClick={GotoLogin}>Login Now</button>
                </div>
            </form>
        </div>
    );
};
export default Register;










