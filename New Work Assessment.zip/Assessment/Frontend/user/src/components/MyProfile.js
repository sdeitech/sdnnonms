import React from 'react';
import { useNavigate } from 'react-router-dom';
import './profile.css';

function MyProfile() {
  
  const navigate=useNavigate();
  const user=localStorage.getItem("userdata");
  const newuser=JSON.parse(user);
  console.log(newuser, "asdf");



  return (
    <div>
      <h3>My Profile</h3>
      <img src={`http://localhost:4000/${newuser.profile}`} className='center'/>
      <p className='info'>FirstName: {newuser.firstname}</p>
      <p className='info'>LastName: {newuser.lastname}</p>
      <p className='info'>Email: {newuser.email}</p>  
      <p className='info'>Date of Birth:{newuser.DOB}</p>
      <p className='info'>Gender:{newuser.gender}</p>          
       <button className='info' type="submit">UPDATE</button>        
     <button onClick={()=>navigate('/user')}>Go to DashBoard</button>
    </div>
  )
}

export default MyProfile;
