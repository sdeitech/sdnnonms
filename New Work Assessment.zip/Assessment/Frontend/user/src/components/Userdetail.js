import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './user.css'

function Userdetail() {
    const navigate = useNavigate();
    
    const [data, setData] = useState([]);
    const [view, setView] = useState(null);
    const [currentPage, setCurrentPage]=useState(1);
    const [totalPages,setTotalPages]=useState(0);
    const [search, setSearch] = useState('');
    const [limit, setLimit] = useState(3);


    // To fetch the data
    const fetchData = async (page) => {
        let token=localStorage.getItem('userdata');

        let auth={
            headers:{
                Authorization: `bearer ${token}`
            },
        };
        try {
            const response = await axios.get(`http://localhost:4000/users/paginate?page=${page}&limit=${limit}&search=${search}`,auth);
            console.log(response.data.users);

            setData(response.data.user);
            setTotalPages(response.data.totalPages);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const handleadd = async (id) => {
       navigate('/add')
    };

    const viewdata = async (id) => {
        try {

            const response = await axios.get(`http://localhost:4000/users/view/${id}`);

            setView(response.data);
            console.log(response, "geting")

        } catch (error) {
            console.log('Error in getting data:', error);
        }
    };

    useEffect(() => {
        fetchData(currentPage);
    }, [currentPage, search]);


    const handleSearch = (e) => {
        setSearch(e.target.value);
        setCurrentPage(1); // Reset to first page on search
    };

    const handleNextPage = () => {
            setCurrentPage(currentPage +1);
     };
        
    

    const handlePrevPage = () => {
            setCurrentPage(currentPage -1);
    };
    
    return (
        <div>
            <h2>DashBoard</h2>
            <button onClick={()=>navigate('/myprofile')}>My Profile</button>
            <input 
                type="text"
                placeholder="Search by name"
                value={search}
                onChange={handleSearch}
            />
            <table>
                <thead>
                    <tr>
                        <th>Sr.No.</th>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((user, index) => (
                        <tr key={index}>
                            <td>{index+1}</td>
                            <td>{user.firstname}</td>
                            <td>{user.lastname}</td>
                            <td>{user.email}</td>
                            <td>
                                <button onClick={() => viewdata(user._id)}>View</button>
                                <button onClick={()=>navigate('/add')}>Update</button>
                            </td>
                        </tr>

                    ))}
                </tbody>
            </table>
            {view && (
                <div>
                    <h3>Details:</h3>

                    <div key={view._id}>
                        <p>First Name: {view.firstname}</p>
                        <p>Last Name: {view.lastname}</p>
                        <p>Email: {view.email}</p>
                        
                    </div>
                </div>
            )}
             <button onClick={() => handleadd()}>Add User</button>
             <button onClick={()=>navigate('/')}>LogOut</button>
            <div>
                    <button onClick={handlePrevPage} disabled={currentPage === 1}>Previous</button>
                    <span> Page {currentPage} of {totalPages} </span>
                    <button onClick={handleNextPage} disabled={currentPage === totalPages}>Next</button>
            </div> 
        </div>

    );
};

export default Userdetail;
