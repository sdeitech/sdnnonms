import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductsModule } from './products/products.module';
import { ConsulModule } from './consul/consul.module';
import { ConsulService } from './consul/consul.service';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [
    ConsulModule,
    MongooseModule.forRootAsync({
      imports: [ConsulModule],
      inject: [ConsulService],
      useFactory: async (consulService: ConsulService) => {
        const mongoUri = await consulService.getKey('mongodb/DATABASE_URL');
        if (!mongoUri) {
          throw new Error('MongoDB URI not found in Consul');
        }
        return {
          uri: mongoUri,
        };
      },
    }),
    ProductsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
