import { Module } from '@nestjs/common';
import { ProductsService } from './products.service';
import { ProductsController } from './products.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ConsulModule } from 'src/consul/consul.module';
import { JwtModule } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';
import { Product, ProductSchema } from './schema/product.schema';

@Module({
  imports: [
    // Register the Product schema for MongoDB
    MongooseModule.forFeature([{ name: Product.name, schema: ProductSchema }]),

    // Import the ConsulModule for dynamic configuration
    ConsulModule,

    // Configure the JwtModule dynamically using Consul
    JwtModule.registerAsync({
      imports: [ConsulModule],
      useFactory: async (consulService: ConsulService) => {
        const jwtSecret = await consulService.getKey('JWT_SECRET');
        const jwtExpiry = await consulService.getKey('EXPIRES_IN');

        if (!jwtSecret || !jwtExpiry) {
          throw new Error('error');
        }

        return {
          secret: jwtSecret,
          signOptions: { expiresIn: jwtExpiry },
        };
      },
      inject: [ConsulService],
    }),
  ],
  providers: [ProductsService],
  controllers: [ProductsController],
})
export class ProductsModule {}
