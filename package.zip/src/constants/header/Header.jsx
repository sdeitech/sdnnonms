import React from "react";
import Icons from "../../assets/assets";
import { useDispatch } from "react-redux";
import { logoutUser } from "../../context/Reducers/LoginUser";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

const Header = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    toast.success("Logged Out");
    setTimeout(() => {
      dispatch(logoutUser());
      navigate("/");
    }, 1000);
  };
  return (
    <div className="bg-gray-400 mt-0 flex flex-row justify-between px-6 py-4">
      <div className="h-10 rounded-md">
        <input
          type="text"
          placeholder="Search usere"
          className="h-10 rounded-md w-60 px-2 focus:outline-none"
        />
      </div>
      <div className="flex flex-row items-center justify-center gap-6">
        <Link to={"/adduser"}>
          <div>
            <button>Add user</button>
          </div>
        </Link>
        <div className=" rounded-full border-2 border-gray-900 p-1 ">
          <img
            src={Icons.profile}
            alt=""
            height={30}
            width={30}
            className="rounded-full"
          />
        </div>
        <div>
          <button
            className="bg-black text-white px-3 py-1 rounded-sm font-medium"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <Toaster />
    </div>
  );
};

export default Header;
