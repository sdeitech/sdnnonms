import React from "react";
import PrivateLayout from "../layout/PrivateLayout";
import Dashboard from "../pages/Dashboard";
import AddUser from "../pages/AddUser";

const PrivateRouters = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },

  {
    path: "/adduser",
    element: (
      <PrivateLayout>
        <AddUser />
      </PrivateLayout>
    ),
  },
];

export default PrivateRouters;
