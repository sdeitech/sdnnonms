
import express from 'express';
import { uploadImage , uploadImages } from '../controllers/fileUploadController.js'; // Ensure the correct path
import { fileupload } from '../helper/multer.js'; // Ensure the correct path

const fileuploadroute = express.Router();

fileuploadroute.post("/image", fileupload.single('image'), uploadImage);
fileuploadroute.post("/images", fileupload.array('images', 5), uploadImages);

export default fileuploadroute;
