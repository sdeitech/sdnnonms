import mongoose from 'mongoose'
import config from '../config/config' 
const NODE_ENV = process.env.NODE_ENV || "local"; //local

export const connect = async()=>{

    try {
        await mongoose.connect(`mongodb://${config[NODE_ENV].db.HOST}:${config[NODE_ENV].db.PORT}/${config[NODE_ENV].db.DATABASE}`)
        console.log("database is connected to mongodb")
    } catch (error) {
        console.log(error.message)
        return error
    }
}