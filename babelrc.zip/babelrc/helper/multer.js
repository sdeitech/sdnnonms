import multer from 'multer'
import path from 'path'

const storage = multer.diskStorage({
    destination: function (req,file,cb){
      cb(null , './upload_images')
    },
    filename: function(req,file,cb){
        cb(null , Date.now() + path.extname(file.originalname))
    }
})

const fileFilter =  (req,file,cb) =>{
    console.log(file.originalname , "fileName")
    const allowfileTypes = ['image/png' , 'image/jpg' ,'image/jpeg']
    if(!allowfileTypes.includes(file.mimetype)){
        return cb(new Error('Invalid file type. Only PNG, JPG, and JPEG are allowed.'))
    }
    return cb(null, true)
}

export const fileupload = multer({
    storage: storage,
    fileFilter:fileFilter,
    limit:5*1024*1024
})