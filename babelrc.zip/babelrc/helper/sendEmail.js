import nodemailer from 'nodemailer'

const transporter = nodemailer.createTransport({
    host : "smtp.gmail.com",
    port : 587,
    secure: false ,
    auth :{
        user: "harshalmahadeonagpure@gmail.com",
        pass: "yazwvhdyotufyqlv"
    }

})

export const sendEmail = async (to , body , subject)=>{

    const mail = await transporter.sendMail({
        from: `harshal <harshalmahadeonagpure@gmail.com>`,
        to : `${to}`,
        subject: `${subject}`,
        html: `${body}`

    

    })


    console.log(mail , "mail")

  return mail
}