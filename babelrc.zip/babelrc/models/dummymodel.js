import mongoose from "mongoose";

const dummymodelSchema = new mongoose.Schema({
    filename : String
})

const dummymodel = mongoose.model("dummymodel" , dummymodelSchema)

export default dummymodel