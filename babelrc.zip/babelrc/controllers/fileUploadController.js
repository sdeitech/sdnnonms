import dummymodel from "../models/dummymodel"

export const uploadImage= async(req , res) =>{
  console.log(req.file)

  const newFile = new dummymodel({
    filename : req.file.filename
  })
  newFile.save()
  res.json({newFile:newFile})
}

export const uploadImages = (req , res) =>{
  console.log(req.file)
  
}