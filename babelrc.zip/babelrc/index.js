//Ganesh Golhar from bajaj institute
const express  = require('express');
// const cors = require('cors
const dummy = require('./models/dummymodel')
const app = express();
import {sendEmail} from './helper/sendEmail'
import {connect} from './db/db'
import fileuploadroute from './routes/uploadFile'
connect()
// middleware
app.use(express.json())

//routes
app.use("/api",fileuploadroute)

app.use("/getImage", express.static("upload_images"))

app.get("/sendEmail" ,async(req,res) =>{
  const email =  await sendEmail("ganesh.golhar35@gmail.com" , "<h1>hii new mail from ganesh</h1>" , "testing a mail from ganesh")
  return res.json({email:email})
} )



module.exports = app