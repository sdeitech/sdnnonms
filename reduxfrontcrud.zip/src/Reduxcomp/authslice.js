import { createSlice } from "@reduxjs/toolkit";


const userSlice = createSlice({
    name:"auth",
    initialState:{
    authUser:{

        token:null,
        logindetails:{}
    }
},
reducers:{
    authUser:(state,action)=>{
        console.log(action.payload)
        state.authUser.token =action.payload.token
        state.authUser.logindetails =action.payload.userData


    }
    
     

    }
})
export default userSlice.reducer;
export const {authUser}=userSlice.actions





