import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./slice"
import usersre from "./authslice"


const Store = configureStore({
    reducer:{
        users:userReducer,usersre
    }
})
export default Store