import Signin from "../auth/Signin";
import  Signup  from "../auth/Signup";
// import PrivateLayout from "../layout/PrivateLayout";
import PublicLayout from "../layout/PublicLayout";
import Home from "../Components/Home";
import Update from "../Components/Update";
import Create from "../Components/Create"
const PublicRoute = [
    {
        path: "/",
        element: (
            <PublicLayout>
                <Signup />

            </PublicLayout>
        ),
    },
    {
        path: "/login",
        element: (
            <PublicLayout>
                <Signin />
            </PublicLayout>
        ),
    },
    {
        path: "/home",
        element: (
            <PublicLayout>
                <Home />
            </PublicLayout>
        ),
    },
    {
        path: "/create",
        element: (
            <PublicLayout>
                <Create />
            </PublicLayout>
        ),
    },
    {
        path: "/edit/:id",
        element: (
            <PublicLayout>
                <Update />
            </PublicLayout>
        ),
    },

]
export default PublicRoute


// <Routes>
//     <Route path="/" element={<Home/>}></Route>
//     <Route path="/create" element={<Create/>}></Route>
//     <Route path="/edit/:id" element={<Update/>}></Route>
// </Routes>