import { createBrowserRouter } from "react-router-dom";
import PrivateRoute from "./PrivateRoute";
import PublicRoute from "./PublicRoute";

const Routes = createBrowserRouter([...PrivateRoute, ...PublicRoute]);

export default Routes;