import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import { deleteUser } from '../Reduxcomp/slice';
import axios from "axios"
import { useState,useEffect } from 'react';

const Home = () => {
    const [userdata, setUserData] = useState([]);
    const users = useSelector((state) => state.users);  //extracting or taking data from redux store for use in state
    // console.log(users);
    const dispatch = useDispatch();
    const userId = localStorage.getItem("userId")

    const handleDelete=async (id)=>{
      
        try {
            const res = await axios.delete(`http://localhost:4565/api/deleteuser/${id}`, {
                // name:name,
                // email:email,
         
         })
         console.log(res,"deleted data");


            dispatch(deleteUser({userId:userId}))
            
        } catch (error) {
            console.log(error)
        }

    }
    const id = localStorage.getItem("userId")
    const fetchData = async () => {
        try {
            const response = await axios.get(
                `http://localhost:4565/api/getuser/${id}`
            );
            console.log(response.data.users, "hhhgghhghh");

            setUserData(response.data);
            console.log(response.data,"abhiiiii");
        } catch (error) {
            console.log("error fetching data");
        }
    };
  



    useEffect(() => {
        fetchData();
    }, [])

    
    
    return (
        <div classsName="container">
            <h2>Crud App</h2>
            {/* create button which is link to page means when we click on that button new page will open with the help of link */}
            <Link to="/create" className='btn btn-success my-3'>Create +</Link> 
            <table className='table'>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {/* mapping on userdata for listing in dashboard */}
                    {userdata?.map((user,index)=>{
                        return(
                        <tr key={index}>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>
                            <Link to={`/edit/${JSON.stringify(user)}`}className='btn btn-sm btn-primary'>Edit</Link>
                            <button onClick={()=> handleDelete(user._id)} className='btn btn-sm btn-danger ms-2'>Delete</button>
                            </td>
                        </tr>
                        )
                    })}
                </tbody>
            </table>


        </div>
    )
}
export default Home;
