const validation = (formData) => {
    let error = {};

    if (!formData.firstname) {
        error.firstname = "Name is required";
    }
    if (!formData.lastname) {
        error.lastname = "LastName is required";
    }
    if (!formData.age) {
        error.age = "age is required";
    }


    if (!formData.email) {
        error.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        error.email = "Email address is invalid";
    }
 
    if (!formData.password) {
        error.password = "Password is required";
    } else if (formData.password.length < 6) {
        error.password = "Password needs to be more than 5 characters";
    }
    if (!formData.profile) {
        error.profile = "profile is required";
    }



    return error;
};

export default validation;