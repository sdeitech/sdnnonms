import React from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux';
import { useState } from 'react';
import { updateUser } from '../Reduxcomp/slice';
import axios from "axios"


function Update() {
    // for grabing the id 
    const { id } = useParams();
    const userData = JSON.parse(id)
    console.log(userData,"data")

  const [name,setName] = useState(userData.name)
  const [email,setEmail] = useState(userData.email)
  const navigate = useNavigate()

    const handleUpdate = async (e) => {
        e.preventDefault()

        try {
            const res = await axios.put(`http://localhost:4565/api/updateuser/${userData._id}`,{
                name:name,
                email:email
            })

            console.log(res.data)
            navigate("/")
        } catch (error) {
            console.log(error)
            
        }

    }

    return (
        <div className='d-flex w-100 vh-100 justify-content-center align-items-center'>
            <div className='w-50 border bg-secondary text-white p-5'>
                <h4>Update user</h4>
                {/* //handle submit for when we submit the form this function will call and apply action of definition written in that                     */}
                <form onSubmit={handleUpdate}> <div>

                    <label htmlFor='name'>Name:</label>
                    <input type='text' name='name' className='form-control' placeholder='enter name'
                        value={name}
                        onChange={e => setName(e.target.value)}

                    />
                </div>
                    <div>
                        <label htmlFor='email'>Email:</label>
                        <input type='email' name='email' className='form-control' placeholder='enter email'
                            value={email}
                            onChange={e => setEmail(e.target.value)}

                        />
                    </div>
                    <button className='btn btn-info'>Submit</button>
                </form>
            </div>

        </div>
    )
}

export default Update
