// import React from 'react';
// import Home from "./Components/Home"
import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';
import { RouterProvider} from "react-router-dom"
// import Create from './Components/Create';
// import  Update  from './Components/Update';
import Routes from './routes/route';

function App() {
  return (
  <>
  <RouterProvider router={Routes} />
  </>
  );
}

export default App;
