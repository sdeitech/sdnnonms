import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import db from './config/dbConnection.js'
import userRouter from "./route/userRoute.js"
import path from 'path'
const app = express();

app.use(cors({ origin: "*" }));
app.use(express.json({ limit: "50mb" }));

app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));
app.use('/', express.static(path.join('image')));
app.use("/",userRouter);

export default app;

