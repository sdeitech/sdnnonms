import mongoose from 'mongoose';
const userSchema = mongoose.Schema({
    firstName:{
        type:String,
        required:true
    },
    lastName:{
        type:String,
        required:true
    },
    email: {
        type: String,
        required: true
    },
    dob:{
        type:Date,
        required:true
    },
    password: {
        type: String,
        required: true,
        unique:true
    },
    gender:{
            type:String,
            required:true
    },
    married:{
        type:Boolean,
        default:false
    },
    role:{
        type:String,
        required:true
    },
    image:{
        type:String,
    },
    tokens: [
        {
            token: {
                type: String,
                required: true
            }
        }
    ]
})

const User=mongoose.model("User",userSchema)
export default User;