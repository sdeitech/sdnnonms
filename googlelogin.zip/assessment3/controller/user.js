import User from "../model/user.js";
import jwt from 'jsonwebtoken';
import bcrypt, { hash } from 'bcrypt';

const createUser = async (req, res) => {
    // console.log(req.file)
    try {
        const { firstName, lastName, email, dob, password, gender, married, image, role } = req.body;
        const hashPass = await bcrypt.hashSync(password, 10);
        const newuser = new User({
            firstName: firstName,
            lastName: lastName,
            email: email,
            dob: dob,
            password: hashPass,
            gender: gender,
            married: married,
            image: req.file.path,
            role: role,
        });

        await newuser.save();
        res.status(200).json(newuser);

    }
    catch (error) {
        res.status(500).json({ message: "user not created" })
    }
}

const getUser = async (req, res) => {
    try {
        const ddddd = await User.find({})
        res.status(200).json(ddddd);

    }
    catch (error) {
        res.status(500).json("error while getting use information");
    }
}

const getUserById = async (req, res) => {
    try {
        // console.log(req.body,"jjjghjgh")
        const newuser = await User.findOne({ id: req.body._id })
        // console.log(newuser,"fdsfhjskhj")
        if (!newuser) {
            return res.json({ message: "user not found" })
        }
        res.status(200).json(newuser)

    }
    catch (error) {
        res.status(500).json({ message: "error while getting user by Id" })
    }
}

const deleteUserbyId = async (req, res) => {
    // console.log(req.body)
    try {
        // console.log("hfhfhf")
        const userdelete = await User.findOne({ _id: req.params.id });
        console.log(userdelete);
        if (!userdelete) {
            return res.json({ message: "user not deleted" })
        }
        res.status(200).json({ message: "userId deleted successfully" });
    } catch (error) {

        res.status(500).json({ message: "id not found" });
    }
}

const paginationAndSearching = async (req, res) => {
    try {
        const filter = {
            $or: [
                {
                    firstName: { $regex: req.query.searchText || "", option: "i" }
                }
            ]
        }
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query?.limit)
        const skip = (page - 1) * limit;

        const user = await User.find().skip(skip).limit(limit);
        const total = await User.countDocuments();

        const response = {
            Users: user,
            pagination: {
                total_record: total,
                perPage: limit,
                currentPage: page,
                // totalPage: Math.ceil(total_record / perPage)
            }
        }
        res.status(200).json(response);

    }
    catch (error) {
        res.json({ message: "error while doing pagination and searching" })
    }
}

// const uploadImage = (req, res) => {
//     if (!req.file) {
//         return res.status(400).json({ message: "file not upload" })

//     }
//     res.status(500).json({ message: "file upload ", file: req.file });
// }

export default {
    createUser,
    getUser,
    getUserById,
    deleteUserbyId,
    paginationAndSearching,
   // uploadImage
};