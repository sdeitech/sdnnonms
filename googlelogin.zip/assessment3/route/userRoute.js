import express from 'express';
const userRouter=express.Router();

import user from '../controller/user';
import userlogin from '../controller/userlogin.js';
import  { middlewareUpload } from "../middleware/multer.js"


import { googleLogin,getuser ,userRegistration} from '../controller/googlelogin.js';

//user register
userRouter.post("/user/register",middlewareUpload,user.createUser);


userRouter.get("/user",user.getUser)
userRouter.get("/user/:id",user.getUserById);
userRouter.delete('/user/:id',user.deleteUserbyId);
userRouter.get("/users",user.paginationAndSearching)

// userRouter.post("/user/image",middlewareUpload.single('image'),user.uploadImage);

//user login
userRouter.post('/user/login',userlogin.loginUser);




//new api calls 
///login with google

userRouter.post("/user-register",middlewareUpload,userRegistration);
userRouter.post("/google-login",googleLogin);
userRouter.get("/get-googleuser",getuser)

export default userRouter;