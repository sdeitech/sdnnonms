import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";
import React, { useState } from 'react';


const clientId = "531162091657-a8l74t9nuhjjhgdln9bqd44tfng3bshi.apps.googleusercontent.com";
const Login = () => {
    const [logindata,setloginData]=useState(
        localStorage.getItem("loginData")
        ?JSON.parse(localStorage.getItem("loginData")):null
    )

    const handleSuccess = async (response) => {
         console.log("response",response)
        try {
            const res= await fetch("http://localhost:5005/api/login",{
                method:"post",
                body:JSON.stringify({token:response}),
                headers:{"Content-Type":"application/json"}
            });
            console.log("login with google success");
            if(!res.ok)
            {
               throw new Error("failed to login with google");
            }
            console.log("zhdgsdt")
            const data = await res.json();

            setloginData(data);
            localStorage.setItem("loginData",JSON.stringify(data));

        }
        catch (error) {
            console.log("login not success");
        }

    }
    const handleError = () => {
        console.log("error while login")
    }
    return (
        <div className="container ">
            <button type="button">
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={(CredentialResponse)=>{
                        handleSuccess(CredentialResponse.credential);
                    }}
                    onError={handleError}
                />
            </GoogleOAuthProvider>
            </button>
        </div>
    )
}

export default Login