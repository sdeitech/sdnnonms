import React from 'react'

const Logout = () => {
  return (
    <div>
        <button type="button">Logout</button>
    </div>
  )
}

export default Logout