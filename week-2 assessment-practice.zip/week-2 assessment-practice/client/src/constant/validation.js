const validateUser = (values) => {
    let errors = {};

    if (!values.productName) {
        errors.productName = "Enter Product Name";
    }

    if (!values.description) {
        errors.description = "Enter Description";
    }

    if (!values.quantity) {
        errors.quantity = "Enter Quantity";
    }

    if (!values.expiryDate) {
        errors.expiryDate = "Enter Expiry Date";
    }
    if (!values.manufacturerName) {
        errors.manufacturerName = "Enter Manufacturer Name";
    }



    return errors;
};

export default validateUser;
