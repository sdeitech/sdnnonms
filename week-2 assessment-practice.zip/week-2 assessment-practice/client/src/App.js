import { useEffect, useState } from 'react';
import './App.css';
import MyForm from './components/Form';
import ProductDetail from './components/ProductDetail';
import ProductList from './components/ProductList';
import axios from 'axios';
import SearchFilter from './components/SearchFilter';
import Pagination from './components/Pagination';

function App() {
  const [product, setProduct] = useState([]);
  const [selector, setSelector] = useState(null);
  const [editProduct, setEditProduct] = useState(null); 
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [updateSelector, setUpdateSelector] = useState();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [productsPerPage] = useState(5);


  useEffect(() => {
    fetchProduct();
  }, []);

  // Handle Search
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    if (e.target.value !== '') {
      const filtered = product.filter(p =>
        p.productName.toLowerCase().includes(e.target.value.toLowerCase())
      );
      setFilteredProducts(filtered);
    } else {
      setFilteredProducts(product);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setFilteredProducts(product);
  };

  // Pagination Logic
  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);


  const fetchProduct = async () => {
    try {
      const response = await axios.get(`http://localhost:8000/api/product`);
      setProduct(response.data);
    } catch (error) {
      console.error("error fetching data", error);
    }
  };

  const updateProduct = async (productId, updatedData) => {
    try {
      const response = await axios.put(`http://localhost:8000/api/product/${productId}`, updatedData);
      setProduct(prevData =>
        prevData.map(product => (product._id === productId ? response.data : product))
      );
      setEditProduct(null); 
      console.log("Updated product:", response.data);
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const deleteProduct = async (productId) => {
    try {
      await axios.delete(`http://localhost:8000/api/product/${productId}`);
      fetchProduct();  
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  return (
    <div>

<div className="mt-4">
        <SearchFilter
          searchTerm={searchTerm}
          handleSearch={handleSearch}
          clearSearch={clearSearch}
        />
        <ProductList
          product={currentProducts}
          viewProduct={setSelector}
          updateProduct={updateSelector}
          deleteProduct={fetchProduct} // Refresh product list after deletion
        />

        <Pagination
          productsPerPage={productsPerPage}
          totalProducts={filteredProducts.length}
          paginate={paginate}
        />

  <MyForm
    updateProduct={updateProduct}
    editProduct={editProduct}
    setEditProduct={setEditProduct}
    setProduct={setProduct}
    fetchProduct={fetchProduct}
  />       
      </div>

  <ProductList
    product={product}
    viewProduct={setSelector}
    updateProduct={setEditProduct}
    deleteProduct={deleteProduct}
  />

  {selector && <ProductDetail product={selector} />}


    </div>
  );
}

export default App;
