import React, { useState } from 'react';
import { Form, Button, Row, Col, FormGroup, Label, Input } from 'reactstrap';
import axios from 'axios';

function SendEmail() {
    const [formData, setFormData] = useState({
        email: '',
        subject: '',
        message: ''
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:8000/api/send-email', formData);
            alert('Email sent successfully');
        } catch (error) {
            console.error('Error sending email:', error);
            alert('Failed to send email');
        }
    };

    return (
        <div>
            <h2>Send Email</h2>
            <Form onSubmit={handleSubmit}>
                <Row>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="email">Email</Label>
                            <Input
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                type="email"
                                required
                            />
                        </FormGroup>
                    </Col>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="subject">Subject</Label>
                            <Input
                                id="subject"
                                name="subject"
                                value={formData.subject}
                                onChange={handleInputChange}
                                type="text"
                                required
                            />
                        </FormGroup>
                    </Col>
                </Row>
                <FormGroup>
                    <Label for="message">Message</Label>
                    <Input
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        type="textarea"
                        required
                    />
                </FormGroup>
                <Button type="submit">Send Email</Button>
            </Form>
        </div>
    );
}

export default SendEmail;
