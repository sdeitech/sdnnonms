import React from 'react';
import { Input, Button } from 'reactstrap';

const SearchFilter = ({ searchTerm, handleSearch, clearSearch }) => {
    return (
        <div>
            <Input
                type="text"
                placeholder="Search by product name"
                value={searchTerm}
                onChange={handleSearch}
            />
            <Button color="secondary" onClick={clearSearch}>Clear</Button>
        </div>
    );
};

export default SearchFilter;
