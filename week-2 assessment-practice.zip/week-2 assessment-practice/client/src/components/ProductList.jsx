import React from 'react';
import Table from 'react-bootstrap/Table';
import { Button } from "react-bootstrap";


const ProductList = ({ product, viewProduct, updateProduct, deleteProduct }) => {
    return (
        <div>
            <h2>Product List</h2>
            <Table striped>
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Expiry Date</th>
                        <th>Manufacturer Name</th>
                    </tr>
                </thead>
                <tbody>
                    {product.length && product.map(product => (
                        <tr key={product._id}>
                            <td>{product.productName}</td>
                            <td>{product.description}</td>
                            <td>{product.quantity}</td>
                            <td>{product.expiryDate}</td>
                            <td>{product.manufacturerName}</td>
                            <td>
                                <Button className="me-2" onClick={() => viewProduct(product)}>View</Button>
                                <Button className="me-2" onClick={() => updateProduct(product)}>Edit</Button>
                                <Button onClick={() => deleteProduct(product._id)}>Delete</Button>
                            </td>

                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default ProductList;


