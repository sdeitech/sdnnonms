import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Label, Input, FormGroup, Row, Col, FormFeedback } from 'reactstrap';
import axios from "axios";

function MyForm({ updateProduct, editProduct, setEditProduct, setProduct, fetchProduct }) {
  const [formData, setFormData] = useState({
    productName: '',
    description: '',
    quantity: '',
    expiryDate: '',
    manufacturerName: '',
    image: null  // To store the selected image
  });

  // Error state to track validation errors
  const [errors, setErrors] = useState({});

  // Prefill form when editing a product
  useEffect(() => {
    if (editProduct) {
      setFormData({
        productName: editProduct.productName,
        description: editProduct.description,
        quantity: editProduct.quantity,
        expiryDate: editProduct.expiryDate,
        manufacturerName: editProduct.manufacturerName,
        image: null  // Reset image to null for edit mode
      });
    } else {
      setFormData({
        productName: '',
        description: '',
        quantity: '',
        expiryDate: '',
        manufacturerName: '',
        image: null
      });
    }
  }, [editProduct]);

  // Handle input change for text fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle file input change for image
  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] }); // Store the selected file
  };

  // Validate form data
  const validateForm = () => {
    const errors = {};

    // Check for required fields
    if (!formData.productName.trim()) errors.productName = "Product name is required";
    if (!formData.manufacturerName.trim()) errors.manufacturerName = "Manufacturer name is required";
    if (!formData.quantity || formData.quantity <= 0) errors.quantity = "Quantity must be a positive number";
    if (!formData.expiryDate) errors.expiryDate = "Expiry date is required";
    else if (new Date(formData.expiryDate) <= new Date()) errors.expiryDate = "Expiry date must be in the future";
    if (formData.image && formData.image.size > 5 * 1024 * 1024) errors.image = "Image size should be less than 5MB"; // Example for image size validation

    setErrors(errors);

    // Return true if no errors
    return Object.keys(errors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return; // Stop form submission if validation fails

    const data = new FormData();
    data.append('productName', formData.productName);
    data.append('description', formData.description);
    data.append('quantity', formData.quantity);
    data.append('expiryDate', formData.expiryDate);
    data.append('manufacturerName', formData.manufacturerName);

    // Append the file if available
    if (formData.image) {
      data.append('image', formData.image);
    }

    try {
      const response = await axios.post(`http://localhost:8000/api/product`, data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      console.log('Product added', response.data);
      setProduct(prevProduct => [...prevProduct, response.data]);
      fetchProduct();  // Fetch updated products list
    } catch (error) {
      console.error("Error uploading product", error);
    }

    // Clear the form
    setFormData({
      productName: '',
      description: '',
      quantity: '',
      expiryDate: '',
      manufacturerName: '',
      image: null
    });
    setEditProduct(null);
  };

  return (
    <div>
      <h1>{editProduct ? 'Edit Product' : 'Add Product'}</h1>
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="productName">Product Name</Label>
              <Input
                id="productName"
                name="productName"
                value={formData.productName}
                onChange={handleInputChange}
                type="text"
                invalid={!!errors.productName} // Show error if validation fails
                required
              />
              <FormFeedback>{errors.productName}</FormFeedback>
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="description">Description</Label>
              <Input
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                type="text"
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="quantity">Quantity</Label>
              <Input
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleInputChange}
                type="number"
                invalid={!!errors.quantity} // Show error if validation fails
              />
              <FormFeedback>{errors.quantity}</FormFeedback>
            </FormGroup>
            <FormGroup>
              <Label for="expiryDate">Expiry Date</Label>
              <Input
                id="expiryDate"
                name="expiryDate"
                value={formData.expiryDate}
                onChange={handleInputChange}
                type="date"
                invalid={!!errors.expiryDate} // Show error if validation fails
              />
              <FormFeedback>{errors.expiryDate}</FormFeedback>
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="manufacturerName">Manufacturer Name</Label>
              <Input
                id="manufacturerName"
                name="manufacturerName"
                value={formData.manufacturerName}
                onChange={handleInputChange}
                type="text"
                invalid={!!errors.manufacturerName} // Show error if validation fails
              />
              <FormFeedback>{errors.manufacturerName}</FormFeedback>
            </FormGroup>
          </Col>
        </Row>

        {/* File input for image upload */}
        <input type="file" name="image" onChange={handleFileChange} />
        {errors.image && <p className="text-danger">{errors.image}</p>} {/* Display image validation error */}

        <Button type="submit">{editProduct ? 'Update Product' : 'Add Product'}</Button>
      </Form>
    </div>
  );
}

export default MyForm;
