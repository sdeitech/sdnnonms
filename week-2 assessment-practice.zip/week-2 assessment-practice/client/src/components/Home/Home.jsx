import { useEffect, useState } from 'react';
import MyForm from './Form';
import ProductDetail from './ProductDetail';
import ProductList from './ProductList';
import axios from 'axios';
import SearchFilter from './SearchFilter';
import Pagination from './Pagination';

function Home() {
    const [product, setProduct] = useState([]);
    const [selector, setSelector] = useState(null);
    const [editProduct, setEditProduct] = useState(null);
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [productsPerPage] = useState(5);

    useEffect(() => {
        fetchProduct();
    }, []);

    const fetchProduct = async () => {
        try {
            const response = await axios.get(`http://localhost:8000/api/product`);
            setProduct(response.data);
            setFilteredProducts(response.data); // Initialize filteredProducts
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
        if (e.target.value !== '') {
            const filtered = product.filter(p =>
                p.productName.toLowerCase().includes(e.target.value.toLowerCase())
            );
            setFilteredProducts(filtered);
        } else {
            setFilteredProducts(product);
        }
    };

    const clearSearch = () => {
        setSearchTerm('');
        setFilteredProducts(product);
    };

    const indexOfLastProduct = currentPage * productsPerPage;
    const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
    const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const updateProduct = async (productId, updatedData) => {
        try {
            const response = await axios.put(`http://localhost:8000/api/product/${productId}`, updatedData);
            setProduct(prevData =>
                prevData.map(product => (product._id === productId ? response.data : product))
            );
            setEditProduct(null);
        } catch (error) {
            console.error('Error updating product:', error);
        }
    };

    const deleteProduct = async (productId) => {
        try {
            await axios.delete(`http://localhost:8000/api/product/${productId}`);
            fetchProduct();
        } catch (error) {
            console.error('Error deleting product:', error);
        }
    };

    return (
        <div>
            <div className="mt-4">
                <SearchFilter
                    searchTerm={searchTerm}
                    handleSearch={handleSearch}
                    clearSearch={clearSearch}
                />
                <ProductList
                    product={currentProducts}
                    viewProduct={setSelector}
                    updateProduct={setEditProduct}
                    deleteProduct={deleteProduct}
                />
                <Pagination
                    productsPerPage={productsPerPage}
                    totalProducts={filteredProducts.length}
                    paginate={paginate}
                />
                <MyForm
                    updateProduct={updateProduct}
                    editProduct={editProduct}
                    setEditProduct={setEditProduct}
                    setProduct={setProduct}
                    fetchProduct={fetchProduct}
                />
            </div>
            {selector && <ProductDetail product={selector} />}
        </div>
    );
}

export default Home;
