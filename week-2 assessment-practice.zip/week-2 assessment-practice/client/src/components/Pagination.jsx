import React from 'react';
import { Pagination as BootstrapPagination, PaginationItem, PaginationLink } from 'reactstrap';

const Pagination = ({ productsPerPage, totalProducts, paginate }) => {
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(totalProducts / productsPerPage); i++) {
        pageNumbers.push(i);
    }

    return (
        <BootstrapPagination>
            {pageNumbers.map(number => (
                <PaginationItem key={number}>
                    <PaginationLink onClick={() => paginate(number)} href="#">
                        {number}
                    </PaginationLink>
                </PaginationItem>
            ))}
        </BootstrapPagination>
    );
};

export default Pagination;
