const Joi = require('joi');

const validateProduct = (data) => {
    const schema = Joi.object({
        productName: Joi.string().required(),
        description: Joi.string(),
        quantity: Joi.number().integer().min(1).required(),
        expiryDate: Joi.date().greater('now').required(),
        manufacturerName: Joi.string().required(),
        // Add any other validation rules you need
    });

    return schema.validate(data);
};

module.exports = { validateProduct };
