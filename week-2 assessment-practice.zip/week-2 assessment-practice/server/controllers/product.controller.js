const Product = require('../models/product.model');
var mongoose = require('mongoose');
const { validateProduct } = require('../validators/productValidation'); // Joi validation


// Create Product Controller
exports.createProduct = async (req, res) => {
    // Validate product input using Joi
    const { error } = validateProduct(req.body);
    if (error) {
        return res.status(400).json({ error: error.details[0].message });
    }

    try {
        const newproduct = new Product(req.body);
        await newproduct.save();
        res.status(201).json(newproduct);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get All Products Controller
exports.getProduct = async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get Product by ID Controller
exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Update Product Controller
exports.updateProduct = async (req, res) => {
    // Validate product input using Joi
    const { error } = validateProduct(req.body);
    if (error) {
        return res.status(400).json({ error: error.details[0].message });
    }

    try {
        const updatedProduct = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedProduct) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(updatedProduct);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Delete Product Controller
exports.deleteProduct = async (req, res) => {
    try {
        const deletedProduct = await Product.findByIdAndDelete(req.params.id);
        if (!deletedProduct) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json({ message: 'Product deleted' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Upload Product Image Controller
exports.uploadProductImage = (req, res) => {
    try {
        const { filename } = req.file;

        if (!filename) {
            return res.status(400).json({ message: 'No file uploaded' });
        }

        // Construct image path
        const productImage = `/uploads/${filename}`;

        // Example of saving the image URL into a product
        const productData = {
            image: productImage,
            // other product details can be here
        };

        // Save the product to the database (pseudo-code, replace with actual DB logic)
        Product.create(productData)
            .then(product => {
                res.status(201).json({ message: 'Product created', product });
            })
            .catch(error => {
                res.status(500).json({ message: 'Error saving product', error });
            });
    } catch (error) {
        res.status(500).json({ message: 'Error uploading file', error });
    }
};




// module.exports = router;
