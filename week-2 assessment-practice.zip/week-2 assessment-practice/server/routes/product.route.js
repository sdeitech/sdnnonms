const express = require('express');
const router = express.Router();
const ProductController = require('../controllers/product.controller');
const { sendEmail } = require('../services/emailService');

const { upload } = require('../helper/multer');

router.post('/product',ProductController.createProduct);

router.get('/product', ProductController.getProduct);

router.get('/product/:id',ProductController.getProductById);

router.put('/product/:id', ProductController.updateProduct);

router.delete('/product/:id', ProductController.deleteProduct);

router.post("/upload", upload.single('image'), ProductController.uploadProductImage);

router.post('/send-email', (req, res) => {
    const { email, subject, message } = req.body;
    const htmlContent = `<p>${message}</p>`;

    const result = sendEmail(email, subject, htmlContent);

    if (result) {
        res.status(200).json({ message: 'Email sent successfully' });
    } else {
        res.status(500).json({ message: 'Failed to send email' });
    }
});


