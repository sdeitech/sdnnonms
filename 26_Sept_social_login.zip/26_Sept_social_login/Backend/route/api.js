import express from 'express';

import { loginWithGoogle } from '../controllers/auth/LoginController.js'

const router = express.Router();

// For Login with google
router.post('/login-with-google', loginWithGoogle);

export default router;
