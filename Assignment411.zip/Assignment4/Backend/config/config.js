export const config = {
    local: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT:3215,
    },
    stagg: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3215,
    },
    prod: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment4",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3215,
    },
  };
  