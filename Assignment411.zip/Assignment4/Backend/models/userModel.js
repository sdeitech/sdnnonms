import mongoose from "mongoose";
import Userlist from "./userList";
const Schema = mongoose.Schema;
 
//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },
  DOB: {
    type: String,
  },
  password: {
    type: String,
  },
  gender: {
    type: String,
    enum: ["male", "female"],
  },
  profile:{
    type:String,
  },
  // userss : [
  //   {
  //       type:mongoose.Schema.Types.ObjectId,
  //       // ref:"userlist"
  //   }
  // ] ,
  createdBy : 
    {
        type:mongoose.Schema.Types.ObjectId,
        
    }
 
});

const Users = mongoose.model("Users", UserSchema);
export default Users;