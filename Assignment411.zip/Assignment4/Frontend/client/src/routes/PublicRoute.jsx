import SignIn from "../components/SignIn";
import SignUp from "../components/signUp";
import PublicLayout from "../layout/PublicLayout";
import Updateregistrationform from "../constants/updateregistrationform";
import Dashboard from "../components/Dashboard";

const PublicRoutes = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignUp />
       
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignUp />
      </PublicLayout>
    ),
  },
  {
    path: "/update",
    element: (
      <PublicLayout>
        <Updateregistrationform />
      </PublicLayout>
    ),
  },
  {
    path: "/back",
    element: (
      <PublicLayout>
        <Dashboard />
      </PublicLayout>
    ),
  },
  {
    path: "/out",
    element: (
      <PublicLayout>
        <SignIn />
      </PublicLayout>
    ),
  },
  {
    path: "/register",
    element: (
      <PublicLayout>
        <SignUp/>
      </PublicLayout>
    ),
  },

];
export default PublicRoutes;