import React from "react";
import { Link } from "react-router-dom"
import DataTable from "./datatable";
const Dashboard = () => {
  
  return (

    <div> <h1>Welcome to  Dashboard! please click on add user button to insert the users</h1> <Link to={"/adduser"}><button >Add User</button></Link>

      <Link to={"/update"}><button >My Profile</button></Link>
      <Link to={"/out"}><button >Log Out </button></Link>
    
      <DataTable />
    </div>
  );
};

export default Dashboard;