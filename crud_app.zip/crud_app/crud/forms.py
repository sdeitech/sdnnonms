# from django import forms
# from .models import UserProfile

# class UserProfileForm(forms.ModelForm):
#     class Meta:
#         model = UserProfile
#         fields = ['name', 'email', 'gender', 'dob', 'terms_and_conditions', 'profile_image']
#         widgets = {
#             'dob': forms.DateInput(attrs={'type': 'date'}),
#             'terms_and_conditions': forms.CheckboxInput(),
#         }

#     def __init__(self, *args, **kwargs):
#         super(UserProfileForm, self).__init__(*args, **kwargs)
#         self.fields['name'].widget.attrs.update({'class': 'form-control'})
#         self.fields['email'].widget.attrs.update({'class': 'form-control'})
#         self.fields['gender'].widget.attrs.update({'class': 'form-control'})
#         self.fields['dob'].widget.attrs.update({'class': 'form-control'})
#         self.fields['profile_image'].widget.attrs.update({'class': 'form-control-file'})



from django import forms
from .models import UserProfile

class UserProfileForm(forms.ModelForm):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]
    
    gender = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.RadioSelect)
    
    class Meta:
        model = UserProfile
        fields = ['name', 'email', 'gender', 'dob', 'terms_and_conditions', 'profile_image']
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
            'terms_and_conditions': forms.CheckboxInput(),
        }

    def __init__(self, *args, **kwargs):
        super(UserProfileForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'form-control'})
        self.fields['email'].widget.attrs.update({'class': 'form-control'})
        self.fields['dob'].widget.attrs.update({'class': 'form-control'})
        self.fields['profile_image'].widget.attrs.update({'class': 'form-control-file'})
