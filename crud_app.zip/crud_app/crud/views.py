from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from .models import UserProfile

class UserProfileCreateView(View):
    def get(self, request):
        return render(request, 'create_profile.html')

    def post(self, request):
        name = request.POST.get('name')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        terms_and_conditions = True if request.POST.get('terms_and_conditions') == "on" else False
        profile_image = request.FILES.get('profile_image')

        user_profile = UserProfile(
            name=name,
            email=email,
            gender=gender,
            dob=dob,
            terms_and_conditions=terms_and_conditions,
            profile_image=profile_image
        )
        user_profile.save()

        return redirect('profile_success')


class ProfileSuccessView(View):
    def get(self, request):
        users = UserProfile.objects.all()  
        
        context = {
            'users': users,
            'success_message': 'Your profile has been successfully created.'  
        }
        return render(request, 'profile_success.html', context)


class UserProfileUpdateView(View):
    def get(self, request, user_id):
        user_profile = get_object_or_404(UserProfile, id=user_id)
        
        context = {
            'user_profile': user_profile
        }
        return render(request, 'update_profile.html', context)

    def post(self, request, user_id):
        user_profile = get_object_or_404(UserProfile, id=user_id)
        
        user_profile.name = request.POST.get('name')
        user_profile.email = request.POST.get('email')
        user_profile.gender = request.POST.get('gender')
        user_profile.dob = request.POST.get('dob')
        user_profile.terms_and_conditions = True if request.POST.get('terms_and_conditions') == "on" else False
        profile_image = request.FILES.get('profile_image')
        
        if profile_image:
            user_profile.profile_image = profile_image

        user_profile.save()
        
        return redirect('profile_success')

class UserProfileDeleteView(View):
    def get(self, request, user_id):
        user_profile = get_object_or_404(UserProfile, id=user_id)
        
        user_profile.delete()
        
        return redirect('profile_success')
