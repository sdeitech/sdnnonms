from django.urls import path
from .views import UserProfileCreateView, ProfileSuccessView ,UserProfileDeleteView,UserProfileUpdateView

urlpatterns = [
    path('', UserProfileCreateView.as_view(), name='create_profile'),
    path('profile-success/', ProfileSuccessView.as_view(), name='profile_success'), 
    path('delete-profile/<int:user_id>/', UserProfileDeleteView.as_view(), name='delete_profile'),
    path('update-profile/<int:user_id>/', UserProfileUpdateView.as_view(), name='update_profile'),  # Update the URL pattern
]
