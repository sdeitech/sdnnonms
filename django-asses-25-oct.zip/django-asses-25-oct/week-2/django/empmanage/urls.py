from django.urls import path
from .views import CreateEmployee, GetEmployee, UpdateEmployee,DeleteEmployee,GetEmployeeById

urlpatterns = [
    path('', CreateEmployee.as_view(), name="employee_form"),
    path('get/', GetEmployee.as_view(), name="get_employee"),
    path('getid/<int:id>', GetEmployeeById.as_view(), name="getEmpById"),
    path('delete_employee/<int:id>', DeleteEmployee.as_view(), name='delete_employee'),
    path('update_employee/<int:id>', UpdateEmployee.as_view(), name="update_employee")    
]
