from django.shortcuts import render, redirect
from .models import Employee
from django.views import View 

class GetEmployee(View):
    def get(self, request):
        emp_obj = Employee.objects.all()
        return render(request, 'employee_list.html', {'emp_obj': emp_obj})

class GetEmployeeById(View):
    def get(self, request, id):
        emp_obj = Employee.objects.get(id=id)
        print(id)
        print(emp_obj)
        return render(request, 'employee_detail.html', {'emp_obj': emp_obj})

class CreateEmployee(View):
    def get(self, request):
        emp_obj = Employee.objects.all()
        return render(request, 'employee_form.html', {'emp_obj': emp_obj})
    
    def post(self, request):
        e_id = request.POST.get('e_id')
        f_name = request.POST.get('f_name')
        l_name = request.POST.get('l_name')
        dep = request.POST.get('dep')
        pos = request.POST.get('pos')
        dob = request.POST.get('dob')
        d_join = request.POST.get('d_join')
        salary = request.POST.get('salary')
        is_full = request.POST.get('is_full', False) == 'on'
        email = request.POST.get('email')
        phone_no = request.POST.get('phone_no')
        add = request.POST.get('add')
        city = request.POST.get('city')
        state = request.POST.get('state')
        last_review = request.POST.get('last_review')

        Employee.objects.create(
            employee_id = e_id,
            first_name = f_name,
            last_name = l_name,
            department = dep,
            position = pos,
            date_of_birth = dob,
            date_joined = d_join,
            salary = salary,
            is_full_time = is_full,
            email = email,
            phone_number = phone_no,
            address = add,
            city = city,
            state = state,
            last_performance_review = last_review
        )
        obj = Employee.objects.all()
        return redirect('/get')
    

    
class DeleteEmployee(View):
    def get(self, request,id):
        emp_obj = Employee.objects.get(id=id)
        emp_obj.delete()
        return redirect('/get')
    
class UpdateEmployee(View):
    def get(self,request,id):
        emp_obj = Employee.objects.get(id=id)
        context = {'emp_obj': emp_obj}
        return render(request, 'employee_update.html', context)
    
    def post(self,request,id):
        e_id = request.POST.get('e_id')
        f_name = request.POST.get('f_name')
        l_name = request.POST.get('l_name')
        dep = request.POST.get('dep')
        pos = request.POST.get('pos')
        dob = request.POST.get('dob')
        d_join = request.POST.get('d_join')
        salary = request.POST.get('salary')
        is_full = request.POST.get('is_full')
        email = request.POST.get('email')
        phone_no = request.POST.get('phone_no')
        add = request.POST.get('add')
        city = request.POST.get('city')
        state = request.POST.get('state')
        last_review = request.POST.get('last_review')

        print(dob)
        print(d_join)
        emp_obj = Employee.objects.get(id=id)

        if e_id:
            emp_obj.employee_id = e_id

        if f_name:
            emp_obj.first_name = f_name
    
        if l_name:
            emp_obj.last_name = l_name

        if dep:
            emp_obj.department = dep

        if pos:
            emp_obj.position = pos
        
        if dob:
            emp_obj.date_of_birth = dob
        
        if d_join:
            emp_obj.date_joined = d_join

        if salary:
            emp_obj.salary = salary

        if is_full == 'on':
            emp_obj.is_full_time = True
        else:
            emp_obj.is_full_time = False 

        if email:
            emp_obj.email = email

        if phone_no:
            emp_obj.phone_number = phone_no
        
        if add:
            emp_obj.address = add
        
        if city:
            emp_obj.city = city
        
        if state:
            emp_obj.state = state
        
        if last_review:
            emp_obj.last_performance_review = last_review

        emp_obj.save()
        return redirect('/get')

