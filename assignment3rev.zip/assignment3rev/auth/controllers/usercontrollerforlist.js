// import Userlist from "../models/usermodelforuserlist"
// import Users from "../models/users";

// exports.addUserInList = async (req, res) => {
//     try {
//       console.log("req.body.........",req.body)
//       const newUser = new Userlist(req.body);
//       await newUser.save();
//       return res.status(201).json({newUser});
//     } catch (error) {
//       res.status(400).json({ error: error.message });
//     }
//   };
//   exports.getUserInList = async (req, res) => {
//     try {
//       const users = await Userlist.find();
//       res.json({ users: users, message: "Logged Successful" });
//     } catch (error) {
//       res.status(500).json({ error: error.message });
//     }
//   };
//   exports.updateUserInList = async(req,res)=>{
//     const{id}=req.params;
//     try{
     
//      if(id)
//      {
//        const updateUser = await Users.findByIdAndUpdate(id,req.body);
//        return res.status(200).json(getUpdatedData);
//         }
        
//         else{
//             return res.status(400).json({message:"id not found"});
//         }
//      }
//      catch(error)
//      {
//         return res.status(400).json(error);
//      }
//     };
//     exports.updateUser = async(req,res)=>{
//       const{id}=req.params;
//       console.log(">......",id)
//       try{
       
//        if(id)  
//        {
//         console.log(req.body);
//          const updateUser = await Users.findByIdAndUpdate(id,req.body);
//          console.log(req.body);
         
//          return res.status(200).json(updateUser);
//           }
          
//           else{
//               return res.status(400).json({message:"id not found"});
//           }
//        }
//        catch(error)
//        {
//           return res.status(400).json(error);
//        }
//       };