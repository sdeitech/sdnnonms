// import express from "express";
// import addUserInList  from "../controllers/usercontrollerforlist"
// import getUserInList from "../controllers/usercontrollerforlist"
// import updateUserInList from "../controllers/usercontrollerforlist"
// const Router = express.Router();

// Router.post("/postdata",addUserInList)
// Router.get("/getdataInList",getUserInList)
// Router.put("/updateUserInList",updateUserInList)


// export default Router;