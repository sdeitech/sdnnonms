import express from "express";
import { getRegisterUserById,registerUser, userLogin,getUsers,getdatabyemail,addUserInList,getUserInList,updateUserInList,updateUser} from "../controllers/users";
//  import {addUserInList,getUserInList,updateUserInList,updateUser} from "../controllers/usercontrollerforlist";
import { uploadMiddleware } from "../helpers/multer";
const userRouter = express.Router();

//signup api call
userRouter.post("/signup", uploadMiddleware.single("profile"), registerUser);

//login api call
userRouter.post("/login", userLogin);

userRouter.get("/getdata",getUsers)

userRouter.post("/postdata",addUserInList)

userRouter.get("/getdataInList",getUserInList)

userRouter.put("/updateUserInList/:id",updateUserInList)
userRouter.put("/updateUser/:id", uploadMiddleware.single("profile"),updateUser)
// userRouter.put("/updateUserInList",updateUserInList)

userRouter.get("/getdatausingemail/:email",getdatabyemail)
userRouter.get("/getRegisterUserById",getRegisterUserById)

export default userRouter;
