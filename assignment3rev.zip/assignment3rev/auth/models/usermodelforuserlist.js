import mongoose from "mongoose";
const Schema = mongoose.Schema;

 
//user schema
const UserSchema = new Schema({
  firstname: {
    type: String,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
  },
  gender: {
    type: String,
  },
  phone: {
    type: Number,
  },
  users : [
    {
        type:mongoose.Schema.Types.ObjectId,
        ref:"Users"
    }
  ]
 
})

const Userlist = mongoose.model("userlist", UserSchema);
export default Userlist;