import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
//const apiUrl = process.env.REACT_APP_API_URL;
import validation from "./validation";



const SignIn = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error,setError] =useState({})

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const error = validation(formData)
    setError(error)
    console.log(error)
    try {
      const res = await axios.post("http://localhost:3002/api/login", formData);
      console.log(res.data);
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("email", res.data.email);
      navigate("/dashboard");
    } catch (error) {
      console.log(error.message);
    }
  };
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh', // Full screen height
        background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)', // Gradient background
      }}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: '#fff',
          padding: '40px',
          borderRadius: '12px',
          boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)', // Shadow effect
          width: '400px',
          textAlign: 'center',
        }}
      >
        <h1 style={{ fontSize: '28px', marginBottom: '20px', color: '#333' }}>
          Login
        </h1>
        <form
          onSubmit={handleSubmit}
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '100%',
          }}
        >
          <input
            type="email"
            name="email"
            placeholder="Email Address"
            onChange={handleChnage}
            required
            // {error.email && <p className="error">{error.email}</p>}
            style={{
              padding: '12px',
              marginBottom: '15px',
              borderRadius: '8px',
              border: '1px solid #ddd',
              fontSize: '16px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              transition: 'border-color 0.3s ease',
            }}
          />
               {error.email && <p style={{ color: "red" }}>{error.email}</p>}
          <input
            type="password"
            name="password"
            placeholder="Password"
            onChange={handleChnage}
            required
            // {error.password && <p className="error">{error.password}</p>}
            style={{
              padding: '12px',
              marginBottom: '20px',
              borderRadius: '8px',
              border: '1px solid #ddd',
              fontSize: '16px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              transition: 'border-color 0.3s ease',
            }}
          />
                {error.password && <p style={{ color: "red" }}>{error.password}</p>}
          <button
            type="submit"
            style={{
              padding: '12px',
              borderRadius: '8px',
              backgroundColor: '#28a745',
              color: 'white',
              fontSize: '16px',
              border: 'none',
              cursor: 'pointer',
              marginBottom: '15px',
              boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ease',
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = '#218838')}
            onMouseOut={(e) => (e.target.style.backgroundColor = '#28a745')}
          >
            Login
          </button>
        </form>
        <p style={{ marginTop: '10px', color: '#666' }}>
          Don't have an account?{' '}
          <a
            href="/register"
            style={{
              color: '#007bff',
              textDecoration: 'none',
              fontWeight: 'bold',
            }}
            onMouseOver={(e) => (e.target.style.textDecoration = 'underline')}
            onMouseOut={(e) => (e.target.style.textDecoration = 'none')}
          >
            Sign Up
          </a>
        </p>
      </div>
    </div>
  );
};
export default SignIn;