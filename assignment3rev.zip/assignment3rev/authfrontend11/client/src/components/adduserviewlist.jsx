import React from "react"
const View = ({curruntUser,showview,setshowview}) => {
    return (
      <div style={{border:"solid 1px",backgroundColor:"aquamarine",position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:"400px", color:"green",margin:"auto",textAlign:"center"}}>   
      <p>firstname :{curruntUser?.firstname}</p>
      <p>lastname :{curruntUser?.lastname}</p>
      <p>email :{curruntUser?.email}</p>
      <p>gender:{curruntUser?.gender}</p>
      <p>phone:{curruntUser?.phone}</p>
     
      
      
      <button onClick={()=>
  
          {setshowview(!showview)}
      }>close</button>
      </div>
    )
  }
  
  export default View;