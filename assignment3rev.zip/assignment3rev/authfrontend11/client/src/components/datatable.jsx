import React, { useEffect, useState } from "react";
import axios from "axios";

import View from "./adduserviewlist";

const DataTable = () => {
    const [data, setData] = useState([]);
    const fetchData = async () => {
        try {
            const response = await axios.get(
                "http://localhost:3002/api/getdataInList"
            );
            console.log(response.data.users, "hhhgghhghh");

            setData(response.data.users);
            // console.log(setData);
        } catch (error) {
            console.log("error fetching data");
        }
    };


    useEffect(() => {
        fetchData();
    }, [])

    const [currentPage,setCurrentPage]=useState(1);
    const [recordsPerPage] =useState(5);
    
    
    const indexOfLastRecord = currentPage*recordsPerPage;
    const indexOfFirstRecord=indexOfLastRecord-recordsPerPage;
    
    const currentRecords = data.slice(indexOfFirstRecord,indexOfLastRecord)
    console.log(currentPage)
    const nPages = Math.ceil(data.length/recordsPerPage);
    
    const pageNumbers = [...Array(nPages+1).keys()].slice(1);
    
    const goToNextPage =()=>{
      if(currentPage!==nPages)
        setCurrentPage(currentPage+1);
    }
    
    const goToPrevPage =()=>{
      if(currentPage!==1)
        setCurrentPage(currentPage-1)
    }

    const [curruntUser, setcurruntUser] = useState(null);


    const [showview, setshowview] = useState(false)

    const Handleview = (data) => {
        setshowview(!showview)
        setcurruntUser(data)

    }
    return (
        <div>
            <table border="1">
                

                <thead>
                    <tr >
                        <th>srno</th>
                        <th>firstname</th>
                        <th>lastname</th>
                        <th>email</th>
                        <th>gender</th>
                        <th>phone</th>
                       
                    </tr>
                </thead>
                <tbody>
                    {currentRecords && currentRecords.map((item, i) => {
                        return (
                            <tr key={i}>
                                <td>{i+1}</td>
                                {/* <td>{item.srno}</td> */}
                                <td>{item.firstname}</td>
                                <td>{item.lastname}</td>
                                <td>{item.email}</td>
                                <td>{item.gender}</td>
                                <td>{item.phone}</td>
                                <button onClick={() => Handleview(item)} >View</button>
                            </tr>
                        )
                    }
                    )}
                </tbody>
            </table>

            {showview && <View curruntUser={curruntUser} showview={showview} setshowview={setshowview} />}





            <nav>
           <ul className="pagination justify-content-center">
              <li className="page-item">
                <a className="page-link" 
                onClick={goToPrevPage}
                href="#"
                >Previous
                  
                </a>

              </li>

               {pageNumbers.map(pgNumbers=>(
                <li key={pgNumbers} 
                className={`page-item ${currentPage==pgNumbers ? 'active':''}`}
                >
                  <a onClick={()=>setCurrentPage(pgNumbers)}
                    className="page-link"
                    href="#" > 
                    {pgNumbers}
                    
                       </a>
                </li>
               ))}

                <li className="page-item">
                <a className="page-link" 
                onClick={goToNextPage}
                href="#"
                >Next
                  
                </a>

              </li>

            </ul>
           </nav>

        </div>
    );
};
export default DataTable;