// import * as React from 'react';

// // import  { useContext } from 'react';
// import Pagination from '@mui/material/Pagination';
// import Stack from '@mui/material/Stack';

// export default function BasicPagination() {
// //   const { currPage, setCurrPage, totalPage } = useContext(userContext)
// //   const handlePage = (event, page) => {
// //     setCurrPage(page)
// //   }
//   return (
//     <Stack spacing={2}>
//       {/* <Pagination count={10} /> */}
//       <Pagination count={10} color="primary" />
//       {/* <Pagination count={10} color="secondary" /> */}
//       {/* <Pagination count={10} disabled /> */}
//       {/* onChange={handlePage} */}
//     </Stack>
//   );

// }



// import { userContext } from '../context/AppContext';


// const PaginationRounded = () => {
 
//   return (
//     <Stack spacing={2}>
//       <Pagination
//         count={totalPage || 1}
//         page={currPage || 1}
//         onChange={handlePage}
//         variant="outlined"
//         shape="rounded" />
//     </Stack>
//   );
// }

// export default PaginationRounded