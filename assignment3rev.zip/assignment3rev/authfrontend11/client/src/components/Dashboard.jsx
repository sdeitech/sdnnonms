import React  from "react";
//import DataTable from "./datatable";
//import userlist from "./const/userlist";
import { Link } from "react-router-dom"
import DataTable from "./datatable";
//import BasicPagination from "./BasicPagination";
//import { Pagination } from "@mui/material";

const Dashboard = () => {

  



  return (
    
    <div> <h1>Welcome to  Dashboard! please click on add user button to insert the users</h1> <Link to={"/adduser"}><button >Add User</button></Link>
       
       <Link to={"/update"}><button >My Profile</button></Link>
       <Link to={"/out"}><button >Log Out </button></Link>
     <input type="text" placeholder="search"/>


     
       
<DataTable/>
{/*       
<BasicPagination/>       */}
    </div>
    
  );
};

export default Dashboard;

