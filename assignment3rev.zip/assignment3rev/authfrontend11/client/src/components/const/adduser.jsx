import React, { useState } from "react";
import axios from 'axios'
import { useNavigate } from "react-router-dom";
import validation from "../validation";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";


function AddUser() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
  firstname :"",
  lastname :"",
  email :"",
  gender:"",
  phone:""
});
const [curruntUser, setcurruntUser] = useState(null);
// const [error, setError] = useState({});
const handleInputChange = (e) => {
  const {name,value} =e.target;
  setUser({...user,[name]:value});
};

const handleSubmit = async (e) => {
  e.preventDefault();
  
  const error = validation(setUser)
  // setError(error)
  console.log(error)
  

  try{
    const response = await axios.post("http://localhost:3002/api/postdata",user);
    
  
  console.log("user data submitted :", response.user);
  navigate("/dashboard");
  }catch(err){
    console.error("Error in submitting form:",err.message);
    
  }
  setUser({
    firstname :"",
  lastname :"",
  email :"",
  gender:"",
  phone:""
  });
};

  // function add() {
  //   // HERE is the change, you need to keep the previous values 
  //   setAddNew([...addNew, <NewUser />]);
  // }



  return (
    
    <div style={{border:"2px solid", alignContent:"center"}}>
      <h2>Add User</h2>
      <form onSubmit={handleSubmit}>
      <div>
        <label>firstname:</label>
        <input type="text"
        name="firstname"
        value={user.firstname}
        onChange={handleInputChange}required
        // {error.firstname && <p className="error">{error.firstname}</p>}
        />
      </div>
      <div>
        <label>lastname:</label>
        <input type="text"
        name="lastname"
        value={user.lastname}
        onChange={handleInputChange}required
        // {error.lastname && <p className="error">{error.lastname}</p>}
        />
      </div>
      <div>
        <label>email:</label>
        <input type="email"
        name="email"
        value={user.email}
        onChange={handleInputChange}required
        // {error.email && <p className="error">{error.email}</p>}
        />
      </div>
      <div>
      <label>gender:</label>
      <select name="gender"
        value={user.gender}
        onChange={handleInputChange}required >
           {/* {error.gender && <p className="error">{error.gender}</p>} */}
          <option value="">select gender</option>
          <option value="male">male</option>
          <option value="female">female</option>
          <option value="female">female</option>
        </select>
      <div>
        <label>phone:</label>
        <input type="Number"
        name="phone"
        value={user.phone}
        onChange={handleInputChange}required
        // {error.phone && <p className="error">{error.phone}</p>}
        />
      </div>
      <button type="submit">Submit</button>
      {/* navigate("/dashboard"); */}
    </div>
    </form>
    </div>
  );
}

export default AddUser;

