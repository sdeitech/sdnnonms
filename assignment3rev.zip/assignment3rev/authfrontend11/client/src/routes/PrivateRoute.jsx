import Dashboard from "../components/Dashboard";
import PrivateLayout from "../layout/PrivateLayout";
import AddUser from "../components/const/adduser";

const PrivateRoutes = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },
  {
    path:"/adduser",
    element: (
      <PrivateLayout>
        <AddUser/>
      </PrivateLayout>
    ),
  },
];
export default PrivateRoutes;




///////////////////

// const PrivateRoutes = [
//   {
//     // path: "/dashboard",
//     path:"/datatable",
//     element: (
//       <PrivateLayout>
//         {/ <Dashboard /> /}
//         <DataTable/>
//       </PrivateLayout>
//     ),
//   },
//   {
//     path:"/adduser",
//     element: (
//       <PrivateLayout>
//         <AddUser/>
//       </PrivateLayout>
//     ),
//   },
// ];
