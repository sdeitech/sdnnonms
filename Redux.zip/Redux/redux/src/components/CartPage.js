import React from "react";
import { useSelector } from "react-redux";
 
 function CartPage() {
    const{cart, totalquantity,totalprice}=useSelector((state)=>state.all_cart);


   return (
     <div>
        {
            cart.map((data)=>{
                <p>
                    <strong>{data.title}</strong>
                </p>
            })
        }
       <p>product</p>

       <p>totalquantity<span>0</span></p>
       <p>price<span><strong>0</strong></span></p>
     </div>
   )
 }
 
 export default CartPage;
 