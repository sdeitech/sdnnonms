import './App.css';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import cartPage from './components/CartPage';
import {BrowserRouter, Routes,Route} from 'react-router-dom';

function App() {
  return (
    // <BrowserRouter>
    <div >
      <h1>Hello</h1>
      <Navbar/>
      {/* <Routes> */}
        {/* <Route path="/" element={<ProductCard/>}/> */}
        {/* <Route path="/cart" element={<cartPage/>}/> */}
      {/* </Routes> */}
      <ProductCard/>
    </div>
   
  );
}

export default App;
