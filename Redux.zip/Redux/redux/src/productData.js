export default [
    {
        id:1,
        title:"My first Product",
        img:"https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=600",
        price:200.0,
        quantity:1,
    },
    {
        id:2,
        title:"My second Product",
        img:"https://images.pexels.com/photos/335257/pexels-photo-335257.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
        price:500.0,
        quantity:1,
    },
]