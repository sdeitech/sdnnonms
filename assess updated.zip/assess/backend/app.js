const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const profileRouter = require('./routes/profileRoute')
const db = require('./config/db');

const app = express();

app.use(cors({ origin: "*" }));

app.use(express.json());

app.use(bodyParser.json());

app.use('/api', profileRouter);

export default app;
