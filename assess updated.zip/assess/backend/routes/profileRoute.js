const express = require('express');
const router = express.Router();
const profileController = require('../controller/profileController')
import profileDetailController from '../controller/profileDetailController';

router.post('/register', profileController.registerUser)
router.post('/login', profileController.loginUser)

router.get('/user', profileDetailController.getUser);
router.post('/create', profileDetailController.createUser);
router.get('/user/:id', profileDetailController.getUserId);
router.put('/user/:id', profileDetailController.updateUser);
router.delete('/user/:id', profileDetailController.deleteUser);

module.exports = router;