import MainPagination from "./component/MainPagination";
import "./App.css";

function App() {
  return (
    <div>
      <MainPagination />
    </div>
  );
}

export default App;
