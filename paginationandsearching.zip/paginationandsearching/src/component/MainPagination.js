import React, { useState } from "react";
import { records } from "../data";
import Table from "./table";
import Paginate from "./paginate";

export default function MainPagination() {
  const [data, setdata] = useState(records);
  const [currentPage, setCurrentPage] = useState(1);
  const [dataPerPage] = useState(10);

  const totalPages = Math.ceil(records.length / dataPerPage);

  const indexOflastItem = dataPerPage * currentPage;
  const indexOffirstItem = indexOflastItem - dataPerPage;

  const currentData = records.slice(indexOffirstItem, indexOflastItem);

  return (
    <div className="container-mt5">
        <h2>Simple Example of the pagination</h2>
        <Table data={data} />
        <Paginate 
            totalPages={totalPages} 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage}
        />

    </div>
    );
}
