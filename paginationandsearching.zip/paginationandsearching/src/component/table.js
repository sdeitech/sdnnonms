import "bootstrap/dist/css/bootstrap.min.css";
import React, { Fragment } from "react";

function Table({ data }) {
  return (
    <Fragment>
      <div>
        <table className="table">
          <thead>
            <th>Id</th>
            <th>firstName</th>
            <th>lastName</th>
            <th>Location</th>
          </thead>
          <tbody>
            {data.map((d) => (
              <tr key={d.id}>
                <td>{d.id}</td>
                <td>{d.firstName}</td>
                <td>{d.lastName}</td>
                <td>{d.location}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Fragment>
  );
}
export default Table;
