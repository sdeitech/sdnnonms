const jwt = require("jsonwebtoken");

const verifyToken = (req, res, next) => {
  try {
    const token = req.header("Authorization");
    const verified = jwt.verify(token, "This_is_key");
    console.log(verified);
    if (!verified) {
      return res.status(404).json({ msg: "access denied" });
    }
    next();
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
};

module.exports = verifyToken;
