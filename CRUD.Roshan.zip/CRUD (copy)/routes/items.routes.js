const express = require("express");
const router = express.Router();
const itemController = require("../controllers/item.controller");
const verifyToken = require("../middleware/verifyTokens.middleware");

// CRUD routes using controller methods
router.post("/", verifyToken, itemController.createItem); // Create
router.get("/", verifyToken, itemController.getItems); // Read
router.put("/:id", itemController.updateItem); // Update
router.delete("/:id", itemController.deleteItem); // Delete

module.exports = router;
