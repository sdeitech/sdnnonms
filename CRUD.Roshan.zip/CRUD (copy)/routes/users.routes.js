const express = require("express");
const route = express.Router();
const userController = require("../controllers/user.controller");

route.post("/adduser", userController.createUser); // Corrected this line
route.post("/login", userController.loginUser);
route.get("/users", userController.getUser);
route.delete("/deleteusers/:id", userController.deleteUser);
route.put("/updateusers/:id", userController.updateUser);

module.exports = route;
