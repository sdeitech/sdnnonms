const express = require("express");
const bodyParser = require("body-parser");
const itemRoutes = require("./routes/items.routes");
const userRoutes = require("./routes/users.routes");
const db = require("./db"); // Connect to the database
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use("/items", itemRoutes);
app.use("/roshan", userRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
