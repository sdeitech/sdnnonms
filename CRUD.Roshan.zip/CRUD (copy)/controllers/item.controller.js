const Item = require("../models/items.models"); // Create Item
exports.createItem = async (req, res) => {
  try {
    const newItem = new Item(req.body);
    await newItem.save();
    res.status(201).json(newItem);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Read Item
exports.getItems = async (req, res) => {
  try {
    const getItems = await new Item.find();
    res.json(getItems);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getItems = async (req, res) => {
  try {
    const items = await Item.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update Item
exports.updateItem = async (req, res) => {
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!item) {
      return res.status(404).json({ error: "Item not found" });
    }
    res.json(item);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete Item
exports.deleteItem = async (req, res) => {
  try {
    const removeItemID = await Item.findByIdAndDelete(req.params.id);
    if (!removeItemID) {
      res.status(400).json({ error: "No Record Found!!" });
    }

    res.json({ message: "Item deleted Successfully!!", item: removeItemID });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
