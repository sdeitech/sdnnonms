const User = require("../models/users.models");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// Create User
exports.createUser = async (req, res) => {
  const { name, username, password } = req.body;
  try {
    const user = new User(req.body);
    const hashPass = await bcrypt.hash(password, 10);
    const newUser = new User({ name, username, password: hashPass });
    console.log(newUser);

    await newUser.save();
    res.status(200).json(newUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

//Read User Data
exports.getUser = async (req, res) => {
  try {
    const getuser = await User.find();
    res.json(getuser);
  } catch (error) {
    res.staus(404).json({ error: error.message });
  }
};

// Delete User
exports.deleteUser = async (req, res) => {
  try {
    const removeItemID = await Item.findByIdAndDelete(req.params.id);
    if (!removeItemID) {
      res.status(400).json({ error: "No Record Found!!" });
    }
    res.json({ message: "Item deleted Successfully!!", item: removeItemID });
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};

// Update User
exports.updateUser = async (req, res) => {
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!item) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(item);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.loginUser = async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({ username });

    if (!user) {
      return res.status(404).json({ msg: "user not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      const token = jwt.sign({ username, password }, "This_is_key", {
        expiresIn: "1h",
      });

      return res.status(201).json({ msg: "loged In", token: token });
    } else {
      return res.status(401).json({ msg: "invalid credentials" });
    }
  } catch (error) {
    res.status(401).json({ ERROR: error.message });
  }
};
