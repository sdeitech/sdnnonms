const Users = require("../models/user.model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const loginUser = async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await Users.findOne({ username });

    if (!user) {
      return res.status(404).json({ msg: "user not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      const token = jwt.sign({ username, password }, "This_is_key", {
        expiresIn: "1h",
      });

      return res.status(201).json({ msg: "loged In", token: token });
    } else {
      return res.status(401).json({ msg: "invalid credentials" });
    }
  } catch (error) {
    res.status(401).json({ ERROR: error.message });
  }
};

module.exports = loginUser;
