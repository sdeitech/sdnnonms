import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
// import { useNavigate } from "react-router-dom";

export const LoginAuthUser = createAsyncThunk(
  "LoginAuthUser", async (userCredentials) => {
    // const navigate=useNavigate();
    try {
      const response = await axios.post(`http://localhost:4000/authUser/login`, userCredentials);
      const { data } = response;

      localStorage.setItem("token",data?.token)
      // window.location.href = "/dashboard"
      // console.log("token",data)
      
      return response;
    } catch (error) {
      console.log("error while login ")
    }
  }
)

export const RegisterAuthUser = createAsyncThunk(
  "registerAuthUser",
  async (userData) => {
    try {
      const response = await axios.post(
        `http://localhost:4000/authUser/register`,
        userData, {
        headers: {
          "Content-Type": "multipart/form-data",
        }
      });
      console.log(response.data)
      return response.data;
    } catch (error) {
      console.log("error while registering user");
    }
  }
);

export const AuthUser = createSlice({
  name: "AuthUser",
  initialState: {
    users: null,
    isLoading: false,
    error: false,
  },
  extraReducers: (builder) => {
    builder
      .addCase(RegisterAuthUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(RegisterAuthUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.users = action.payload;
      })
      .addCase(RegisterAuthUser.rejected, (state, action) => {
        state.error = true;
        state.users = action.payload;
      });

    builder
      .addCase(LoginAuthUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(LoginAuthUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.users = action.payload;
      })
      .addCase(LoginAuthUser.rejected, (state) => {
        state.error = true;
      })
  },
});

export default AuthUser.reducer;
