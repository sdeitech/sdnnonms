import Publicroute from "./Publicroute";
import { createBrowserRouter } from "react-router-dom";

const router=createBrowserRouter([
    ...Publicroute
])

export default router;