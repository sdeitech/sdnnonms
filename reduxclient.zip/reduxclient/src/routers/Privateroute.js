import Privatelayout from "../layouts/Privatelayout";
import Dashboard from '../Component/Dashboard'
const Privateroute= [
    {
        path:'/dashboard',
        exact:true,
        element:<Privatelayout><Dashboard/></Privatelayout>
    }
]

export default Privateroute;