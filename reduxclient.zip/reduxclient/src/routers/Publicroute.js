import { Register } from "../Component/Register";
import Publiclayout from "../layouts/Publiclayout";

const Publicroute=[
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Register /></Publiclayout>
    }
]

export default Publicroute;