import { Register } from "../Component/Register";
import { Login } from "../Component/Login";
import Publiclayout from "../layouts/Publiclayout";

const Publicroute = [
    {
        path: '/',
        exact: true,
        element: <Publiclayout><Login /></Publiclayout>
    },
    {
        path: '/register',
        exact: true,
        element: <Publiclayout><Register /></Publiclayout>
    }
]

export default Publicroute;