import React, { useState } from 'react'
import '../styles/Register.css'
import { useDispatch } from 'react-redux';
import { RegisterAuthUser } from '../features/Authuser'


export const Register = () => {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        DOB: '',
        password: '',
        isMarried: false,
        gender: 0
    });
    const [profile, setProfile] = useState(null);

    const handleFileChange = (e) => {
        setProfile(e.target.files[0]);
    }
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const userData = new FormData();
        userData.append("firstName", formData.firstName)
        userData.append("lastName", formData.lastName);
        userData.append("email", formData.email);
        userData.append("DOB", formData.DOB);
        userData.append("password", formData.password);
        userData.append("isMarried", formData.isMarried);
        userData.append("gender", formData.gender);
        userData.append("profile", profile);

        dispatch(RegisterAuthUser(userData));
    }

    return (
        <div className='conatainer form-data' >
            <div className='container login-container' >
                <form onSubmit={handleSubmit} encType='multipart/form-data'>
                    <h2>REGISTRATION FORM</h2>
                    <div className='form-group'>
                        <input
                            type="text"
                            name="firstName"
                            value={formData.firstName}
                            placeholder='firstName'
                            onChange={handleChange}
                        />
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type="text"
                            name="lastName"
                            value={formData.lastName}
                            placeholder='lastName'
                            onChange={handleChange}
                        />
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            placeholder='email'
                            onChange={handleChange}
                        />
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type="date"
                            name='DOB'
                            value={formData.DOB}
                            placeholder="DOB"
                            onChange={handleChange}
                        />
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type='password'
                            name="password"
                            value={formData.password}
                            placeholder='password'
                            onChange={handleChange}
                        />

                    </div>
                    <br />
                    <div className='form-group'>
                        <label>isMarried:</label>
                        <input
                            type="checkbox"
                            name="isMarried"
                            value={formData.isMarried}
                            onChange={handleChange}
                        />
                        <br />
                    </div>
                    <div classsName="form-group">
                        <input
                            type="radio"
                            id='0'
                            name="gender"
                            value={formData.gender}
                            onChange={handleChange}
                        /> Male

                        <input
                            type="radio"
                            id='1'
                            name="gender"
                            value={formData.gender}
                            onChange={handleChange}
                        /> Female
                    </div>
                    <br />
                    <div className='form-group'>
                        <input
                            type="file"
                            name="profile"
                            accept='profiles/*'
                            onChange={handleFileChange}></input>
                        <br />
                    </div>
                    <div>
                        <button type="submit">register</button>
                    </div>
                </form>
            </div>
        </div>
    )
}
