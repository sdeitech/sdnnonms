import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { LoginAuthUser } from '../features/Authuser';
import { useNavigate } from 'react-router-dom';
export const Login = () => {

    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [formData, setFromData] = useState({
        email: '',
        password: ''
    });
    const [error, setError] = useState(null);
    const handleSimpleSubmit = async (e) => {
        e.preventDefault();
        const result = await dispatch(LoginAuthUser(formData));
        console.log(result,"result")
        // console.log(result)
        // const code = result.payload.status;
        // console.log(code)
        if (result?.payload?.status == 200) {
            navigate("/dashboard")
        }
        else{
            console.log("login not success")
            navigate('/')
        }
    }
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFromData((prev) => ({
            ...prev, [name]: value
        }))
    }

    return (
        <div className='conatainer form-data'>
            <div className='container login-container'>
                <form className='login-form'>
                    <h3 > SIGN IN</h3>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="email"
                            name="email"
                            placeholder='EMAIL'
                            onChange={handleChange}
                            value={formData.email}
                        />
                    </div>
                    <br></br>
                    <div className='form-group'>
                        <input
                            className='form-control'
                            type="password"
                            name="password"
                            placeholder='PASSWORD'
                            onChange={handleChange}
                            value={formData.password}
                        />
                    </div>
                    <br></br>
                    <div>
                        <button
                            type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={handleSimpleSubmit}>
                            SUBMIT
                        </button> &nbsp;
                        <button type="submit"
                            variant="success"
                            className='btn btn-primary btn-block'
                            onClick={() =>
                                navigate('/register')
                            }>
                            SIGNUP
                        </button> &nbsp;
                    </div>
                </form>
            </div>
        </div>
    )
}
