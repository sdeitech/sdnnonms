from django.shortcuts import render
# from django.shortcuts import render,redirect,get_object_or_404
from django.views import View
# from .models import Employee
# from django.core.paginator import Paginator
from django.shortcuts import render,redirect
from django.views import View
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required,permission_required
User = get_user_model()

class signUp(View):
    def get(self,request):
        return render(request,'signUp.html')
    
    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        
        user = User.objects.create_user(
            username=username,
            password=password,
            email=email,
            first_name=first_name,
            last_name=last_name,
            mobile=mobile_number
        )
        user.save()
        print(user)
        
        return redirect("signIn/")
    
class signIn(View):
    def get(self,request):
        return render(request,'signIn.html')  
    
    
    def post(self,request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not User.objects.filter(username=username).exists():
            return redirect("signUp")
        
        user = authenticate(username=username,password=password)
        print(user,"user data")
        
        if user is not None:
            login(request,user)
            return redirect("index")
        else:
            return redirect("signUp")  
        
class Logout(View):
    def get(self,request):
        logout(request)
        return redirect("")        

class Index(View):
    @method_decorator(login_required)
    def get(self, request):
        return render(request,'index.html')
    
    
class story(View):
    def get(self, request):
        return render(request,'story.html')
    
class products(View):
    def get(self, request):
        return render(request,'products.html')        
    
    
class contact(View):
    def get(self, request):
        return render(request,'contact.html')        


class faqs(View):
    def get(self, request):
        return render(request,'faqs.html')        