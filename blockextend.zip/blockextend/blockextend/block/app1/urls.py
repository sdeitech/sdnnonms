from django.urls import path
from . import views

urlpatterns = [
        path('', views.Index.as_view(),name='index'),
        path('story/', views.story.as_view(),name='story'),
        path('products/', views.products.as_view(),name='products'),
        path('contact/', views.contact.as_view(),name='contact'),
        path('faqs/', views.faqs.as_view(),name='faqs'),
        


]
