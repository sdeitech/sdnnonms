from django.shortcuts import render

# Create your views here.

# from django.shortcuts import render,redirect,get_object_or_404
from django.views import View
# from .models import Employee
# from django.core.paginator import Paginator

class postGet(View):
    def get(self, request):
        return render(request,'index.html')