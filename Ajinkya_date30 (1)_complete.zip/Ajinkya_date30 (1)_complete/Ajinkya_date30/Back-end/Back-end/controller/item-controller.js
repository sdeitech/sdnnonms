const Item = require('../model/item.model');
// Create Product 
exports.getItem = async (req, res) => {
    try {
        const userId = req.body.userId || req.params.userId; // Get userId from body or params
        if (!userId) {
            return res.status(400).json({ message: 'userId is required' });
        }
        
        // Find items where userId matches the passed userId
        const items = await Item.find({ userId });
        if (!items.length) {
            return res.status(404).json({ message: 'No items found for this user' });
        }
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Create a new Item with userId from the request body
exports.createItem = async (req, res) => {
    try {
        const userId = req.body.userId;
        if (!userId) {
            return res.status(400).json({ message: 'userId is required' });
        }

        // Create a new item with userId passed in request body
        const newItem = new Item({
            ...req.body,
            userId, // Assign userId from the request body
            date: new Date(req.body.date) // Optional: handle date
        });

        await newItem.save();
        res.status(201).json(newItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
// Update Item 
exports.updateItem = async (req, res) => {
    try {
        const item = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!item) {
            return res.status(404).json({ error: 'Item not found' });
        }
        res.json(item);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
// Delete Item 
exports.deleteItem = async (req, res) => {
    try {
        const item = await Item.findByIdAndDelete(req.params.id);
        if (!item) {
            return res.status(404).json({ error: 'Item not found' });
        }
        res.json({ message: 'Item deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};