const router = require('express').Router()
const { register, logIn , getUserById, updateUser ,upload} = require('../controller/user.controller')
const verifyToken = require('../middleware/verifyToken')
const {isRequestValidated, validateSignUpRequest, validateSignIpRequest} = require('../validate/auth')

// router.route("/register").post(validateSignIpRequest, isRequestValidated, register);
router.post('/register', upload.single('profilePic'), register);
router.route("/login").post(validateSignUpRequest, isRequestValidated, logIn);

// router.route("/update").post(validateSignUpRequest, isRequestValidated, update);

router.get("/userById/:id", getUserById); 

//router.route("/getUser").get(validateSignUpRequest, isRequestValidated, getUser);
router.route("/userEdit/:id").put( updateUser); 
module.exports = router