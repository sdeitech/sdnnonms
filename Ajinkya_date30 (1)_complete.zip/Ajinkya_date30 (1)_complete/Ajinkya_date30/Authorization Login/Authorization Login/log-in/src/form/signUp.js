import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Signup() {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        DOB: '',
        password: '',
        gender: '',
        profilePic: null
        // isMarried: false, // Add the checkbox value for marital status
    });
    const [error, setError] = useState(null);
    const navigate = useNavigate();

   // Handle input changes
    const handleChange = (e) => {
        const { name, value, type, checked, files } = e.target;
        if (type === 'checkbox') {
            setFormData((prevData) => ({
                ...prevData,
                [name]: checked,
            }));
        } else if (type === 'file') {
            // Handle file input separately
            setFormData((prevData) => ({
                ...prevData,
                profilePic: files[0], // Set the selected file
            }));
        } else {
            setFormData((prevData) => ({
                ...prevData,
                [name]: value,
            }));
        }
    };

    // Handle form submission
    // const handleSubmit = async (e) => {
    //     e.preventDefault(); // Prevent page reload on form submit
    //     try {
    //         const response = await axios.post('http://localhost:5000/user/register', formData);
    //         if (response.status === 201) {
    //             // Registration successful, redirect to another page
    //             alert('Registration successful!');
    //             // Reset the form data after successful submission
    //         setFormData({
    //             firstName: '',
    //             lastName: '',
    //             email: '',
    //             DOB: '',
    //             password: '',
    //             gender: '',
    //             // isMarried: false,  // Reset the checkbox as well
    //         });
    //             navigate('/'); // Replace with the appropriate route
    //         }
    //     } catch (error) {
    //         setError('Registration failed, please try again.');
    //         console.error('Error during registration:', error);
    //     }
    // };
// Handle form submission
const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent page reload on form submit

    const data = new FormData();
    data.append('firstName', formData.firstName);
    data.append('lastName', formData.lastName);
    data.append('email', formData.email);
    data.append('DOB', formData.DOB);
    data.append('password', formData.password);
    data.append('gender', formData.gender);
    data.append('profilePic', formData.profilePic); // Append profile picture

    try {
        const response = await axios.post('http://localhost:5000/user/register', data, {
            headers: {
                'Content-Type': 'multipart/form-data', // Ensure form-data is sent
            },
        });

        if (response.status === 201) {
            // Registration successful, reset form
            alert('Registration successful!');
            setFormData({
                firstName: '',
                lastName: '',
                email: '',
                DOB: '',
                password: '',
                gender: '',
                profilePic: null, // Reset profile pic
            });
            navigate('/'); // Redirect to another route
        }
    } catch (error) {
        setError('Registration failed, please try again.');
        console.error('Error during registration:', error);
    }
};
return (
    <div>
        <form onSubmit={handleSubmit}> {/* Attach the handleSubmit function to the form */}
            <h4>Sign Up</h4>
            <div>
                <input
                    type='text'
                    name='firstName'
                    placeholder='First Name'
                    value={formData.firstName}
                    onChange={handleChange}
                    required
                /><br />
                <input
                    type='text'
                    name='lastName'
                    placeholder='Last Name'
                    value={formData.lastName}
                    onChange={handleChange}
                    required
                /><br />
                <input
                    type='email'
                    name='email'
                    placeholder='Email'
                    value={formData.email}
                    onChange={handleChange}
                    required
                />
            </div><br />
            <div>
                <input
                    type='date'
                    name='DOB'
                    value={formData.DOB}
                    onChange={handleChange}
                    required
                />
                <input
                    type='password'
                    name='password'
                    placeholder='Password'
                    value={formData.password}
                    onChange={handleChange}
                    required
                />
            </div><br />
            <div>
                <label>Gender</label>
                <input
                    type='radio'
                    name='gender'
                    value='male'
                    onChange={handleChange}
                    checked={formData.gender === 'male'} // Manage radio selection
                /><label>Male</label>
                <input
                    type='radio'
                    name='gender'
                    value='female'
                    onChange={handleChange}
                    checked={formData.gender === 'female'} // Manage radio selection
                /><label>Female</label>
            </div><br />
            <div>
                {/* Add file input for profile picture */}
                <input
                    type="file"
                    name="profilePic"
                    accept="image/*"
                    onChange={handleChange}
                /><label>Select Profile Picture</label>
            </div><br />
            <button type="submit" className="btn btn-primary">Register</button>
        </form>
        {error && <div className="alert alert-danger">{error}</div>} {/* Show error message if any */}
    </div>
);
}

export default Signup;