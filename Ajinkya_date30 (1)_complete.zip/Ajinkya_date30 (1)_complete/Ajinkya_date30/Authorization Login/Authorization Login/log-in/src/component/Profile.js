import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function Profile() {
    const [user, setUser] = useState(null); // Initialize user as null
    const [error, setError] = useState(null); // State to manage errors
    const [isEditing, setIsEditing] = useState(false); // State to toggle edit mode
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        DOB: '',
        gender: '',
        profilePic: null, // Added profile picture to formData
    });
    const [previewPic, setPreviewPic] = useState(null); // State to store profile picture preview

    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem('user')); // Get the user from localStorage
        
        if (storedUser && storedUser.id) {
            const fetchUserData = async () => {
                try {
                    const response = await axios.get(`http://localhost:5000/user/userById/${storedUser.id}`);
                    setUser(response.data.user);
                    setFormData({
                        firstName: response.data.user.firstName,
                        lastName: response.data.user.lastName,
                        email: response.data.user.email,
                        DOB: response.data.user.DOB,
                        gender: response.data.user.gender,
                        profilePic: response.data.user.profilePic, // Load profile pic if available
                    });
                    setPreviewPic(response.data.user.profilePic); // Show existing profile pic
                } catch (error) {
                    console.error('Error fetching user data:', error);
                    setError('Failed to fetch user data');
                }
            };

            fetchUserData();
        } else {
            console.error('No user found in localStorage');
            setError('No user found in localStorage');
        }
    }, []);

    // Handle input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    // Handle profile picture change
    const handleProfilePicChange = (e) => {
        const file = e.target.files[0];
        setFormData((prevData) => ({
            ...prevData,
            profilePic: file,
        }));

        // Create preview URL for the image
        const reader = new FileReader();
        reader.onloadend = () => {
            setPreviewPic(reader.result); // Set the image preview
        };
        if (file) {
            reader.readAsDataURL(file);
        }
    };

    // Handle form submission for updating user data
    const handleUpdate = async (e) => {
        e.preventDefault();
        const storedUser = JSON.parse(localStorage.getItem('user'));

        try {
            // Prepare the form data for the request
            const formDataToSubmit = new FormData();
            formDataToSubmit.append('firstName', formData.firstName);
            formDataToSubmit.append('lastName', formData.lastName);
            formDataToSubmit.append('email', formData.email);
            formDataToSubmit.append('DOB', formData.DOB);
            formDataToSubmit.append('gender', formData.gender);
            if (formData.profilePic) {
                formDataToSubmit.append('profilePic', formData.profilePic); // Append profile picture
            }

            const response = await axios.put(
                `http://localhost:5000/user/userEdit/${storedUser.id}`,
                formDataToSubmit,
                { headers: { 'Content-Type': 'multipart/form-data' } }
            );
            setUser(response.data.user);
            setIsEditing(false);
            alert('User updated successfully');
        } catch (error) {
            console.error('Error updating user data:', error);
            setError('Failed to update user data');
        }
    };

    return (
        <div className="container mt-5">
          
            {error && <div className="alert alert-danger">{error}</div>}
            {user ? (
                <div>
                
                    {/* Display profile picture */}
                    {previewPic && (
                        <div className="text-center mb-4">
                            <img
                                src={`http://localhost:5000/${previewPic}`}
                                alt="Profile"
                                style={{
                                    width: '150px',
                                    height: '150px',
                                    objectFit: 'cover',
                                    borderRadius: '10px', // Rounded corners
                                    border: '2px solid #ccc'
                                }}
                            />
                        </div>
                    )}
                    
                    {isEditing ? (
                        <form onSubmit={handleUpdate}>
                            <div className="form-group">
                                <label>Firstname</label>
                                <input
                                    type="text"
                                    name="firstName"
                                    value={formData.firstName}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Lastname</label>
                                <input
                                    type="text"
                                    name="lastName"
                                    value={formData.lastName}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>DOB</label>
                                <input
                                    type="date"
                                    name="DOB"
                                    value={formData.DOB}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Gender</label>
                                <input
                                    type="text"
                                    name="gender"
                                    value={formData.gender}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Profile Picture</label>
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleProfilePicChange}
                                    className="form-control"
                                />
                            </div>
                            <button type="submit" className="btn btn-primary">Update</button>
                            <button type="button" className="btn btn-secondary ml-2" onClick={() => setIsEditing(false)}>Cancel</button>
                        </form>
                    ) : (
                        <table className="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Email</th>
                                    <th>DOB</th>
                                    <th>Gender</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{user.firstName}</td>
                                    <td>{user.lastName}</td>
                                    <td>{user.email}</td>
                                    <td>{user.DOB}</td>
                                    <td>{user.gender}</td>
                                    <td>
                                        <button className="btn btn-warning" onClick={() => setIsEditing(true)}>Edit</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    )}
                </div>
            ) : (
                <p>Loading user data...</p>
            )}
        </div>
    );
}

export default Profile;