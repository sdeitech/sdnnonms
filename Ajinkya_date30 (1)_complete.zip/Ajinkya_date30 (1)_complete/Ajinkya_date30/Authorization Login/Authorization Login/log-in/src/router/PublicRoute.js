import { React } from "react";
import Form from "../form/Form";
import PublicLayout from "../layout/PublicLayout";
import Signup from "../form/signUp";
import Profile from "../component/Profile";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><Form /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><div><Signup/></div></PublicLayout>
    },

    {
    	path: "/Profile",
    	exact: true,
    	element: <PublicLayout><div><Profile/></div></PublicLayout>
    }
];
export default publicRoutes;
