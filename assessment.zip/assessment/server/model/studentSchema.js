
const mongoose = require ('mongoose');

//Schema of product details

const StudentSchema = mongoose.Schema({
    firstname:{
        type:String,
    },
    lastname:{
        type:String,
    },
    email:{
        type:String,
    },
    marksinenglish:{
        type:Number,
    },
    marksinscience:{
        type:Number,
    },
    marksinmaths:{
        type:Number,
    },
    aboutyou:{
        type:String,
    },
    percentage:{
      type:Number,
    },
    grade:{
      type :String
    }

});

const studentModel = mongoose.model("students",StudentSchema);
module.exports=studentModel;

const Student = mongoose.model("Student", StudentSchema);

module.exports = Student;
