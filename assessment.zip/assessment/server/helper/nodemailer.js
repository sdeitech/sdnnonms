// import nodemailer from "nodemailer";
const nodemailer =require("nodemailer")


const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "altamashpathan1808@gmail.com",
    pass: "qkjbxzapfqcvysii",
  },
});

const sendMailToUser = async (to, text) => {
  const mailOptions = {
    from: "altamashpathan1808@gmail.com",
    to: to,
    subject: "result",
    text: text,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("mail sent");
    return { status: true };
  } catch (error) {
    console.log(error.message);
    console.log({ status: false });
  }
};

module.exports = sendMailToUser;
