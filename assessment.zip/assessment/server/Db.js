//db code

const mongoose =require("mongoose");

const MongoConnection=async()=>{ 
    try {
        await mongoose.connect("mongodb://localhost:27017/CRUD");
        console.log("Database connected");
        
    } catch (error) {
        console.log("error" , error.message);
        
    }
    
mongoose.connect=("mongodb://localhost:27017");
const db = mongoose.connection;
}
module.exports=MongoConnection
