
const sendMailToUser = require("../helper/nodemailer")
const Student = require("../model/studentSchema");


exports.createStudent = async (req, res) => {
  // console.log(req.body)
  try {
    const newStudent = new Student(req.body);
    await newStudent.save();

    const email = await sendMailToUser(req.body.email,"hello")
    console.log(email);
    if(email.status){
    return res.status(201).json({student:newStudent});
    }

  } catch (error) {
    console.log(error.message)
    res.status(400).json({ error: error.message });
  }
};

exports.getStudent = async (req, res) => {
  
  try {
    const student= await Student.find({});
    res.json({ student: student, message: "Logged Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

