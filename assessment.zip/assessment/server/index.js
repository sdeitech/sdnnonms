const express = require('express');
const bodyParser = require("body-parser");
const cors = require('cors')
const MongoConnection = require('./Db') 
MongoConnection();



const app= express();
app.use(cors())

const PORT = 5051;
const StudentRoutes = require("./routes/studentRoutes")

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use('/api',StudentRoutes);



app.listen(PORT,()=>
{
    console.log(`server is running on http://localhost:${PORT}`);
    
});
