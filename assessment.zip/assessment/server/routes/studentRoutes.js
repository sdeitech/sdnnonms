//routes code

const express = require('express');
const router = express.Router();

const StudentController = require('../controller/studentController');
const createStudent = require('../controller/studentController')

router.post('/createStudent',StudentController.createStudent);
router.get('/getStudent',StudentController.getStudent);
// router.get('/getProductid/:id',ProductController.getProductid);
// router.put('/putProduct/:id',ProductController.putProduct);
// router.delete('/deleteProduct/:id',ProductController.deleteProduct);

// router.post('/login',UserController.login);

module.exports = router;

