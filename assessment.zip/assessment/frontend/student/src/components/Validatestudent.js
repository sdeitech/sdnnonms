const validationStudent = () => {

}

export default validationStudent;