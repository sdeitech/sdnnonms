import React, { useEffect, useState } from "react";
import axios from "axios";
// import Updateform from "./Updateform";
import View from "./View";
const DataTable = () => {
  const [data, setData] = useState([]);
  const fetchData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5051/api/getStudent"
      );
      console.log(response);
      
      setData(response.data.student);
      // console.log(setData);
    } catch (error) {
      console.log("error fetching data");
    }
  };
  // const [updatedata,setupdatedata] = useState(null);

  useEffect(() => {
  
    fetchData();
  },[])

  
  const [curruntUser,setcurruntUser] = useState(null);



  // const update = (user) => {
  //   setshowupdate(!showupdate);
  //   console.log(update);
  //   setcurruntUser(user)
  // };


  const[showview,setshowview]=useState(false)

   const Handleview = (data)=>{
    setshowview(!showview)
    setcurruntUser(data)

   }
  return (
    <div className="data">
      <table border="2" solid className="update">
        <thead>
          <tr >
            <th>firstname</th>
            <th>lastname</th>
            <th>email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => {
              return(
            <tr key={item._id}>
              <td>{item.firstname}</td>
              <td>{item.lastname}</td>
              <td>{item.email}</td>
              <td>
                <button onClick={() => Handleview(item)} >View</button>
              </td>
              {/* <td>{item.marksinenglish}</td>
              <td>{item.marksinscience}</td>
              <td>{item.marksinmaths}</td> */}
            </tr>
            )
          }
          )}
        </tbody>
      </table>
      {/* {showupdate && (
      <Updateform
        // updatedata={updatedata}
        curruntUser={curruntUser}
        />
        )} */}
        
        {showview && <View curruntUser={curruntUser} showview={showview} setshowview={setshowview}/>}
    </div>
  );
};
export default DataTable;
