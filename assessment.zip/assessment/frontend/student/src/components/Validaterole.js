const validateStudent = (values) => {
    let errors = {};

    if (!values.firstname) {
        errors.firstname = "FirstName is required";
    }

    if (!values.lastname) {
        errors.lastname = "LastName is required";
    }

    if (!values.email) {
        errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = "Email address is invalid";

    }if (!values.marksinenglish) {
        errors.marksinenglish = "marks is required";
    

    }if (!values.marksinscience) {
        errors.marksinscience = "marks is required";
   
    }if (!values.marksinmaths) {
        errors.marksinmaths = "marks is required";
    }

    return errors;
};

export default validateStudent;
