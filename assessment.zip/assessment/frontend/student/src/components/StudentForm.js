import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Student.css";
import validateStudent from "./Validaterole";
// import Pagination from "@mui/material/Pagination";
// import Stack from "@mui/material/Stack";

const StudentForm = () => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    marksinenglish: "",
    marksinscience: "",
    marksinmaths: "",
    percentage: "",
    grade: "",
  });
  // console.log(formData,"dhole bhau");

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(e.target);

    setFormData({
      ...formData,
      [name]: value,
    });
  };
  console.log(formData, "formdata");

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData, "formData");

    const validationErrors = validateStudent(formData);
    if (Object.keys(validationErrors).length === 0) {
      try {
        const response = await axios.post(
          "http://localhost:5051/api/createStudent",
          formData
        );
        console.log("Form data submitted:", response.data);
        window.location.reload();
      } catch (err) {
        console.error("Error submitting form:", err.message);
      }
    } else {
      setErrors(validationErrors);
    }

    // handleSubmit(e);
  };

  return (
    <div className="main" style={{}}>
      <h1 style={{ textAlign: "center" }}>Student Management</h1>
      <form onSubmit={handleSubmit}>
        <div className="child">
          <label htmlfor="name">first name:</label>
          <input
            type="text"
            placeholder="first name"
            name="firstname"
            onChange={handleChange}
            // onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          {errors.firstname && <p className="error">{errors.firstname}</p>}
          <label htmlfor="">last name:</label>
          <input
            type="text"
            placeholder="lastname"
            name="lastname"
            onChange={handleChange}
          />
          {errors.lastname && <p className="error">{errors.lastname}</p>}
          <label htmlfor="Quantity">email:</label>
          <input
            type="email"
            placeholder="email"
            name="email"
            onChange={handleChange}
          />
          {errors.email && <p className="error">{errors.email}</p>}

          <label htmlfor="">marks in english:</label>
          <input
            type="number"
            placeholder="marks"
            name="marksinenglish"
            onChange={handleChange}
          />
          {errors.marksinenglish && (
            <p className="error">{errors.marksinenglish}</p>
          )}

          <label htmlfor="">marks in science:</label>
          <input
            type="number"
            placeholder="marks"
            name="marksinscience"
            onChange={handleChange}
            // onChange={e => setProd({ ...prod, description: e.target.value })}
          />
          {errors.marksinscience && (
            <p className="error">{errors.marksinscience}</p>
          )}

          <label htmlfor="">marks in maths:</label>
          <input
            type="number"
            placeholder="marks"
            name="marksinmaths"
            onChange={handleChange}
          />
          {errors.marksinmaths && (
            <p className="error">{errors.marksinmaths}</p>
          )}
        </div>
        <button
          className="button"
          type="submit"
          style={{ backgroundColor: "blue", color: "white", margin: "auto" }}
        >
          Submit
        </button>
        <button
          className="button"
          type="reset"
          style={{ backgroundColor: "blue", color: "white" }}
        >
          Reset
        </button>
      </form>
    </div>
  );
};

export default StudentForm;
