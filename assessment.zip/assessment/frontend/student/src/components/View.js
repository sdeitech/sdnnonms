import React from 'react'


// const calculate = () => {

//   // Getting input from user into height variable.
//   let english = document.querySelector("#english").value;
//   let science = document.querySelector("#science").value;
//   let maths = document.querySelector("#maths").value;
//   let grades = "";

//   // Input is string so typecasting is necessary. */
//   let totalgrades =
//       parseFloat(english) +
//       parseFloat(science) +
//       parseFloat(maths);
//   // Checking the condition for the providing the 
//   // grade to student based on percentage
//   let percentage = (totalgrades / 400) * 100;
//   if (percentage <= 100 && percentage >= 80) {
//       grades = "A";
//   } else if (percentage <= 79 && percentage >= 60) {
//       grades = "B";
//   } else if (percentage <= 59 && percentage >= 40) {
//       grades = "C";
//   } else {
//       grades = "F";
//   }
//   // Checking the values are empty if empty than
//   // show please fill them
//   if (english == "" || science == ""
//       || maths == "") {
//       document.querySelector("#showdata").innerHTML
//           = "Please enter all the fields";
//   } else {

//       // Checking the condition for the fail and pass
//       if (percentage >= 39.5) {
//           document.querySelector(
//               "#showdata"
//           ).innerHTML =
//               ` Out of 300 your total is  ${totalgrades} 
//         and percentage is ${percentage}%. <br> 
//         Your grade is ${grades}. You are Pass. `;
//       } else {
//           document.querySelector(
//               "#showdata"
//           ).innerHTML =
//               ` Out of 300 your total is  ${totalgrades} 
//         and percentage is ${percentage}%. <br> 
//         Your grade is ${grades}. You are Fail. `;
//       }
//   }
// };



const View = ({curruntUser,showview,setshowview}) => {

  
  const percentage = ((curruntUser.marksinenglish + curruntUser.marksinscience + curruntUser.marksinmaths)/300)*100
  
  let grades ;
  if (percentage <= 100 && percentage >= 80) {
          grades = "A";
      } else if (percentage <= 79 && percentage >= 60) {
          grades = "B";
      } else if (percentage <= 59 && percentage >= 40) {
          grades = "C";
      } else {
          grades = "F";
      }
  
  return (
    <div style={{border:"solid 1px",backgroundColor:"aquamarine",position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:"400px", color:"black",margin:"auto",textAlign:"center"}}>   
    <p>firstname :{curruntUser?.firstname}</p>
    <p>lastname :{curruntUser?.lastname}</p>
    <p>Email :{curruntUser?.email}</p>
    <p>Marks in English : {curruntUser?.marksinenglish}</p>
    <p>Marks in Science :{curruntUser?.marksinscience}</p>
    <p>Marks in Maths :{curruntUser?.marksinmaths}</p>
    <p>percentage :{percentage}</p>
    <p>grade:{grades}</p>
    
    <button onClick={()=>

        {setshowview(!showview)}
    }>close</button>
    </div>
  )
}

export default View
