// import logo from './logo.svg';
import './App.css';
import DataTable from './components/DataTable';
import StudentForm from './components/StudentForm';
// import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div>
      <StudentForm/>
      <DataTable/>
    </div>
  );
}

export default App;
