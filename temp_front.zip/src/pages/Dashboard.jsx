import axios from "axios";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveUserData } from "../context/Reducers/userSlice";
import { Card, Typography } from "@material-tailwind/react";
import Icons from "../assets/assets";
// import fetchUser from "../costomHooks/fetchUser";

const TABLE_HEAD = ["Profile", "First Name", "LastName", "Email", "Action"];

const Dashboard = () => {

  const uid = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);


  console.log(uid, token)




  const userData = useSelector((state) => state.userData.subUsers);
  console.log(userData, "demoooooooooooooooooooooooooooooooooo");

  const dispatch = useDispatch();

  const fetchUser = async () => {
    try {
      const res = await axios.get(`http://localhost:3002/api/user/${uid}`, {
        headers: {
          Authorization: token,
        },
      });
      dispatch(saveUserData(res.data));
      console.log(res.data, "from call");
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    console.log("calling api")
    fetchUser();
  }, []);

  return (
    <div className="w-5/6 mx-auto mt-8">
      <Card className="h-full w-full overflow-scroll">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              {TABLE_HEAD.map((head) => (
                <th
                  key={head}
                  className="border-b border-blue-gray-100 bg-blue-gray-50 p-4"
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {userData?.map(({ _id, firstName, lastName, email }, index) => (
              <tr key={_id} className="even:bg-blue-gray-50/50">
                <td className="p-4">
                  <img
                    src={Icons.profile}
                    alt=""
                    height={40}
                    width={40}
                    className="rounded-full"
                  />
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal"
                  >
                    {firstName}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal"
                  >
                    {lastName}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal"
                  >
                    {email}
                  </Typography>
                </td>
                <td className="p-4">
                  <Typography
                    as="a"
                    href="#"
                    variant="small"
                    color="blue-gray"
                    className="font-medium"
                  >
                    View
                  </Typography>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default Dashboard;
