import React, { useEffect, useState } from "react";
import useForm from "../costomHooks/useForm";
import toast, { Toaster } from "react-hot-toast";
import axios from "axios";
import { loginSuccess } from "../context/Reducers/LoginUser";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  
  const dispatch = useDispatch();

  const navigate = useNavigate();
  const [toastShown, setToastShown] = useState(false);

  const data = useSelector((state) => state.loginUser);

  console.log(data, "userdata");

  const signInData = {
    email: "",
    password: "",
  };

  const { formData, handleChange } = useForm(signInData);

  const handleSignIn = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/signin`,
        formData
      );
      setToastShown(true);

      dispatch(loginSuccess(res.data));

      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Login successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className="border border-gray-300 py-10 px-6 rounded-2xl shadow-xl w-96 flex flex-col items-center  mx-auto mt-20 ">
      <div className="text-2xl mb-6 ">
        <p>Login</p>
      </div>
      <form onSubmit={handleSignIn} className="flex flex-col gap-5 ">
        <div className="border border-gray-400 rounded-md ">
          <input
            type="text"
            name="email"
            onChange={handleChange}
            placeholder="Enter your email"
            className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
          />
        </div>

        <div className="border border-gray-400 rounded-md ">
          <input
            type="text"
            name="password"
            onChange={handleChange}
            placeholder="Enter your password"
            className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
          />
        </div>

        <div className=" text-white bg-black text-center w-20 py-2 rounded-md mx-auto">
          <button type="submit">Login</button>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default SignIn;
