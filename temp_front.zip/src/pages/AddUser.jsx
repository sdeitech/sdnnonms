import React, { useEffect, useState } from "react";
import Icons from "../assets/assets";
import useForm from "../costomHooks/useForm";
import { Link } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";
import fetchUser from "../costomHooks/fetchUser";
import toast, { Toaster } from "react-hot-toast";


const AddUser = () => {
  const id = useSelector((state) => state.loginUser?.userId);
  const token = useSelector((state) => state.loginUser?.token);
  const [updateState, setUpdateState] = useState(false);

  const addUserData = {
    firstName: "",
    lastName: "",
    email: "",
  };
  const { formData, handleChange, resetForm } = useForm(addUserData);

  console.log(formData);

  const handleAddUserSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `http://localhost:3002/api/user/${id}`,
        formData,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      setUpdateState(!updateState);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  //   useEffect(() => {
  //     fetchUser();
  //   }, [updateState]);

  return (
    <div>
      <form onSubmit={handleAddUserSubmit}>
        <div className="w-96 border border-gray-200 shadow-lg p-4 flex flex-col  gap-6 items-center mx-auto mt-10 rounded-md ">
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="firstName"
              onChange={handleChange}
              placeholder="Enter your first name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="lastName"
              onChange={handleChange}
              placeholder="Enter your last name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="email"
              onChange={handleChange}
              placeholder="Enter your email"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="bg-black text-white px-4 py-2 rounded-md">
            <button type="submit">Add</button>
          </div>
          <Link to={"/dashboard"}>
            <div className="bg-gray-300 p-2 rounded-full">
              <Icons.crossIcon />
            </div>
          </Link>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default AddUser;
