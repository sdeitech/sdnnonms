import React, { useEffect, useState } from "react";
import { Radio } from "@material-tailwind/react";
import { Link } from "react-router-dom";
import useForm from "../costomHooks/useForm";
import Icons from "../assets/assets";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";

const SignUp = () => {
  const SignUpData = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    gender: "",
    isMarried: false,
    DOB: "",
    profile: null,
  };

  const [toastShown, setToastShown] = useState(false);

  const { formData, previewImg, handleChange, resetForm } = useForm(SignUpData);
  
  console.log(formData);
  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);

    const formDataToSend = new FormData();

    formDataToSend.append("firstName", formData.firstName);
    formDataToSend.append("lastName", formData.lastName);
    formDataToSend.append("email", formData.email);
    formDataToSend.append("password", formData.password);
    formDataToSend.append("gender", formData.gender);
    formDataToSend.append("isMarried", formData.isMarried);
    formDataToSend.append("DOB", formData.DOB);

    if (formData.profile) {
      formDataToSend.append("profile", formData.profile);
    }

    try {
      const res = await axios.post(
        `http://localhost:3002/api/signup`,
        formDataToSend
      );
      setToastShown(true);
      console.log(res.data);
      resetForm();
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (toastShown) {
      toast.success("Registration successful!");
      setToastShown(false);
    }
  }, [toastShown]);

  return (
    <div className=" py-10 px-6 rounded-2xl shadow-xl flex flex-col items-center mx-auto border border-gray-200 w-1/2 ">
      <div className="text-2xl mb-6">
        <p>Sign Up here</p>
      </div>

      <div className="mb-6">
        {previewImg ? (
          <div className="rounded-full h-20 w-20 border-2 border-gray-500 p-1">
            <img
              src={previewImg}
              alt="Profile Preview"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        ) : (
          <div className="rounded-full h-20 w-20 border-2 border-gray-500 p-1">
            <img
              src={Icons.profile}
              alt="Default Profile"
              className="rounded-full h-full w-full object-cover"
            />
          </div>
        )}
      </div>

      <form onSubmit={handleLoginSubmit}>
        <div
          className="lg:grid lg:grid-cols-2 lg:grid-rows-4 lg:gap-4 
        md:flex md:flex-col md:gap-5 
        "
        >
          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="firstName"
              onChange={handleChange}
              placeholder="Enter your first name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="lastName"
              onChange={handleChange}
              placeholder="Enter your last name"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="email"
              onChange={handleChange}
              placeholder="Enter your email"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 rounded-md ">
            <input
              type="text"
              name="password"
              onChange={handleChange}
              placeholder="Enter your password"
              className=" focus:outline-none h-10 w-80 px-2 rounded-md text-gray-600 "
            />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 gap-8">
            <Radio
              name="gender"
              label="Male"
              value="male"
              checked={formData.gender === "male"}
              onChange={handleChange}
            />
            <Radio
              name="gender"
              label="Female"
              value="female"
              checked={formData.gender === "female"}
              onChange={handleChange}
            />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 ">
            <input type="date" name="DOB" onChange={handleChange} />
          </div>

          <div className="border border-gray-400 h-10 rounded-md flex items-center justify-center text-gray-500 gap-6">
            <label>Is married ?</label>
            <input
              type="checkbox"
              name="isMarried"
              checked={FormData.isMarried}
              onChange={handleChange}
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
            />
          </div>

          <div>
            <label
              htmlFor="profile"
              className="cursor-pointer bg-gray-300 px-4 py-2 rounded-md"
            >
              Upload Profile
            </label>
            <input
              type="file"
              id="profile"
              name="profile"
              onChange={handleChange}
              style={{ display: "none" }}
            />
          </div>
          {previewImg && (
            <a href={previewImg} target="_blank" className="text-blue-600">
              View Profile
            </a>
          )}
        </div>

        <div className="flex  flex-col items-center mt-4 gap-3">
          <div className=" text-white bg-black text-center py-2 w-28 rounded-md mx-auto">
            <button type="submit">Sign Up</button>
          </div>

          <div>
            <p>
              Alredy have an account ?{" "}
              <Link to={"/login"}>
                <span className="text-blue-400">click here</span>
              </Link>
            </p>
          </div>
        </div>
      </form>
      <Toaster />
    </div>
  );
};

export default SignUp;
