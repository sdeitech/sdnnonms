import React from "react";
import PrivateLayout from "../layout/PrivateLayout";
import Dashboard from "../pages/Dashboard";
import AddUser from "../pages/AddUser";
import UpdateUserProfile from "../pages/UpdateUserProfile";

const PrivateRouters = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },

  {
    path: "/adduser",
    element: (
      <PrivateLayout>
        <AddUser />
      </PrivateLayout>
    ),
  },

  {
    path: "/profile",
    element: (
      <PrivateLayout>
        <UpdateUserProfile />
      </PrivateLayout>
    ),
  },
];

export default PrivateRouters;
