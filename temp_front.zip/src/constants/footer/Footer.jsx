import React from "react";

const Footer = () => {
  return (
    <div className="bg-black text-white text-center py-10 w-full">
      <p>All Rights Reserved</p>
    </div>
  );
};

export default Footer;
