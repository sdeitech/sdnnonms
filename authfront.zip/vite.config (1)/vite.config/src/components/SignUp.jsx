import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
const apiUrl = import.meta.env.VITE_API_URL;

const SignUp = () => {
  const [formData, setFormData] = useState({
    email: "",
    mobile: "",
    gender: "",
    profile: null,
    password: "",
  });

  console.log(formData);
  const handleChnage = (e) => {
    const { name, value, type, files } = e.target;
    if (type === "file") {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${apiUrl}/signup`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      console.log(res.data);
    } catch (error) {
      console.log(error.message);
    }
  };

      return (
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100vh',
            background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
          }}
        >
          <div
            style={{
              padding: '40px',
              backgroundColor: '#fff',
              borderRadius: '12px',
              width: '400px',
              boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)',
              textAlign: 'center',
            }}
          >
            <h1 style={{ fontSize: '28px', marginBottom: '20px', color: '#333' }}>
              Create an Account
            </h1>
            <form
              style={{
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
              }}
              onSubmit={handleSubmit}
              encType="multipart/form-data"
            >
              <input
                type="email"
                name="email"
                placeholder="Email Address"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <input
                type="tel"
                name="mobile"
                placeholder="Mobile Number"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <div
                style={{
                  marginBottom: '15px',
                  display: 'flex',
                  justifyContent: 'space-around',
                  fontSize: '16px',
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center' }}>
                  Male
                  <input
                    type="radio"
                    name="gender"
                    value="male"
                    checked={formData.gender === 'male'}
                    onChange={handleChnage}
                    style={{ marginLeft: '8px' }}
                  />
                </label>
                <label style={{ display: 'flex', alignItems: 'center' }}>
                  Female
                  <input
                    type="radio"
                    name="gender"
                    value="female"
                    checked={formData.gender === 'female'}
                    onChange={handleChnage}
                    style={{ marginLeft: '8px' }}
                  />
                </label>
              </div>
              <input
                type="file"
                name="profile"
                onChange={handleChnage}
                required
                style={{
                  marginBottom: '15px',
                  padding: '10px',
                  backgroundColor: '#f9f9f9',
                  borderRadius: '8px',
                  border: '1px dashed #ddd',
                  cursor: 'pointer',
                  fontSize: '14px',
                }}
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                onChange={handleChnage}
                required
                style={{
                  padding: '12px',
                  marginBottom: '20px',
                  borderRadius: '8px',
                  border: '1px solid #ddd',
                  fontSize: '16px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  transition: 'border-color 0.3s ease',
                }}
              />
              <button
                type="submit"
                style={{
                  padding: '12px',
                  borderRadius: '8px',
                  backgroundColor: '#6a11cb',
                  color: 'white',
                  fontSize: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  marginBottom: '15px',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
                  transition: 'background-color 0.3s ease',
                }}
                onMouseOver={(e) => (e.target.style.backgroundColor = '#5e10b1')}
                onMouseOut={(e) => (e.target.style.backgroundColor = '#6a11cb')}
              >
                Sign Up
              </button>
            </form>
            <p style={{ marginTop: '15px', color: '#666' }}>
              Already have an account?{' '}
              <Link
                to="/login"
                style={{
                  color: '#2575fc',
                  textDecoration: 'none',
                  fontWeight: 'bold',
                }}
                onMouseOver={(e) => (e.target.style.textDecoration = 'underline')}
                onMouseOut={(e) => (e.target.style.textDecoration = 'none')}
              >
                Sign In
              </Link>
            </p>
          </div>
        </div>
      );
    };
    

export default SignUp;

// const onFinishFailed = (errorInfo) => {
//   console.log("Failed:", errorInfo);
// };
// const App = () => (
//   <>
//     <h1 style={{ textAlign: "center" }}>Register</h1>
//     <div
//       style={{
//         justifyContent: "cenetr",
//         display: "flex",
//         alignItems: "center",
//         border: "solid 3px",
//       }}
//     >
//       <Form
//         name="basic"
//         labelCol={{
//           span: 8,
//         }}
//         wrapperCol={{
//           span: 16,
//         }}
//         style={{
//           maxWidth: 600,
//         }}
//         initialValues={{
//           remember: true,
//         }}
//         onFinish={onFinish}
//         onFinishFailed={onFinishFailed}
//         autoComplete="off"
//       >
//         <Form.Item
//           label="Email"
//           name="Email"
//           rules={[
//             {
//               required: true,
//               message: "Please input your email!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>

//         <Form.Item
//           label="Password"
//           name="password"
//           rules={[
//             {
//               required: true,
//               message: "Please input your password!",
//             },
//           ]}
//         >
//           <Input.Password />
//         </Form.Item>

//         <Form.Item
//           label="Phone"
//           name="phone"
//           rules={[
//             {
//               required: true,
//               message: "Please input your phone number!",
//             },
//           ]}
//         >
//           <Input />
//         </Form.Item>

//         <Form.Item
//           name="remember"
//           wrapperCol={{
//             offset: 8,
//             span: 16,
//           }}
//         >
//           <Checkbox>Remember me</Checkbox>
//         </Form.Item>

//         <Form.Item
//           wrapperCol={{
//             offset: 8,
//             span: 16,
//           }}
//         >
//           <Button
//             type="primary"
//             htmlType="submit"
//             style={{
//               alignItems: "center",
//               display: "flex",
//               justifyContent: "center",
//             }}
//           >
//             Submit
//           </Button>
//         </Form.Item>
//       </Form>
//     </div>
//   </>
// );
// export default App;
