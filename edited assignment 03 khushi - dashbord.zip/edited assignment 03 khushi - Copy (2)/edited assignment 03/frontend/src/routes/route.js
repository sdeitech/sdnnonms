import { createBrowserRouter } from "react-router-dom";
import SignIn from "../components/SignInForm";
import Signup from "../components/SignUpForm";
import Layout from "../layout/privatLayout";
import PrivateLayout from "../layout/privatLayout";
import Dashboard from "../components/dashbord";
//import MyProfile from "../components/constants/MyProfile";
//import PrivateRoute from "../routes/PrivatRoute"
const routers = createBrowserRouter([
  {
    path: "/",
    exact: true,
    element: (
      <Layout>
        <SignIn />
      </Layout>
    ),
  },
  {
    path: "/signup",
    exact: true,
    element: (
      <Layout>
        <Signup />
      </Layout>
    ),
  },
  // {
  //   path: "/myprofile",
  //   exact: true,
  //   element: (
  //     <Layout>
  //       <PrivateLayout>
  //         <MyProfile />
  //       </PrivateLayout>
  //     </Layout>
  //   ),
  // },
//   {
//     path: "/table",
//     exact: true,
//     element: (
//       <Layout>
//         <PrivateLayout>
//           <TableView />
//         </PrivateLayout>
//       </Layout>
//     ),
//   },
  {path:"/dashbord",
		exact:true,
	     element:(
			<Layout>
				<PrivateLayout>
					<Dashboard/>
				</PrivateLayout>
			</Layout>
		 ),
  },
]);
export default routers;
