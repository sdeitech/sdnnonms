import React, { useState, useEffect, useRef } from "react";
import { Button, Form, Alert, Spinner } from "react-bootstrap";
import DefaultImage from "../assets/avatar.png";
import EditIcon from "../assets/edit-text.png";
// import { URLs } from "../constants/urlConstants";
import axios from "axios";

const MyProfile = () => {
  const [avatarURL] = useState(DefaultImage);
  const [profileData, setProfileData] = useState({});
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef();

  const initialState = {
    firstName: "",
    lastName: "",
    email: "",
    dob: "",
    marriedStatus: false,
    gender: "",
  };

  const [formData, setFormData] = useState(initialState);

  useEffect(() => {
    const fetchProfileData = async () => {
      setLoading(true);
      setErrorMessage("");
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get("http://localhost:5000/user/api", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProfileData(response.data);
        setFormData(response.data);
      } catch (error) {
        setErrorMessage("Error fetching profile data.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfileData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");
    try {
      const token = localStorage.getItem("token");
      await axios.put(`${ "http://localhost:5000/user/api/getReport"}/${profileData._id}`, formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (error) {
      setErrorMessage("Failed to update profile.");
    } finally {
      setLoading(false);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Handle image upload logic
      console.log("Selected file:", file);
    }
  };

  return (
    <div>
      {loading && <Spinner animation="border" />}
      {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
      <div className="relative h-96 w-96 m-8">
        <img src={avatarURL} alt="Avatar" className="h-96 w-96 rounded-full" />
      </div>
      <Form onSubmit={handleProfileUpdate} encType="multipart/form-data">
        <button type="button" onClick={triggerFileUpload} className="flex-center absolute bottom-12 right-14 h-9 w-9 rounded-full">
          <img src={EditIcon} alt="Edit" className="object-cover" />
        </button>
        <input type="file" ref={fileInputRef} hidden onChange={handleFileChange} />

        {Object.entries(formData).map(([key, value]) => (
          <Form.Group key={key} className="mb-3" controlId={`form${key.charAt(0).toUpperCase() + key.slice(1)}`}>
            <Form.Label>{key.charAt(0).toUpperCase() + key.slice(1)}</Form.Label>
            {key === "gender" ? (
              <Form.Control as="select" name={key} value={value} onChange={handleInputChange}>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </Form.Control>
            ) : (
              <Form.Control
                type={key === "dob" ? "date" : key === "email" ? "email" : "text"}
                placeholder={`Enter ${key.charAt(0).toUpperCase() + key.slice(1)}`}
                name={key}
                value={value}
                onChange={handleInputChange}
              />
            )}
          </Form.Group>
        ))}

        <Button variant="warning" type="submit" disabled={loading}>
          {loading ? "Updating..." : "Update"}
        </Button>
      </Form>
    </div>
  );
};

export default MyProfile;
