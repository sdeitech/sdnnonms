 import ViewRecordModal from "./ViewRecordModel";
import { Table, Button, Pagination } from "react-bootstrap";
import { useEffect, useState } from "react";
import axios from "axios";
import UpdateRecordModal from "./UpdateTableViewdata";
//import { toast, ToastContainer } from "react-toastify";
//import "react-toastify/ReactToastify.css";

function TableView() {
  /**
   * Initialization of useStates
   */
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [limit] = useState(5);
  const [search, setSearch] = useState("");
  const [show, setShow] = useState(false);
  const [item, setItem] = useState({});
  const [updateShow, setUpdateShow] = useState(false);

  /**
   * Function to fetch Records from backend with pagination
   */
  const getRecordHandle = async (page, limit, search = "") => {
    try {
      const token = localStorage.getItem("token");
      const result = await axios.get(
        "http://localhost:5000/user/api",
        {
          params: { page, limit, search },
          headers: {
            Authorization: `Bearer ${token}`, // Attach token in Authorization header
          },
        }
      );
      // to check if data is passed properly or not
      console.log(result.data);

      // To validate the data is properly passed in setData or not
      if (result.data && result?.data.user) {
        setData(result.data.user);
        setTotalPages(result.data.totalPages);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // useEffect is used to Fetch data
  useEffect(() => {
    getRecordHandle(page, limit, search);
  }, [page, limit, search]);

  /**
   * Delete Handler to delete records from the Table
   */
  const deleteHandle = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(
        `http://localhost:5000/user/api//${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      getRecordHandle(page, limit, search);
    } catch (error) {
      console.error(error);
    }
  };

  // For Modal View Handler
  const handeshow = (ele) => {
    setShow(true);
    setItem(ele);
  };

  const handleClose = () => {
    setShow(false);
  };

  // For Update Modal View Handler
  const handleUpdateShow = (ele) => {
    setUpdateShow(true);
    setItem(ele);
  };

  const handleUpdateClose = () => {
    setUpdateShow(false);
  };

  const onUpdate = () => {
    getRecordHandle(page, limit, search);
    
  };

  // Pagination Handlers for Next Record
  const handleNext = () => {
    if (page < totalPages) setPage(page + 1);
  };

  // Pagination Handlers for Previous Record
  const handlePrevious = () => {
    if (page > 1) setPage(page - 1);
  };

  return (
    <>
      <input
         className="w3-input w3-border"
        type="search"
        placeholder="Search Data"
        value={search}
        onChange={(e) => {
          setSearch(e.target.value);
        }}
      />
      
      <ViewRecordModal show={show} data={item} handleClose={handleClose} />
      <UpdateRecordModal
        handleUpdateShow={updateShow}
        handleUpdateClose={handleUpdateClose}
        data={item}
        onUpdate={onUpdate}
      />
      <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>SrNo</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(data) &&
            data.map((ele) => {
              return (
                <tr key={ele._id}>
                  <td>{ele.SrNo}</td>
                  <td>{ele.firstname}</td>
                  <td>{ele.lastname}</td>
                  <td>{ele.email}</td>
                  <td>
                    <Button className="w3-input w3-border" onClick={() => handeshow(ele)} variant="info">
                      VIEW
                    </Button>
                    <Button    className="w3-input w3-border"
                      variant="danger"
                      onClick={() => deleteHandle(ele._id)}
                    >
                      DELETE
                    </Button>
                    <Button
                       className="w3-input w3-border"
                      variant="warning"
                      onClick={() => handleUpdateShow(ele)}
                    >
                      UPDATE
                    </Button>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </Table>

      {/* Pagination Controls */}
      <Pagination>
        <Pagination.Prev onClick={handlePrevious} disabled={page === 1} />
        <Pagination.Item active>{page}</Pagination.Item>
        <Pagination.Next onClick={handleNext} disabled={page === totalPages} />
      </Pagination>
    </>
  );
}

export default TableView;

