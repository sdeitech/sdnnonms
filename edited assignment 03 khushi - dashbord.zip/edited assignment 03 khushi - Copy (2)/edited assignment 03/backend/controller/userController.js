const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const File= require("../models/multer.model");
const userModel =require("../models/userModels")
const userdataModel =require("../models/userDataModel") 
const jwt = require("jsonwebtoken");
const modelUser = require("../models/userModels");
const {
  OK,
  CREATED,
  BAD_REQUEST,
  NOT_FOUND,
  RECORD_NOT_FOUND,
  REGISTER_FAILED,
  RECORD_FOUND,
  REGISTERED,
  REMOVED,
  UPDATED,
  UPDATE_FAILED,
} = require("../config/constants");
//get

exports.getUser = async (req, res) => {
  const { page = 1, limit = 5, search = "" } = req.query;
  const pageNo = Number(page);
  const limitNo = Number(limit);
  const skip = (pageNo - 1) * limitNo;
  try {
    const searchRegex = new RegExp(search, "i");
    const query = {
      $or: [
        { firstName: { $regex: searchRegex } },
        { lastName: { $regex: searchRegex } },
        { email: { $regex: searchRegex } },
        { dob: { $regex: searchRegex } },
        { marriedStatus: { $regex: searchRegex } },
        { gender: { $regex: searchRegex } },
      ],
    };

    const userFetch = await modelUser
      .find()
      .sort({ firstName: 1 })
      .skip(skip)
      .limit(limitNo);
    const totalNoOfRecords = await userModel.countDocuments(query);
    const totalPages = Math.ceil(totalNoOfRecords / limitNo);

    res.status(200).json({
      message: "RECORD_FOUND",
      user: userFetch,
      totalNoOfRecords,
      totalPages,
    });
  } catch (error) {
    res.status(400).json({ message: "RECORD_NOT_FOUND" });
  }
};



  // try {
  //   const userFetch = await modelUser.find().sort({ name: 1 });
  //   res.status(OK).json({ message: RECORD_FOUND, user: userFetch });
  // } catch (error) {
  //   res.status(BAD_REQUEST).json({ message: NOT_FOUND });
  // }
// For Fetching User by Id
exports.getUserById = async (req, res) => {
  try {
    const getUserById = await userModel.findById({ _id: req.params.id });
    res.status(OK).json({ message: RECORD_FOUND, report: getUserById });
  } catch (error) {
    res.status(NOT_FOUND).json({ error: RECORD_NOT_FOUND });
  }
};
//create user records 

exports.createUser = async (req, res) => {
  const { firstname, lastname, email, DOB, marriedStatus, gender, password } =
    req.body;
  try {
    console.log(req.body)
    // const user = new userModel(req.body);
    const hashPass = await bcrypt.hash(password, 10);
    console.log(hashPass)
    const newUser = new modelUser({
      firstname,
      lastname,
      email,
      DOB,
      marriedStatus,
      gender,
      password: hashPass,
    });

    await newUser.save();
    res.status(OK).json({ message: REGISTERED, record: newUser });
  } catch (error) {
    console.log(error)
    res.status(BAD_REQUEST).json({ message: REGISTER_FAILED });
  }
};

// To add data into Secondary Model userData
exports.newUserStorage = async (req, res) => {
  try {
    const { firstName, lastName, email } = req.body;
    const { id } = req.params;

    const searchUser = await userdataModel.findOne({ email: email });
    if (searchUser) {
      return res.status(FORBIDDEN).json({ message: EXISTS });
    }

    const isExistUser = await userModel.findById(id);
    if (!isExistUser) {
      return res.status(NOT_FOUND).json({ message: NOT_FOUND });
    }

    const newUserModel = new userdataModel({
      firstName,
      lastName,
      email,
    });
    await newUserModel.save();
    const pushUser = await userModel.findByIdAndUpdate(id, {
      $push: { users: newUserModel },
    });
    await pushUser.save();
    res.status(OK).json({ message: REGISTERED });
  } catch (error) {
    console.error(error);
    res.status(SERVER_ERROR).json({ message: SERVER_MESSAGE_ERROR });
  }
};
// For Updating an User Record
exports.updateUser = async (req, res) => {
  try {
    const updateUser = await userModel.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
      }
    );
    if (!updateUser) {
      return res.status(NOT_FOUND).json({ error: RECORD_NOT_FOUND });
    }
    res.status(OK).json({ message: UPDATED, item: updateUser });
  } catch (error) {
    console.log(error);
    res.status(NOT_FOUND).json({ error: UPDATE_FAILED });
  }
};

// Delete User
exports.deleteUser = async (req, res) => {
  try {
    const removeID = await modelUser.findByIdAndDelete(req.params.id);
    if (!removeID) {
      res.status(BAD_REQUEST).json({ error: "No Record Found!!" });
    }
    res.json({ message: REMOVED, record: removeID });
  } catch (error) {
    res.status(NOT_FOUND).json({ error: error.message });
  }
};
//login 

exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(req.body)
    const user = await modelUser.findOne({ email }).select("password");

    if (!user) {
      return res.status(404).json({ msg: "user not found" });
    }
    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      const token = jwt.sign({ email, password }, "This_is_key : ", {
        expiresIn: "3h",
      });

      user.token = token;
      console.log(user.token)
      await user.save();

      return res.status(201).json({ msg: "Loged In", token: token });
    } else {
      return res.status(401).json({ msg: "Invalid Credentials" });
    }
  } catch (error) {
    
    console.log(error)
    res.status(401).json({ ERROR: error.message });
    
  }
};
//For File Uploading
exports.uploadimage = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  try {
    const newFile = new File({
      filename: req.file.filename,
      path: req.file.path,
      mimetype: req.file.mimetype,
      size: req.file.size,
    });

    await newFile.save();
    res
      .status(200)
      .json({ message: "File uploaded successfully", file: req.file });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

