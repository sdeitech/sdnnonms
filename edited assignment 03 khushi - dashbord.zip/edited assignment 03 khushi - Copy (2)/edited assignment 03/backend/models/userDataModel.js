import mongoose from "mongoose";

const userDataSchema = mongoose.Schema(
    {
        firstName: {
            type: String,
            required: true,
          },
          lastName: {
            type: String,
            required: true,
          },
          email: {
            type: String,
            required: true,
            unique: true,
          },

    },
);

const userDataModel =mongoose.model("userData",userDataSchema);

module.exports=userDataModel;