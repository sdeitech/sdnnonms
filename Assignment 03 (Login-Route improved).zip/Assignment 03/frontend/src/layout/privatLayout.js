import {useNavigate, Link} from "react-router-dom";

const PrivateLayout = ({ children }) => {
const navigate = useNavigate()

    const logoutHandle = () => {
    localStorage.removeItem('token')
    // localStorage.removeItem('userData')
    navigate("/")
}
    return (
        <>
        <div className="layout">
            <Link to='/dashbord'>Back to Pavilion</Link>
            <div className="content">
                {children}
            </div>
            <button onClick={logoutHandle}>LogOut</button>
        </div>
        
        </>
    );
};

export default PrivateLayout;