import { createBrowserRouter } from "react-router-dom";
import SignIn from "../components/SignInForm";
import Signup from "../components/SignUpForm";
import Layout from "../layout/privatLayout";
import Dashboard from "../components/dashbord";
import MyProfile from "../components/MyProfile";
import PrivatRoute from "./PrivatRoute";

const routers = createBrowserRouter([
  {
    path: "/",
    exact: true,
    element: (
      <Layout>
        <SignIn />
      </Layout>
    ),
  },
  {
    path: "/signup",
    exact: true,
    element: (
      <Layout>
        <Signup />
      </Layout>
    ),
  },
  {
    path: "/profile",
    exact: true,
    element: (
      <Layout>
          <MyProfile />
      </Layout>
    ),
  },
  {path:"/dashbord",
		exact:true,
	     element:(
			<Layout>
				<PrivatRoute>
					<Dashboard/>
				</PrivatRoute>
			</Layout>
		 ),
  },
]);
export default routers;
