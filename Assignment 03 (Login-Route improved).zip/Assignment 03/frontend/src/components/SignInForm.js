import axios from "axios";
import { useState } from "react";
import { Link, useNavigate} from "react-router-dom";
import "../App.css";

const Signin = () => {
  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  const changeHandle = (x) => {
    setData({ ...data, [x.target.name]: x.target.value });
  };

  const onSubmitHandle = async (x) => {
    x.preventDefault();
    try {
      console.log(data)
      const response = await axios.post(
        "http://localhost:5000/user/api/login",
        data
      );
      
      localStorage.setItem("token", response.data?.token);
      navigate("/dashbord");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div>
        
        <h2 className="header">Signin Form</h2>
      </div>
      <form onSubmit={onSubmitHandle}>
        <div>
          <input
          className="email"
            type="text"
            placeholder="Enter email"
            name="email"
            value={data.email}
            onChange={changeHandle}
            required
          />
          <input
          
            className="password"
            type="text"
            placeholder="Enter password"
            name="password"
            value={data.password}
            onChange={changeHandle}
            required
          />
        </div>
        <button type="submit">SUBMIT</button>
        <Link to="/signup">Not a User?</Link>
        {/* <Navigate to="/signup">gg</Navigate> */}
    
      </form>
    </>
  );
};
export default Signin;
