import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "../App.css";

/**
 * Main ViewRecordModal function has parameters as props
 */
function ViewRecordModal({ show, handleClose, data }) {

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {data?.firstname} {data?.lastname} Record
            
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="Show-body">
            <label>first name</label>
            <h4>{data?.firstname}</h4>
            <label>Last Name</label>
            <h4>{data?.lastname}</h4>
            <label>Email Address</label>
            <h3>{data?.email}</h3>
            <label>Date of Birth</label>
            <h3>{data?.dob}</h3>
            <label>Married Status</label>
            <h3>{data?.marriedStatus}</h3>
            <label>Gender</label>
            <h3>{data?.gender}</h3>
          </div>
        
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={handleClose}>
            Okay
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ViewRecordModal;