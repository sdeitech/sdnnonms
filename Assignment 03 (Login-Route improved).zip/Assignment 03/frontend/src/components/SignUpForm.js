import axios from "axios";
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "../App.css";

const SignUp = () => {
  const [data, setData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    DOB: "",
    gender: "",
    marriedStatus: "",
    password: "",
  });
  const navigate = useNavigate();

  const changeHandle = (e) => {
    const { name, value, type, checked } = e.target;

    setData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const onSubmitHandle = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/user/api", data);

      localStorage.setItem("token", response.data.token);
      console.log(response.data.token);
      navigate("/dashbord");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div>
        <h2 className="App-header">Signup form</h2>
      </div>
      <form onSubmit={onSubmitHandle}>
        <div>
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter firstname"
            name="firstname"
            onChange={changeHandle}
          />
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter lastname"
            name="lastname"
            onChange={changeHandle}
          />
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter the email"
            name="email"
            onChange={changeHandle}
          />
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter the date of birth"
            name="DOB"
            onChange={changeHandle}
          />
          <input
            className="w3-input w3-border"
            type="checkbox"
            name="marriedStatus"
            checked={data.marriedStatus}
            onChange={changeHandle}
          />
          <label className="w3-input w3-border"> Married</label>
          <br />

          <input
            className="w3-input w3-border"
            type="password"
            placeholder="Enter the password"
            name="password"
            onChange={changeHandle}
          />
          <div>
          <select
                  id="gender"
                  name="gender"
                  className="form-select"
                  onChange={changeHandle}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
          </div>
        </div>
        <button type="submit">Submit</button>
        <Link to="/">Already User?</Link>
      </form>
    </>
  );
};

export default SignUp;
