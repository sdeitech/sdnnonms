import { Button , Form  } from "react-bootstrap";
import TableView from "./Tableviewdata";
import { useState } from "react";
import {Link} from 'react-router-dom'
import axios from "axios";


const Dashboard = () => {
  const [data,setData]=useState({
    firstname: "",
    lastname: "",
    topics: "",
  });


  const onChangeHandle = (e) => {
    const { name, value } = e.target;
    setData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const addDataHandle = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost/5000/user/api/useData", data);
      localStorage.setItem("token", response.data?.token);
      alert("User added successfully!");
    } catch (error) {
      console.error("Error Adding Data", error);
    }
  };



  return (
    <>
    <div>
      <Link to='/profile'>Profile</Link>
      <h2>Add User</h2>
      <Form onSubmit={addDataHandle}>
        <Form.Group className="mb-3" controlId="formFirstName">
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter First Name"
            name="firstName"
            value={data.firstname}
            onChange={onChangeHandle}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formLastName">
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Last Name"
            name="lastName"
            value={data.lastname}
            onChange={onChangeHandle}
            required
          />
  
        </Form.Group>

        <Button variant="primary" type="submit">
          Add User
        </Button>
      </Form>
    </div>
    <div>
      <TableView />
    </div>
  </>
);
};


export default Dashboard;