import React, { useState, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import axios from "axios";

const MyProfile = () => {
  const [formData, setFormData] = useState([])
  const token = localStorage.getItem("token");

  console.log("FORM DATA --> ", formData)

  useEffect(() => {
    const fetchProfileData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/user/api");
        console.log("MYPROFILE ---> ", response.data.user)
        setFormData(response.data.user);

        console.log("FORM DATA ---> ", formData)
        // setFormData(response.data);
      } catch (error) {
      }
    };

    fetchProfileData();
  }, [token]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.get(`http://localhost:5000/user/api/getReport`, formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (error) {
      console.error("Failed to update profile.", error.message);
    }
  };


  return (
    
      <Form encType="multipart/form-data">
        
        {/* First Name Field */}
        <Form.Group className="mb-3" controlId="formFirstName">
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter First Name"
            name="firstname"
            value={formData.firstname}
            onChange={handleInputChange}
            required
          />
        </Form.Group>

        {/* Last Name Field */}
        <Form.Group className="mb-3" controlId="formLastName">
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Last Name"
            name="lastname"
            value={formData.lastname}
            onChange={handleInputChange}
            required
          />
        </Form.Group>

        {/* Email Field */}
        <Form.Group className="mb-3" controlId="formEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter Email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            required
          />
        </Form.Group>

        {/* Date of Birth Field */}
        <Form.Group className="mb-3" controlId="formDob">
          <Form.Label>Date of Birth</Form.Label>
          <Form.Control
            type="date"
            name="dob"
            value={formData.dob ? formData.dob.split("T")[0] : ""}
            onChange={handleInputChange}
            required
          />
        </Form.Group>

        {/* Married Status Checkbox */}
        <Form.Group className="mb-3" controlId="formMarriedStatus">
          <Form.Check
            type="checkbox"
            label="Married"
            name="marriedStatus"
            checked={formData.marriedStatus === "true"}
            onChange={handleInputChange}
          />
        </Form.Group>

        {/* Gender Field */}
        <Form.Group className="mb-3" controlId="formGender">
          <Form.Label>Gender</Form.Label>
          <Form.Control
            as="select"
            name="gender"
            value={formData.gender}
            onChange={handleInputChange}
            required
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </Form.Control>
        </Form.Group>

        {/* Update Button */}
        <Button variant="warning" onClick={handleProfileUpdate}>
          Update
        </Button>        
        

      </Form>
  );
};

export default MyProfile;
