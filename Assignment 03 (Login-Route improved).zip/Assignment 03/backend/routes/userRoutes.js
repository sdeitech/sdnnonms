import express from "express";
import userController from "../controller/userController.js";
import verifyToken from "../middleware/viewToken.middleware.js";
import { uploadMiddleware } from "../helper/multer.js";


const router = express.Router();


router.get("/api", userController.getUser);
router.get("/api/:id", verifyToken, userController.getUserById);
router.post("/api", userController.createUser);
router.put("/api/:id", verifyToken, userController.updateUser);
router.delete("/api/:id", verifyToken, userController.deleteUser);

router.post("/api/useData/:id", userController.newUserStorage);

router.post("/api/login", userController.loginUser);

router.post("/image", uploadMiddleware.single('image'),userController.uploadImage);


export default router;
