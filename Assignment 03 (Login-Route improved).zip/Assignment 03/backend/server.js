import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import { dbConnection } from "./config/db.js";
import userRouter from "./routes/userRoutes";

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}))
dbConnection();
app.use("/user", userRouter);
//app.use("/image", userRouter);

/**
 * Exporting App
 */
module.exports = app;
