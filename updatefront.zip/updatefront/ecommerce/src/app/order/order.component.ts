import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { OrderService } from './order.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  shippingAddress: string = ''; // User's default address
  editableAddress: string = ''; // Editable version of the address
  paymentMethod: string = ''; // Holds the selected payment method
  paymentGateway: string = ''; // Holds the selected payment gateway
  finalPrice: number = 0; // Final price for the order
  discount: number = 0; // Discount applied to the order
  showPaymentGateways: boolean = false; // Toggle visibility of payment gateway options

  constructor(private router: Router, private orderService: OrderService) {}

  ngOnInit(): void {
    // Retrieve checkout data from localStorage
    const checkoutData = JSON.parse(localStorage.getItem('checkoutData') || '{}');
    this.finalPrice = checkoutData.finalPrice || 0;
    this.discount = checkoutData.discount || 0;

    // Fetch the user's registered address as the default shipping address
    this.fetchShippingAddress();
  }

  fetchShippingAddress(): void {
    try {
      this.orderService.getShippingAddress().subscribe(
        (response: any) => {
          this.shippingAddress = response.shipping_address || '';
          this.editableAddress = this.shippingAddress; // Set editable address to the fetched address
        },
        (error) => {
          console.error('Error fetching shipping address:', error);
          if (error.status === 401) {
            Swal.fire({
              title: 'Unauthorized',
              text: 'Your session has expired. Please log in again.',
              icon: 'error'
            });
            this.router.navigate(['/login']);
          } else {
            Swal.fire({
              title: 'Error',
              text: 'Unable to fetch your shipping address.',
              icon: 'error'
            });
          }
        }
      );
    } catch (e) {
      console.error('Token error:', e);
      Swal.fire({
        title: 'Error',
        text: 'Authentication token is missing or invalid. Please log in again.',
        icon: 'error'
      });
      this.router.navigate(['/login']);
    }
  }

  saveShippingAddress(): void {
    if (!this.editableAddress.trim()) {
      Swal.fire({
        title: 'Invalid Address',
        text: 'Shipping address cannot be empty.',
        icon: 'warning'
      });
      return;
    }

    this.orderService.updateShippingAddress(this.editableAddress).subscribe(
      (response: any) => {
        Swal.fire({
          title: 'Address Saved!',
          text: 'Your shipping address has been updated successfully.',
          icon: 'success'
        });
        this.shippingAddress = this.editableAddress;
      },
      (error) => {
        Swal.fire({
          title: 'Error',
          text: 'There was an issue saving your address. Please try again.',
          icon: 'error'
        });
        console.error('Error updating address:', error);
      }
    );
  }

  selectPaymentMethod(method: string): void {
    this.paymentMethod = method;
    this.showPaymentGateways = method === 'Online'; // Show payment gateways if online payment is selected
    if (method !== 'Online') {
      this.paymentGateway = ''; // Reset payment gateway if not online payment
    }
  }

  selectPaymentGateway(gateway: string): void {
    this.paymentGateway = gateway;
  }

  placeOrder(): void {
    if (!this.shippingAddress.trim()) {
      Swal.fire({
        title: 'No Shipping Address',
        text: 'Please provide a valid shipping address before proceeding.',
        icon: 'warning'
      });
      return;
    }

    if (!this.paymentMethod) {
      Swal.fire({
        title: 'No Payment Method',
        text: 'Please select a payment method before proceeding.',
        icon: 'warning'
      });
      return;
    }

    if (this.paymentMethod === 'Online' && !this.paymentGateway) {
      Swal.fire({
        title: 'No Payment Gateway',
        text: 'Please select a payment gateway for online payment.',
        icon: 'warning'
      });
      return;
    }

    const orderData = {
      shipping_address: this.shippingAddress,
      payment_method: this.paymentMethod,
      payment_gateway: this.paymentGateway || null,
      total_amount: this.finalPrice
    };

    this.orderService.placeOrder(orderData).subscribe(
      (response: any) => {
        Swal.fire({
          title: 'Order Placed!',
          text: `Your order has been placed successfully! Total: ${this.finalPrice} with ${this.discount}% discount.`,
          icon: 'success'
        });
        this.router.navigate(['/']);
      },
      (error) => {
        Swal.fire({
          title: 'Error',
          text: 'There was an issue placing your order. Please try again.',
          icon: 'error'
        });
        console.error('Error placing order:', error);
      }
    );
  }
}
