import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router'; // Import Router
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private http: HttpClient, private router: Router) {} // Inject Router

  onSubmit(loginForm: any) {
    // Prepare the login credentials
    const loginData = {
      email: loginForm.value.email,
      password: loginForm.value.password
    };

    // API request to login
    this.http.post('http://localhost:8900/api/login/', loginData).subscribe(
      (response: any) => {
        // If login is successful, store the token in localStorage
        if (response.token) {
          localStorage.setItem('token', response.token);
          localStorage.setItem('shippingAddress',response.shipping_address);

          // Show success alert
          Swal.fire({
            title: "Good job!",
            text: "Login successful",
            icon: "success"
          }).then(() => {
            // Navigate to the home page after the user closes the alert
            this.router.navigate(['/home']);
          });
        } else {
          Swal.fire({
            title: "Error!",
            text: "Login failed, please try again",
            icon: "error"
          });
        }
      },
      (error) => {
        // Handle error
        Swal.fire({
          title: "Error!",
          text: "Something went wrong. Please try again later.",
          icon: "error"
        });
      }
    );

    // Handle the login form logic here
    console.log('Login form submitted');
  }
}
