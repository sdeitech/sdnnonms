import { Component } from '@angular/core';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { RegistrationService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  constructor(private registrationService: RegistrationService) {}

  onSubmit(registrationForm: NgForm) {
    if (registrationForm.valid) {
      const formData = registrationForm.value;
      this.registrationService.register(formData).subscribe(
        response => {
          // Display success alert when registration is successful
          Swal.fire({
            title: "Good job!",
            text: "Registration successful",
            icon: "success"
          });
          console.log('Registration successful:', response);
        },
        error => {
          // Display error alert if registration fails
          Swal.fire({
            title: "Oops!",
            text: "Registration failed. Please try again.",
            icon: "error"
          });
          console.log('Registration failed:', error);
        }
      );
    } else {
      // Show alert if form is not valid
      Swal.fire({
        title: "Error!",
        text: "Please fill in all fields correctly.",
        icon: "error"
      });
    }
  }
}
