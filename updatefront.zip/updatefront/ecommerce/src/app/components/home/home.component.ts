import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
   name:string = "welcome to our website"
   image:string="https://www.shutterstock.com/image-photo/calm-weather-on-sea-ocean-600nw-2212935531.jpg"
   description:string="Nature is the source of all true knowledge."
   details:string="heyyyyyyyyyyyyy"
}
