import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // Import HttpClient and HttpHeaders
import Swal from 'sweetalert2';
import { CouponService } from '../../coupon.service';

interface Product {
  name: string;
  price: number;
  image: string;
  quantity?: number; 
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  curruntCount:any

  constructor(private http: HttpClient , private couponService :CouponService) {}

  ngOnInit(): void {
    this.getProducts(); 
  }

  // Fetch products from the API with Authorization Header
  getProducts(): void {
    const apiUrl = 'http://127.0.0.1:8900/api/products/';
    
    // Retrieve the token from localStorage
    const token = localStorage.getItem('token');
    if (!token) {
      Swal.fire({
        title: 'Error',
        text: 'User is not authenticated. Please log in.',
        icon: 'error'
      });
      return;
    }

    // Set up headers with the token
    const headers = new HttpHeaders({
      'Authorization': `Token ${token}`
    });

    this.http.get<Product[]>(apiUrl, { headers }).subscribe({
      next: (response) => {
        console.log('Fetched products:', response);  // Log the API response
        this.products = response;
      },
      error: (error) => {
        console.error('Error fetching products:', error);
        Swal.fire({
          title: 'Error',
          text: 'There was an error loading products.',
          icon: 'error'
        });
      }
    });
  }
  

  // Add product to cart
  addToCart(product: Product): void {
    let cart: Product[] = JSON.parse(localStorage.getItem('cart') || '[]');
    
    // Check if the product already exists in the cart
    const existingProduct = cart.find(item => item.name === product.name);
    
    if (existingProduct) {
      // If the product exists, increase its quantity
      existingProduct.quantity = (existingProduct.quantity || 1) + 1;
    } else {
      // If the product doesn't exist, add it with quantity 1
      product.quantity = 1;
      cart.push(product);
     this.curruntCount = this.couponService.getCartCount()
     this.couponService.updateCartCount(this.curruntCount+1)

    }
    
    // Save the updated cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
  
    // Show success message
    Swal.fire({
      title: 'Good job!',
      text: `${product.name} added to cart.`,
      icon: 'success'
    });
  
    console.log(`${product.name} added to cart.`);
  }

  imageshow(path: string): string {
    return 'http://127.0.0.1:8900' + path;
  }
}
