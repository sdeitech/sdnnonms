import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { CouponService } from '../../coupon.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  cartCount: number = 0;
  couponCode: string = '';
  couponValid: boolean = false;
  totalPrice: number = 0;
  discount: number = 0; // Initialize discount to 0
  finalPrice: number = 0;

  constructor(private couponService: CouponService) {}

  ngOnInit(): void {
    this.loadCart();
  }

  // Load the cart
  loadCart(): void {
    this.couponService.getCart().subscribe(
      (response) => {
        this.cart = response.cart || [];
        this.updateCartCount();
        this.calculateTotalPrice();
      },
      (error) => {
        console.error('Error loading cart:', error);
        Swal.fire({
          title: 'Error',
          text: 'There was an issue loading your cart. Please try again later.',
          icon: 'error'
        });
      }
    );
  }

  // Update the cart count
  updateCartCount(): void {
    this.cartCount = this.cart.reduce((total, item) => total + item.quantity, 0);
  }

  // Calculate the total price of the cart
  calculateTotalPrice(): void {
    this.totalPrice = 0;
    this.cart.forEach(item => {
      this.totalPrice += item.price * item.quantity;
    });
    this.finalPrice = this.totalPrice - this.discount;
  }

  // Increase the quantity of a product in the cart
  increaseQuantity(product: any): void {
    product.quantity++;
    this.updateCartItem(product);
  }

  // Decrease the quantity of a product in the cart
  decreaseQuantity(product: any): void {
    if (product.quantity > 1) {
      product.quantity--;
      this.updateCartItem(product);
    }
  }

  // Update the cart item on the server
  updateCartItem(product: any): void {
    this.couponService.updateCartItem(product.id, product.quantity).subscribe(
      (response) => {
        this.loadCart(); // Reload cart after update
      },
      (error) => {
        console.error('Error updating cart item:', error);
        Swal.fire({
          title: 'Error',
          text: 'There was an issue updating the cart. Please try again later.',
          icon: 'error'
        });
      }
    );
  }

  // Remove a product from the cart
  removeFromCart(product: any): void {
    this.couponService.removeCartItem(product.id).subscribe(
      (response) => {
        this.loadCart(); // Reload cart after removing item
      },
      (error) => {
        console.error('Error removing product from cart:', error);
        Swal.fire({
          title: 'Error',
          text: 'There was an issue removing the product from your cart. Please try again later.',
          icon: 'error'
        });
      }
    );
  }

  // Apply the coupon
  applyCoupon(): void {
    this.couponService.validateCoupon(this.couponCode).subscribe(
      (response) => {
        this.discount = response.discount || 0; // Set the discount value
        this.finalPrice = this.totalPrice - this.discount;
        Swal.fire({
          title: 'Success',
          text: 'Coupon applied successfully!',
          icon: 'success'
        });
      },
      (error) => {
        this.discount = 0; // Reset discount if the coupon is invalid
        this.finalPrice = this.totalPrice;
        Swal.fire({
          title: 'Error',
          text: 'Invalid coupon code. Please try again.',
          icon: 'error'
        });
      }
    );
  }

  // Checkout process
  checkout(): void {
    if (this.cart.length === 0) {
      Swal.fire({
        title: 'Error',
        text: 'Your cart is empty. Please add some items to proceed with checkout.',
        icon: 'error'
      });
      return;
    }

    // Proceed with the checkout process (e.g., navigating to checkout page or API call)
    console.log('Proceeding to checkout...');
    // Example: this.router.navigate(['/checkout']);
  }

  // Get image path for a product (define this method)
  getimagepath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `http://127.0.0.1:8000${path.startsWith('/') ? path : '/' + path}`;
  }
}
