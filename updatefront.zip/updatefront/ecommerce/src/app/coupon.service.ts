import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CouponService {


  private apiUrl = 'http://127.0.0.1:8900/api/cart/'; // Base cart API URL
  private couponUrl = 'http://127.0.0.1:8900/api/';
  
// Step 1: Get the initial cart count from localStorage (default to 0 if not found)
 
  // Step 1: Initialize the cart count from localStorage (or default to 0)
 
  
  // Step 2: Create a BehaviorSubject to manage the cart count
  private cartCountSubject = new BehaviorSubject<number>(0);

  constructor(private http: HttpClient) {
  const initialCartCount = parseInt(localStorage.getItem('cartCount') || '0');
  this.cartCountSubject.next(initialCartCount);

    
  }

  // Helper function to get the token from localStorage
  private getAuthToken(): string | null {
    return localStorage.getItem('token'); // Ensure the token is saved as 'token'
  }
    

   // Step 3: Method to get the current cart count
   getCartCount() {
    return this.cartCountSubject.asObservable();  // Return an observable to subscribe to
  }

  // Step 4: Method to update the cart count
  updateCartCount(newCount: number) {
    this.cartCountSubject.next(newCount);
    localStorage.setItem('cartCount', newCount.toString()); // Save the updated count in localStorage
  }

  // Helper function to create headers with the Authorization token
  private createAuthHeaders(): HttpHeaders {
    const token = this.getAuthToken();
    let headers = new HttpHeaders();
    if (token) {
      headers = headers.set('Authorization', `Token ${token}`); // Add token to Authorization header
    }
    return headers;
  }

  // Fetch the user's cart
  getCart(): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.get(this.apiUrl, { headers });
  }

  // Add a product to the cart
  addToCart(productId: number, quantity: number = 1): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}add/`, { product_id: productId, quantity }, { headers });
  }

  // Update cart item quantity
  updateCartItem(productId: number, quantity: number): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}update/`, { product_id: productId, quantity }, { headers });
  }

  // Remove a product from the cart
  removeCartItem(productId: number): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}remove/`, { product_id: productId }, { headers });
  }

  // Validate the coupon
  validateCoupon(couponCode: string): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.couponUrl}validate-coupon/`, { code: couponCode }, { headers });  // Use 'code' instead of 'coupon_code'
  }

  // Clear the cart
  clearCart(): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.delete(this.apiUrl, { headers });
  }
}
