import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CouponService {
  private apiUrl = 'http://127.0.0.1:8900/api/cart/'; // Base cart API URL

  constructor(private http: HttpClient) {}

  // Helper function to get the token from localStorage
  private getAuthToken(): string | null {
    return localStorage.getItem('token'); // Make sure the token is saved as 'token'
  }

  // Helper function to create headers with the Authorization token
  private createAuthHeaders(): HttpHeaders {
    const token = this.getAuthToken();
    console.log('Token:', token);
    let headers = new HttpHeaders();
    if (token) {
      headers = headers.set('Authorization', `Token ${token}`); // Add token to Authorization header
    }
    return headers;
  }

  // Fetch the user's cart with token
  getCart(): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.get(`${this.apiUrl}`, { headers });
  }

  // Add a product to the cart with token
  addToCart(productId: number, quantity: number = 1): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}add/`, { product_id: productId, quantity }, { headers });
  }

  // Update cart item quantity with token
  updateCartItem(productId: number, quantity: number): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}update/`, { product_id: productId, quantity }, { headers });
  }

  // Remove a product from the cart with token
  removeCartItem(productId: number): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}remove/`, { product_id: productId }, { headers });
  }

  // Validate the coupon with token
  validateCoupon(couponCode: string): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}apply-coupon/`, { coupon_code: couponCode }, { headers });
  }

  // Clear the cart with token
  clearCart(): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.delete(`${this.apiUrl}`, { headers });
  }
}
