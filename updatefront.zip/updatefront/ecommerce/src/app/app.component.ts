import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  cartCount: number = 0;
  title = 'Your Application';
  showModal: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.updateCartCount();  // Check cart count when the app starts
  }

  // Check if the user is logged in by verifying if a token exists in localStorage
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token'); // Returns true if token exists
  }

  // Logout functionality
  logout(): void {
    // Clear the token from localStorage
    localStorage.removeItem('token');

    // Optionally clear other user-related data from localStorage
    localStorage.removeItem('user');

    // Redirect the user to the login page
    this.router.navigate(['/login']);
  }

  // Handle cart button click
  handleCartClick(): void {
    if (this.isLoggedIn()) {
      // If the user is logged in, navigate to the cart page
      this.router.navigate(['/cart']);
    } else {
      // If the user is not logged in, show the login prompt modal
      this.showModal = true;
    }
  }

  // Update cart count based on the products in the cart
  updateCartCount(): void {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartCount = cart.reduce((count: number, product: any) => count + (product.quantity || 1), 0);
  }

  // Close the modal
  closeModal(): void {
    this.showModal = false;
  }
}
