import React from "react";
function Paginate({ totalPages, currentPage, setCurrentPage })
 {
  const prevPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const nextPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div>
      <button onClick={prevPage} disabled={currentPage === 1}>
        prevPage
      </button>
      
      {[...Array(totalPages)].map((_, index) => {
        const pageNumber = index + 1; ///because index start with 0
        return (
          <button
            key={pageNumber}
            onClick={() => handlePageClick(pageNumber)}
            disabled={currentPage === pageNumber}
          >
            {pageNumber}
          </button>
        );
      })}

      <button onClick={nextPage} disabled={currentPage === totalPages}>
        nextPage
      </button>
    </div>
  );
}
export default Paginate;
