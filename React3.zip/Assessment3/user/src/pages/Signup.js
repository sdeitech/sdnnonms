import React, { useState } from 'react'
import {Link} from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';

const Signup = () => {
    const [info, setInfo]=useState('');
    const[signUpInfo , setSignupInfo] =useState({
        firstName:'',
        lastName: ' ',
        email:' ',
        dob:' ',
        password: ' ',
        gender:' ',
        file: ' '
  });
//   const[error ,setError] = useState(null)

  const Navigate = useNavigate()

  const handleSignUp = async (e) => {
    e.preventDefault();
    try{
      const userData = new FormData();
      userData.append("firstName",signUpInfo.firstName)
      userData.append("lastName",signUpInfo.lastName)
      userData.append("email",signUpInfo.email)
      userData.append("dob",signUpInfo.dob)
      userData.append("password",signUpInfo.password)
      userData.append("gender",signUpInfo.gender)
      userData.append("file", signUpInfo.file);

      console.log("userData____",userData);
      
        const response = await axios.post('http://localhost:5001/api/register',userData);
        setInfo([...info , response.data]);
        setSignupInfo({
            firstName:'',
            lastName: ' ',
            email:' ',
            dob:' ', 
            password: ' ',
            gender:' '
          
            
         });
         
         localStorage.setItem("user_data", JSON.stringify(response.data.newuser));

         Navigate('/login');
         console.log("SignUp Successful");
    }catch(error){
        console.error(error);
    }

  };
  const handleChange = (e) =>{
    const{name , value} = e.target;
    console.log(name , value);
    const copySignUpInfo ={...signUpInfo};
    copySignUpInfo[name] = value;
    setSignupInfo(copySignUpInfo);

  }
  console.log('signup',signUpInfo)

  return (
    <div className="container">
        <h1>Signup</h1>
        <form onSubmit={handleSignUp}>
            <div>
            <label>FirstName :</label>
            <input
             type="text"
             name="firstName"
             placeholder="Enter your name"
             onChange={handleChange}
            />
            </div>
            <div>
            <label>LastName :</label>
            <input
             type="text"
             name="lastName"
             placeholder="Enter your Last Name"
            onChange={handleChange}
            />
            </div>
            <div>
            <label>Email :</label>
            <input
             type="email"
             name="email"
             placeholder="Enter your Email"
             onChange={handleChange}
            />
            </div>
            <div>
            <label>Date Of Birth :</label>
            <input
             type="Date"
             name="dob"
             placeholder="Enter your Date Of Birth"
              onChange={handleChange}
            />
            </div>
            <div>
            <label>Password :</label>
            <input
             type="password"
             name="password"
             placeholder="Enter Password Here"
              onChange={handleChange}
            />
            </div>
            <div>
            <label>Gender :</label>
            <input
             type="text"
             name="gender"
             placeholder="Enter Password Here"
             onChange={handleChange}
            />
            </div>
            <div>
            <label>Profile Picture :</label>
            <input
             type="file"
             name="file"
             placeholder="Enter File Here"
             onChange={handleChange}
            />
            </div>
            <button type="submit">SignUp</button>
            <span>Already Have An Account?
                <Link to="/login">Login</Link>
            </span>
        </form>
<ToastContainer />
    </div>
  )
}

export default Signup;