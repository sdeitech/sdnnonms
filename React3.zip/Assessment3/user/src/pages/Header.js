import React from 'react'

const Header = () => {
  return (
    <div className='header'>

<li><a href="/myprofile">MyProfile</a></li>

    </div>
  )
}

export default Header