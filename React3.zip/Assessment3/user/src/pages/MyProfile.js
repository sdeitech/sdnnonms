import React from 'react'
import {Link} from 'react-router-dom';
import { useNavigate } from 'react-router-dom'
export const MyProfile = () => {

    const userInfo = localStorage.getItem("user_data");
    const newUserInfo = JSON.parse(userInfo);
    console.log(newUserInfo,"dgsd")
//   const Navigate = useNavigate()
//   Navigate('/dashboard');


  return (
    <div className='container'>
        {/* <h3>My Profile</h3> */}
        <div>
            <p>First Name:{newUserInfo.firstName}</p> 
            <p>Last Name:{newUserInfo.lastName}</p>
            <p>Email:{newUserInfo.email}</p>
            <p>Date Of Birth:{newUserInfo.dob}</p>
            <p>Gender:{newUserInfo.gender}</p>
           <button  className="btn" type="submit">Update</button>
        </div>
    <Link to='/dashboard'> Back to Dashboard</Link>
    
    </div>

  )
};
