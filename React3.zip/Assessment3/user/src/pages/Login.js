import React, { useState } from 'react'
import {Link} from 'react-router-dom';
import {ToastContainer} from 'react-toastify'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { handleError } from '../utils';
// import PrivateLayout from './PrivateLayout';

const Login = () => {
    const [info, setInfo]=useState({
        email:' ',
        password:' '
    });
    
  const[error ,setError] = useState(null)

  const Navigate = useNavigate()

  const handleLogin = async (e) => {
    e.preventDefault();
    const {email , password} = info;
    if(!email || !password){
        return handleError('UserName and Password Required')
    }
    try{
        const response = await axios.post('http://localhost:5001/user/login',info);
        const {data} = response
         console.log(response.data ,'response');
        
         Navigate('/dashboard');
         console.log("Login Successful");
          localStorage.setItem("token",response.data.token);
          // console.log(response.data)
        

         localStorage.setItem("user_data", JSON.stringify(response.data.user));
         


    }catch(error){
        setError("Check Your Credentials !")
    }

  };
  const handleChange = (e) =>{
    const{name , value} = e.target;
    setInfo((prevData) =>({
        ...prevData,
        [name] :value,
    }));

  };
  console.log('login',info)

  return (
    <div className="container">
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <h1>Login</h1>
        <form onSubmit={handleLogin}>
            <div>
            <label>Email</label>
            <input
             type="email"
             name="email"
             placeholder="Enter your Email"
             onChange={handleChange}
            />
            </div> 
            <div>
            <label>Password</label>
            <input
             type="password"
             name="password"
             placeholder="Enter Password Here"
              onChange={handleChange}
            />
            </div>   
            <button type="submit">Login</button>
            <span>Don't Have An Account?
                <Link to="/signup">SignUp</Link>
            </span>
        </form>
        <ToastContainer />

    </div>
  )
}

export default Login;