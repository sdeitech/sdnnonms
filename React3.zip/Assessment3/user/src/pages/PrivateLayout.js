import React, { useEffect } from "react";
import { useNavigate } from "react-router";
// import { useSelector } from "react-redux";

const PrivateLayout = ({ children }) => {
    //   let token = useSelector(state=> state.userReducer.token);
    let token = localStorage.getItem('token');
    let navigate = useNavigate();
    useEffect(() => {
        if (!token) {
            navigate("/");
        }
    }, [token, navigate]);

    return (
        <div className="layout">
            <div className="content">
                {/* <Header /> */}
                {children}
                {/* <Footer /> */}
            </div>
        </div>
    );
};

export default PrivateLayout;
