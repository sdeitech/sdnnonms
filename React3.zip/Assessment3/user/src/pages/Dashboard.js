
import React  from 'react'
// import{useNavigate} from 'react-router-dom';
import{useState , useEffect} from 'react';
import axios from 'axios';
import { MyProfile } from './MyProfile';
import { useNavigate } from 'react-router-dom';
import Header from './Header';
import Paginate from './Paginate';



const Dashboard = () => {
      const[user , setUser] = useState();
    //Setdata State for Manage Data
    const [data, setData] = useState([]);
    //Postcontent state used for POST content
    // const[error , setError] = useState(null)
    const [postcontent, setPostContent] = useState({
      firstName:'',
      lastName: ' ',
      email:' ',
      dob:' ',
      password: ' ',
      gender:' '
    });
    const [oneinfo, setOneInfo] = useState(null);

    const navigate = useNavigate();

    const handleDelete = async (id) => {
        // e.preventDefault();
     try{
        const response = await axios.delete(`http://localhost:5001/api/remove/${id}`,user);
        // setUser(response.data);
        getData();

     }catch(error){
        console.error("error in deleting",error)
     }
    };

    const handleView = async (id) => {
        try {
            const response = await axios.get(`http://localhost:5001/api/user/${id}`);
            setOneInfo(response.data);
            console.log(response.data, "data");

        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const handleInput = (e) => {
        const { name, value } = e.target;
        setPostContent({ ...postcontent, [name]: value });
    };

    const getData = async () => {
        try {
            const response = await axios.get('http://localhost:5001/api/get-info');
            setData(response?.data);
            // console.log(response.data)
        } catch (error) {
            setData([]);
        }
    };

    const createData = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5001/api/add', postcontent);
            setData([...data, response.data]);
            setPostContent({
              firstName:'',
              lastName: ' ',
              email:' '
            });
        } catch (error) {
            // console.error(error);
        // setError('cfvdg')
        console.error(error)

        }
    };

    useEffect(() => {
        getData();
    }, []);

    return (
        <div>
            <Header/>
        <p onClick={() => navigate('/myprofile')}>My Profile</p>
            
        {/* {error && <p style={{ color: 'red' }}>{error}</p>} */}

            <form onSubmit={createData}>
                <div className="input-group">
                    <label>FirstName:
                        <input
                            type="text"
                            name="firstName"
                            value={postcontent.firstName}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>LastName:
                        <input
                            type="text"
                            name="lastName"
                            value={postcontent.lastName}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <div className="input-group">
                    <label>
                        Email:
                        <input
                            type="text"
                            name="email"
                            value={postcontent.email}
                            onChange={handleInput}
                        />
                    </label>
                </div>
                <span>
                    <button type="submit">Submit</button>
                    {/* <button type="reset">Reset</button> */}
                    {/* <input type="reset" value="reset" /> */}
                </span>

            </form>

            <table className='table-add'>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((info) => (
                        <tr key={info._id}>
                            <td>{info.firstName}</td>
                            <td>{info.lastName}</td>
                            <td>{info.email}</td>
                            <td>
                                <button onClick={() => handleView(info._id)}>View</button>
                                <button onClick={() => handleDelete(info._id)}>Delete</button>
                                {/* <button type="button">Delete</button> */}

                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            
            {oneinfo && oneinfo.length > 0 && (
                <div>//   const[error ,setError] = useState(null)

                    <h3> Your Details:</h3>
                    {oneinfo.map((info, index) => (
                        <div key={index}>
                            <p>First Name:{info.firstName}</p>
                            <p>Last Name:{info.lastName}</p>
                            <p>Email:{info.email}</p>
                            <hr/>
                        </div>
                    ))}
                     <Paginate 
            totalPages={totalPages} 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage}
        />
                </div>
            )}
            <div>
                
            </div>

        </div>
    );
}


export default Dashboard;