import {Navigate, Route, Routes} from 'react-router-dom';
import Login from "./pages/Login"
import Signup from './pages/Signup';
import './App.css';
import Dashboard from './pages/Dashboard';
import { MyProfile } from './pages/MyProfile';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<Navigate to='/login'/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/signup' element={<Signup/>}/>
        <Route path='/dashboard' element={<Dashboard/>}/>
        <Route path='/myprofile'  element={<MyProfile/>}/>
      </Routes>
    </div>
  );
}

export default App;
