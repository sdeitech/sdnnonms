
from .models import User,Register
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.hashers import check_password

# Create your views here.

def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        age = request.POST['age']
        gender = request.POST['gender']
        email = request.POST['email']
        password = request.POST['password']

        # Save the user data (store email as username)
        new_user = Register.objects.create(
            email=email,  # Store email as username
            first_name=first_name,
            last_name=last_name,
            age=age,
            gender=gender,
        #    make_password(password): Ensures that the password is securely hashed before storing
        #                             it in the database. Storing raw passwords is insecure.
            password=make_password(password)  # Hash the password
        )
        new_user.save()
        return redirect('login')  # Redirect after registration

    return render(request, 'register.html')


def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            # Register: This is your custom user model that stores the user's information
            #          (such as email, first name, last name, etc.). You access it here to interact with the database.
            # Try to find the user with the provided email
            user = Register.objects.get(email=email)
            # Check if the password matches
            # check_password: A utility from Django's auth.hashers module that checks whether a plaintext password
            #                 matches a hashed password (useful during login).
            if check_password(password, user.password):
                # Password matches, log the user in (for simplicity, set session data)
                # request.session['user_id'] = user.id: Saves the user's ID in the session.
                # This allows the app to track the user across multiple requests
                request.session['user_id'] = user.id
                # request.session['email'] = user.email: Stores the user's email in the session.
                request.session['email'] = user.email
                return redirect('about')  # Redirect to home page or dashboard
            else:
                # messages.error(request, ...): Displays an error message if a user with the given email already exists
                messages.error(request, 'Invalid password')
        except Register.DoesNotExist:
            messages.error(request, 'User with this email does not exist')

    return render(request, 'login.html')




def fun(request):
    return render(request,'index.html')

def sum(request):
    Num1=int(request.POST.get("Number1"))
    Num2=int(request.POST.get("Number2"))
    result=Num1+Num2
 
    context = {'result':result}
    return render(request,'about.html',context)



def createuser(request):
    if request.method == 'POST':
        data = request.POST
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        age = data.get('age')
        # dob = data.get('DOB')
        gender = data.get('gender')
        newUUser = User.objects.create(
            first_name = first_name,
            last_name=last_name,
            age=age,
            # DOB = dob,
            gender=gender
        )
        return redirect('/about')    
    else:
        return render(request,'index.html')    
        
def viewuser(request):
          allUser = User.objects.all()
          return render(request,'about.html' , context={"allUser":allUser})   

    
def deleteuser(request,id):
          User.objects.get(id=id).delete()
          return redirect('/about')




def updateuser(request, id):
    user = get_object_or_404(User, id=id)  # Use get_object_or_404 for error handling
    
    if request.method == 'POST':
        data = request.POST
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        age = data.get('age')
        # dob = data.get('DOB')
        gender = data.get('gender')
        
        # Update user fields
        user.first_name = first_name
        user.last_name = last_name
        user.age = age
        # user.DOB = dob
        user.gender = gender
        
        # Save the updated user
        user.save()
        
        # Redirect to 'about' dynamically
        return redirect(reverse('about'))
        # return redirect('/about')
    else:
        user = User.objects.get(id=id)
#         return render(request, 'update.html', {'user': user})
    # For GET request, render the update form with user data
    return render(request, 'update.html', {'user': user})

        