from django.shortcuts import render

# Create your views here.
def fun(request):
    return render(request,'index.html')

def sum(request):
    Num1=int(request.POST.get("Number1"))
    Num2=int(request.POST.get("Number2"))
    result=Num1+Num2
 
    context = {'result':result}
    return render(request,'about.html',context)
    