from django.shortcuts import render , redirect
from .models import User
# Create your views here.
def fun(request):
    return render(request,'index.html')

def sum(request):
    Num1=int(request.POST.get("Number1"))
    Num2=int(request.POST.get("Number2"))
    result=Num1+Num2
 
    context = {'result':result}
    return render(request,'about.html',context)

def homePage(request):
    return render(request , 'index.html')


def createuser(request):
    if request.method == 'POST':
        data = request.POST
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        age = data.get('age')
        dob = data.get('DOB')
        gender = data.get('gender')
        newUUser = User.objects.create(
            first_name = first_name,
            last_name=last_name,
            age=age,
            DOB = dob,
            gender=gender
        )
        return redirect('/about')    
    else:
        return render(request,'index.html')    
        
def viewuser(request):
          allUser = User.objects.all()
          return render(request,'about.html' , context={"allUser":allUser})   

    
def deleteuser(request,id):
          User.objects.get(id=id).delete()
          return redirect('/about')
      
def updateuser(request,id):
    if request.method=='POST':
        users= User.objects.get(id=id)
        
        data = request.POST
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        age = data.get('age')
        dob = data.get('DOB')
        gender=data.get('gender')
        
        users.first_name = first_name,
        users.last_name=last_name,
        users.age = age,
        users.DOB = dob,
        users.gender =gender,
        
        users.save()
        
        return redirect('/about')   
    else:  
        user = User.objects.get(id=id)
        return render(request, 'update.html', {'user':user}) 
        