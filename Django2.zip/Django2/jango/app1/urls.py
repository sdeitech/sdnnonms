from django.urls import path
from . import views

urlpatterns = [
    path('',views.homePage ,name="index"),
    path('createuser/',views.createuser ,name="createuser"),
    path('about/',views.viewuser,name="about"),
    path('delete/<int:id>',views.deleteuser,name="delete"),
    path('update/<int:id>',views.updateuser,name="update")
    
    
    
    
   
]




# from django.urls import path
# from . import views
# urlpatterns = [
#     # path('admin/', admin.site.urls),
#     path('', views.index,name='index'),
#     path('about/', views.addition,name='about')