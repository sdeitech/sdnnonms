import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
// import { Document } from 'mongoose';

@Schema()
export class Statement {
  @Prop({ required: true })
  description: string;

  @Prop({ required: true, enum: ['common', 'classification'] })
  type: string;

  @Prop({ required: true })
  key: number;

  @Prop({ required: true })
  order: number;
}

export const StatementSchema = SchemaFactory.createForClass(Statement);
