import { ApiProperty } from '@nestjs/swagger';

// Swagger DTO class for State
export class StateDto {
  @ApiProperty({
    description: 'The unique key for the state',
    example: '1234',
  })
  key: string;

  @ApiProperty({
    description: 'The state code',
    example: 'CA',
  })
  statecode: string;

  @ApiProperty({
    description: 'The country the state belongs to',
    example: 'USA',
  })
  country: string;

  @ApiProperty({
    description: 'List of carriers associated with the state',
    type: [Object],
    example: [{ carrierName: 'Carrier A' }, { carrierName: 'Carrier B' }],
  })
  carrier: { carrierName: string }[];
}
