import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { JwtModule } from '@nestjs/jwt';
import { StatesController } from './states.controller';
import { StatesService } from './states.service';
import { State, StateSchema } from './schema/states.schema';
import { ConsulModule } from 'src/consul/consul.module';  // Import ConsulModule if ConsulService is part of it
import { ConsulService } from 'src/consul/consul.service'; // Import ConsulService directly

@Module({
  imports: [
    MongooseModule.forFeature([{ name: State.name, schema: StateSchema }]),
    ConsulModule,  // Ensure ConsulModule is imported here to provide ConsulService
    JwtModule.registerAsync({
      imports: [ConsulModule],  // Import ConsulModule if it's required for JwtModule async config
      useFactory: async (consulService: ConsulService) => {
        // Fetch JWT secret and expiry from Consul dynamically
        const jwtSecret = await consulService.getKey('JWT_SECRET');
        const jwtExpiry = await consulService.getKey('EXPIRES_IN');

        if (!jwtSecret || !jwtExpiry) {
          throw new Error('JWT configuration missing from Consul');
        }

        return {
          secret: jwtSecret,  // Set the JWT secret
          signOptions: { expiresIn: jwtExpiry },  // Set the JWT expiry time
        };
      },
      inject: [ConsulService],
    }),
  ],
  providers: [StatesService, ConsulService],  // Make sure ConsulService is provided
  controllers: [StatesController],
})
export class StatesModule {}
