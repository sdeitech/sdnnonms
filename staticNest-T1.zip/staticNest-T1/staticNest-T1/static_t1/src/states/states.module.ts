import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { JwtModule } from '@nestjs/jwt';
import { StatesController } from './states.controller';
import { StatesService } from './states.service';
import { State, StateSchema } from './schema/states.schema';
import { ConsulModule } from 'src/consul/consul.module'; // Import ConsulModule if ConsulService is part of it
import { ConsulService } from 'src/consul/consul.service'; // Import ConsulService directly
import { ERROR_MESSAGES } from 'src/constants/constants';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: State.name, schema: StateSchema }]),
    ConsulModule,
    JwtModule.registerAsync({
      imports: [ConsulModule],
      useFactory: async (consulService: ConsulService) => {
        // Fetch JWT secret and expiry from Consul dynamically
        const jwtSecret = await consulService.getKey('JWT_SECRET');
        const jwtExpiry = await consulService.getKey('EXPIRES_IN');

        if (!jwtSecret || !jwtExpiry) {
          throw new Error(ERROR_MESSAGES.JWT_CONFIGURATION_MISSING);
        }

        return {
          secret: jwtSecret, // Set the JWT secret
          signOptions: { expiresIn: jwtExpiry }, // Set the JWT expiry time
        };
      },
      inject: [ConsulService],
    }),
  ],
  providers: [StatesService, ConsulService],
  controllers: [StatesController],
})
export class StatesModule {}
