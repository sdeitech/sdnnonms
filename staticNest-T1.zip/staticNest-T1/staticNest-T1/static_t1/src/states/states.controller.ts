import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { StatesService } from './states.service';
import { AuthGuard } from 'src/static/authguard/static.authguard';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { StateDto } from './Dto/states.dto';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';

@ApiTags('States')
@UseGuards(AuthGuard)
@Controller('states')
export class StatesController {
  constructor(private readonly statesService: StatesService) {}

  @Get('all')
  @ApiOperation({ summary: 'Get all states' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATES_RETRIVED,
    type: [StateDto],
  }) // Response description and type
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  async getAll() {
    return this.statesService.getAllStates();
  }

  @Get('bystatecode/:statecode')
  @ApiOperation({ summary: 'Get states by state code' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATES_RETRIVED_BY_STATECODE,
    type: StateDto,
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  async getByStateCode(@Param('statecode') statecode: string) {
    return this.statesService.getByStateCode(statecode);
  }

  @Get('bycountry/:country')
  @ApiOperation({ summary: 'Get states by country' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATES_RETRIVED_BY_COUNTRY,
    type: [StateDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  async getByCountry(@Param('country') country: string) {
    return this.statesService.getByCountry(country);
  }

  // Endpoint to get states by carrier name
  @Get('bycarrier/:carrier')
  @ApiOperation({ summary: 'Get states by carrier name' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATES_RETRIVED_BY_CARRIER,
    type: [StateDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  async getByCarrier(@Param('carrier') carrier: string) {
    return this.statesService.getByCarrier(carrier);
  }
}
