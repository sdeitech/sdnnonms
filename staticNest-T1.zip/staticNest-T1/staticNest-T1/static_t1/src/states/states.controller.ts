import { Controller, Get, Param,UseGuards } from '@nestjs/common';
import { StatesService } from './states.service';
import { AuthGuard } from 'src/static/authguard/static.authguard'; 

@Controller('states')
export class StatesController {
  constructor(private readonly statesService: StatesService) {}

  // Endpoint to get all states
  @UseGuards(AuthGuard)
  @Get('all')
  async getAll() {
    return this.statesService.getAllStates();
  }

  // Endpoint to get states by statecode
  @Get('bystatecode/:statecode')
  async getByStateCode(@Param('statecode') statecode: string) {
    return this.statesService.getByStateCode(statecode);
  }

  // Endpoint to get states by country
  @Get('bycountry/:country')
  async getByCountry(@Param('country') country: string) {
    return this.statesService.getByCountry(country);
  }

  // Endpoint to get states by carrier name
  @Get('bycarrier/:carrier')
  async getByCarrier(@Param('carrier') carrier: string) {
    return this.statesService.getByCarrier(carrier);
  }
}
