import { Prop, Schema as NestSchema } from '@nestjs/mongoose';
import { SchemaFactory } from '@nestjs/mongoose';  // Add this import
import { Document } from 'mongoose';

// Define the State interface as a Document
export interface State extends Document {
  key: string;
  statecode: string;
  country: string;
  carrier: { carrierName: string }[];
}

@NestSchema()
export class State {
  @Prop()
  key: string;

  @Prop()
  statecode: string;

  @Prop()
  country: string;

  @Prop([{ carrierName: String }])
  carrier: { carrierName: string }[];
}

// Define and export the schema
export const StateSchema = SchemaFactory.createForClass(State);
