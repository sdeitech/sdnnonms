import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { JwtService } from '@nestjs/jwt';
import { Model } from 'mongoose';
import { State } from './schema/states.schema';
import { ConsulService } from 'src/consul/consul.service'; // Assuming ConsulService is available
import { ERROR_MESSAGES } from 'src/constants/constants';

@Injectable()
export class StatesService {
  constructor(
    @InjectModel(State.name) private readonly stateModel: Model<State>,
    private readonly jwtService: JwtService, // Inject JwtService
    private readonly consulService: ConsulService, // Inject ConsulService
  ) {}

  // Get All States
  async getAllStates(): Promise<State[]> {
    return this.stateModel.find().exec();
  }

  // Get States by statecode
  async getByStateCode(statecode: string): Promise<State[]> {
    return this.stateModel.find({ statecode }).exec();
  }

  // Get States by country
  async getByCountry(country: string): Promise<State[]> {
    return this.stateModel.find({ country }).exec();
  }

  // Get States by carrier
  async getByCarrier(carrierName: string): Promise<State[]> {
    return this.stateModel.find({ 'carrier.carrierName': carrierName }).exec();
  }

  // Method to validate JWT token
  async validateToken(token: string): Promise<any> {
    const jwtSecret = await this.consulService.getKey('jwt/secret');
    if (!jwtSecret) {
      throw new Error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
    }

    try {
      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      return decoded;
    } catch (error) {
      throw new Error(ERROR_MESSAGES.TOKEN_INVALID);
    }
  }
}
