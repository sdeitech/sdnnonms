import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { JwtService } from '@nestjs/jwt';
import { Model } from 'mongoose';
import { State } from './schema/states.schema';
import { ConsulService } from 'src/consul/consul.service'; // Assuming ConsulService is available

@Injectable()
export class StatesService {
  constructor(
    @InjectModel(State.name) private readonly stateModel: Model<State>,
    private readonly jwtService: JwtService, // Inject JwtService
    private readonly consulService: ConsulService, // Inject ConsulService
  ) {}

  // Add static hardcoded data
  async addStaticData() {
    const states = [
      {
        statecode: 'NY',
        country: 'USA',
        carrier: [
          { carrierName: 'LIC' },
          { carrierName: 'Jeevan Bhima' }
        ],
      },
      {
        statecode: 'CA',
        country: 'USA',
        carrier: [
          { carrierName: 'HDFC Life' },
          { carrierName: 'Max Life' }
        ],
      },
      {
        statecode: 'TX',
        country: 'USA',
        carrier: [
          { carrierName: 'Bajaj Allianz' },
          { carrierName: 'SBI Life' }
        ],
      },
    ];

    for (const state of states) {
      const existingState = await this.stateModel.findOne({ statecode: state.statecode }).exec();
      if (!existingState) {
        await this.stateModel.create(state);
      }
    }
  }

  // Get All States
  async getAllStates(): Promise<State[]> {
    // Add static data if not present (only for development/test)
    await this.addStaticData();
    
    return this.stateModel.find().exec();
  }

  // Get States by statecode
  async getByStateCode(statecode: string): Promise<State[]> {
    return this.stateModel.find({ statecode }).exec();
  }

  // Get States by country
  async getByCountry(country: string): Promise<State[]> {
    return this.stateModel.find({ country }).exec();
  }

  // Get States by carrier
  async getByCarrier(carrierName: string): Promise<State[]> {
    return this.stateModel.find({ 'carrier.carrierName': carrierName }).exec();
  }

  // Method to validate JWT token
  async validateToken(token: string): Promise<any> {
    const jwtSecret = await this.consulService.getKey('jwt/secret');
    if (!jwtSecret) {
      throw new Error('JWT secret is not available from Consul');
    }

    try {
      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      return decoded;
    } catch (error) {
      throw new Error('Invalid or expired token');
    }
  }
}
