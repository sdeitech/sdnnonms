import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { JwtModule } from '@nestjs/jwt';
import { ClassificationController } from './classification.controller';
import { ClassificationService } from './classification.service';
import { ConsulModule } from 'src/consul/consul.module';
import { ConsulService } from 'src/consul/consul.service'; // Import ConsulService
import {
  Classification,
  ClassificationSchema,
} from './schema/classification.schema';
import { ERROR_MESSAGES } from 'src/constants/constants';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Classification.name, schema: ClassificationSchema },
    ]),
    ConsulModule,
    JwtModule.registerAsync({
      imports: [ConsulModule],
      useFactory: async (consulService: ConsulService) => {
        // Fetch JWT secret and expiry from Consul dynamically
        const jwtSecret = await consulService.getKey('JWT_SECRET');
        const jwtExpiry = await consulService.getKey('EXPIRES_IN');

        if (!jwtSecret || !jwtExpiry) {
          throw new Error(ERROR_MESSAGES.JWT_CONFIGURATION_MISSING);
        }

        return {
          secret: jwtSecret, // Set the JWT secret
          signOptions: { expiresIn: jwtExpiry }, // Set the JWT expiry time
        };
      },
      inject: [ConsulService],
    }),
  ],
  providers: [ClassificationService, ConsulService],
  controllers: [ClassificationController],
})
export class ClassificationModule {}
