import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';

@Schema()
export class Classification {
  @Prop()
  businessCategoryCode: string;

  @Prop()
  nameOrValue: string;

  @Prop()
  country: string;

  @Prop()
  carriers: string[];

  @Prop()
  states: string[];
}

export const ClassificationSchema =
  SchemaFactory.createForClass(Classification);
