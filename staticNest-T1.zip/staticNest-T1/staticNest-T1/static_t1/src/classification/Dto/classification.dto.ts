import { ApiProperty } from '@nestjs/swagger';

export class ClassificationDto {
  @ApiProperty({
    description: 'Business category code',
    example: 'ABC123',
  })
  businessCategoryCode: string;

  @ApiProperty({
    description: 'Name or value associated with the classification',
    example: 'Insurance Type',
  })
  nameOrValue: string;

  @ApiProperty({
    description: 'Country code or name associated with the classification',
    example: 'US',
  })
  country: string;

  @ApiProperty({
    description: 'List of carriers associated with the classification',
    example: ['Carrier1', 'Carrier2'],
    type: [String], // Array of strings
  })
  carriers: string[];

  @ApiProperty({
    description: 'List of states associated with the classification',
    example: ['California', 'New York'],
    type: [String], // Array of strings
  })
  states: string[];
}
