import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ClassificationService } from './classification.service';
import { AuthGuard } from 'src/static/authguard/static.authguard';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { ClassificationDto } from './Dto/classification.dto';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';

@ApiTags('Classification')
@Controller('classification')
export class ClassificationController {
  constructor(private readonly classificationService: ClassificationService) {}

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Get all classifications' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED,
    type: [ClassificationDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get()
  async getAll() {
    return this.classificationService.getAllClassifications();
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: SUCCESS_MESSAGES.CLASSIFICATION_BY_BUSSINESS_CODE })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED_BY_CODE,
    type: ClassificationDto,
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('code/:code')
  async getByCode(@Param('code') code: string) {
    return this.classificationService.getByCode(code);
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Get classifications by carrier' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED_BY_CARRIER,
    type: [ClassificationDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('carrier/:carrier')
  async getByCarrier(@Param('carrier') carrier: string) {
    return this.classificationService.getByCarrier(carrier);
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Get classifications by state' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED_BY_STATE,
    type: [ClassificationDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('state/:state')
  async getByState(@Param('state') state: string) {
    return this.classificationService.getByState(state);
  }

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Get classifications by carrier and state' })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED_BY_CARRIER_AND_STATE,
    type: [ClassificationDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('carrier/:carrier/state/:state')
  async getByCarrierAndState(
    @Param('carrier') carrier: string,
    @Param('state') state: string,
  ) {
    return this.classificationService.getByCarrierAndState(carrier, state);
  }

  @UseGuards(AuthGuard)
  @ApiOperation({
    summary:
      'Get classifications by carrier, state, and business category code',
  })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description:
      SUCCESS_MESSAGES.CLASSIFICATION_RETRIVED_BY_CARRIER_AND_STATE__AND_CODE,
    type: ClassificationDto,
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('carrier/:carrier/state/:state/code/:code')
  async getByCarrierStateCode(
    @Param('carrier') carrier: string,
    @Param('state') state: string,
    @Param('code') code: string,
  ) {
    return this.classificationService.getByCarrierStateCode(
      carrier,
      state,
      code,
    );
  }
}
