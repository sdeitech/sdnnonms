import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Classification } from './schema/classification.schema';

@Injectable()
export class ClassificationService {
  constructor(
    @InjectModel(Classification.name)
    private readonly classificationModel: Model<Classification>,
  ) {}

  // Fetch all classifications
  async getAllClassifications(): Promise<Classification[]> {
    return this.classificationModel.find().exec();
  }

  // Fetch classification by businessCategoryCode
  async getByCode(code: string): Promise<Classification | null> {
    return this.classificationModel
      .findOne({ businessCategoryCode: code })
      .exec();
  }

  // Fetch classification by carrier
  async getByCarrier(carrier: string): Promise<Classification[]> {
    return this.classificationModel.find({ carriers: carrier }).exec();
  }

  // Fetch classification by state
  async getByState(state: string): Promise<Classification[]> {
    return this.classificationModel.find({ states: state }).exec();
  }

  // Fetch classification by carrier and state
  async getByCarrierAndState(
    carrier: string,
    state: string,
  ): Promise<Classification[]> {
    return this.classificationModel
      .find({
        carriers: carrier,
        states: state,
      })
      .exec();
  }

  // Fetch classification by carrier, state, and businessCategoryCode
  async getByCarrierStateCode(
    carrier: string,
    state: string,
    code: string,
  ): Promise<Classification | null> {
    return this.classificationModel
      .findOne({
        carriers: carrier,
        states: state,
        businessCategoryCode: code,
      })
      .exec();
  }
}
