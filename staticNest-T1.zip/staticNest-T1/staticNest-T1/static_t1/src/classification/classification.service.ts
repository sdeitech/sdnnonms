import { Injectable } from '@nestjs/common';
import { Classification } from './schema/classification.schema';

@Injectable()
export class ClassificationService {
  // Hardcoded static data
  private staticData: Classification[] = [
    {
      businessCategoryCode: 'BC001',
      nameOrValue: 'Business Category 1',
      country: 'USA',
      carriers: ['Carrier1', 'Carrier2'],
      states: ['California', 'Texas'],
    },
    {
      businessCategoryCode: 'BC002',
      nameOrValue: 'Business Category 2',
      country: 'Canada',
      carriers: ['Carrier3'],
      states: ['Ontario', 'Quebec'],
    },
    {
      businessCategoryCode: 'BC003',
      nameOrValue: 'Business Category 3',
      country: 'Germany',
      carriers: ['Carrier4', 'Carrier5'],
      states: ['Bavaria', 'Berlin'],
    },
  ];

  // Fetch all classifications
  getAllClassifications(): Classification[] {
    return this.staticData;
  }

  // Fetch classification by businessCategoryCode
  getByCode(code: string): Classification | undefined {
    return this.staticData.find((item) => item.businessCategoryCode === code);
  }

  // Fetch classification by carrier
  getByCarrier(carrier: string): Classification[] {
    return this.staticData.filter((item) => item.carriers.includes(carrier));
  }

  // Fetch classification by state
  getByState(state: string): Classification[] {
    return this.staticData.filter((item) => item.states.includes(state));
  }

  // Fetch classification by carrier and state
  getByCarrierAndState(carrier: string, state: string): Classification[] {
    return this.staticData.filter(
      (item) => item.carriers.includes(carrier) && item.states.includes(state),
    );
  }

  // Fetch classification by carrier, state, and businessCategoryCode
  getByCarrierStateCode(
    carrier: string,
    state: string,
    code: string,
  ): Classification | undefined {
    return this.staticData.find(
      (item) =>
        item.carriers.includes(carrier) &&
        item.states.includes(state) &&
        item.businessCategoryCode === code,
    );
  }
}
