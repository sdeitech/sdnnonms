import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConsulService } from './consul/consul.service';
import { ConsulModule } from './consul/consul.module';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { StaticModule } from './static/static.module';
import { StatesModule } from './states/states.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Make it available throughout the app
    }),
    ConsulModule,
    MongooseModule.forRootAsync({
      imports: [ConsulModule],
      inject: [ConsulService],
      useFactory: async (consul: ConsulService) => {
        const mongoUri = await consul.getKey('mongodb/DATABASE_URL');
        // console.log('MongoDB URI:', mongoUri); // Log URI for debugging
        return {
          uri: mongoUri,
        };
      },
    }),
    StaticModule,
    StatesModule,
  ],
  controllers: [AppController],
  providers: [AppService, ConsulService],
})
export class AppModule {}
