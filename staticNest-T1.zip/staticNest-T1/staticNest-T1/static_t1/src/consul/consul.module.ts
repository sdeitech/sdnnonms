import { Module } from '@nestjs/common';
import { ConsulService } from './consul.service';

@Module({
  providers: [ConsulService],
  exports: [ConsulService], // Export the service for use in other modules
})
export class ConsulModule {}
