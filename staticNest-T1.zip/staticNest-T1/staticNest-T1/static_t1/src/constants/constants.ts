// src/constants.ts

export const ERROR_MESSAGES = {
  INVALID_CLIENT_ID_PASSWORD: 'Invalid client ID or password',
  JWT_CREDENTIALS_NOT_FOUND: 'JWT credentials not found',
  JWT_CONFIGURATION_MISSING: 'JWT configuration missing from Consul',
  TOKEN_GENERATION_FAILED: 'Failed to generate token',
  TOKEN_INVALID: 'Invalid token or expired may be',
  TOKEN_MISSING: 'Token is required',
  TOKEN_MIS_OR_INVALID: 'Token missing or invalid',
  TOKEN_VERIFY_FAILED: 'Token verification failed',
  JWT_SECRET_NOT_FOUND: 'JWT secret not found in Consul',
  CLIENT_ID_NOT_FOUND: (clientId: string) =>
    `ClientId ${clientId} not found in the database`,
  TOKEN_INVALID_OR_EXPIRED: 'Token is invalid or expired',
  UNKNOWN_ERROR: 'Unknown error occurred during token verification',
  //static_module_errors
  UNAUTHORIZED_ACCESS: 'Unauthorized access',
  UNAUTHORIZED: 'Unauthorized',
  AUTHORIZATION_HEADER_MISSING: 'Authorization header is missing or invalid',
  STATEMENT_NOT_FOUND: 'Statement not found',
  NO_STATEMENTS_FOUND: 'No statements found for this type',
  STATIC_DATA_SAVE_FAILED: 'Error saving static data',
  STATIC_DATA_ACCESS_FAILED: 'Error retrieving static data',
};

export const SUCCESS_MESSAGES = {
  TOKEN_GENERATED: 'Token generated successfully',
  USER_REGISTERED: 'User registered successfully',
  //static_success
  STATIC_DATA_SAVED: 'Static data saved successfully.',
  STATIC_DATA_ALREADY_EXISTS:
    'Static data already exists, skipping initialization.',
  STATIC_RETRIVED: ' retrieved static data',
  STATIC_RETRIVED_BY_ID: ' Retrieve static data by ID',
  STATIC_RETRIVED_BY_TYPE: ' retrieved static data by type',
  STATEMENT_RETRIEVED: 'Statement retrieved successfully.',
  STATEMENT_RETRIEVED_BY_TYPE: 'Statements retrieved by type successfully.',
  STATES_RETRIVED: 'Successfully retrieved all states',
  STATES_RETRIVED_BY_STATECODE: 'Successfully retrieved states by state code',
  STATES_RETRIVED_BY_COUNTRY: 'Successfully retrieved states by country',
  STATES_RETRIVED_BY_CARRIER: 'Successfully retrieved states by carrier',
  CLASSIFICATION_RETRIVED: 'Successfully retrieved all classifications',
  CLASSIFICATION_BY_BUSSINESS_CODE:
    'Get classification by business category code',
  CLASSIFICATION_RETRIVED_BY_CODE:
    'Successfully retrieved classification by code',
  CLASSIFICATION_RETRIVED_BY_CARRIER:
    'Successfully retrieved classifications by carrier',
  CLASSIFICATION_RETRIVED_BY_STATE:
    'Successfully retrieved classifications by state',
  CLASSIFICATION_RETRIVED_BY_CARRIER_AND_STATE:
    'Successfully retrieved classifications by carrier and state',
  CLASSIFICATION_RETRIVED_BY_CARRIER_AND_STATE__AND_CODE:
    'Successfully retrieved classification by carrier, state, and code',
};
