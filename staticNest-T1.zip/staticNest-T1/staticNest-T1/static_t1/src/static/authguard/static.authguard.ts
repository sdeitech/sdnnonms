import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ERROR_MESSAGES } from 'src/constants/constants';
import { ConsulService } from 'src/consul/consul.service';

@Injectable()
export class AuthGuard implements CanActivate {
  private readonly logger = new Logger(AuthGuard.name);
  constructor(
    private readonly jwtService: JwtService,
    private readonly consulService: ConsulService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException(
        ERROR_MESSAGES.AUTHORIZATION_HEADER_MISSING,
      );
    }

    const token = authHeader.split(' ')[1]; // Extract token

    // Validate the token
    const jwtSecret = await this.consulService.getKey('JWT_SECRET');
    if (!jwtSecret) {
      throw new UnauthorizedException(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
    }

    try {
      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }
      return true; // Token is valid
    } catch (error) {
      if (error instanceof UnauthorizedException) {
        this.logger.warn(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
        throw error;
      } else {
        const typedError = error as Error;
        this.logger.error(ERROR_MESSAGES.UNKNOWN_ERROR, typedError.stack);
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
      }
    }
  }
}
