import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { JwtService } from '@nestjs/jwt';
import { ConsulService } from 'src/consul/consul.service';
import { Statement } from './schema/static.schema';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';

@Injectable()
export class StaticService {
  private readonly logger = new Logger(StaticService.name);

  constructor(
    @InjectModel(Statement.name)
    private statementModel: Model<Statement>,
    private jwtService: JwtService,
    private consulService: ConsulService,
  ) {}

  async getStaticData(token: string): Promise<Statement[]> {
    try {
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      if (!jwtSecret) {
        this.logger.error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
        throw new UnauthorizedException(ERROR_MESSAGES.UNAUTHORIZED_ACCESS);
      }

      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }

      this.logger.log(`Static data accessed by clientId: ${decoded.clientId}`);
      return this.statementModel.find().exec();
    } catch (error) {
      this.logger.error(
        ERROR_MESSAGES.STATIC_DATA_ACCESS_FAILED,
        error instanceof Error ? error.stack : error,
      );
      throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
    }
  }

  async getById(id: string, token: string): Promise<Statement> {
    try {
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      if (!jwtSecret) {
        this.logger.error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
        throw new UnauthorizedException(ERROR_MESSAGES.UNAUTHORIZED_ACCESS);
      }

      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }

      const statement = await this.statementModel.findById(id).exec();
      if (!statement) {
        throw new UnauthorizedException(ERROR_MESSAGES.STATEMENT_NOT_FOUND);
      }

      this.logger.log(SUCCESS_MESSAGES.STATEMENT_RETRIEVED);
      return statement;
    } catch (error) {
      this.logger.error(
        ERROR_MESSAGES.STATIC_DATA_ACCESS_FAILED,
        error instanceof Error ? error.stack : error,
      );
      throw new UnauthorizedException(ERROR_MESSAGES.STATIC_DATA_ACCESS_FAILED);
    }
  }

  async getByType(type: string, token: string): Promise<Statement[]> {
    try {
      const jwtSecret = await this.consulService.getKey('JWT_SECRET');
      if (!jwtSecret) {
        this.logger.error(ERROR_MESSAGES.JWT_SECRET_NOT_FOUND);
        throw new UnauthorizedException(ERROR_MESSAGES.UNAUTHORIZED_ACCESS);
      }

      const decoded = this.jwtService.verify(token, { secret: jwtSecret });
      if (!decoded || !decoded.clientId) {
        throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_INVALID);
      }

      const statements = await this.statementModel.find({ type }).exec();
      if (!statements || statements.length === 0) {
        throw new UnauthorizedException(ERROR_MESSAGES.NO_STATEMENTS_FOUND);
      }

      this.logger.log(SUCCESS_MESSAGES.STATEMENT_RETRIEVED_BY_TYPE);
      return statements;
    } catch (error) {
      this.logger.error(
        ERROR_MESSAGES.STATIC_DATA_ACCESS_FAILED,
        error instanceof Error ? error.stack : error,
      );
      throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_VERIFY_FAILED);
    }
  }
}
