import {
  Controller,
  Get,
  Headers,
  Param,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { StaticService } from './static.service';
import { AuthGuard } from './authguard/static.authguard';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { StatementDto } from './Dto/static.sto';
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from 'src/constants/constants';

@ApiTags('Static Data')
@Controller('static')
export class StaticController {
  constructor(private readonly staticService: StaticService) {}

  @UseGuards(AuthGuard)
  @ApiOperation({ summary: SUCCESS_MESSAGES.STATIC_RETRIVED })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATIC_RETRIVED,
    type: [StatementDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('data')
  async getStaticData(
    @Headers('Authorization') authHeader: string,
  ): Promise<StatementDto[]> {
    const token = authHeader.split(' ')[1]; // Extract token from Authorization header
    return this.staticService.getStaticData(token);
  }

  @ApiOperation({ summary: SUCCESS_MESSAGES.STATIC_RETRIVED_BY_ID })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATIC_RETRIVED_BY_ID,
    type: StatementDto,
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('data/:id')
  async getById(
    @Param('id') id: string,
    @Headers('Authorization') token: string,
  ): Promise<StatementDto> {
    if (!token || !token.startsWith('Bearer ')) {
      throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_MIS_OR_INVALID);
    }

    const jwtToken = token.split(' ')[1];
    return this.staticService.getById(id, jwtToken);
  }

  @ApiOperation({ summary: SUCCESS_MESSAGES.STATIC_RETRIVED_BY_TYPE })
  @ApiBearerAuth()
  @ApiResponse({
    status: 200,
    description: SUCCESS_MESSAGES.STATEMENT_RETRIEVED_BY_TYPE,
    type: [StatementDto],
  })
  @ApiResponse({ status: 401, description: ERROR_MESSAGES.UNAUTHORIZED })
  @Get('data/type/:type')
  async getByType(
    @Param('type') type: string,
    @Headers('Authorization') token: string,
  ): Promise<StatementDto[]> {
    if (!token || !token.startsWith('Bearer ')) {
      throw new UnauthorizedException(ERROR_MESSAGES.TOKEN_MIS_OR_INVALID);
    }

    const jwtToken = token.split(' ')[1];
    return this.staticService.getByType(type, jwtToken);
  }
}
