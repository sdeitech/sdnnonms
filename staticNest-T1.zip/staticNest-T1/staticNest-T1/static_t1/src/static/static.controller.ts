import {
  Controller,
  Get,
  Headers,
  Param,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { StaticService } from './static.service';
import { Statement } from './schema/static.schema';
import { AuthGuard } from './authguard/static.authguard';

@Controller('static')
export class StaticController {
  constructor(private readonly staticService: StaticService) {}

  // Endpoint to retrieve all static data
  @UseGuards(AuthGuard)
  @Get('data')
  async getStaticData(
    @Headers('Authorization') authHeader: string,
  ): Promise<Statement[]> {
    const token = authHeader.split(' ')[1]; // Extract token from Authorization header
    return this.staticService.getStaticData(token);
  }

  // Endpoint to get static data by ID
  @Get('data/:id')
  async getById(
    @Param('id') id: string,
    @Headers('Authorization') token: string,
  ): Promise<Statement> {
    // Extract Bearer token from the Authorization header
    if (!token || !token.startsWith('Bearer ')) {
      throw new UnauthorizedException('Token missing or invalid');
    }

    const jwtToken = token.split(' ')[1]; // Extract the token part

    return this.staticService.getById(id, jwtToken);
  }

  // Endpoint to get static data by type
  @Get('data/type/:type')
  async getByType(
    @Param('type') type: string,
    @Headers('Authorization') token: string,
  ): Promise<Statement[]> {
    // Extract Bearer token from the Authorization header
    if (!token || !token.startsWith('Bearer ')) {
      throw new UnauthorizedException('Token missing or invalid');
    }

    const jwtToken = token.split(' ')[1]; // Extract the token part

    return this.staticService.getByType(type, jwtToken);
  }
}
