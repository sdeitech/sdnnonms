import { ApiProperty } from '@nestjs/swagger';

export class StatementDto {
  @ApiProperty({
    description: 'Description of the statement',
    example: 'Statement description',
  })
  description: string;

  @ApiProperty({
    description: 'Type of the statement (common or classification)',
    example: 'common',
    enum: ['common', 'classification'],
  })
  type: string;

  @ApiProperty({
    description: 'Unique key identifier for the statement',
    example: 1,
  })
  key: number;

  @ApiProperty({
    description: 'Order of the statement in the list',
    example: 1,
  })
  order: number;
}
