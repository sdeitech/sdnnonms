const express = require('express')
const {createServer} = require('node:http');
const {join} = require('node:path')


const {Server} = require('socket.io')

const app = express(); //express server
const server = createServer(app); //http server

const io = new Server(server) //socket io server
PORT=4567; //port number

app.get('/',(req,res)=>{
    res.sendFile(
      join(__dirname,'index.html')
    );
})

io.on('connection',(socket)=>{
    console.log("A user connected");

    socket.on('chat message',(msg)=>{
        io.emit('chat message',msg)
        console.log('message:'+msg)
    })
    socket.on('disconnect',()=>{
            console.log("user Disconnected");
        // close();
    
})
})

server.listen(PORT,()=>{
    console.log(`server is listening on ${PORT}`);
    

})
