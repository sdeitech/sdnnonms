

1] Retrieve a list of all customers who have placed an order, showing their FirstName, LastName, 
   and TotalAmount from the Orders table.
   
   SELECT    c.FirstName,
             c.LastName,
			 o.TotalAmount
	FROM Customer AS c JOIN
           Orders AS  o 
	ON  c.CustomerId= o.CustomerId  ;

2] Write a query to fetch all orders along with the ProductName and 
   Quantity for each product in the order.
   
   SELECT p.ProductName ,
         op.Quantity
	FROM Product AS p 
    JOIN OrderProduct AS op 
    ON op.ProductId= p.ProductId ;

3] Find the FirstName and LastName of customers who live in the city of 
   Los Angeles and have placed an order. Include the OrderDate and TotalAmount in your results.
   
   SELECT 
        c.FirstName,
		c.LastName,
        o.OrderDate,
        o.TotalAmount  
	FROM Customer AS c 
		JOIN CustomerAddress AS ca
        ON c.CustomerId=ca.CustomerId 
		JOIN  Orders As o 
	    ON o.CustomerId=ca.CustomerId 
	 WHERE ca.City= 'Los Angeles';
     
4] List the FirstName, LastName, and AddressLine1 for customers who have placed an order in January 2024.

   SELECT 
        c.FirstName,
		c.LastName,
        ca.AddressLine1
   FROM Customer AS c 
		JOIN  CustomerAddress As ca 
        On c.CustomerId=ca.CustomerId 
        JOIN  Orders As o 
	    ON o.CustomerId=ca.CustomerId 
   WHERE o.OrderDate>='2024-01-01' AND o.OrderDate<='2024-02-01' ;
   
5] Get a list of CustomerId, OrderId, and the total number of products ordered by each customer.

  SELECT 
        o.CustomerId,
		op.OrderId,
       SUM(op.Quantity)
   FROM Orders AS o
   JOIN OrderProduct AS op 
   ON  o.OrderId=op.OrderId
   GROUP BY op.OrderId; 
   
 
6] List all customers along with their address information, if available.
   Show the CustomerId, FirstName, LastName, City, and State.  
   
     SELECT 
        c.CustomerId,
        c.FirstName,
        c.LastName,
	    ca.City,
        ca.State
   FROM Customer AS c 
   JOIN CustomerAddress AS ca
   ON c.CustomerId=ca.CustomerId 
   WHERE EXISTS ( SELECT 1 FROM CustomerAddress where c.CustomerId=ca.CustomerId  )
   
   
7] Write a query to find all customers who have never placed an order. 
   Show their FirstName, LastName, and Email.
  
  SELECT   c.FirstName,
           c.LastName,
           c.Email
  FROM Customer AS c 
  LEFT JOIN Orders As o 
  ON  o.CustomerId=c.CustomerId WHERE o.OrderId IS NULL;
  
  
  8] Retrieve a list of all orders and display the FirstName and LastName of the customers,
   even if the customer has no associated address.
   
  SELECT   c.FirstName,
           c.LastName
  FROM Customer AS c 
  LEFT JOIN CustomerAddress AS ca
  ON  c.CustomerId=ca.CustomerId WHERE ca.PostalCode IS NULL;
  
  9] List all products along with the total number of orders 
   placed for each product. Include products that have never been ordered.
   
    
        SELECT p.ProductName, COUNT(op.OrderId) AS TotalOrders 
  FROM Product p
  LEFT JOIN OrderProduct op ON p.ProductId = op.ProductId 
  GROUP BY p.ProductName;
 
 10] Write a query to display all FirstName, LastName, OrderId, 
    and OrderDate of customers. Ensure that customers who have not 
	placed any orders are also included in the results.
    
       SELECT  c.FirstName ,
		       c.LastName ,
			   o.OrderId,
               o.OrderDate
	   FROM Customer AS c JOIN 
            Orders AS o
	   ON o.CustomerId=c.CustomerId ;
     
     
11] Retrieve a list of customers whose Email addresses contain the
    string "smith". Display their FirstName, LastName, and Email.
      
       SELECT  c.FirstName ,
		       c.LastName ,
			   c.Email
	   FROM Customer AS c WHERE c.Email LIKE "%smith%";
    
               
               
      12] Write a query to find all customers whose FirstName starts with 
    the letter 'S'. Show the FirstName, LastName, and PhoneNumber.         
               
	  SELECT  c.FirstName ,
		       c.LastName ,
			   c.PhoneNumber
	   FROM Customer AS c WHERE c.FirstName LIKE "S%";
                  
               
     13] Find all customers whose LastName ends with the letter 'm'. 
    Display their FirstName, LastName, and Email.
    
       SELECT  c.FirstName ,
		       c.LastName ,
			   c.Email
	   FROM Customer AS c WHERE c.LastName LIKE "%m";
               
               
    14] Retrieve a list of customers whose AddressLine1 contains the 
    word "Elm". Show their FirstName, LastName, and AddressLine1.           
      
        
	  SELECT 
           c.FirstName ,
		   c.LastName ,
           ca.AddressLine1 
      FROM Customer AS c JOIN CustomerAddress AS ca
      ON c.CustomerId=ca.CustomerId WHERE ca.AddressLine1 LIKE "%Elm%" ;
      
      
     
   15] Write a query to display all customers whose FirstName starts 
       with 'K' or ends with 'n'. Show the FirstName, LastName, and Email.
      
      SELECT FirstName , LastName ,Email FROM Customer WHERE  FirstName LIKE   'K%' AND 'n';
     
     
   16] List all customers who are either 28 years old or live in New York.
       Show their FirstName, LastName, Age, and City.       
               
         SELECT 
               c.FirstName , 
			   c.LastName , 
			   c.Age , 
               ca.City 
		 FROM Customer AS c JOIN  CustomerAddress AS ca  
         ON  c.CustomerId=ca.CustomerId WHERE  c.Age=28 OR ca.City='New York';
         
         
               
      17] Write a query to find all products with a price between 500 and 2000. 
    Display their ProductName, Price, and Stock.
    
		SELECT ProductName,  
               Price,
               Stock
		FROM Product  
		WHERE Price BETWEEN 500 AND 2000;
        
     18] Retrieve a list of customers who live in either 'New York' or 'Los Angeles'.
      Show their FirstName, LastName, City, and State.
           
         SELECT c.FirstName,
                c.LastName,
				ca.City, 
                ca.State 
		  FROM   Customer  AS c
          JOIN CustomerAddress AS ca 
          ON c.CustomerId=ca.CustomerId 
          WHERE ca.City='New York' OR ca.City='Los Angeles';
          
           
       
       
     19] Write a query to display all orders placed between '2024-01-15' and '2024-03-18'.
    Show the OrderId, CustomerId, OrderDate, and TotalAmount.  
       
        SELECT  
                  OrderId, 
				  CustomerId , 
				  OrderDate,
                  TotalAmount
		FROM Orders  
		WHERE OrderDate BETWEEN '2024-01-15' AND '2024-03-18';
       
	20] Find all products that are either priced at 1200 or have a stock of 50. 
		Display their ProductName, Price, and Stock.
          
            SELECT  
                  ProductName, 
				  Price , 
				  Stock 
			FROM Product  
            WHERE Price = 1200 OR Stock=50;
          