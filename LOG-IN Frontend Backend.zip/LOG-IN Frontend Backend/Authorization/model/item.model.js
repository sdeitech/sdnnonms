
// const mongoose = require('mongoose');
// // Define Item Schema
// const itemSchema = new mongoose.Schema({
//  firstname: { type: String, required: true },
//  lastname: { type: String, required: true },
//  description: String,
// });
// // Create Item Model
// const Item = mongoose.model('Item', itemSchema);
// module.exports = Item;
