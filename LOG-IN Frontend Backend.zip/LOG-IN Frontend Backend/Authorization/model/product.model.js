const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
 productName: { type: String, required: true },
 description: { type: String, required: true },
 quantity: { type: Number, required: true },
 expiryDate: { type: Date, required: true },
 manufacturer: { type: String, required: true },
});

const Product = mongoose.model('Product', productSchema);
module.exports = Product;