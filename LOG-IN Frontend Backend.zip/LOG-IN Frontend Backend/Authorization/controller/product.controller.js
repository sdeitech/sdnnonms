const Product = require('../model/product.model');
// Create Product 
exports.createProduct = async (req, res) => {
    try {
        req.body.date = new Date(req.body.date);
        const newProduct = new Product(req.body);
        await newProduct.save(); res.status(201).json(newProduct);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
console.log(Product);
// Get All Items 
exports.getProduct = async (req, res) => {
    try {
        const product01 = await Product.find();
        res.json(product01);
        console.log("your products are ")
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
// Update Item 
exports.updateProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
// Delete Item 
exports.deleteProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};