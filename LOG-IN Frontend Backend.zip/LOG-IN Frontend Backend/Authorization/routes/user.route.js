const router = require('express').Router()
const {register , logIn} = require('../controller/user.controller')
const verifyToken= require('../middleware/verifyToken')

router.post('/register',register);
router.post('/login',logIn);
router.get('/protected',verifyToken,(req,res)=>{
 res.send(req.user)
});



module.exports = router