const express = require('express');
const router = express.Router();
const productController = require('../controller/product.controller');

// CRUD routes using controller methods
router.post('/post', productController.createProduct); // Create
router.get('/getproducts', productController.getProduct); // Read
router.put('/:id', productController.updateProduct); // Update
router.delete('/:id/deleteitems', productController.deleteProduct); // Delete

module.exports = router;