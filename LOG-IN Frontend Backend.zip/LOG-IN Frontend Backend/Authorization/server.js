
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/user.route');
const productRoutes = require ('./routes/product.routes')
const cors = require('cors');
const db = require('./db'); // Connect to the database
const app = express();
const PORT = 4000;

// Get All Items 

app.use(cors());
app.use(express.json());
// app.use('/item', itemRoutes);
app.use('/user', userRoutes);
app.use('/', productRoutes);

app.listen(PORT, () => {
 console.log(`Server is running on http://localhost:${PORT}`);
});
