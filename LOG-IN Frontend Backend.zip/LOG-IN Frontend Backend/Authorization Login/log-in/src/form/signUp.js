import React, { useState } from 'react';
import axios from 'axios';
import '../styles/Form.css';
import { useNavigate } from 'react-router-dom';

const SignUpForm = () => {
    const [signUp, setSignUp] = useState({
        userName: '',
        email: '',
        password: '',
    });
    const [error, setError] = useState(null);
    const navigate = useNavigate()

    const handleChange = (e) => {
        const { name, value } = e.target;
        setSignUp((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };
    const handleSignUp = async (e) => {
        e.preventDefault();
        try {
            // Example of making a login request
              const response = await axios.post('http://localhost:4000/user/register', signUp);
            // Handle successful login (e.g., store user info, redirect)
            localStorage.setItem('token', response.data.token)
             navigate('/Form');
            console.log('Register Successfully:');
        } catch (err) {
            setError('Register failed. Please check your credentials.');
        }
    };
    


    return (

        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div>
            <h2>SignUp</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form>
                <div>
                <label>Username:</label>
                    <input
                        type="email"
                        name="email"
                        value={signUp.userName}
                        onChange={handleChange}
                        required
                    />
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={signUp.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={signUp.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                {/* <button type="submit">Login</button> */}
                <button type="submit" >SignUp</button>

            </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
        
    );
};

export default SignUpForm;
