const trustedIPs = ["127.0.0.1", "192.168.0.1", "::ffff:127.0.0.1","::1","::ffff:49.248.148.242","localhost","::ffff:54.201.160.69","::ffff:49.248.148.242","::ffff:52.87.234.64","::ffff:52.199.239.198"];

export const restrictAccess = (req, res, next) => {
  const requestIP = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  if (trustedIPs.includes(requestIP)) {
    return next(); // Proceed to the next middleware
  } else {
    res.status(403).json({ error: `Access denied for IP: ${requestIP}` });
  }
};
