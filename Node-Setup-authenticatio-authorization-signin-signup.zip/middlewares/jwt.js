import jwt from "jsonwebtoken";
import { HTTP_MESSAGES } from "../const/message";
import response from "../const/response";

export const verifyJWT = (req,res,next) => {
  const token = req.headers.authorization.split(" ")[1];
  if(!token) return response.somethingErrorMsgResponse(res,403,{},HTTP_MESSAGES.EN.TOKEN_INVALID)
  try{
    const decoded = jwt.verify(token, process.env.JWT_KEY);
    req.user = decoded;
    return next();
  }catch(err){
    return response.unAuthorizedErrorMsgResponse(res,403,{},HTTP_MESSAGES.EN.TOKEN_EXPIRED)
  }
}