import Auditlog from "../models/Auditlog";
import moment from "moment";

const createPersonDataToSave = (req,data) => {
  console.log("pasword", data?.password)
    const ipAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip;
    const payload = {
      type: {
        system: "http://dicom.nema.org/resources/ontology/DCM",
        code: "110110",
        display: "Patient Record"
      },
      subtype: [
        {
          code: "Disclosure",
          display: "HIPAA disclosure"
        }
      ],
      action: "R",
      recorded:  moment().toISOString(),
      outcome: "0",
      outcomeDesc: "Successful Disclosure",
      agent: [
        {
          type: {
            coding: [
              {
                system: "http://dicom.nema.org/resources/ontology/DCM",
                code: "110153",
                display: "Source Role ID"
              }
            ]
          },
          who: {
            identifier: {
              value:  data?.email 
            }
          },
          altId: req.user._id,
          name: data?.firstName + " " + data?.lastName,
          requestor: true,
          location: {
            reference: "Location/1"
          },
          policy: [
            "http://consent.com/yes"
          ],
          network: {
            address: ipAddress,
            type: "1"
          }
        }
      ],
      source: {
        site: "Watcher",
        observer: {
          display: "Watchers Accounting of Disclosures Application"
        },
        type: [
          {
            system: "http://terminology.hl7.org/CodeSystem/security-source-type",
            code: "4",
            display: "Application Server"
          }
        ]
      }
    }
    // if(data?.role === 'OrgAdmin-Staff' || data?.role === 'OrgAdmin'){
    //     payload['managingOrganization'] = {
    //       "reference": `Organization/${data?.orgId}`
    //     }
    // }
    return payload
}


  export const auditlogMiddleware = async (req, res, next, type) => {
    // console.log(req?.headers, "req?.connection", req?.connection?.remoteAddress);
    try {
      // if (type === 'Patient Record') {
        const data = req.body; 
        const payload = createPersonDataToSave(req, data);
        const auditlog = new Auditlog(payload);
        await auditlog.save();
      // }
    } catch (error) {
      console.error("Failed to log audit data:", error);
    }
    next();
  };