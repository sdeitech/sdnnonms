import { HTTP_MESSAGES } from "../const/message";
import response from "../const/response";
import Person from "../models/PersonModel";

export const mustBeSuperAdmin = async (req, res, next) => {
  const user_id = req.user._id;
  const user = await Person.findOne({_id: user_id });
  let languageSelected = HTTP_MESSAGES.EN;
  if (user.role === "SuperAdmin") {
    return next(); // Add return statement here
  } else {
    return response.unAuthorizedErrorMsgResponse(
      res,
      403,
      languageSelected.NOT_AUTHORIZED
    );
  }
};

export const mustBeOrganizationAdmin = async (req, res, next) => {
  const user_id = req.user._id;
  const user = await Person.findOne({_id: user_id });
  let languageSelected = HTTP_MESSAGES.EN
  if (user.role === "OrgAdmin") {
    return next(); // Add return statement here
  } else {
    return response.unAuthorizedErrorMsgResponse(
      res,
      403,
      languageSelected.NOT_AUTHORIZED
    );
  }
};

export const mustBePatient = async (req, res, next) => {
  const user_id = req.user._id;
  const user = await Person.findOne({_id: user_id });
  let languageSelected = HTTP_MESSAGES.EN
  if (user.role === "Patient") {
    return next(); // Add return statement here
  } else {
    return response.unAuthorizedErrorMsgResponse(
      res,
      403,
      languageSelected.NOT_AUTHORIZED
    );
  }
};

