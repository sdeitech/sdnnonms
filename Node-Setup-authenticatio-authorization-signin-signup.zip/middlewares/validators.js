import Joi from "joi";
import response from "../const/response";
import {responseStatus} from "../const/response";
import { HTTP_MESSAGES } from "../const/message";

const signUpSchema = Joi.object({
    email: Joi.string().regex(/^\S+@\S+\.\S+$/).required().messages({
        "string.pattern.base": "Email must not have leading or trailing spaces and must be a valid email format."
    }),      
    password: Joi.string().trim().min(1).required(),
    passwordConfirmation: Joi.string(),
    isAdmin: Joi.boolean(),
    role: Joi.string(),
    otp: Joi.string(),
});

const logInSchema = Joi.object({
  email: Joi.string().trim().min(1).email().required(),
  password: Joi.string().trim().min(1).required()
});

const personSchema = Joi.object({
  firstName: Joi.string().trim().required(),
  lastName: Joi.string().trim().required(),
  phone: Joi.number().required(),
  email: Joi.string().regex(/^\S+@\S+\.\S+$/).required().messages({
      "string.pattern.base": "Email must not have leading or trailing spaces and must be a valid email format."
  }),      
  gender: Joi.string().trim().required(),
  dob: Joi.string().required(),
  address: Joi.string().required(),
  city: Joi.string().required(),
  state: Joi.string().required(),
  postalCode: Joi.number().required(),
  orgId: Joi.number(),
});

const organizationSchema = Joi.object({
  firstName: Joi.string().trim().required(),
  lastName: Joi.string().trim().required(),
  phone: Joi.number().required(),
  email: Joi.string().regex(/^\S+@\S+\.\S+$/).required().messages({
      "string.pattern.base": "Email must not have leading or trailing spaces and must be a valid email format."
  }),      
  gender: Joi.string().trim().required(),
  dob: Joi.string().required(),
  address: Joi.string().required(),
  city: Joi.string().required(),
  state: Joi.string().required(),
  postalCode: Joi.number().required()
});

const validationMiddleware = async (req, res, next, schema) => {
    let languageSelected = HTTP_MESSAGES.EN;

  const options = {
    abortEarly: false, // include all errors
    allowUnknown: false, // ignore unknown props
    whiteSpace: " ",
  };
  if (schema === "signUp") {
    var { error } = signUpSchema.validate(req.body, options);
  }
  if (schema === "logIn") {
    var { error } = logInSchema.validate(req.body, options);
  }
  if (schema === "Person") {
    var { error } = personSchema.validate(req.body, options);
  }
  if (schema === "Organization") {
    var { error } = organizationSchema.validate(req.body, options);
  }

  if (error) {
    response.somethingErrorMsgResponse(
        res,
        500,
        languageSelected.SOMETHING_WENT_WRONG,
        error
      );
  } else {
    next();
  }
};

export default validationMiddleware;