const jwt = require("jsonwebtoken");

export const socketAuthMiddleware = (socket, next) => {
  const token = socket.handshake.query.token;

  if (!token) {
    return next(new Error("Authentication error: JWT token missing."));
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_KEY); // Replace with your secret key
    socket.decoded = decoded; // Attach the decoded token payload to the socket object
    return next();
  } catch (err) {
    return next(new Error("Authentication error: Invalid JWT token."));
  }
};
