import {HTTP_MESSAGES} from "../const/message";
import response from "../const/response";
import logger from "../utils/logger";
import Person from "../models/PersonModel";
import {createOrgDataToSave, createPersonDataToSave} from "../helper/generatePayload"
import { generatePassword } from "../utils/misc";
import Organization from "../models/OrganizationModel";

export const createOrgAdmin = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;

  try {
    const firstName = req.body.firstName.trim();
    const lastName = req.body.lastName.trim();
    const existingOrg = await Organization.findOne({ name:`${firstName} ${lastName}` });

    if (existingOrg) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.ORGANIZATION_ALREADY_EXIST
      );
    }

    const newOrg = new Organization(createOrgDataToSave({ ...req.body, password: generatePassword() }));
    const user = await newOrg.save();
    const user_id = user?._id;

    if (user) {
      const newOrgdata = new Person(createPersonDataToSave({ ...req.body, password: generatePassword(), role: "OrgAdmin",orgId: user_id }));
      const orgData = await newOrgdata.save();

      if(orgData){
        return response.successResponse(
          res,
          200,
          languageSelected.ORG_REGISTRATION_SUCCESS
        );
      } else {
        return response.somethingErrorMsgResponse(
          res,
          500,
          languageSelected.PERSON_UPDATE_FAILED
        );
      }
    }else {
      return response.somethingErrorMsgResponse(
        res,
        500,
        languageSelected.ORG_UPDATE_FAILED
      );
    }
  } catch (error) {
    logger.error("Registration error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const updateOrgAdmin = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const updateOrgData = createOrgDataToSave({ ...req.body });

    const updatedOrgvalue = await Organization.findOneAndUpdate(
      { _id: req.body.orgId },
      updateOrgData,
      { new: true }
    ).exec();

    if (updatedOrgvalue) {
      return response.successResponse(
        res,
        200,
        { data: updatedOrgvalue },
        languageSelected.ORGANIZATION_UPDATED_SUCCESS
      );
    } else {
      return response.somethingErrorMsgResponse(
        res,
        500,
        languageSelected.ORG_UPDATE_FAILED
      );
    }
  } catch (error) {
    logger.error("update error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const deleteOrg = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const deleteOrgvalue = await Organization.findOneAndUpdate(
      { _id: req.body.orgId },
      {active:false},
      { new: true }
    ).exec();

    if (deleteOrgvalue) {
      return response.successResponse(
        res,
        200,
        { data: deleteOrgvalue },
        languageSelected.DATA_DELETED_SUCCESS
      );
    } else {
      return response.somethingErrorMsgResponse(
        res,
        500,
        languageSelected.ORG_UPDATE_FAILED
      );
    }
  } catch (error) {
    logger.error("delete error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};
