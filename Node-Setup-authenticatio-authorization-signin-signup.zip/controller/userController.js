import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import {HTTP_MESSAGES} from "../const/message";
import response from "../const/response";
import logger from "../utils/logger";
import Person from "../models/PersonModel";
import {createPatientDataToSave, createPersonDataToSave} from "../helper/generatePayload"
import { generatePassword } from "../utils/misc";
import Patient from "../models/PatientModel";

//superAdmin api
export const createSuperAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const existingUser = await Person.findOne({
      "telecom.system": "email",
      "telecom.use": "home",
      "telecom.value":  req.body.email,
      "role" : "SuperAdmin-Staff"
    });

    if (existingUser) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.EMAIL_ALREADY_EXISTS
      );
    }
    const newUser = new Person(createPersonDataToSave({...req.body, password: generatePassword(), role: "SuperAdmin-Staff"}));

    const user = await newUser.save();
    const user_id = user?._id;
    user.password = null;

    return response.successResponse(
      res,
      200,
      { user_id: user_id },
      languageSelected.REGISTRATION_SUCCESS
    );
  } catch (error) {
    logger.error("Signup error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const updateSuperAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const userId  = req.query?.userId
    const user = await Person.findOne({_id: userId, role: "SuperAdmin-Staff"});
    if (!user) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.DATA_NOT_FOUND
      );
    }
    const updateStaff = createPersonDataToSave({...req.body})
    delete updateStaff?.password;
    delete updateStaff?.role;
    await Person.findByIdAndUpdate(userId, updateStaff, {new: true})
    return response.successResponse(
      res,
      200,
      {},
      languageSelected.DATA_UPDATED_SUCCESS
    );
  } catch (error) {
    logger.error("error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const deleteSuperAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const userId  = req.query?.userId
    await Person.findByIdAndUpdate({_id: userId, role: "SuperAdmin-Staff"}, {active: false});
    return response.successResponse(
      res,
      200,
      {},
      languageSelected.DATA_DELETED_SUCCESS
    );
  } catch (error) {
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

// orgAdmin Api
export const createOrgAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const existingUser = await Person.findOne({
      "telecom.system": "email",
      "telecom.use": "home",
      "telecom.value":  req.body.email,
      "role" : "OrgAdmin-Staff"
    });

    if (existingUser) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.EMAIL_ALREADY_EXISTS
      );
    }
    const newUser = new Person(createPersonDataToSave({...req.body, password : generatePassword(), role: "OrgAdmin-Staff"}));

    const user = await newUser.save();
    const user_id = user?._id;
    user.password = null;

    return response.successResponse(
      res,
      200,
      { user_id: user_id },
      languageSelected.REGISTRATION_SUCCESS
    );
  } catch (error) {
    console.log("error", error)
    logger.error("Signup error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const updateOrgAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const userId  = req.query?.userId
    const user = await Person.findOne({_id: userId, role: "OrgAdmin-Staff"});
    if (!user) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.DATA_NOT_FOUND
      );
    }

    const updateStaff = createPersonDataToSave({...req.body })
    delete updateStaff.password;
    delete updateStaff.role;
    delete updateStaff?.managingOrganization
    await Person.findByIdAndUpdate(userId, updateStaff, {new: true})

    return response.successResponse(
      res,
      200,
      {},
      languageSelected.DATA_UPDATED_SUCCESS
    );
  } catch (error) {
    console.log("error", error)
    logger.error("error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const deleteOrgAdminStaff = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const userId  = req.query?.userId
    await Person.findByIdAndUpdate({_id: userId, role: "OrgAdmin-Staff"}, {active: false});
    return response.successResponse(
      res,
      200,
      {},
      languageSelected.DATA_DELETED_SUCCESS
    );
  } catch (error) {
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

//Patient api
export const createPatient = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const existingUser = await Patient.findOne({
      "telecom.system": "email",
      "telecom.use": "home",
      "telecom.value":  req.body.email,
      "role" : "Patient"
    });

    if (existingUser) {
      return response.errorMessageResponse(
        res,
        409,
        languageSelected.EMAIL_ALREADY_EXISTS
      );
    }
    const patientData = await createPatientDataToSave({ ...req.body, password: generatePassword(), role: "Patient" }, res);
    const newUser = new Patient(patientData);
    const user = await newUser.save();
    const user_id = user?._id;
    user.password = null;

    return response.successResponse(
      res,
      200,
      { user_id: user_id },
      languageSelected.REGISTRATION_SUCCESS
    );
  } catch (error) {
    logger.error("Signup error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const login = async (req, res) => {
  const { email, password,role } = req.body;

  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const user = await Person.findOne({
      "telecom.system": "email",
      "telecom.use": "home",
      "telecom.value": email
    })

    if (!user) {
      return response.errorMessageResponse(res, 404, {}, languageSelected.AUTH_ERROR);
    }
    const isPasswordCorrect = await bcrypt.compare(password, user?.password);

    if (isPasswordCorrect) {
      const token = jwt.sign(
        {
          _id: user._id,
          email: user.email,
          role: user.role
        },
        process.env.JWT_KEY,
        {
          expiresIn: "24h"
        }
      );

      user.password = undefined;
      return response.successResponse(
        res,
        200,
        { access_token: token, user },
        languageSelected.LOGIN_SUCCESS
      );
    } else {
      return response.successResponse(
        res,
        404,
        {},
        languageSelected.USER_NOT_FOUND
      );
    }
  } catch (error) {
    console.log(error);
    logger.error("Login error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};

export const verifyOTPOnEmail = async (req, res) => {
  let languageSelected = HTTP_MESSAGES.EN;

  try {
    const { otp, userId } = req.query;

    // Find the patient with the provided user ID and status "InProgress"
    let user = await Person.findById({ _id : userId})

    if (!user) {return response.successResponse(res, 404, {}, "User not found")}

    // Compare the provided OTP with the hashed OTP in the database
    const isVerified = await bcrypt.compare(otp, user.otp);

    if (!isVerified) {
      return response.successResponse(
        res,
        404,
        {},
        "OTP verification failed for email"
      );
    }

    // Generate JWT Token
    const token = jwt.sign(
      {
        _id: user._id,
        email: user.email, // Assuming email is provided in the body
        role: "ADMIN"
      },
      process.env.JWT_KEY,
      {
        expiresIn: "24h"
      }
    );

    // Update patient record
    user.otp = "";
    await user.save();

    // Remove sensitive information from the profile
    delete user.otp;

    return response.successResponse(
      res,
      200,
      { access_token: token, user },
      languageSelected.PATIENT_SIGNUP_SUCCESS
    );
  } catch (error) {
    console.log(error);
    logger.error("Login error", { error });
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
};