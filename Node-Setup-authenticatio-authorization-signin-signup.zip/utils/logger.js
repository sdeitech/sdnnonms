// logger.mjs
import { createLogger, format, transports } from "winston";

const { combine, timestamp, printf } = format;

// Define a custom format for human-readable logging
const myFormat = printf(({ level, message, timestamp }) => {
  return `${timestamp} [${level}]: ${message}`;
});

const logger = createLogger({
  level: "info",  // Change the log level if needed
  format: combine(
    timestamp(),
    format.json() // Add the JSON format here
  ),
  transports: [
    new transports.Console({
      format: combine(
        timestamp(),
        myFormat // Human-readable format for console
      )
    }),
    new transports.File({
      filename: "application.log",
      format: combine(
        timestamp(),
        format.json() // JSON format for file
      )
    })
  ]
});

module.exports = logger;
