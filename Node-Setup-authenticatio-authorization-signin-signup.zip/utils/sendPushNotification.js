import FCM from "fcm-node";

export const sendPushNotification = async(notificationData, fcm_token) => {
  const fcmServerkey = process.env.FCM_SERVER_KEY
  try {
    var fcm = new FCM(fcmServerkey);
    var message = {
      to: fcm_token,
      // collapse_key: "your_collapse_key",
      notification: notificationData
    };
    fcm.send(message, function (err, response) {
      if (err) {
        console.log("Something has gone wrong!",err);
      } else {
        console.log("Successfully sent with response: ", response);
      }
    });
  } catch (error) {
    console.log("error", error);
  }
};
