import axios from "axios";
import dotenv from "dotenv";

dotenv.config();
const env = process.env.NODE_ENV || "local";
const envData = require(`../config/${env}.config`);
const port = envData.config.port || 8000;

export const mainServiceRequest = axios.create({
  baseURL : `https://ss.stagingsdei.com:${port}/api/v1`
})