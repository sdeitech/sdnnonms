import mongoose from "mongoose";

const AuditlogSchema = mongoose.Schema(
    {
        resourceType: {
            type: String,
            default: "AuditEvent"
        },
        type: {
            type: Object,
            required: false,
        },
        subtype: {
            type: Array,
            required: false,
        },
        action: {
            type: String,
            required: false,
        },
        recorded: {
            type: String,
            required: false,
        },
        outcome: {
            type: String,
            required: false,
        },
        outcomeDesc: {
            type: String,
            required: false,
        },
        agent:{
            type: Array,
            required:false
        },
        source:{
            type: Object,
            required:false
        }
    },
    { timestamps: true }
)
const Auditlog = mongoose.model("Auditlog", AuditlogSchema);

export default Auditlog;