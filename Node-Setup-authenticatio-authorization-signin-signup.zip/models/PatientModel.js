import mongoose from "mongoose";

const PatientSchema = mongoose.Schema(
  {
    resourceType: {
      type: String,
      default: "Patient"
    },
    active: {
      type : Array,
      require : false
    },
    isVerified: {
      type : Array,
      default: true
    },
    name: {
      type : Array,
      default : true
    },
    telecom: {
      type : Array,
      default : true
    },
    gender: {
      type : String,
      default : true
    },
    birthDate: {
      type: String,
      required: false
    },
    address:{
      type : Array,
      require : false
    }
  },
  { timestamps: true }
)
const Patient = mongoose.model("Patient", PatientSchema)
export default Patient;