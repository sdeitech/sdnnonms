import mongoose from "mongoose";

const PersonSchema = mongoose.Schema(
  {
    resourceType: {
      type: String,
      default: "Person"
    },
    active: {
      type : Array,
      default: true
    },
    name: {
      type : Array,
      require : false
    },
    password: {
      type : String,
      require : false
    },
    telecom: {
      type : Array,
      require : false
    },
    gender: {
      type : String,
      require : false
    },
    birthDate: {
      type: String,
      require : false
    },
    address:{
      type : Array,
      require : false
    },
    managingOrganization:{
      type: Object,
      require: false
    },
    otp:{
      type: Number,
      require: false
    },
    role: {
      type: String,
      enum: ["SuperAdmin", "SuperAdmin-Staff", "OrgAdmin", "OrgAdmin-Staff", "Patient"], // Define the allowed values for role here
      required: false
    }
  },
  { timestamps: true }
)
const Person = mongoose.model("Person", PersonSchema)
export default Person;