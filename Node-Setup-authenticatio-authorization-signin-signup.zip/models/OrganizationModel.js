import mongoose from "mongoose";

const orgSchema = mongoose.Schema(
  {
    resourceType: {
      type: String,
      default: "Organization"
    },
    active: {
      type : Array,
      default: true
    },
    name: {
      type : String,
      require : false
    },
    telecom: {
      type : Array,
      require : false
    },
    address:{
      type : Array,
      require : false
    },
    contact:{
      type : Array,
      require : false
    },
    assignToStaff:{
      type : Array,
      require : false
    }
  },
  { timestamps: true }
)
const Organization = mongoose.model("Organization", orgSchema)
export default Organization;