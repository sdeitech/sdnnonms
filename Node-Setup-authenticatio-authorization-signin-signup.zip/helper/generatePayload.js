import bcrypt from "bcrypt"
import response from "../const/response"
import { HTTP_MESSAGES } from "../const/message"
import { encryptData } from "./encryptData"

export const createPersonDataToSave = (data) => {
  console.log("pasword", data?.password)
  const payload = {
    "active" : true,
    "name" : [{"text": data?.firstName + " " + data?.lastName}],
    "password": data?.password ? bcrypt.hashSync(data?.password, 10) : null,
    "telecom": [{
      "system": "phone",
      "value": data?.phone,
      "use": "home"
    },
    {
      "system": "email",
      "value": data?.email,
      "use": "home"
    }],
    "gender": data?.gender,
    "birthDate": data?.dob,
    "address": {
      "use": "home",
      "line": [data?.address],
      "city": data?.city,
      "state": data?.state,
      "postalCode": data?.postalCode
    },
    "otp": data?.otp,
    "role": data?.role
  }
  if(data?.role === "OrgAdmin-Staff" || data?.role === "OrgAdmin"){
    payload["managingOrganization"] = {
      "reference": `Organization/${data?.orgId}`
    }
  }
  return payload
}

export const createPatientDataToSave = async(data, res) => {
  console.log("pasword", data?.password)
  let languageSelected = HTTP_MESSAGES.EN;
  try {
    const payload = {
      "active" : true,
      "name" : [{"text": await encryptData(JSON.stringify(data?.firstName)) + " " + await encryptData(JSON.stringify(data?.lastName))}],
      "password": data?.password ? bcrypt.hashSync(data?.password, 10) : null,
      "telecom": [{
        "system": "phone",
        "value": await encryptData(JSON.stringify(data?.phone)),
        "use": "home"
      },
      {
        "system": "email",
        "value": await encryptData(JSON.stringify(data?.email)),
        "use": "home"
      }],
      "gender": await encryptData(JSON.stringify(data?.gender)),
      "birthDate": await encryptData(JSON.stringify(data?.dob)),
      "address": {
        "use": "home",
        "line": [await encryptData(JSON.stringify(data?.address))],
        "city": await encryptData(JSON.stringify(data?.city)),
        "state": await encryptData(JSON.stringify(data?.state)),
        "postalCode": await encryptData(JSON.stringify(data?.postalCode))
      },
      "role": await encryptData(JSON.stringify(data?.role))
    }
    console.log("payload", payload)

    return payload
  } catch (error) {
    console.log("error", error)
    return response.somethingErrorMsgResponse(
      res,
      500,
      languageSelected.SOMETHING_WENT_WRONG,
      error
    );
  }
}

export const createOrgDataToSave = (data) => {
  const payload = {
    "name": data?.firstName + " " + data?.lastName,
    "active" : true,
    "telecom": [{
      "system": "phone",
      "value": data?.phone,
      "use": "work"
    },
    {
      "system": "email",
      "value": data?.email,
      "use": "work"
    }],
    "address": [
      {
        "use": "home",
        "line": [data?.address],
        "city":  data?.city,
        "state": data?.state,
        "postalCode": data?.postalCode,
        "country": data?.country
      }
    ]
  }
  return payload
}
