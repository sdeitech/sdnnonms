exports = module.exports = function (io) {
  /*
	#1. New Connection Established
	#2. New Notification to UserId
	*/

  // TODO:- Use JWT Token decode data from socket.decoded;

  io.on("connection", (socket) => {
    // Handle events from the client
    socket.on("subscribe", (userId) => {
      console.log("New User Joined");
      socket.join(userId);
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected");
    });

    socket.on("", (userId) => {
    });

    socket.on("", (userId) => {
    });
  });
};