import { AES } from "crypto-js";

export const encryptData = async (data) => {
  try {
    const encrypted = AES.encrypt(data, process.env.JWT_KEY).toString();
    return encrypted;
  } catch (error) {
    console.log("Encryption error:", error);
    throw error;
  }
};