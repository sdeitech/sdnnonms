require("@babel/register")({
  presets: ["@babel/preset-env"]
});

require("./app.js");