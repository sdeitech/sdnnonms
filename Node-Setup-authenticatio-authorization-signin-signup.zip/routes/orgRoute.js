import {verifyJWT} from "../middlewares/jwt"
import { mustBeSuperAdmin } from "../middlewares/authorization";
import { createOrgAdmin, deleteOrg, updateOrgAdmin } from "../controller/orgController";
import validationMiddleware from "../middlewares/validators";

const express= require("express")

export const orgRoutes = express.Router();

orgRoutes.use(verifyJWT)

orgRoutes.post("/create-orgAdmin",(req, res, next) => validationMiddleware(req, res, next, "Organization"), [mustBeSuperAdmin], createOrgAdmin);
orgRoutes.put("/update-orgAdmin",(req, res, next) => validationMiddleware(req, res, next, "Organization"), [mustBeSuperAdmin], updateOrgAdmin);
orgRoutes.put("/delete-orgAdmin", [mustBeSuperAdmin], deleteOrg);