import { createOrgAdminStaff, createPatient, createSuperAdminStaff, deleteOrgAdminStaff, deleteSuperAdminStaff, login, updateOrgAdminStaff, updateSuperAdminStaff, verifyOTPOnEmail } from "../controller/userController";
import validationMiddleware from "../middlewares/validators";
import {verifyJWT} from "../middlewares/jwt"
import { mustBeOrganizationAdmin, mustBeSuperAdmin } from "../middlewares/authorization";
import {auditlogMiddleware} from "../middlewares/auditlog";

const express= require("express")

export const userRoutes = express.Router();

userRoutes.post("/login", login);

userRoutes.post("/verify-email", verifyOTPOnEmail);
userRoutes.use(verifyJWT)

//superAdmin
userRoutes.post("/create-superAdmin-staff", (req, res, next) => validationMiddleware(req, res, next, "Person"),[mustBeSuperAdmin], createSuperAdminStaff);
userRoutes.put("/update-superAdmin-staff", (req, res, next) => validationMiddleware(req, res, next, "Person"), [mustBeSuperAdmin], updateSuperAdminStaff)
userRoutes.put("/delete-superAdmin-staff", [mustBeSuperAdmin], deleteSuperAdminStaff)

//orgAdmin
userRoutes.post("/create-orgAdmin-staff", (req, res, next) => validationMiddleware(req, res, next, "Person"), [mustBeOrganizationAdmin], createOrgAdminStaff);
userRoutes.put("/update-orgAdmin-staff", (req, res, next) => validationMiddleware(req, res, next, "Person"), [mustBeOrganizationAdmin], updateOrgAdminStaff);
userRoutes.put("/delete-orgAdmin-staff", [mustBeOrganizationAdmin], deleteOrgAdminStaff);

//patient
userRoutes.post("/create-patient", (req, res, next) => validationMiddleware(req, res, next, "Person"), (req, res, next) => auditlogMiddleware(req, res, next, "Patient Record"),[mustBeOrganizationAdmin], createPatient);
