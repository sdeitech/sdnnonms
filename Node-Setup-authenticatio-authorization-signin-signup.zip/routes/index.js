import { restrictAccess } from "../middlewares/whitelistedIP";

const express= require("express")

export const eventRoutes = express.Router();

eventRoutes.post("/api/v2/emit-new-event",[restrictAccess], (req, res) => {
  try {
    const io = req.app.get("io");
    const { payload, targetUserIds,eventName } = req.body;
    emitNotificationEvent(io, eventName, payload, targetUserIds, res);
  } catch (err) {
    console.error(err);
    res.sendStatus(500);
  }
});

const emitNotificationEvent = (io, eventName, payload, targetUserIds, res) => {
  try {
    targetUserIds.forEach((userId) => {
      io.to(userId).emit(eventName, payload);
    });
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.sendStatus(500);
  }
};

