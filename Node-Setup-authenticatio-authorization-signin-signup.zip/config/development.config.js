export const config = {
  host: "https://ss.stagingsdei.com",
  port: 9169,
  socketPort:9198,
  baseUrl: "",
  db: {
    host: "54.201.160.69",
    port: 5432,
    username: "hest",
    database: "hest",
    password: "WSXEedij86"
  }
};
config.baseUrl = `${config.host}:${config.port}/`;
