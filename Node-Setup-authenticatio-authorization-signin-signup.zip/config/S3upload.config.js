import fs from "fs";
import mime from "mime-types";
import s3 from "./S3.config";

export const uploadPublicFile = async (file) => {
  try {
    const params = {
      Bucket: "",
      Key: "public/" + file.filename,
      Body: fs.createReadStream(file.path),
      ACL: "public-read" // Set ACL to public-read for public files
    };
    const response = await s3.upload(params).promise();
    const key = response.Key;
    const publicUrl = response.Location;
    return { key: key, publicUrl: publicUrl };
  } catch (error) {
    console.log("error inside uploadPublicFile", error);
  }
};

export const uploadPrivateFiles = async (files) => {
  try {
    // const uploadPromises = files.map(async (file) => {
    //   const params = {
    //     Bucket: "",
    //     Key: "private/" + file.filename,
    //     Body: fs.createReadStream(file.path),
    //     ACL: "private",
    //   };
    //   return s3.upload(params).promise();
    // });
    // const uploadedFiles = await Promise.all(uploadPromises);
    for (let index = 0; index < files.length; index++) {
      const element = files[index];
      const params = {
        Bucket: "",
        Key: "private/" + element.filename,
        Body: fs.createReadStream(element.path),
        ACL: "private"
      };
      const response = await s3.upload(params).promise();
      element.s3key = response.Key
    }
    // await Promise.all(files.map(async (file, index) => {
    // file.s3key = uploadedFiles[index].key;
    // }));
    return files;
  } catch (error) {
    console.log("error in uploading file",error)
  }
};

export const generateSignedUrl = async (key) => {
  try {
    return new Promise((resolve, reject) => {
      if (key) {
        const contentType = mime.contentType(key);
        const parts = contentType.split(".");
        const extension = parts[parts.length - 1];
        let type
        if (extension == "pdf") {
          type = "application/pdf"
        }else if(extension == "svg"){
          type = "image/svg+xml"
        }
        else{
          type = `image/${extension}`
        }
        const signedUrl = s3.getSignedUrl("getObject", {
          Bucket: "",
          Key: key,
          // Expires: 3600, // URL expiration time in seconds (1 hour in this example),
          ResponseContentType: type,
          ResponseContentDisposition: "inline"
        });
        if (signedUrl) {
          resolve(signedUrl);
        } else {
          reject("");
        }
      } else {
        resolve("");
      }
    });
  } catch (error) {
    console.log("error", error);
  }
};
