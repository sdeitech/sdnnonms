const config = {
  local: {
    PORTS: {
      API_PORT: 8000
    },
    BaseUrl: {
      userServiceUrl: "http://localhost:8001",
      departmentServiceUrl: "http://localhost:8002",
      virtualServiceUrl: "http://localhost:8008"
    }
  }
};

export const get = (env) => {
  return config[env];
}