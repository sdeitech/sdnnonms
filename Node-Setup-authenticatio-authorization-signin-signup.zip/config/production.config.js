export const config = {
  host: "http://localhost",
  port: 9169,
  socketPort:9198,
  baseUrl: "",
  db: {
    host: "",
    port: 5432,
    username: "",
    database: "",
    password: ""
  }
};
config.baseUrl = `${config.host}:${config.port}/`;
