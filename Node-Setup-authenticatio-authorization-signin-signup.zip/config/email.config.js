export const config = {
  SENDING_FROM:process.env.SENDING_FROM,
  EMAIL_USER:process.env.EMAIL_USER,
  EMAIL_PASS:  process.env.EMAIL_PASS,
  HOST: process.env.HOST,
  SMTP_PORT: process.env.SMTP_PORT
};
