export const config = {
  host: "http://localhost",
  port: 8000,
  socketPort:9198,
  baseUrl: "",
  db: {
	  host: "localhost",
	  port: 5432,
	  username: "healthmatics",
	  database: "healthmatics",
	  password: "healthmatics"
  }
};
config.baseUrl = `${config.host}:${config.port}/`;
