const dotenv = require("dotenv");

dotenv.config();

module.exports = {
  apps: [
    {
      name: "health-matics",
      script: "./index.js",
      watch: true,
      ignore_watch: [
        ".git",
        "uploads",
        "node_modules"
      ]
    }
  ]
};