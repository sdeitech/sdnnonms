import path from "path";
import http from "http";
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import { isDBConnected } from "./config/db.config";
import { eventRoutes } from "./routes";
import { socketAuthMiddleware } from "./middlewares/verifySocket";
import { restrictAccess } from "./middlewares/whitelistedIP";
import { userRoutes } from "./routes/userRoute";
import { orgRoutes } from "./routes/orgRoute";

dotenv.config();
const env = process.env.NODE_ENV || "local";
const envData = require(path.join(__dirname, "config", `${env}.config`));
const port = envData.config.port || 8000;
const app = express();

// Middleware
app.use(cors({origin: ["http://localhost:3000"]}));

// Add JSON parsing middleware

// Serve static files from the "uploads" directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

isDBConnected();

app.use(express.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));
app.use(bodyParser.json());

//routes for apis
app.use("/api/v1/user", userRoutes)
app.use("/api/v1/org", orgRoutes)

// Routes for Socket.IO events
app.use("/", [restrictAccess], eventRoutes);

// Create an HTTP server
// const serverOptions = {
//   key: fs.readFileSync("/home/jenkins/SSL/ss.key"),
//   cert: fs.readFileSync("/home/jenkins/SSL/ss.crt"),
//   // ca: fs.readFileSync("/home/jenkins/SSL/ssb.crt"),
// };

const server = http.createServer(app);
// Start the server
server.listen(port, () => {
  console.log(`HealthMatics App is running on port ${port}`);
});

server.on("error",function(){
  console.log("error in server connection")
})

// Create a Socket.IO server
const io = require("socket.io")(server, {
  // transports: ["websocket"],
  maxHttpBufferSize: 1e12,
  pingTimeout: 6000,
  cors: {
    origin: "*"
  }
});

app.set("io", io);
// Apply socket authentication middleware
io.use(socketAuthMiddleware);
// Require and initialize socket helper
require("./helper/socketHelper")(io);
