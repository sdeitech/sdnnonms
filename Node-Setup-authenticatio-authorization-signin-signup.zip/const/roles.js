export const roles = {
  ADMIN:"ADMIN",
  STAFF : "STAFF",
  PATIENT : "PATIENT"
}