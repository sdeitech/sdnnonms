import { configureStore } from "@reduxjs/toolkit";
// import userReducer from "./slice"
import usersre from "./authslice"


const Store = configureStore({
    reducer:{
        users:usersre
    }
})
export default Store