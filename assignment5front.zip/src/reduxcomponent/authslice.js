import { createSlice } from "@reduxjs/toolkit";


const userSlice = createSlice({
    name:"auth",
    initialState:{
    authUser:{

        token:null,
        userId:null
        // logindetails:{}
    }
},
reducers:{
    authUser:(state,action)=>{
        console.log(action.payload)
        state.authUser.token =action.payload.token
        state.authUser.userId =action.payload.userId
        state.userId = action.payload.userId;


    },
    logoutUser: (state) => {
        state.userId = null;
        state.token = null;
      },
      clearUsers: (state) => {
        state.userData = null;
      },
    
     

    }
})
export default userSlice.reducer;
export const {authUser,logoutUser,clearUsers}=userSlice.actions




// const initialState = {
//   userId: null,
//   token: null,
// };

// const LoginUserSlice = createSlice({
//   name: "loginDetails",
//   initialState: initialState,
//   reducers: {
//     loginSuccess: (state, action) => {
//       console.log(action.payload);
//       state.userId = action.payload.id;
//       state.token = action.payload.token;
//     },
//     logoutUser: (state) => {
//       state.userId = null;
//       state.token = null;
//     },
//   },
// });

// export const { loginSuccess, logoutUser } = LoginUserSlice.actions;
// export default LoginUserSlice.reducer;