import React, { useState } from "react";
import axios from 'axios'
import { useNavigate } from "react-router-dom";
// import validation from "../components/validation";
import Stack from "@mui/material/Stack";


function AddUser() {
  const navigate = useNavigate();
 
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    email: "",
    gender: "",
    phone: "",
  
    

  });
  const [curruntUser, setcurruntUser] = useState(null);
  // const [error, setError] = useState({});
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // const error = validation(setUser)
    // setError(error)
    // console.log(error)


    try {
      const token = localStorage.getItem('token');
      const response = await axios.post("http://localhost:3217/api/postdata", user,{
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          
      }
      });
      console.log("user data submitted :", response.user);
      navigate("/dashboard");
    } catch (err) {
      console.error("Error in submitting form:", err.message);

    }
    // setUser({
    //   firstname: "",
    //   lastname: "",
    //   email: "",
    //   gender: "",
    //   phone: ""
    // });
  };

  return (

    <div style={{ border: "2px solid", alignContent: "center" }}>
      <h2>Add User</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>firstname:</label>
          <input type="text"
            name="firstname"
            value={user.firstname}
            onChange={handleInputChange} 
      
          />
              {/* {error.firstname && <p className="error">{error.firstname}</p>} */}
        </div>
        <div>
          <label>lastname:</label>
          <input type="text"
            name="lastname"
            value={user.lastname}
            onChange={handleInputChange}
       
          />
             {/* {error.lastname && <p className="error">{error.lastname}</p>} */}
        </div>
        <div>
          <label>email:</label>
          <input type="email"
            name="email"
            value={user.email}
            onChange={handleInputChange} 
          
          />
          {/* {error.email && <p className="error">{error.email}</p>} */}
        </div>
        <div>
          <label>gender:</label>
          <select name="gender"
            value={user.gender}
            onChange={handleInputChange}  >
        
            <option value="">select gender</option>
            <option value="male">male</option>
            <option value="female">female</option>
            
          </select>
          {/* {error.gender && <p className="error">{error.gender}</p>} */}
          <div>
            <label>phone:</label>
            <input type="Number"
              name="phone"
              value={user.phone}
              onChange={handleInputChange} 
           
            />
             {/* {error.phone && <p className="error">{error.phone}</p>} */}
          </div>
          <button type="submit">Submit</button>
          {/* {error.submit && <p className="error">{error.submit}</p>} */}
          {/* navigate("/dashboard"); */}
        </div>
      </form>
    </div>
  );
}

export default AddUser;