import React from "react";
import { Link } from "react-router-dom"
import DataTable from "./datatable";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logoutUser,clearUsers } from "../reduxcomponent/authslice";
import toast, { Toaster } from "react-hot-toast";
// import UploadCsv from "./Uploadcsv";
const Dashboard = () => {
  // const logout =()=>{
  //   localStorage.clear();
  
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const handlepassword = async ()=>{
    navigate("/change")
    }

    const handleLogout = () => {
      toast.success("Logged Out");
      setTimeout(() => {
        dispatch(logoutUser());
        dispatch(clearUsers())
        navigate("/login");
      }, 1000);
    };
  
  return (
    


    <div> <h1>Welcome to  Dashboard! please click on add user button to insert the users</h1> <Link to={"/adduser"}><button >Add User</button></Link>

      <Link to={"/update"}><button >My Profile</button></Link>
      <button   onClick={handleLogout} >Log Out </button>
      <Link to={"/change"}><button
        onSubmit={handlepassword}
            type="submit"
            style={{
              // padding: '12px',
              borderRadius: '8px',
              // backgroundColor: '#28a745',
              color: 'white',
              fontSize: '16px',
              border: 'none',
              cursor: 'pointer',
              marginBottom: '15px',
              // boxShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
              transition: 'background-color 0.3s ',
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = '#218838')}
            onMouseOut={(e) => (e.target.style.backgroundColor = '#28a745')}
          >
            Change password
          </button></Link>
          <Toaster/>
         
      <DataTable />

    </div>
  );
};

export default Dashboard;
