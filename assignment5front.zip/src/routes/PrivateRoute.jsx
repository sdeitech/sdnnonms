import Dashboard from "../components/Dashboard";
import PrivateLayout from "../layout/PrivateLayout";
import AddUser from "../constants/adduser";

const PrivateRoutes = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },
  {
    path:"/adduser",
    element: (
      <PrivateLayout>
        <AddUser/>
      </PrivateLayout>
    ),
  },
];
export default PrivateRoutes;