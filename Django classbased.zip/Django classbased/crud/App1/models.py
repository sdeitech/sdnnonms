from django.db import models
class student_details(models.Model):
  firstname = models.CharField(max_length=50)
  lastname = models.CharField(max_length=50)
  age = models.IntegerField()
  dob = models.DateField()
  is_passed = models.BooleanField(default=False)