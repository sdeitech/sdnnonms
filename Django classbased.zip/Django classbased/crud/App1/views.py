from django.shortcuts import render,redirect
from .models import student_details
from django.views import View
# Create your views here.


class student(View):
  def get(self,request):
    return render(request,'studentDetails.html')
  
  def post(self,request):
    firstname = request.POST.get('firstname')
    lastname = request.POST.get('lastname')
    age = request.POST.get('age')
    dob = request.POST.get('dob')
    is_passed = request.POST.get('is_passed')
     
    if is_passed == "on":
      is_passed = True
    else:
      is_passed = False
    
    user = student_details.objects.create(
      firstname = firstname,
      lastname = lastname,
      age = age,
      dob = dob,
      is_passed = is_passed
      
    )
    print(user,"hdkjskhkdhk")
    
    user.save()
    return redirect("dashboard")
  
  

  
class read(View):
  def get(self,request):
    student=student_details.objects.all()
      
    return render(request,'Dashboard.html',{'student':student})
    


class delete_student(View):
  def get(self,request,id):
    obj = student_details.objects.get(id=id)
    obj.delete()
    return redirect("dashboard")
  
  
 
class update_student(View):
  def get(self,request,id):
    obj = student_details.objects.get(id=id)
    date = str(obj.dob)
    print(date)
    return render(request,'update.html',{'obj':obj , "date" :date })


  def post(self,request,id):
      firstname = request.POST.get('firstname')
      lastname = request.POST.get('lastname')
      age = request.POST.get('age')
      dob = request.POST.get('dob')
      is_passed = request.POST.get('is_passed')
      
      obj = student_details.objects.get(id=id)
      
      if firstname: 
        obj.firstname = firstname
      if lastname:
        obj.lastname = lastname
      if age:
        obj.age = age
      if dob:
        obj.dob = dob
      if is_passed == "on":
        obj.is_passed = True
      else:
        obj.is_passed = False
      
        
      obj.save()
      return redirect('dashboard')


# def student(request):
#   if request.method == "POST":
#     firstname = request.POST.get('firstname')
#     lastname = request.POST.get('lastname')
#     age = request.POST.get('age')
#     dob = request.POST.get('dob')
#     is_passed = request.POST.get('is_passed')
     
#     if is_passed == "on":
#       is_passed = True
#     else:
#       is_passed = False
    
#     user = student_details.objects.create(
#       firstname = firstname,
#       lastname = lastname,
#       age = age,
#       dob = dob,
#       is_passed = is_passed
      
#     )
#     print(user,"hdkjskhkdhk")
    
#     user.save()
#     return redirect("dashboard")
#   else:
  
#    return render(request,'studentDetails.html')


# def read(request):  
#     student=student_details.objects.all()
      
#     return render(request,'Dashboard.html',{'student':student})
  
  
# def delete_student(request,id):
#   obj = student_details.objects.get(id=id)
#   obj.delete()
#   return redirect("dashboard")


# def update_student(request,id):
#   if request.method == 'GET':
#     obj = student_details.objects.get(id=id)
    
#     return render(request,'update.html',{'obj':obj})
#   else:
#     firstname = request.POST.get('firstname')
#     lastname = request.POST.get('lastname')
#     age = request.POST.get('age')
#     dob = request.POST.get('dob')
#     is_passed = request.POST.get('is_passed')
    
#     obj = student_details.objects.get(id=id)
    
#     if firstname: 
#       obj.firstname = firstname
#     if lastname:
#       obj.lastname = lastname
#     if age:
#       obj.age = age
#     if dob:
#       obj.dob = dob
#     if is_passed == "on":
#       obj.is_passed = True
#     else:
#       obj.is_passed = False
    
      
#     obj.save()
#   return redirect('dashboard')
      
      
      