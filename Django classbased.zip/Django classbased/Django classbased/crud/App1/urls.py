from .views import student,read,delete_student,update_student
from django.urls import path

urlpatterns = [
  # path('index/',views.index,name='index'),
  path('',student.as_view(),name='student'),
  path('read/',read.as_view(),name='dashboard'),
  path('delete/<int:id>',delete_student.as_view(),name='delete'),
  path('update/<int:id>',update_student.as_view(),name='update')
]
