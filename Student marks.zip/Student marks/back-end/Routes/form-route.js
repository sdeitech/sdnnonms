const express = require('express');
const router = express.Router();
const formController = require('../controller/form-controller');

// CRUD routes using controller methods
router.post('/post', formController.createForm); // Create
router.get('/getforms', formController.getForm); // Read
module.exports = router;
