const express = require('express');
const bodyParser = require('body-parser');
const formRoutes = require('./Routes/form-route');
const db = require('./db');
const app = express();
const PORT = 7000;
const cors = require("cors");



app.use(cors({origin: '*'}));
app.use(bodyParser.json());
app.use('/', formRoutes);

app.listen(PORT, () => {
 console.log(`Server is running on http://localhost:${PORT}`);
});