const Form = require('../model/form-model');
const sendRegistrationEmail = require('../helper/mail')
// const Email = require('../helper/mail')
// Create Form 
exports.createForm = async (req, res) => {
    try {
        req.body.date = new Date(req.body.date);
        const newForm = new Form(req.body);
        await newForm.save(); res.status(201).json(newForm);
        const data = await sendRegistrationEmail("testmail6707@yopmail.com")
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
console.log(Form);
// Get All Form Items 
exports.getForm = async (req, res) => {
    try {
        const form01 = await Form.find();
        res.json(form01);
        console.log("marks Form")
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
