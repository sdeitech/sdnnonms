const mongoose = require('mongoose');

const formSchema = new mongoose.Schema({
 firstName: { type: String, required: true },
 lastName: { type: String, required: true },
 email : { type: String, required: true },
 englishMarks: { type: Number, required: true },
 scienceMarks: { type: Number, required: true },
 mathsMarks: { type: Number, required: true },
 aboutYou: { type: String, required: true },
});

const Form = mongoose.model('Form', formSchema);
module.exports = Form;