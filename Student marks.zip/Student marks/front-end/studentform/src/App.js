import './App.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [englishMarks, setEnglishMarks] = useState('');
  const [scienceMarks, setScienceMarks] = useState('');
  const [mathsMarks, setMathsMarks] = useState('');
  const [user, setUser] = useState('');
  const [viewForm, setViewForm] = useState('');
  const [errors, setErrors] = useState({});

  const [avg, setAvg] = useState('')

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:7000/getforms');
      setUser(response.data);
    } catch (error) {
      setUser([]);
      console.log('Error fetching data:', error);
    }
  };
  const postData = async () => {
    console.log("postData")
    try {
      const response = await axios.post('http://localhost:7000/post', {
        firstName,
        lastName,
        email,
        englishMarks,
        scienceMarks,
        mathsMarks,
      });
      console.log(response, "rahul");
      setUser((prevUsers) => [...prevUsers, response.data]);
      // resetForm();
      console.log('Data posted successfully:', response.data);
    } catch (error) {
      console.error('Error posting data:', error);
    }
  };


  const formavgPercentage = (user) => {
    setAvg(user)
  }

  const viewFormDetails = (user) => {
    setViewForm(user);
  };

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   postData();
  // }

  const clearViewUser = () => {
    setViewForm(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validateForm(user);
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      // Form submission logic here
      console.log('Form submitted successfully!');
    } else {
      console.log('Form submission failed due to validation errors.');
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const validateForm = (user) => {
    const errors = {};

    if (firstName.length === 0) {
      errors.firstName('First Name can not be empty')
      return
    }
    if (lastName.length === 0) {
      errors.lastName('Last Name can not be empty')
      return
    }
    if (!user.email) {
      errors.email = 'Email is required';
    } else  {
      errors.email = 'Email is invalid';
    }

    if (englishMarks < 0) {
      errors.englishMarks = 'Please Enter Positive Value';
    }

    if (scienceMarks < 0) {
      errors.englishMarks = 'Please Enter Positive value';
    }

    if (mathsMarks < 0) {
      errors.englishMarks = 'Please Enter positive value';
    }

    return errors;
  };


  return (
    <div className="container">
      <h1>Student Marks Form</h1>
      <table >
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            {/* <th>English marks</th>
            <th>maths marks</th>
            <th>Science marks</th> */}
            <th>Action</th>
          </tr>
        </thead>
        <tbody>

          {Array.isArray(user) && user.length > 0 ? (
            user.map((Form) => (
              <tr key={Form._id}>
                <td>{Form.firstName}</td>
                <td>{Form.lastName}</td>
                <td>{Form.email}</td>
                {/* <td>{Form.englishMarks}</td>
                <td>{Form.scienceMarks}</td>
                <td>{Form.mathsMarks}</td> */}

                <td><button type='submit' onClick={() => viewFormDetails(Form)} >View</button>
                  {/* <button data-toggle="modal" data-target="#exampleModal" type='submit'>Clear</button>*/}</td>

              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">Loading...</td>
            </tr>
          )}
        </tbody>


      </table><br /><br />
      {viewForm && (
        <div>
          <h2>User Details</h2>
          <p>First Name: {viewForm.firstName}</p>
          <p>Last Name: {viewForm.lastName}</p>
          <p>Email: {viewForm.email}</p>
          <p>englishMarks: {viewForm.englishMarks}</p>
          <p>scienceMarks: {viewForm.scienceMarks}</p>
          <p>mathsMarks: {viewForm.mathsMarks}</p>
          <p>Grade: {viewForm.mathsMarks}</p>
          <p>Percentage: {viewForm.mathsMarks}</p>
          <button onClick={clearViewUser}>Close</button>
        </div>
      )}

      <div className="modal-body">
        <form onSubmit={handleSubmit}>
          <div><br />
            <label>First Name :</label>
            <input type="text"
              value={firstName}
              placeholder="Enter First name"
              onChange={(e) => setFirstName(e.target.value)} />
            {errors.firstName && (
              <span className="error-message">
                {errors.firstName}
              </span>
            )}<br /><br />

            <label>Last Name :</label>
            <input type="text"
              value={lastName}
              placeholder="Enter last name"
              onChange={(e) => setLastName(e.target.value)} />
            {errors.lastName && (
              <span className="error-message">
                {errors.lastName}
              </span>
            )}<br /><br />

            <label>Email :</label>
            <input type="text"
              value={email}
              placeholder="Enter Email"
              onChange={(e) => setEmail(e.target.value)} />
            {errors.email && (
              <span className="error-message">
                {errors.email}
              </span>)}<br /><br />

            <label>English Marks :</label>
            <input type="text"
              value={englishMarks}
              placeholder="english marks"
              onChange={(e) => setEnglishMarks(e.target.value)} />
            {errors.englishMarks && (
              <span className="error-message">
                {errors.englishMarks}
              </span>)}<br /><br />

            <label>Science Marks :</label>
            <input type="text"
              value={scienceMarks}
              placeholder="Enter Science Marks"
              onChange={(e) => setScienceMarks(e.target.value)} /><br /><br />

            <label>Maths Marks :</label>
            <input type="text"
              value={mathsMarks}
              placeholder="Enter Maths marks"
              onChange={(e) => setMathsMarks(e.target.value)} /><br /><br />

            {/* <label>About You</label>
            <input type="text"
              value={scienceMarks}
              placeholder="Enter Science Marks"
              onChange={(e) => (e.target.value)} /><br /><br /> */}


            <button type='submit' data-toggle="modal" data-target="#exampleModal" onClick={postData} >submit</button>
          </div>
        </form>

      </div>
      {/* <div className="modal-footer">
        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
      </div> */}
    </div>
    // </div>
    //</div>
    //</div>


  )
};
export default App;
