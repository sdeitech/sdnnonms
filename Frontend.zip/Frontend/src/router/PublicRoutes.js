import { React } from "react";
import PublicLayout from "../layout/PublicLayout";
import Loginform from "../Login-SignUp/loginform";
import SignUp from "../Login-SignUp/SignUpForm";
import AddPatientForm from "../component/AddPatient";
import PatientList from "../component/PatientList";

const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><Loginform /></PublicLayout>
    },
    {
    	path: "/signUp",
    	exact: true,
    	element: <PublicLayout><SignUp/></PublicLayout>
    },
    {
    	path: "/add-patient",
    	exact: true,
    	element: <PublicLayout><AddPatientForm/></PublicLayout>
    },
    {
    	path: "/patient-list",
    	exact: true,
    	element: <PublicLayout><PatientList/></PublicLayout>
    }
];
export default publicRoutes;
