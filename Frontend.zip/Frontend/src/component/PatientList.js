// import React, { useState, useEffect } from "react";
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Pagination,
//   Box
// } from "@mui/material";
// import axios from "axios";

// function PatientList() {
//   const [data, setData] = useState([]);         // Stores patient data
//   const [error, setError] = useState(null);     // Error handling
//   const [pagination, setPagination] = useState({
//     total_record: 0,
//     per_page: 8,
//     current_page: 1,
//     total_pages: 1,
//   });                                           // Stores pagination data
//   const [loading, setLoading] = useState(false); // Loading state

//   // Fetch patient data based on the current page
//   const fetchPatientData = async (page = 1) => {
//     try {
//       setLoading(true);
//       const response = await axios.get(
//         `http://localhost:5000/patient/getPatient?page=${page}`
//       );
//       console.log(response.data)
//       setData(response.data.patients);
//       setPagination({
//         total_record: response.data.pagination.total_record,
//         per_page: response.data.pagination.per_page,
//         current_page: response.data.pagination.current_page,
//         total_pages: response.data.pagination.total_pages,
//       });
//       setError(null);
//     } catch (error) {
//       setData([]);
//       setError("Failed to fetch data.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch data on component mount and when the page changes
//   useEffect(() => {
//     fetchPatientData(pagination.current_page);
//   }, [pagination.current_page]);

//   // Handle page change
//   const handlePageChange = (event, value) => {
//     setPagination((prevPagination) => ({
//       ...prevPagination,
//       current_page: value,
//     }));
//   };

//   return (
//     <Box sx={{ mt: 4 }}>
//       {loading ? (
//         <p>Loading...</p>
//       ) : error ? (
//         <p>{error}</p>
//       ) : (
//         <>
//           <TableContainer component={Paper}>
//             <Table aria-label="patient table">
//               <TableHead>
//                 <TableRow>
//                   <TableCell><strong>Patient Name</strong></TableCell>
//                   <TableCell><strong>Blood Group</strong></TableCell>
//                   <TableCell><strong>Gender</strong></TableCell>
//                   <TableCell><strong>Age</strong></TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {data.map((patient) => (
//                   <TableRow key={patient._id}>
//                     <TableCell>{patient.patientName}</TableCell>
//                     <TableCell>{patient.bloodGroup}</TableCell>
//                     <TableCell>{patient.gender}</TableCell>
//                     <TableCell>{patient.age}</TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           </TableContainer>

//           {/* Pagination Component */}
//           <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
//             <Pagination
//               count={pagination.total_pages}
//               page={pagination.current_page}
//               onChange={handlePageChange}
//               color="primary"
//             />
//           </Box>
//         </>
//       )}
//     </Box>
//   );
// }

// export default PatientList;

















import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Pagination,
  Box,
  TextField,         // Import Material-UI TextField for search
  Button
} from "@mui/material";
import axios from "axios";

function PatientList() {
  const [data, setData] = useState([]);         // Stores patient data
  const [error, setError] = useState(null);     // Error handling
  const [pagination, setPagination] = useState({
    total_record: 0,
    per_page: 8,
    current_page: 1,
    total_pages: 1,
  });                                           // Stores pagination data
  const [loading, setLoading] = useState(false); // Loading state
  const [searchText, setSearchText] = useState(""); // Search query state

  // Fetch patient data based on the current page and search text
  const fetchPatientData = async (page = 1) => {
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:5000/patient/getPatient?page=${page}&searchText=${searchText}`
      );
      console.log(response.data);
      setData(response.data.patients);
      setPagination({
        total_record: response.data.pagination.total_record,
        per_page: response.data.pagination.per_page,
        current_page: response.data.pagination.current_page,
        total_pages: response.data.pagination.total_pages,
      });
      setError(null);
    } catch (error) {
      setData([]);
      setError("Failed to fetch data.");
    } finally {
      setLoading(false);
    }
  };

  // Fetch data on component mount and when the page or search text changes
  useEffect(() => {
    fetchPatientData(pagination.current_page);
  }, [pagination.current_page, searchText]);

  // Handle page change
  const handlePageChange = (event, value) => {
    setPagination((prevPagination) => ({
      ...prevPagination,
      current_page: value,
    }));
  };

  // Handle search submission
  const handleSearch = () => {
    fetchPatientData(1);  // Start from page 1 when searching
  };

  return (
    <Box sx={{ mt: 4 }}>
      {/* Search Input */}
      <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
        <TextField
          label="Search Patients"
          variant="outlined"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)} // Update search text on change
        />
        <Button
          variant="contained"
          color="primary"
          onClick={handleSearch}
          sx={{ ml: 2 }}
        >
          Search
        </Button>
      </Box>

      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <>
          <TableContainer component={Paper}>
            <Table aria-label="patient table">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Patient Name</strong></TableCell>
                  <TableCell><strong>Blood Group</strong></TableCell>
                  <TableCell><strong>Gender</strong></TableCell>
                  <TableCell><strong>Age</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((patient) => (
                  <TableRow key={patient._id}>
                    <TableCell>{patient.patientName}</TableCell>
                    <TableCell>{patient.bloodGroup}</TableCell>
                    <TableCell>{patient.gender}</TableCell>
                    <TableCell>{patient.age}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination Component */}
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            <Pagination
              count={pagination.total_pages}
              page={pagination.current_page}
              onChange={handlePageChange}
              color="primary"
            />
          </Box>
        </>
      )}
    </Box>
  );
}

export default PatientList;


