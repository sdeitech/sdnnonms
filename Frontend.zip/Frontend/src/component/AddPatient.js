import React, { useState } from "react";
import {
  TextField,
  Button,
  MenuItem,
  InputLabel,
  FormControl,
  Select,
} from "@mui/material";

function AddPatientForm() {
  const [formData, setFormData] = useState({
    name: "",
    bloodGroup: "",
    gender: "",
    age: "",
  });

  const [error, setError] = useState({
    nameError: "",
    bloodGroupError: "",
    genderError: "",
    ageError: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { name, bloodGroup, gender, age } = formData;

    // Basic validation
    setError({
      nameError: name === "" ? "Please enter patient name" : "",
      bloodGroupError: bloodGroup === "" ? "Please select a blood group" : "",
      genderError: gender === "" ? "Please select gender" : "",
      ageError: age === "" || age <= 0 ? "Please enter a valid age" : "",
    });

    if (name && bloodGroup && gender && age > 0) {
      console.log("Patient Data:", formData);
      // Perform further actions like sending data to the backend
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <h1>Add Patient</h1>

      <TextField
        label="Patient Name"
        name="name"
        value={formData.name}
        onChange={handleChange}
        fullWidth
        sx={{ mb: 2 }}
      />
      <span className="error-message">{error.nameError}</span>

      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel>Blood Group</InputLabel>
        <Select
          name="bloodGroup"
          value={formData.bloodGroup}
          onChange={handleChange}
          label="Blood Group"
        >
          <MenuItem value="A+">A+</MenuItem>
          <MenuItem value="A-">A-</MenuItem>
          <MenuItem value="B+">B+</MenuItem>
          <MenuItem value="B-">B-</MenuItem>
          <MenuItem value="AB+">AB+</MenuItem>
          <MenuItem value="AB-">AB-</MenuItem>
          <MenuItem value="O+">O+</MenuItem>
          <MenuItem value="O-">O-</MenuItem>
        </Select>
      </FormControl>
      <span className="error-message">{error.bloodGroupError}</span>

      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel>Gender</InputLabel>
        <Select
          name="gender"
          value={formData.gender}
          onChange={handleChange}
          label="Gender"
        >
          <MenuItem value="Male">Male</MenuItem>
          <MenuItem value="Female">Female</MenuItem>
          <MenuItem value="Other">Other</MenuItem>
        </Select>
      </FormControl>
      <span className="error-message">{error.genderError}</span>

      <TextField
        label="Age"
        name="age"
        type="number"
        value={formData.age}
        onChange={handleChange}
        fullWidth
        sx={{ mb: 2 }}
      />
      <span className="error-message">{error.ageError}</span>

      <Button variant="contained" color="primary" type="submit">
        Submit
      </Button>
    </form>
  );
}

export default AddPatientForm;
