import { Component } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  pageTitle: string = 'Contact Us';
  pageDescription: string = 'Have a question or suggestion? Reach out to us using the form below.';

  contactForm = {
    name: '',
    email: '',
    message: ''
  };

  onSubmit() {
    const allFieldsFilled = Object.values(this.contactForm).every(field => field !== '');

    if (allFieldsFilled) {
      console.log('Form Submitted:', this.contactForm);

      Swal.fire({
        title: 'Success!',
        text: `Heyy ${this.contactForm.name}!!! Your message has been sent!`,
        icon: 'success',
        confirmButtonText: 'OK',
      });

      this.contactForm = { name: '', email: '', message: '' };
    } else {
      Swal.fire({
        title: 'Oops!',
        text: 'Please fill in all fields before submitting.',
        icon: 'error',
        confirmButtonText: 'OK',
      });
    }
  }
}
