import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavComponent implements OnInit {
  cartItemsCount: number = 0;  // Declare and initialize cartItemsCount

  ngOnInit(): void {
    this.getCartItemsCount();  // Call the method to fetch the cart count from localStorage
  }

  getCartItemsCount(): void {
    // Fetch the cart count from localStorage, default to 0 if it doesn't exist
    const cartItemsCount = JSON.parse(localStorage.getItem('cartItemsCount') || '0');
    this.cartItemsCount = cartItemsCount;
  }
}
