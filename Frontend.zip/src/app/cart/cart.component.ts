import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

interface Product {
  id?: number;
  title: string;
  description: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Product[] = [];
  couponCode: string = '';
  totalPrice: number = 0;
  discount: number = 0;
  finalPrice: number = 0;

  constructor() {}

  ngOnInit(): void {
    this.loadCart();
    this.calculateTotalPrice();
  }

  loadCart(): void {
    const savedCart = localStorage.getItem('cart');
    this.cart = savedCart ? JSON.parse(savedCart) : [];
  }

  calculateTotalPrice(): void {
    this.totalPrice = this.cart.reduce((total, product) => total + product.price, 0);
    this.finalPrice = this.totalPrice - this.discount;
  }

  removeFromCart(product: Product): void {
    const index = this.cart.findIndex(item => item.id === product.id);

    if (index !== -1) {
      this.cart.splice(index, 1);

      localStorage.setItem('cart', JSON.stringify(this.cart));

      this.calculateTotalPrice();

      Swal.fire({
        title: 'Removed!',
        text: `${product.title} has been removed from cart`,
        icon: 'info'
      });
    }
  }

  clearCart(): void {
    Swal.fire({
      title: 'Clear Cart?',
      text: 'Are you sure you want to remove all items from your cart?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, clear it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.cart = [];
        localStorage.removeItem('cart');
        this.calculateTotalPrice();

        Swal.fire(
          'Cleared!',
          'Your cart has been emptied.',
          'success'
        );
      }
    });
  }

  applyCoupon(): void {
    if (this.couponCode.toUpperCase() === 'FIRSTORDER') {
      this.discount = this.totalPrice * 0.1;
      this.finalPrice = this.totalPrice - this.discount;
      Swal.fire({
        title: 'Coupon Applied!',
        text: 'You got a 10% discount',
        icon: 'success'
      });
    } else {
      Swal.fire({
        title: 'Invalid Coupon',
        text: 'The coupon code you entered is not valid',
        icon: 'error'
      });
      this.discount = 0;
      this.finalPrice = this.totalPrice;
    }
  }

  getimagepath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `http://127.0.0.1:8000${path.startsWith('/') ? path : '/' + path}`;
  }
}
