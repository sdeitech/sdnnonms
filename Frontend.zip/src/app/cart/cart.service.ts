import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

interface Product {
  id?: number;
  tittle: string;
  description: string;
  price: number;
  image: string;
  quantity: number;

}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems: Product[] = [];
  private cartSubject: BehaviorSubject<Product[]> = new BehaviorSubject<Product[]>(this.cartItems);

  get cart$() {
    return this.cartSubject.asObservable();
  }

  addToCart(product: Product): void {
    const existingProductIndex = this.cartItems.findIndex(item => item.id === product.id);

    if (existingProductIndex > -1) {
      this.cartItems[existingProductIndex].quantity += 1;
    } else {
      this.cartItems.push({ ...product, quantity: 1 });
    }

    this.cartSubject.next(this.cartItems);
  }

  removeFromCart(productId: number): void {
    this.cartItems = this.cartItems.filter(item => item.id !== productId);
    this.cartSubject.next(this.cartItems);
  }

  clearCart(): void {
    this.cartItems = [];
    this.cartSubject.next(this.cartItems);
  }

  getTotalAmount(): number {
    return this.cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  }
}
