import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';


interface Product {
  id?: number;
  title: string;
  description: string;
  price: number;
  image: string;
  quantity: number;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  private baseUrl = 'http://127.0.0.1:8000/apis/products/';
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    this.http.get<Product[]>(this.baseUrl).subscribe(
      (data) => {
        this.products = data.map(product => ({
          ...product,
          image: this.getimagepath(product.image)
        }));
        console.log(this.products);
      },
      (error) => {
        console.error('There was an error fetching the products!', error);

        Swal.fire({
          title: 'Error!',
          text: 'Could not fetch products',
          icon: 'error'
        });
      }
    );
  }

  addToCart(product: Product): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');

    const existingProductIndex = cart.findIndex((item: Product) => item.id === product.id);

    if (existingProductIndex === -1) {
      // Add product to cart if not already present
      cart.push(product);
      localStorage.setItem('cart', JSON.stringify(cart));

      Swal.fire({
        title: 'Added Successfully!',
        text: `Added ${product.title} to cart`,
        icon: 'success',
      });
    } else {
      Swal.fire({
        title: 'Already in Cart',
        text: `${product.title} is already in your cart`,
        icon: 'info',
      });
    }

    this.updateCartCount();
  }

  getimagepath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `http://127.0.0.1:8000${path.startsWith('/') ? path : '/' + path}`;
  }

  // Update the cart count in localStorage whenever a change occurs
  updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const cartItemsCount = cart.length;
    localStorage.setItem('cartItemsCount', JSON.stringify(cartItemsCount));
  }
}
