import React, { useEffect } from "react";
import { useNavigate } from "react-router";
import Navbarex from "../component/Navbar";


const PrivateLay = ({ children }) => {

    let token = localStorage.getItem('token');
    let userId = localStorage.getItem('user')
    let navigate = useNavigate();
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token,userId, navigate]);

    return (
        <div className="layout">
            <div className="content">
                <Navbarex />
                {children}

            </div>
        </div>
    );
};

export default PrivateLay;
