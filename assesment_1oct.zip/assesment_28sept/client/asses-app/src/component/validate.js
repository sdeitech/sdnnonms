const validate = (values) => {
    let error = {};

    if (!values.firstName) {
        error.firstName = "First Name is required!!";
    }
    if (!values.lastName) {
        error.lastName = "Last Name is required!!";
    }
    if (!values.age) {
        error.age = "AGE is required!!";
    }

    if (!values.gender) {
        error.gender = "Gender is required !!";
    }
    if (!values.dob) {
        error.dob = "Birth Date is required !!";
    }
    if (!values.email) {
        error.email = "Email is required !!";
    }

    if (!values.pass) {
        error.pass = "Password is required !!";
    }




    return error;
};

export default validate;