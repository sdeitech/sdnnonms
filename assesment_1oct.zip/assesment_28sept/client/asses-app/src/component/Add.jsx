import React, { useState } from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
// import validate from './validate';

function AddForm() {
    let userId = localStorage.getItem('user')
    // let token = localStorage.getItem('token')


    const [userData, setUserData] = useState({
        firstName: '',
        lastName: '',
        age: '',
        dob: '',
        gender: '',
        isMarried: '',
        userRef: userId,

    });

    const [error, setError] = useState({})

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({
            ...userData,
            [name]: value,
        });
    };

    console.log(userData);

    const handleSubmit = async (e) => {
        e.preventDefault();

            try {
                const response = await axios.post(
                    "http://localhost:5000/user/userdata",
                    userData
                );
                console.log("userData data submitted:", response.data);
            } catch (err) {
                console.error("Error submitting Data:", err.message);
            }




    };

    const clearuserData = () => {
        setUserData({
            firstName: '',
            lastName: '',
            age: '',
            dob: '',
            gender: '',
            isMarried: '',
        });
    };

    return (
        <Form onSubmit={handleSubmit}>
            <Row className="mb-3">
                <Form.Group as={Col}>
                    <Form.Label>First Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter Name" name="firstName" onChange={handleChange} value={userData.name} />
                    {error.firstName && <p className="error">{error.firstName}</p>}
                </Form.Group>

                <Form.Group as={Col}>
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter Last Name" name="lastName" onChange={handleChange} value={userData.lastName} />
                    {error.lastName && <p className="error">{error.lastName}</p>}
                </Form.Group>
            </Row>

            <Form.Group className="mb-3">
                <Form.Label>age</Form.Label>
                <Form.Control type="number" placeholder="Enter AGE" name="age" onChange={handleChange} value={userData.age} />
                {error.age && <p className="error">{error.age}</p>}
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Date of Birth </Form.Label>
                <Form.Control type="text" placeholder="Date of Birth" name="dob" onChange={handleChange} value={userData.dob} />
                {error.dob && <p className="error">{error.dob}</p>}
            </Form.Group>

            <Row className="mb-2">
                <div className='d-flex'>
                <Form.Check 
                    type="checkbox"
                    label= "Married"
                />
                <Form.Group as={Col}>
                    <Form.Label>Gender</Form.Label>
                    <Form.Control type='text' placeholder="Enter gender" name="gender" onChange={handleChange} value={userData.gender} />
                    {error.gender && <p className="error">{error.gender}</p>}
                </Form.Group>
                </div>
          
            </Row>
            <Button variant="primary" type="submit">
                Submit
            </Button>
            <Button variant="secondary" onClick={clearuserData} className="ms-2">
                Reset
            </Button>
        </Form>
    );
}

export default AddForm;










