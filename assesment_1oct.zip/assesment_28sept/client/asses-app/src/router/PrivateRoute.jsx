import {React} from "react";

import NotFound from "../component/NotFound";

import PrivateLay from "../layout/PrivateLay";
import Dashboard from "../component/Dashboard";
import AddForm from "../component/Add";
import Profile from "../component/Profile";

const PrivateRoute = [
	{
		path: "/users",
		exact: true,
		element: <PrivateLay><Dashboard/></PrivateLay>
	},
    {
		path: "/add",
		exact: true,
		element: <PrivateLay><AddForm/></PrivateLay>
	},
	{
		path: "/profile",
		exact: true,
		element: <PrivateLay><Profile/></PrivateLay>
	},
	{ path: "/*", element: <NotFound/> }
];
export default PrivateRoute;
