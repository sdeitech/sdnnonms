import UserData from '../model/userdata.m'
import { Response } from '../middleware/response';
import { messages } from '../config/constant';

const createUserdata = async (req, res) => {
    try {
        const { firstName, lastName, age, dob, gender, isMarried, userRef } = req.body;
        const newData = new UserData({
            firstName,
            lastName,
            age,
            dob,
            gender,
            isMarried,
            userRef
        });
        console.log(req.body)
        await newData.save();
        return Response._200(res, {
            status: true,
            message: messages.userRegistered,
            body: null,
        });
    } catch (error) {
        console.log(error);

        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};


const getUserdata = async (req, res) => {
    try {
        console.log(req.query);
        
        const data = await UserData.find({userRef:req.query.userid});
        res.send(data)
    } catch (error) {
        console.log(error);

        Response._500(res, {
            status: false,
            message: error.message,
            body: null,
        });
    }
};



module.exports = {
    createUserdata,
    getUserdata,
}