import mongoose from "mongoose";




const userdataSchema = mongoose.Schema({
    firstName: {
        type: String,
        requied: true,
    },
    lastName: {
        type: String,
        requied: true,
    },
    age: {
        type: Number,
    },
    dob: {
        type: String,
        requied: true,
    },

    gender: {
        type: String,
    },
    isMarried: {
        type: String,
    },
    userRef: {
        type:mongoose.Schema.Types.ObjectId,
        ref:'User'
    },

})

const Userdata = mongoose.model("Userdata", userdataSchema);

module.exports = Userdata;