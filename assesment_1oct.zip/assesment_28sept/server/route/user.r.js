import express from "express";
import {registerUser, loginUser, getUser, updateUser} from '../controller/user.c'
import {createUserdata, getUserdata} from '../controller/userdata.c'
import { uploadMiddleware } from "../middleware/multer";
const authrouter = express.Router();


authrouter.post('/register',uploadMiddleware.single('file'),(req,res)=>{registerUser});
authrouter.post('/login', loginUser); 
authrouter.put('/update/:id',updateUser)
authrouter.get('/view', getUser);
authrouter.post('/userdata',createUserdata);
authrouter.get('/userview',getUserdata);





module.exports = authrouter;