import 'dotenv/config.js';

export const config = {
    DB: {
        HOST: process.env.MONGO_DB_HOST,
        PORT: process.env.MONGO_DB_PORT,
        DATABASE: process.env.MONGO_DATABASE,
        
    },
    PORT: process.env.PORT,
    TOKENS:{
        JWT_SECRET: "mysecretkey",
        JWT_EXPIRATION_IN_MINUTES: process.env.JWT_EXPIRATION_IN_MINUTES || 1440,
        NODE_ENV: process.env.NODE_ENV || "local",
    },




};