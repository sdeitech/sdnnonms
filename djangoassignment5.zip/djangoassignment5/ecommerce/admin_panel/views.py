from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.views import View
from .forms import UserForm
from django.contrib.auth import get_user_model

class AdminRegisterView(View):
    def get(self, request):
        form = UserForm()  # Create an empty registration form
        context = {'form': form}
        return render(request, 'register.html', context)

    def post(self, request):
        form = UserForm(request.POST)
        if form.is_valid():
            # Save the user and hash the password
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])  # Hash the password
            user.save()  # Save the user to the database
            login(request, user)  # Automatically log in the user after registration
            messages.success(request, 'Registration successful!')
            return redirect('login')  # Redirect to login page after registration
        return render(request, 'register.html', {'form': form})

class AdminLoginView(View):
    def get(self, request):
        # if request.user.is_authenticated:  # Redirect to dashboard if already logged in
        #     return redirect('dashboard')
        form = AuthenticationForm()  # Create an empty login form
        return render(request, 'login.html', {'form': form})

    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()  # Get the authenticated user
            login(request, user)  # Log the user in
            messages.success(request, 'Login successful!')
            return redirect('dashboard')  # Redirect to the dashboard page after login
        return render(request, 'login.html', {'form': form})

from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views import View
from .models import Product
from .forms import ProductForm

# Dashboard View to list all products
from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from .forms import ProductForm
from .models import Product

# Dashboard View to display products
class DashboardView(View):
    def get(self, request):
        products = Product.objects.all()  # Fetch all products from the database
        return render(request, 'dashboard.html', {'products': products})

# Add Product View to handle form requests
class AddProductView(View):
    def get(self, request):
        # Create an empty product form for GET requests
        form = ProductForm()
        # Return the form as part of a response
        return render(request, 'add_product.html', {'form': form})

    def post(self, request):
        # Handle form submission
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()  # Save the product
            # Return success response as JSON
            return JsonResponse({'status': 'success', 'message': 'Product added successfully'})
        # If form is invalid, return error message
        return JsonResponse({'status': 'error', 'message': 'Invalid form data'})

