from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.AdminRegisterView.as_view(),name='register'),
    path('login/', views.AdminLoginView.as_view(),name='login'),
    path('dashboard/', views.DashboardView.as_view(),name='dashboard'),
    path('add-product/', views.AddProductView.as_view(), name='add_product'),
]