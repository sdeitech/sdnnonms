import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import apiClient from "../apiClient";
import Icons from "../assets/Icons";
import PaginationComponent from "../components/PaginationComponent";

const UserTable = () => {
  const { token, userId } = useSelector((state) => state.loggedInData);

  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const usersPerPage = 10;

  const fetchUsers = async (page) => {
    try {
      const response = await apiClient.get(`/users`,{
        headers:{
          Authorization:token
        }
      });
      console.log(response.data);
      setUsers(response.data.users);
      setTotalPage(Math.ceil(response.data.total / usersPerPage));
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  useEffect(() => {
    fetchUsers(currentPage);
  }, [currentPage]);

  const handleChangePage = (event, newPage) => {
    setCurrentPage(newPage);
  };

  return (
    <div className="container mx-auto my-6 p-6 bg-white shadow-lg rounded-lg relative">
      <h2 className="text-3xl font-bold mb-6 text-center text-gray-700">
        User List
      </h2>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300 rounded-lg shadow">
          <thead className="bg-gray-400 text-white sticky top-0">
            <tr>
              <th className="py-3 px-4 border-b font-semibold">SR No</th>
              <th className="py-3 px-4 border-b font-semibold">First Name</th>
              <th className="py-3 px-4 border-b font-semibold">Last Name</th>
              <th className="py-3 px-4 border-b font-semibold">Email</th>
              <th className="py-3 px-4 border-b font-semibold">
                Mobile Number
              </th>
              <th className="py-3 px-4 border-b font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users?.map((user, index) => (
              <tr
                key={user._id}
                className="text-center hover:bg-gray-100 transition-all duration-200"
              >
                <td className="py-3 px-4 border-b text-gray-600">
                  {(currentPage - 1) * usersPerPage + index + 1}
                </td>
                <td className="py-3 px-4 border-b text-gray-700 font-medium">
                  {user?.firstName}
                </td>
                <td className="py-3 px-4 border-b text-gray-700 font-medium">
                  {user?.lastName}
                </td>
                <td className="py-3 px-4 border-b text-gray-700">
                  {user?.email}
                </td>
                <td className="py-3 px-4 border-b text-gray-700">
                  {user?.mobileNumber}
                </td>

                <td className="py-3 px-4 border-b">
                  <div className="flex justify-center space-x-4">
                    <button
                      className="text-blue-500 hover:text-blue-700 p-2 rounded-full hover:bg-blue-100 transition-all duration-150"
                      title="View"
                    >
                      <Icons.EYE className="text-lg" />
                    </button>
                    <button
                      className="text-green-500 hover:text-green-700 p-2 rounded-full hover:bg-green-100 transition-all duration-150"
                      title="Edit"
                    >
                      <Icons.EDIT className="text-lg" />
                    </button>
                    <button
                      className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-100 transition-all duration-150"
                      title="Delete"
                    >
                      <Icons.DELETE className="text-lg" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 fixed bottom-8 flex justify-center">
        <PaginationComponent
          currentPage={currentPage}
          totalPage={totalPage}
          handleChangePage={handleChangePage}
        />
      </div>
    </div>
  );
};

export default UserTable;
