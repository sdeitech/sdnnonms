import React from "react";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import resetAllStates from "../app/reducers/resetAllStates";

const Sidebar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleLogout = () => {
    dispatch(resetAllStates());
    navigate("/");
  };
  return (
    <div className="h-screen w-64 bg-gray-800 text-white p-5 flex flex-col">
      <Link to={"/admin-dashboard"}>
        <h2 className="text-2xl font-semibold mb-6">Admin Dashboard</h2>
      </Link>
      <nav className="flex flex-col space-y-3">
        <Link to="/admin-dashboard" className="hover:bg-gray-700 p-2 rounded">
          Dashboard
        </Link>
        <Link to="/dashboard/users" className="hover:bg-gray-700 p-2 rounded">
          Users
        </Link>
        <Link
          to="/dashboard/products"
          className="hover:bg-gray-700 p-2 rounded"
        >
          Products
        </Link>
        <Link to="/add-product" className="hover:bg-gray-700 p-2 rounded">
          Add Products
        </Link>
        <Link
          to="/dashboard/settings"
          className="hover:bg-gray-700 p-2 rounded"
        >
          Settings
        </Link>

        <Link
          className="hover:bg-gray-700 p-2 rounded"
          onClick={handleLogout}
        >
          logout
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;
