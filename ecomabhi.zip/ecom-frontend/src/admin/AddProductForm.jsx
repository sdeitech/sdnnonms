import React, { useState } from "react";
import useForm from "../customeHooks/useForm";
import apiClient from "../apiClient";
import { useSelector } from "react-redux";

const AddProductForm = () => {
  const { token, userId } = useSelector((state) => state.loggedInData);

  const [product, setProduct] = useState({
    name: "",
    price: "",
    description: "",
    image: null,
  });

  const { formData, handleChange } = useForm(product);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await apiClient.post(`/add-product/${userId}`, formData, {
        headers: {
          Authorization: token,
          "Content-Type": "multipart/form-data",
        },
      });
      console.log(res.data, "Product added");
    } catch (error) {
      console.error("Error adding product:", error);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md mt-16 border-t-4 border-blue-400">
      <h2 className="text-2xl font-semibold mb-6 text-center text-blue-500">Add New Product</h2>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-gray-700 font-medium mb-2">Product Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-200 transition"
            placeholder="Enter product name"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Price</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-200 transition"
            placeholder="Enter product price"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-200 transition"
            placeholder="Enter product description"
            rows="3"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Product Image</label>
          <div className="flex items-center space-x-4">
            <label className="custom-file-upload cursor-pointer text-white bg-blue-500 py-2 px-4 rounded hover:bg-blue-600 transition">
              <input
                type="file"
                name="image"
                onChange={handleChange}
                className="hidden"
                required
              />
              Choose File
            </label>
            <span className="text-gray-500">{formData.image ? formData.image.name : "No file chosen"}</span>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded-md font-semibold hover:bg-blue-600 transition"
        >
          Add Product
        </button>
      </form>
    </div>
  );
};

export default AddProductForm;
