import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import apiClient from "../apiClient";
import {
  deleteProduct,
  handlePagination,
  storeProductData,
} from "../app/reducers/AdminSlice";
import Icons from "../assets/Icons";
import PaginationComponent from "../components/PaginationComponent";
import ProductDetails from "./ProductDetails";
const imageUrl = import.meta.env.VITE_IMAGE_URL;

const ProductTable = () => {
  const dispatch = useDispatch();

  const { token, userId } = useSelector((state) => state.loggedInData);
  const { products } = useSelector((state) => state.AdminSlice);
  const { currentPage, totalPage, productsPerPage } = useSelector(
    (state) => state.AdminSlice.pagination
  );

  const [product, setProduct] = useState({});
  const [showDetails, setShowDetails] = useState(false);

  console.log(totalPage, currentPage, products);

  const fetchProducts = async (page) => {
    try {
      const response = await apiClient.get(
        `/all-products/?page=${page}&limit=${productsPerPage}`,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      dispatch(storeProductData(response.data));
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  useEffect(() => {
    fetchProducts(currentPage);
  }, [currentPage, userId]);

  const handleChangePage = (event, newPage) => {
    dispatch(handlePagination(newPage));
  };

  const handleDeleteProduct = async (productId) => {
    try {
      const res = await apiClient.delete(`/delete-product/${productId}`, {
        headers: {
          Authorization: token,
        },
      });
      dispatch(deleteProduct(res.data));
      console.log(res.data, "delete product");
    } catch (error) {
      console.error("Error deleting products:", error);
    }
  };

  return (
    <div className="container mx-auto my-6 p-6 bg-white shadow-lg rounded-lg relative">
      <h2 className="text-3xl font-bold mb-6 text-center text-gray-700">
        Product List
      </h2>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300 rounded-lg shadow">
          <thead className="bg-gray-400 text-white sticky top-0">
            <tr>
              <th className="py-3 px-4 border-b font-semibold">SR No</th>
              <th className="py-3 px-4 border-b font-semibold">Image</th>
              <th className="py-3 px-4 border-b font-semibold">Product Name</th>
              <th className="py-3 px-4 border-b font-semibold">Price</th>
              <th className="py-3 px-4 border-b font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product, index) => (
              <tr
                key={product._id}
                className="text-center hover:bg-gray-100 transition-all duration-200"
              >
                <td className="py-3 px-4 border-b text-gray-600">
                  {(currentPage - 1) * productsPerPage + index + 1}
                </td>
                <td className="py-3 px-4 border-b">
                  <img
                    src={`${imageUrl}/${product.image}`}
                    alt={product.name}
                    className="w-16 h-16 object-cover rounded-lg border-2 border-gray-200"
                  />
                </td>
                <td className="py-3 px-4 border-b text-gray-700 font-medium">
                  {product.name}
                </td>
                <td className="py-3 px-4 border-b text-gray-700 font-semibold">
                  ₹{product.price}
                </td>
                <td className="py-3 px-4 border-b">
                  <div className="flex justify-center space-x-4">
                    <button
                      className="bg-blue-100 hover:bg-blue-200 text-blue-500 p-2 rounded-lg transition-all duration-150"
                      title="View"
                      onClick={() => {
                        setProduct(product);
                        setShowDetails(!showDetails);
                      }}
                    >
                      <Icons.EYE className="text-xl" />
                    </button>

                    <Link to={`/update-product/${product._id}`}>
                      <button
                        className="bg-green-100 hover:bg-green-200 text-green-500 p-2 rounded-lg transition-all duration-150"
                        title="Edit"
                      >
                        <Icons.EDIT className="text-xl" />
                      </button>
                    </Link>

                    <button
                      className="bg-red-100 hover:bg-red-200 text-red-500 p-2 rounded-lg transition-all duration-150"
                      title="Delete"
                      onClick={() => {
                        handleDeleteProduct(product._id);
                      }}
                    >
                      <Icons.DELETE className="text-xl" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showDetails && (
        <div>
          <ProductDetails
            product={product}
            setProduct={setProduct}
            showDetails={showDetails}
            setShowDetails={setShowDetails}
          />
        </div>
      )}

      <div className="mt-6 fixed bottom-8 flex justify-center">
        <PaginationComponent
          currentPage={currentPage}
          totalPage={totalPage}
          handleChangePage={handleChangePage}
        />
      </div>
    </div>
  );
};

export default ProductTable;
