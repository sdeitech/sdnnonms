import React, { useEffect, useState } from "react";
import apiClient from "../apiClient";
import { useSelector } from "react-redux";
import { useParams, Link, useNavigate } from "react-router-dom";
import useForm from "../customeHooks/useForm";
import toast, { Toaster } from "react-hot-toast";
const imageUrl = import.meta.env.VITE_IMAGE_URL;

const UpdateProduct = () => {
  const navigate = useNavigate();
  const { token } = useSelector((state) => state.loggedInData);
  const { productId } = useParams();

  const [product, setProduct] = useState({
    name: "",
    price: "",
    description: "",
    image: null,
  });

  const { formData, handleChange, setFormData } = useForm(product);

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const response = await apiClient.get(`/product/${productId}`, {
          headers: {
            Authorization: token,
          },
        });
        const productData = response.data;
        setProduct({
          name: productData.name,
          price: productData.price,
          description: productData.description,
          image: productData.image,
        });
      } catch (error) {
        console.error("Error fetching product details:", error);
      }
    };

    fetchProductDetails();
  }, [productId]);

  useEffect(() => {
    if (product) {
      setFormData(product);
    }
  }, [product, setFormData]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await apiClient.put(
        `/update-product/${productId}`,
        formData,
        {
          headers: {
            Authorization: token,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      toast.success("Product updated");
      setTimeout(() => {
        navigate("/dashboard/products");
      }, 2000);
    } catch (error) {
      toast.error("Cannot update product");
      console.error("Error updating product:", error);
    }
  };

  return (
    <div className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-md mt-20 border-t-4 border-blue-400">
      <h2 className="text-2xl font-bold mb-6 text-center text-blue-500">
        Update Product
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 font-medium mb-2">Product Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-300"
            placeholder="Enter product name"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Price</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-300"
            placeholder="Enter product price"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-300"
            placeholder="Enter product description"
            rows="3"
            required
          />
        </div>

        {product.image && (
          <div>
            <label className="block text-gray-700 font-medium mb-2">Current Product Image</label>
            <img
              src={`${imageUrl}/${product.image}`}
              alt="Current Product"
              className="w-full h-48 object-cover rounded-lg shadow-md mb-4"
            />
          </div>
        )}

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Upload New Product Image (Optional)
          </label>
          <div className="relative">
            <input
              type="file"
              name="image"
              onChange={handleChange}
              className="absolute opacity-0 inset-0 w-full h-full cursor-pointer"
            />
            <div className="w-full px-4 py-2 border border-gray-300 rounded bg-gray-100 text-gray-700 flex items-center justify-center cursor-pointer hover:bg-gray-200">
              Choose File
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition"
        >
          Update Product
        </button>
      </form>

      <Link
        to="/dashboard/products"
        className="block mt-6 text-center text-blue-500 hover:text-blue-700"
      >
        Back to Product List
      </Link>
      <Toaster />
    </div>
  );
};

export default UpdateProduct;
