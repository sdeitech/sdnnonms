import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import resetAllStates from "../app/reducers/resetAllStates.jsx";
import Icons from "../assets/Icons.jsx";
import UserProfile from "../pages/UserProfile.jsx";
import { FaShoppingCart } from "react-icons/fa";
import { Icon } from "@mui/material";

const Navbar = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { cart } = useSelector((state) => state.CartSlice);
  const cartItemCount = cart.length;
  const [showProfile, setShowProfile] = useState(false);

  const handleLogout = () => {
    dispatch(resetAllStates());
    navigate("/");
  };

  return (
    <div>
      <nav className="shadow-md py-4 px-8 fixed w-full bg-gray-800 text-white">
        <div className="container mx-auto flex justify-between items-center">
          <Link to={"/products"}>
            <div className="flex items-center text-white text-3xl font-bold">
              <Icons.LOGO className="mr-2" />
              <span>Shop</span>
            </div>
          </Link>

          <div className="flex-1 mx-4 max-w-lg">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="w-full border border-gray-600 rounded-full py-2 px-4 pl-10 text-gray-700 focus:outline-none f shadow-sm bg-gray-700 "
              />
              <button className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Icons.SEARCH />
              </button>
            </div>
          </div>

          <div className="flex justify-center gap-6">
            <Link to={"/cart"}>
              <div className="relative border p-3 rounded-full bg-gray-800 hover:bg-gray-700 transition duration-200 ease-in-out cursor-pointer">
                <Icons.SHOPPING_CART size={25} className="text-white" />
                <div className="absolute top-0 right-0 bg-red-500 text-white text-xs font-extrabold rounded-full w-5 h-5 flex items-center justify-center">
                  <p>{cartItemCount > 0 ? cartItemCount : 0}</p>
                </div>
              </div>
            </Link>

            <div
              onClick={() => {
                setShowProfile(!showProfile);
              }}
              className="border p-3 rounded-full bg-gray-800 hover:bg-gray-700 transition duration-200 cursor-pointer ease-in-out"
            >
              <Icons.USER_ICON size={25} className="text-white" />
            </div>
          </div>
        </div>
      </nav>
      {showProfile && (
        <div className="absolute top-20 right-4 bg-white shadow-xl border border-gray-300 rounded-lg p-2 z-50">
          <UserProfile handleLogout={handleLogout} />
        </div>
      )}
      <div className="mt-16"></div>
    </div>
  );
};

export default Navbar;
