import { Pagination } from "@mui/material";
import React from "react";

const PaginationComponent = ({ currentPage, totalPage, handleChangePage }) => {
  return (
    <Pagination
      count={totalPage}
      page={currentPage}
      onChange={handleChangePage}
      color="primary"
      shape="rounded"
    />
  );
};

export default PaginationComponent;
