import React from "react";
import { useDispatch, useSelector } from "react-redux";
import apiClient from "../apiClient";
import { addToCart } from "../app/reducers/CartSlice";
import Icons from "../assets/Icons";
const imageUrl = import.meta.env.VITE_IMAGE_URL;

const ProductCard = ({ product }) => {
  const dispatch = useDispatch();
  const { userId, token } = useSelector((state) => state.loggedInData);

  const addItemToCart = async () => {
    let item = {
      productId: product._id,
      name: product.name,
      price: product.price,
      image: product.image,
    };

    try {
      const res = await apiClient.post(
        `/add-to-cart`,
        {
          id: userId,
          productId: product._id,
          quantity: 1,
          price: product.price,
        },
        {
          headers: {
            Authorization: token,
          },
        }
      );

      console.log(res.data);
      dispatch(addToCart(item));
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden ">
      <img
        src={`${imageUrl}/${product.image}`}
        alt={product.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h2 className="text-lg font-semibold text-gray-800">{product.name}</h2>
        <p className="text-gray-700 mt-1">
          ₹{product.price} {/* Rupees symbol added here */}
        </p>
        <p className="text-gray-600 mt-2 text-sm truncate">{product.description}</p>

        <button
          onClick={addItemToCart}
          className="mt-4 flex items-center bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors duration-200"
        >
          <Icons.CART className="mr-2" />
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
