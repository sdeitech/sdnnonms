import React from "react";
import Icons from "../assets/Icons";
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 py-10 px-6">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">ShopLogo</h2>
          <p className="text-sm">
            Discover the best deals and latest products on our e-commerce
            platform. Quality guaranteed for every item you buy.
          </p>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
          <ul>
            <li className="mb-2 hover:text-white">
              <a href="#shop">Shop</a>
            </li>
            <li className="mb-2 hover:text-white">
              <a href="#about">About Us</a>
            </li>
            <li className="mb-2 hover:text-white">
              <a href="#contact">Contact</a>
            </li>
            <li className="mb-2 hover:text-white">
              <a href="#faq">FAQ</a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Contact Us</h3>
          <p className="text-sm mb-2">123 Main St, Anytown, USA</p>
          <p className="text-sm mb-2">Email: support@example.com</p>
          <p className="text-sm mb-2">Phone: +1 (234) 567-890</p>

          <div className="flex space-x-4 mt-4 text-gray-400">
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icons.FACEBOOK className="text-2xl hover:text-white transition duration-200" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icons.TWITTER className="text-2xl hover:text-white transition duration-200" />
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icons.INSTAGRAM className="text-2xl hover:text-white transition duration-200" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icons.LINKEDIN className="text-2xl hover:text-white transition duration-200" />
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-700 mt-8 pt-4 text-center">
        <p className="text-sm">
          &copy; {new Date().getFullYear()} ShopLogo. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
