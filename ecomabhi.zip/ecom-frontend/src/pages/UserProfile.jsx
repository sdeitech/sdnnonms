import React from "react";

const UserProfile = ({handleLogout}) => {
  // Sample user data (Replace with actual Redux or prop data)
  const user = {
    firstName: "User1",
    lastName: "User1",
    email: "user1@gmail.com",
    role: "user",
  };


  return (
    <div className="max-w-xs w-full bg-gray-200 shadow-lg border border-gray-200 rounded-lg p-6 ">
      <div className="flex items-center justify-center mb-4">
        <div className="bg-gray-400 text-gray-800 rounded-full h-20 w-20 flex items-center justify-center text-3xl font-bold">
          {user.firstName?.[0] || ""}
        </div>
      </div>

      <h2 className="text-xl font-semibold text-center mb-2 text-gray-800">
        {user.firstName} {user.lastName}
      </h2>
      <p className="text-gray-600 text-center mb-2">{user.email}</p>

      <p className="text-center text-gray-500 text-sm mb-4">{user.role}</p>

      <button
        onClick={handleLogout}
        className="w-full bg-gray-600 text-white py-2 rounded hover:bg-gray-700 transition duration-200 mb-3"
      >
        Logout
      </button>

    </div>
  );
};

export default UserProfile;
