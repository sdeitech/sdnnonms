import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import CountUp from "react-countup";

const AdminDashboard = () => {
  const [totalProducts, setTotalProducts] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      setTotalProducts(120); 
      setTotalUsers(450); 
      setTotalOrders(230);
    }, 1000);
  }, []);

  return (
    <div className="admin-dashboard p-6">
      <h1 className="text-4xl font-extrabold mb-8 text-center text-gray-800">Admin Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <motion.div
          className="stat-card bg-blue-500 p-6 rounded-lg shadow-lg text-white transition-transform transform hover:scale-105"
          whileHover={{ scale: 1.05 }}
        >
          <h2 className="text-xl font-semibold">Total Products</h2>
          <p className="text-4xl font-bold mt-2">
            <CountUp end={totalProducts} duration={3} />
          </p>
        </motion.div>

        <motion.div
          className="stat-card bg-green-500 p-6 rounded-lg shadow-lg text-white transition-transform transform hover:scale-105"
          whileHover={{ scale: 1.05 }}
        >
          <h2 className="text-xl font-semibold">Total Users</h2>
          <p className="text-4xl font-bold mt-2">
            <CountUp end={totalUsers} duration={3} />
          </p>
        </motion.div>

        <motion.div
          className="stat-card bg-yellow-500 p-6 rounded-lg shadow-lg text-white transition-transform transform hover:scale-105"
          whileHover={{ scale: 1.05 }}
        >
          <h2 className="text-xl font-semibold">Total Orders</h2>
          <p className="text-4xl font-bold mt-2">
            <CountUp end={totalOrders} duration={3} />
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboard;
