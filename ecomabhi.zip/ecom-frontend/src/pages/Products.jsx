import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import apiClient from "../apiClient";
import { allProducts, handlePagination } from "../app/reducers/CartSlice";
import PaginationComponent from "../components/PaginationComponent";
import ProductCard from "../components/ProductCard";

const Products = () => {
  const dispatch = useDispatch();
  const { userId, token } = useSelector((state) => state.loggedInData);

  const { products } = useSelector((state) => state.CartSlice);

  const { currentPage, totalPage, productsPerPage } = useSelector(
    (state) => state.CartSlice.pagination
  );

  const fetchAllProducts = async (page) => {
    try {
      const res = await apiClient.get(
        `/all-products/?page=${page}&limit=${productsPerPage}`,
        {
          headers: {
            Authorization: token,
          },
        }
      );
      console.log(res.data, "from products");
      dispatch(allProducts(res.data));
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchAllProducts(currentPage);
  }, [currentPage, userId]);

  const handleChangePage = (event, newPage) => {
    dispatch(handlePagination(newPage));
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold text-center mb-8">Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product._id} product={product} />
        ))}
      </div>
      <div className=" relative top-4 justify-center">
        <PaginationComponent
          currentPage={currentPage}
          totalPage={totalPage}
          handleChangePage={handleChangePage}
        />
      </div>
    </div>
  );
};

export default Products;
