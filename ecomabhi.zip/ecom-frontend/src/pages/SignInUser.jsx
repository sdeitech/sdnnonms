import React, { useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import apiClient from "../apiClient";
import { loginSuccess } from "../app/reducers/LoginUserSlice";

const SignInUser = ({ userType }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const initialValues = {
    email: "",
    password: "",
    role: userType,
  };

  const [formData, setFormData] = useState(initialValues);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res;
      if (userType === "user") {
        res = await apiClient.post(`/login`, formData);
        // console.log(res.data);
        toast.success("Login Successfully !");
        setTimeout(() => {
          navigate("/products");
        }, 1000);
        dispatch(loginSuccess(res.data));
      } else {
        res = await apiClient.post(`/login`, formData);
        // console.log(res.data);
        toast.success("Login Successfully !");
        setTimeout(() => {
          navigate("/admin-dashboard");
        }, 1000);
        dispatch(loginSuccess(res.data));
      }
    } catch (error) {
      if (userType === "user") {
        toast.error("Invalid credentials for user");
      } else {
        toast.error("Invalid credentials for admin");
      }
      // console.log(error.message);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-semibold text-center mb-6 text-gray-800">
          {userType === "admin" ? "Admin Login" : "User Login"}
        </h2>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-gray-600">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Email"
              className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-600">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Password"
              className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 mt-4 text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            {userType === "admin" ? "Admin Login" : "User Login"}
          </button>
        </form>
        <div className="mt-4 text-center">
          <p className="text-gray-600">
            Don't have an account?{" "}
              {userType === "admin" ? (
                <Link to={"/admin-signup"}> <span className=" text-light-blue-600 " >Sign up here</span> </Link>
              ) : (
                <Link to={"/"}> <span className=" text-light-blue-600 " >Sign up here</span> </Link>
              )}
            
          </p>
        </div>
      </div>
      <Toaster />
    </div>
  );
};

export default SignInUser;
