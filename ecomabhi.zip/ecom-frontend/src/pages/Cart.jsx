import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import apiClient from "../apiClient";
import {
  addToCart,
  fetchCart,
  removeFromCart,
  removeProduct,
} from "../app/reducers/CartSlice";
import { Link } from "react-router-dom";
const imageUrl = import.meta.env.VITE_IMAGE_URL;

const Cart = () => {
  const dispatch = useDispatch();
  const { cart, totalAmmount } = useSelector((state) => state.CartSlice);
  const { userId, token } = useSelector((state) => state.loggedInData);

  console.log(totalAmmount, "amt");
  console.log(userId, "userId");

  useEffect(() => {
    const fetchCartData = async () => {
      try {
        const response = await apiClient.get(`/cart/${userId}`, {
          headers: {
            Authorization: token,
          },
        });
        dispatch(fetchCart(response.data));
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching cart data:", error);
      }
    };

    fetchCartData();
  }, [dispatch, userId]);

  const deleteItem = async (productId) => {
    console.log(productId, "from data");
    console.log(token);

    try {
      const res = await apiClient.delete(`/delete-item`, {
        params: {
          id: userId,
          productId: productId,
        },
        headers: {
          Authorization: token,
        },
      });

      console.log(res.data);
      dispatch(removeProduct(productId));
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };

  const increaseQuantity = async (product) => {
    console.log(product, "form data");
    let item = {
      productId: product.productId,
      name: product.name,
      price: product.price,
      image: product.image,
    };

    try {
      const res = await apiClient.post(
        `/add-to-cart`,
        {
          id: userId,
          productId: product.productId,
          quantity: 1,
          price: product.price,
        },
        {
          headers: {
            Authorization: token,
          },
        }
      );

      console.log(res.data);

      dispatch(addToCart(item));
    } catch (error) {
      console.error("Error adding item to cart:", error);
    }
  };

  const decreaseQuantity = async (product) => {
    try {
      const res = await apiClient.patch(
        `/dec-item`,
        {
          id: userId,
          productId: product.productId,
        },
        {
          headers: {
            Authorization: token,
          },
        }
      );
      dispatch(removeFromCart(product));
      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      alert("No items in cart. Please add items to proceed.");
      return;
    }
    try {
      const items = cart.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
      }));

      const response = await apiClient.post(
        `/order`,
        {
          userId: userId,
          items,
          totalAmount: totalAmmount,
        },
        {
          headers: {
            Authorization: token,
          },
        }
      );

      console.log("Order created:", response.data);
      alert("Order successfully created!");
    } catch (error) {
      console.error("Error during checkout:", error);
      alert("Failed to create order. Please try again.");
    }
  };

  const deleteAllQ = async () => {
    if (cart.length === 0) {
      alert("No items in cart. Please add items to proceed.");
      return;
    }
    try {
      const res = await apiClient.delete(`/delete-cart?userId=${userId}`, {
        headers: {
          Authorization: token,
        },
      });
      dispatch(fetchCart([]));

      console.log(res.data);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="max-w-md mx-auto my-8 p-4 border border-gray-200 shadow-lg rounded-lg">
      <h2 className="text-2xl font-semibold text-center mb-4">Your Cart</h2>
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Image</th>
            <th className="py-2 px-4 border-b">Price</th>
            <th className="py-2 px-4 border-b">Quantity</th>
            <th className="py-2 px-4 border-b">Action</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item, index) => (
            <tr key={index} className="text-center">
              <td className="py-2 px-4 border-b">
                <img
                  src={`${imageUrl}/${item.image}`}
                  className="w-16 h-16 object-cover mx-auto"
                  alt="product"
                />
              </td>
              <td className="py-2 px-4 border-b">₹ {item.price}</td>
              <td className="py-2 px-4 border-b flex items-center justify-center">
                <button
                  onClick={() => decreaseQuantity(item)}
                  className="px-2 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                >
                  -
                </button>
                <span className="mx-2">{item.quantity}</span>
                <button
                  onClick={() => increaseQuantity(item)}
                  className="px-2 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                >
                  +
                </button>
              </td>
              <td className="py-2 px-4 border-b">
                <button
                  onClick={() => deleteItem(item.productId)}
                  className="text-red-500 hover:text-red-700"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="2" className="py-2 px-4 text-right font-semibold">
              Total Price:
            </td>
            <td colSpan="2" className="py-2 px-4 font-semibold">
            ₹{totalAmmount.toFixed(2)}
            </td>
          </tr>
        </tfoot>
      </table>
      <button
        onClick={deleteAllQ}
        className="mt-4 w-full py-2 bg-red-500 text-white font-semibold rounded hover:bg-red-600"
      >
        Delete All Items
      </button>
      <button
        onClick={handleCheckout}
        className="mt-4 w-full py-2 bg-green-500 text-white font-semibold rounded hover:bg-green-600"
      >
        Checkout
      </button>
      <Link to={"/my-order"}>
        <button
          className="mt-4 w-full py-2 bg-green-500 text-white font-semibold rounded hover:bg-green-600"
        >
          My order
        </button>
      </Link>
    </div>
  );
};

export default Cart;
