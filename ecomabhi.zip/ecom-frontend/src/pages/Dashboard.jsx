import ShoppingCartIcon from "@heroicons/react/24/solid/ShoppingCartIcon";
import TruckIcon from "@heroicons/react/24/solid/TruckIcon";
import { Carousel } from "@material-tailwind/react";


const Dashboard = () => {
  return (
    <div className="flex h-1/2 p-4">
      <div className="flex-1">
        <Carousel
          className="rounded-xl h-full"
          navigation={({ setActiveIndex, activeIndex, length }) => (
            <div className="absolute bottom-4 left-2/4 z-50 flex -translate-x-2/4 gap-2">
              {new Array(length).fill("").map((_, i) => (
                <span
                  key={i}
                  className={`block h-1 cursor-pointer rounded-2xl transition-all ${
                    activeIndex === i ? "w-8 bg-white" : "w-4 bg-white/50"
                  }`}
                  onClick={() => setActiveIndex(i)}
                />
              ))}
            </div>
          )}
        >
          <img
            src="https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2560&q=80"
            alt="image 1"
            className="h-full w-full object-cover"
          />
          <img
            src="https://images.unsplash.com/photo-1493246507139-91e8fad9978e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8MHx8&auto=format&fit=crop&w=2940&q=80"
            alt="image 2"
            className="h-full w-full object-cover"
          />
          <img
            src="https://images.unsplash.com/photo-1518623489648-a173ef7824f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHx8fGVufDB8MHx8&auto=format&fit=crop&w=2762&q=80"
            alt="image 3"
            className="h-full w-full object-cover"
          />
        </Carousel>
      </div>

      {/* Right Column with div1 and div2 */}
      <div className="flex flex-col flex-1 items-center justify-center space-y-6 p-4">
        {/* Div1 - Shopping Information */}
        <div className="bg-white w-3/4 h-28 shadow-lg rounded-md flex items-center justify-center gap-4 p-4 transform hover:scale-105 transition duration-300 ease-in-out">
          <ShoppingCartIcon className="h-10 w-10 text-blue-500" />
          <div>
            <h3 className="text-lg font-semibold text-gray-700">Shop Our Collection</h3>
            <p className="text-sm text-gray-500">Browse the latest items in our store</p>
          </div>
        </div>

        {/* Div2 - Delivery Information */}
        <div className="bg-white w-3/4 h-28 shadow-lg rounded-md flex items-center justify-center gap-4 p-4 transform hover:scale-105 transition duration-300 ease-in-out">
          <TruckIcon className="h-10 w-10 text-green-500" />
          <div>
            <h3 className="text-lg font-semibold text-gray-700">Fast & Reliable Delivery</h3>
            <p className="text-sm text-gray-500">Get your products delivered on time</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
