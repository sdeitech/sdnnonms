import twilio from "twilio"
// const twilio = require("twilio"); 
const accountSid = "AC073f034c7ac361fb6078a4a71f625a33";
const authToken = "4c9f424e1ffb42abe80cdf4d606535b2";
const client = twilio(accountSid, authToken);


const sendSMS = async (to,body) => {
    try {
        const message = await client.messages.create({
            body: body,
            from: "+13025240687",
            to: to,
        });

        console.log(message.body);

    } catch (error) {
        console.log(error.message)

    }
}

export default sendSMS
