const smsTemplate = (firstName, lastName, email, password) => {
    return (
        `Hello ${firstName} ${lastName},\n\n` +
        `Your account has been successfully created. Below are your login details:\n` +
        `- Email: ${email}\n` +
        `- Password: ${password}\n\n` +
        `Please keep your login credentials safe. You can log in to your account anytime using these details.\n\n` +
        `Thank you!`
    );
};

export default smsTemplate;
