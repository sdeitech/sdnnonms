import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { Sidebar } from '../component/Sidebar.js'
import "../style/listing.css"

export const Listing = () => {

    const [data, setData] = useState([]);

    const list = async () => {
        try {
            const response = await axios.get('http://localhost:5000/product-get');

            setData(response.data);
        } catch (error) {
            console.log("error occur during fetching ");
        }
    }

    useEffect(() => {
        list();
    }, [])

    return (
        <div>
            <Sidebar />
            <div className='content'>
                <div className='header-section'>
                    <h3>Product Management</h3>
                    <Link  to={`/add_product`}>Add product</Link>
                </div>
                <hr></hr>
                <table className='table table-success table-striped'>
                    <thead>
                        <tr>
                            <th>ProductName</th>
                            <th>Price</th>
                            <th>description</th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((value) => (
                            <tr key={value._id}>
                                <td>{value.productName}</td>
                                <td>{value.price}</td>
                                <td>{value.description}</td>
                                <td>
                                    <button
                                        variant="success"
                                        className="btn btn-primary btn-block"
                                    > Edit
                                    </button> &nbsp;

                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}
