import React, { useState } from 'react'
import axios from 'axios';
import { Sidebar } from '../component/Sidebar';
import '../style/addproduct.css'

export default function AddProduct() {

    const [data, setData] = useState([]);

    const [formData, setFormData] = useState({
        productName: '',
        price: '',
        description: ''
    })

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/product", formData);
            setData(response.data);
        }
        catch (error) {
            console.log("errors")
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...data, [name]: value
        }))
    }

    return (

        <div>
            <Sidebar />
            <div className='content'>
                <form className="form-container" onSubmit={handleSubmit}>
                    <div className='form-group'>
                        <label>Product Name:</label>
                        <input
                            type='text'
                            value={formData.productName}
                            name='productName'
                            placeholder='Enter product name'
                            onChange={handleChange}
                        />
                    </div>
                    <div className='form-group'>
                        <label>price:</label>
                        <input
                            type="number"
                            value={formData.price}
                            name='price'
                            placeholder='price of the product'
                            onChange={handleChange}
                        />
                    </div>
                    <div className='form-group'>
                        <label>Description:</label>
                        <input
                            type="text"
                            value={formData.description}
                            name='description'
                            placeholder='Description of the product'
                            onChange={handleChange}
                        />
                    </div>
                    <div>
                        <button type="submit" onSubmit={handleSubmit}>Add</button>
                    </div>
                </form>
            </div>
        </div>

    )
}
