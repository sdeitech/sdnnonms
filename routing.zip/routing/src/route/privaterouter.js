import React from "react";
import { Listing } from "../product/Listing";
import { Privatelayout } from '../layout/Privatelayout'
import { Dashboard } from "../component/Dashboard";
import AddProduct from "../product/AddProduct";

const privaterouter = [
    {
        path: '/dashboard',
        exact: true,
        element: <Privatelayout> <Dashboard /></Privatelayout>
    },
    {
        path: '/product_list',
        exact: true,
        element: <Privatelayout> <Listing /></Privatelayout>
    },
    {
        path: '/add_product',
        exact: true,
        element: <Privatelayout><AddProduct /></Privatelayout>
    }
]
export default privaterouter;