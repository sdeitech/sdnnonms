import react from 'react'
import { createBrowserRouter } from "react-router-dom";
import Publicroute from "./publicrouter";
import privaterouter from './privaterouter';
const routers = createBrowserRouter([
    ...Publicroute,
    ...privaterouter
])
export default routers;