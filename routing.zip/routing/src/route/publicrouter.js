import { react } from 'react'
import Publiclayout from '../layout/Publiclayout';
import { Listing } from '../product/Listing';
import Userlogin from '../user/Userlogin';
import SignUp from '../user/Signup';
const Publicroute = [
    {
        path: '/',
        exact: true,
        element: <Publiclayout><Userlogin /> </Publiclayout>
    },
    {
        path: '/signup',
        exact: true,
        element: <Publiclayout><SignUp /> </Publiclayout>
    }
]
export default Publicroute;
