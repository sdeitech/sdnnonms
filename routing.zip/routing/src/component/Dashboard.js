import userEvent from '@testing-library/user-event'
import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Sidebar } from './Sidebar';

export const Dashboard = () => {
    const navigate = useNavigate();
    navigate('/')

    return (
        <div>
            <Sidebar />
            <div className="container-fluid bg-blue ">
                <div className="row py-3 d-flex align-items-center mb-3 shadow">
                    <div className="col-6 d-flex ">
                        <div className="input-group rounded-pill">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}
