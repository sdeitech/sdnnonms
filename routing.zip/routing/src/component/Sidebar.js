import React from 'react';
import '../style/sidebar.css'

export const Sidebar = (data) => {
  return (
    <div className='split left'>
      <div class="sidebar">
        <h4>logo</h4>
        <div>
          <a href='/product_list'>Product</a>
        </div>
      </div>
    </div>
  )
}
