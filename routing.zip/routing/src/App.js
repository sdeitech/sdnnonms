import { Listing } from "./product/Listing";
import Userlogin from "./user/Userlogin";
import { RouterProvider } from "react-router-dom";
import routers from "./route/route";

function App() {
  return (
    <RouterProvider router={routers}/>   
  );
}

export default App;
