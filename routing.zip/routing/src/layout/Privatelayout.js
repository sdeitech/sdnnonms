import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export const Privatelayout = ({ children }) => {

  let token = localStorage.getItem("user_data");
  let navigate = useNavigate();
  useEffect(() => {
    if (!token) {
      navigate('/');
    }
  }, [token, navigate])

  return (
    <div className='layout'>
      {children}

    </div>
  )
}
