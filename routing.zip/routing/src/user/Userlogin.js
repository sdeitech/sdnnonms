import React, { useState } from "react";
import '../style/login.css';
import axios from 'axios';
import { useNavigate } from "react-router-dom"
import SignUp from "./Signup";

const Userlogin = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState(null);
  const [show, setShow] = useState(false);

  const navigate = useNavigate();

  const handlesubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/user/login', formData);
      const { data } = response;

      console.log('Login successful:');
      localStorage.setItem("user_data", response.data.token);
      // console.log(response.data.token,"shdhgzhKDfs")
      // navigate('/productlist');
      navigate('/dashboard')
    }
    catch (err) {
      setError('Login failed. Please check your credentials.');
      // navigate('/signup');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  }
  const handleSignup = () => {
    setShow(true);
    navigate('/signup')
  }

  return (
    <div>
      <div className="container login-container">

        <form className="login-form" onSubmit={handlesubmit}>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <h2 className="text-center">Login</h2>
          <div className="form-group">
            <label for="email">Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label for="password">Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div><br></br>
          <button type="submit" className="btn btn-primary btn-block" variant="success">
            Login
          </button>&nbsp;
          <button
            variant="danger"
            className="btn btn-primary btn-block"
            onClick={handleSignup}
          >
            {show}SignUp
          </button>
        </form>
      </div>
    </div>
  );
};

export default Userlogin;
