import React, { useState } from "react";

import axios from 'axios';
import { useNavigate } from "react-router-dom"

const SignUp = () => {
  const [formData, setFormData] = useState({
    name:'',
    email: '',
    password: ''
  });
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handlesubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/user/register', formData);   

      navigate('/');
    }
    catch (err) {
      setError('change password');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  }

  return (
    <div>
      <div className="container login-container">

        <form className="login-form" onSubmit={handlesubmit}>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <h2 className="text-center">User Registration</h2>
          <div className="form-group">
            <label for="name">Name:</label>
            <input
              type="name"
              name="name"
              className="form-control"
              value={formData.name}
              onChange={handleChange}
              error={error}
              required
            />
          </div>
          <div className="form-group">
            <label for="email">Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label for="password">Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div><br></br>
          <button type="submit" className="btn btn-primary btn-block" variant="success">
            Register
          </button>&nbsp;
          
        </form>
      </div>
    </div>
  );
};

export default SignUp;
