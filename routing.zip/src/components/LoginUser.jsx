import React from 'react'

const LoginUser = () => {
    return (
        <div>LoginUser</div>
    )
}

export default LoginUser