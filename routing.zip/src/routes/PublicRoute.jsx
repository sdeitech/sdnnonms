import React from 'react'
import PublicLayout from '../layouts/PublicLayout'
import Login from '../components/Login'

const PublicRoute = [
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Login /></PublicLayout>
    }
]

export default PublicRoute