import React from 'react'
import PrivateLayout from '../layouts/PrivateLayout'
import Dashboard from '../components/Dashboard'
import AddUser from '../components/AddUser'

const PrivateRoute = [
    {
        path: "/user",
        exact: true,
        element: <PrivateLayout><Dashboard /></PrivateLayout>
    },
    {
        path: "/add/user",
        exact: true,
        element: <PrivateLayout><AddUser /></PrivateLayout>
    }
]

export default PrivateRoute