from django.urls import path
from . import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('input/',views.input_marks ,name="input_marks"),
    path('marksheet/',views.display_marksheet ,name="marksheet"),
]


