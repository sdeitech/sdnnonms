from django.db import models

# Create your models here.
class Subject(models.Model):
    name=models.CharField(max_length=100)
    theory_marks=models.IntegerField(default=0)
    internal_marks=models.IntegerField(default=0)
    
    def total_marks(self):
        return self.theory_marks+self.internal_marks
    
    def is_pass(self):
        return self.total_marks()>=35
    def __str__(self):
        return self.name
    