from django.shortcuts import render,redirect
# from .forms import SubjectForm
from .models import Subject

# Create your views here.

def input_marks(request):
    if request.method=='POST':
        Subject.objects.all().delete()
        data = request.POST
        name=data.getlist('subject')
        theory_marks=data.getlist('theory')
        internal_marks=data.getlist('internal')
        
        print("name",name)
        print("theory_marks",theory_marks)
        print("internal_marks",internal_marks)
        for sub,th,inter in zip(name,theory_marks,internal_marks):
        
            newuser =Subject(
            name=sub,
            theory_marks=th,
            internal_marks=inter
        )
            print(newuser,"hhhhhhhhhhhhhh")
            newuser.save()
     

        return redirect('marksheet')
    else:
         return render(request,"input_marks.html")    

def display_marksheet(request):
    subjects=Subject.objects.all()
    total_marks=sum(subject.total_marks() for subject in subjects)
    max_marks=len(subjects)*100
    overall_pass=all(subject.is_pass() for subject in subjects)
    percentage=(total_marks/300)*100
    return render(request,"displaymarksheet.html",{
        'subjects':subjects,
        'total_marks':total_marks,
        'max_marks':max_marks,
        'overall_pass':overall_pass,
        "percentage":percentage
    })
   