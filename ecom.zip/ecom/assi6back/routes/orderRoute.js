import express from 'express';
import { createOrder, getOrders } from '../controllers/orderController';

const router = express.Router();

// Route to create an order
router.post('/create', createOrder);

// Route to get orders for a user
router.get('/getorders/:userId', getOrders);

export default router;
