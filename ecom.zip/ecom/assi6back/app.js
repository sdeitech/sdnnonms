import express from "express";
import cors from "cors";
const app = express();

import userRouter from "./routes/userRoute";
import productRoute from "./routes/productRoute"
import cartRoute from "./routes/cartRoute"
import orderRoute from "./routes/orderRoute"


app.use(express.json());
// app.use(cors({ origin: "*" }));
app.use(cors());
app.use("/getimg", express.static("uploads"));

app.use("/api/user", userRouter);
app.use("/api/productadmin",productRoute)
app.use("/api/cart",cartRoute)
app.use("/api/order",orderRoute)


export default app;
