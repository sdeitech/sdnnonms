export const config = {
    local: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment6",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT:3219,
    },
    stagg: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment6",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3219,
    },
    prod: {
      DB: {
        HOST: "",
        DB_HOST: 27017,
        DB_NAME: "Assignment6",
        USERNAME: "",
        PASSWORD: "",
      },
      API_PORT: 3219,
    },
  };
  