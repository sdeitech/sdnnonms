// config/constants.js
const constants = {
    USER_NOT_FOUND: 'User not found',
    INVALID_CREDENTIALS: 'Invalid credentials',
    USER_ALREADY_EXISTS: 'User already exists',
    INTERNAL_SERVER_ERROR: 'Internal server error',
    ALL_FILEDS_REQUIRED:'All fields are required',
    USER_REGISTERED:'User Registered Successfully',
    LOGGED_SUCCESSFULLY:'User logged in successfully',
  };
  
  export default constants;
  