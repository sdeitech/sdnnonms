import Product from "../models/productModel";



export const createProduct = async (req, res) => {
    // Check user authorization
    if (req.user.role !== "admin") {
        return res.status(403).json({ msg: "You are not authorized" });
    }
    console.log(req.file,"file");
    

    try {
        const { name, price, description } = req.body;
        
        // If you are using multer, the image file will be in req.file
        const image = req.file ? req.file.filename : null; // Get image path from multer

        const product = new Product({
            name,
            price,
            description,
            image,
        });

        const createdProduct = await product.save();
        
        // Respond with the created product
        res.status(201).json(createdProduct);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Get all products
// @route   GET /api/products
// @access  Public
// export const getProducts = async (req, res) => {
//     try {
//         const products = await Product.find({});
//         res.json(products);
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// };


export const getProducts = async (req, res) => {
    try {
        // Get current page from query parameter, default to 1
        const page = parseInt(req.query.page) || 1;
        const search = req.query.search
        const limit = 3;  // Limit of 3 products per page
        const skip = (page - 1) * limit;  // Skip products for previous pages
        console.log(req.query,"dsgf");
        
        const query = search ? { name: { $regex: search, $options: 'i' } } :{}
        // Fetch products with limit and skip
        const products = await Product.find(query).skip(skip).limit(limit);
        const totalProducts = await Product.countDocuments();  // Get total product count

        // Calculate total pages
        const totalPages = Math.ceil(totalProducts / limit);

        res.json({
            products,
            totalPages,
            currentPage: page,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Get a product by ID
// @route   GET /api/products/:id
// @access  Public
export const getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);

        if (product) {
            res.json(product);
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private (Admin)
// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private (Admin)
export const updateProduct = async (req, res) => {
    try {
        const { name, price, description } = req.body;
        const productId = req.params.id;

        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }

        // Update fields only if they are provided in the request body
        product.name = name !== undefined ? name : product.name;
        product.price = price !== undefined ? price : product.price;
        product.description = description !== undefined ? description : product.description;

        // Handle image update if a new image file is provided
        if (req.file) {
            product.image = req.file.filename; // Update image path from multer
        }

        const updatedProduct = await product.save();
        res.json(updatedProduct);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private (Admin)
export const deleteProduct = async (req, res) => {
    const { id } = req.params; // Ensure you're getting the ID from the route params
    if (!id) {
        return res.status(400).json({ message: "Product ID is required" });
    }

    try {
        const product = await Product.findByIdAndDelete(id);
        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json({ message: "Product deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};



















