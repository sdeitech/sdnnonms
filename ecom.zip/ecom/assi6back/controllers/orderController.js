import Order from '../models/orderModel';
import Product from '../models/productModel'; // Assuming you have a Product model
import User from '../models/userModel'; // Assuming you have a User model



export const createOrder = async (req, res) => {
  try {
    const { user, items, totalAmount } = req.body; // Destructure user, items, and totalAmount from the body

    // Validate that items are provided
    if (!items || items.length === 0) {
      return res.status(400).json({ message: 'No items in the order.' });
    }

    // Validate totalAmount
    if (!totalAmount || totalAmount <= 0) {
      return res.status(400).json({ message: 'Invalid total amount.' });
    }

    // Check if the user exists
    const userExists = await User.findById(user);
    if (!userExists) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Prepare the order items
    const orderItems = [];

    // Loop through the items to fetch product details and validate them
    for (const item of items) {
      const product = await Product.findById(item.product);
      if (!product) {
        return res.status(404).json({ message: `Product with ID ${item.product} not found` });
      }

      // Prepare the order item object
      orderItems.push({
        product: item.product,
        quantity: item.quantity,
        price: product.price, // Use the product's price here
      });
    }

    // Create the new order with the received totalAmount
    const newOrder = new Order({
      user, // Use the userId directly from the request body
      items: orderItems,
      totalAmount, // Use the totalAmount passed from the frontend
    });

    // Save the order to the database
    const savedOrder = await newOrder.save();

    // Return the saved order to the client
    return res.status(201).json(savedOrder);
  } catch (error) {
    console.error('Error creating order:', error);
    return res.status(500).json({ message: 'Server error' });
  }
};


// Controller to get orders for a user
export const getOrders = async (req, res) => {
  try {
    const { userId } = req.params; // Get userId from route parameters

    // Find the user's orders and populate the product and user details
    const orders = await Order.find({ user: userId })
      .populate({
        path: 'items.product',
        select: 'name price image', // Specify what fields to populate from the Product model
      })
      .populate({
        path: 'user',
        select: 'name email', // Specify what fields to populate from the User model
      });

    if (!orders || orders.length === 0) {
      return res.status(404).json({ message: 'No orders found for this user' });
    }

    return res.status(200).json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    return res.status(500).json({ message: error.message });
  }
};
