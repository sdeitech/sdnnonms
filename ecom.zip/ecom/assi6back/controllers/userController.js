// import productModel from "../models/productModel";
import User from "../models/userModel"
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import constants from "../config/constant";

export const registerUser = async (req, res) => {
  try {
    const {firstname,lastname, mobileno, email, password,role } = req.body;
    //   const profile = req.file?.filename;
    if (role && role!=='admin' && role !=='user'){
      return res.status(400).send('Invalid role');
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).send('User already exists');
    }
    if(
      !firstname ||
      !lastname ||
      !mobileno ||
      !email ||
      !password||
      !role
    ) {
      return res.status(400).json({ message: constants.ALL_FILEDS_REQUIRED });
      // .json({ message: MESSAGE.ALL_FILEDS_REQ });
    }

    const pass = await bcrypt.hash(password, 10);
    const user = new User({
      firstname,
      lastname,
      mobileno,
      email,
      password: pass,
      role:role ||'user'
    });

    // const emailsend = await sendMailToUser(
    //   email,
    //   `ID : ${email} password : ${password}`
    // );
    //   console.log("email send ", emailsend);
    await user.save();
    res.status(201).json({ msg: constants.USER_REGISTERED });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};



export const userLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: constants.ALL_FILEDS_REQUIRED });
    }
    const existUser = await User.findOne({ email: email });
    // console.log(existUser);

    if (!existUser) {
      return res.status(400).json({ msg: constants.USER_NOT_FOUND });
    }

    //checking password entered by user and database user passsword
    const isMatch = await bcrypt.compare(password, existUser.password);
    console.log(isMatch, "Thankyou");

    //generating token for user
    if (isMatch) {
      console.log(existUser);
      const token = jwt.sign({ id:existUser._id,role:existUser.role }, "KEY", { expiresIn: "10hr" });
      console.log(token);
      
      return res.status(200).json({
        msg: constants.LOGGED_SUCCESSFULLY,
        token: token,
        email: email,
        userId: existUser._id,
        role:existUser.role,
      });
    } else {
      return res.status(400).json({ msg: constants.INVALID_CREDENTIALS });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: error.message });
  }
};  