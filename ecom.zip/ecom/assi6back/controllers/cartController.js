// import Cart from '../models/cartModel';
// import Product from '../models/productModel'; 

// // Get Cart
// export const getCart = async (req, res) => {
//     const { user } = req.query;

//     try {
//         const cart = await Cart.findOne({ user }).populate('items.product');
//         res.json(cart || { items: [] });
//     } catch (error) {
//         res.status(500).json({ message: 'Error fetching cart', error });
//     }
// };

// // Add to Cart
// export const addToCart = async (req, res) => {
//     const { user, product, quantity } = req.body;

//     try {
//         let cart = await Cart.findOne({ user });

//         if (!cart) {
//             cart = new Cart({ user, items: [] });
//         }

//         // Check if the product already exists in the cart
//         const existingItem = cart.items.find(item => item.product.equals(product));

//         // Fetch product price from Product model
//         const productData = await Product.findById(product);
//         if (!productData) {
//             return res.status(404).json({ message: 'Product not found' });
//         }

//         const itemPrice = productData.price;

//         if (existingItem) {
//             existingItem.quantity += quantity;
//         } else {
//             cart.items.push({ product, quantity, price: itemPrice });
//         }

//         await cart.save();
//         res.json(cart);
//     } catch (error) {
//         res.status(500).json({ message: 'Error adding to cart', error });
//     }
// };

// // Update Cart Item
// export const updateCartItem = async (req, res) => {
//     const { user, productId, quantity } = req.body;

//     try {
//         const cart = await Cart.findOne({ user });

//         if (!cart) {
//             return res.status(404).json({ message: 'Cart not found' });
//         }

//         const item = cart.items.find(item => item.product.equals(productId));
//         if (item) {
//             item.quantity = quantity;
//             await cart.save();
//             res.json(cart);
//         } else {
//             res.status(404).json({ message: 'Item not found in cart' });
//         }
//     } catch (error) {
//         res.status(500).json({ message: 'Error updating cart item', error });
//     }
// };

// // Remove Cart Item
// export const removeCartItem = async (req, res) => {
//     const { user, productId } = req.body;

//     try {
//         const cart = await Cart.findOne({ user });

//         if (!cart) {
//             return res.status(404).json({ message: 'Cart not found' });
//         }

//         // Remove item by product ID
//         cart.items = cart.items.filter(item => !item.product.equals(productId));

//         await cart.save();
//         res.json(cart);
//     } catch (error) {
//         res.status(500).json({ message: 'Error removing cart item', error });
//     }
// };


import Cart from '../models/cartModel';
import Product from '../models/productModel';

// Get Cart
export const getCart = async (req, res) => {
    const { user } = req.query;

    try {
        const cart = await Cart.findOne({ user }).populate('items.product');
        res.json(cart || { items: [] });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching cart', error });
    }
};

// Add to Cart
export const addToCart = async (req, res) => {
    const { user, product, quantity } = req.body;

    try {
        let cart = await Cart.findOne({ user });

        if (!cart) {
            cart = new Cart({ user, items: [] });
        }

        // Check if the product already exists in the cart
        const existingItem = cart.items.find(item => item.product.equals(product));

        // Fetch product price from Product model
        const productData = await Product.findById(product);
        if (!productData) {
            return res.status(404).json({ message: 'Product not found' });
        }

        const itemPrice = productData.price;

        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            cart.items.push({ product, quantity, price: itemPrice });
        }

        await cart.save();
        res.json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Error adding to cart', error });
    }
};

// Update Cart Item
export const updateCartItem = async (req, res) => {
    const { user, productId, quantity } = req.body;

    try {
        const cart = await Cart.findOne({ user });

        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }

        const item = cart.items.find(item => item.product.equals(productId));
        if (item) {
            item.quantity = quantity;
            await cart.save();
            res.json(cart);
        } else {
            res.status(404).json({ message: 'Item not found in cart' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error updating cart item', error });
    }
};

// Remove Cart Item
export const removeCartItem = async (req, res) => {
    const { user } = req.body;
    const { productId } = req.params; // Use req.params to get the productId

    try {
        const cart = await Cart.findOne({ user });

        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }

        // Remove item by product ID
        cart.items = cart.items.filter(item => !item.product.equals(productId));

        await cart.save();
        res.json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Error removing cart item', error });
    }
};
