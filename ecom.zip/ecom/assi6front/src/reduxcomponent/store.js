// import { configureStore } from "@reduxjs/toolkit";
// // import userReducer from "./slice"
// import usersre from "./authslice";

// const Store = configureStore({
//   reducer: {
//     users: usersre,
//   },
// });
// export default Store;

// src/redux/store.js
// import { configureStore, combineReducers } from "@reduxjs/toolkit";
// import { persistReducer, persistStore } from "redux-persist";
// import storage from "redux-persist/lib/storage";
// import users from "./slice"; // Import your userSlice
// import products from "./productSlice"; // Import your productSlice

// const rootReducer = combineReducers({
//   users: users,
//   products: products, 
//   // cart:cart,// Add the products slice here
// });

// const persistConfig = {
//   key: "root",
//   storage,
// };

// const persistedReducer = persistReducer(persistConfig, rootReducer);

// const store = configureStore({
//   reducer: persistedReducer,
// });

// const persistore = persistStore(store);

// export { store, persistore };

import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";
import users from "./slice"; // Ensure this points to your updated userSlice
import products from "./productSlice"; // Import your productSlice

const rootReducer = combineReducers({
  users: users,
  products: products, // Include your productSlice
});

const persistConfig = {
  key: "root",
  storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  reducer: persistedReducer,
});

const persistore = persistStore(store);

export { store, persistore };
