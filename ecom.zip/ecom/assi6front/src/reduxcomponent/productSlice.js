// // productSlice.js
// import { createSlice } from "@reduxjs/toolkit";

// const productSlice = createSlice({
//   name: "products",
//   initialState: {
//     productList: [],
//     loading: false,
//     error: null,
//   },
//   reducers: {
//     fetchProductsStart: (state) => {
//       state.loading = true;
//       state.error = null;
//     },
//     fetchProductsSuccess: (state, action) => {
//       state.loading = false;
//       state.productList = action.payload;
//     },
//     fetchProductsFailure: (state, action) => {
//       state.loading = false;
//       state.error = action.payload;
//     },
//   },
// });

// export default productSlice.reducer;
// export const { fetchProductsStart, fetchProductsSuccess, fetchProductsFailure } = productSlice.actions;


import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({
  name: "products",
  initialState: {
    productList: [],
    loading: false,
    error: null,
    selectedProduct: null,
  },
  reducers: {
    fetchProductsStart: (state) => {
      state.loading = true;  // Indicate loading has started
      state.error = null;    // Clear previous errors
    },
    fetchProductsSuccess: (state, action) => {
      state.loading = false;                // Loading has finished
      state.productList = action.payload;  // Update product list
    },
    fetchProductsFailure: (state, action) => {
      state.loading = false;                // Loading has finished
      state.error = action.payload;         // Set the error message
    },
    addProduct: (state, action) => {
      state.productList.push(action.payload);
  },
  deleteProduct(state, action) {
    state.productList = state.productList.filter(product => product._id !== action.payload);
},
setSelectedProduct(state, action) {
  state.selectedProduct = action.payload; // Set the selected product for editing
},
updateProduct(state, action) {
  const index = state.productList.findIndex(product => product._id === action.payload._id);
  if (index !== -1) {
      state.productList[index] = action.payload; // Update the product in the list
  }
},
    // Optionally, add a reset action
    resetProducts: (state) => {
      state.productList = [];
      state.loading = false;
      state.error = null;
    },
  },
});

export default productSlice.reducer;
export const { fetchProductsStart, fetchProductsSuccess, fetchProductsFailure, resetProducts,addProduct,deleteProduct,setSelectedProduct,updateProduct } = productSlice.actions;
