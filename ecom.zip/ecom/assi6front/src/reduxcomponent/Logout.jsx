import { clearState } from "./productSlice"
import { clearUsers } from "./slice"



const Logout = () =>(dispatch) => {
    dispatch(clearState())
    dispatch(clearUsers())
}
export default Logout
