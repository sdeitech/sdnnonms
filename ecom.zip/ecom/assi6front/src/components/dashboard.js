import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { fetchProductsSuccess, fetchProductsFailure, fetchProductsStart, deleteProduct, setSelectedProduct } from '../reduxcomponent/productSlice';
import { addToCart } from '../reduxcomponent/slice';
import { useNavigate } from 'react-router-dom';
import './dashboard.css';
import { FaCartPlus, FaTrash, FaEdit, FaEye } from 'react-icons/fa';
import Navbar from './Navbar'; 
import PaginationOutlined from '../cartPages/PaginationC';

const Dashboard = () => {
    const dispatch = useDispatch();
    const { productList, loading, error,search } = useSelector((state) => state.products);
    const { authUser } = useSelector((state) => state.users);
    const { token, userId, role } = authUser;
    const navigate = useNavigate();

    const [currentPage,setCurrentPage] = useState(1)
    const [totalPage,setTotalPage] = useState(1)
 
    useEffect(() => {
        const fetchProducts = async () => {
            dispatch(fetchProductsStart());
            try {
                const response = await axios.get(`http://localhost:3219/api/productadmin/getproduct?page=${currentPage}`);
                console.log(response.data,"all paginated data")
                setCurrentPage(response.data.currentPage)
                setTotalPage(response.data.totalPages)
                dispatch(fetchProductsSuccess(response.data));
            } catch (error) {
                dispatch(fetchProductsFailure(error.message));
            }
        };

        fetchProducts();
    }, [dispatch,currentPage,search]);

    const handleAddToCart = async (product) => {
        try {
            await axios.post("http://localhost:3219/api/cart/addcart", {
                product: product._id,
                quantity: 1,
                user: userId,
            }, {
                headers: {
                    Authorization: token
                }
            });

            dispatch(addToCart({ productId: product._id, quantity: 1 }));
        } catch (error) {
            console.error("Error adding to cart:", error);
            alert("Failed to add product to cart.");
        }
    };

    const handleAddProductRedirect = () => {
        navigate('/add-product');
    };

    const handleUpdateProduct = (product) => {
        dispatch(setSelectedProduct(product));
        navigate('/update-product');
    };

    const handleViewProduct = (product) => {
        dispatch(setSelectedProduct(product));
        navigate('/view-product');
    };

    const handleDeleteProduct = async (productId) => {
        const confirmed = window.confirm("Are you sure you want to delete this product?");
        if (confirmed) {
            try {
                await axios.delete(`http://localhost:3219/api/productadmin/deleteproduct/${productId}`, {
                    headers: {
                        Authorization: token,
                    },
                });
                dispatch(deleteProduct(productId));
                alert("Product deleted successfully!");
            } catch (error) {
                alert("Failed to delete product. Please try again.");
            }
        }
    };

    if (loading) return <p>Loading products...</p>;
    if (error) return <p>Error fetching products: {error}</p>;

    return (
        <div className="dashboard">
            <Navbar /> 
            <h1>Product Dashboard</h1>
            {role === 'admin' && (
                <button onClick={handleAddProductRedirect} className="add-product-button">
                    Add New Product
                </button>
            )}
            
            <div className="product-list">
                {productList?.products?.map((product) => (
                    <div key={product._id} className="product-card">
                        <img src={`http://localhost:3219/getimg/${product.image}`} alt={product.name} className="product-image" />
                        <h3 className="product-name">{product.name}</h3>
                        <p className="product-price">${product.price}</p>
                        <p className="product-description">{product.description}</p>
                        {authUser.role === 'admin' ? (
                            <div className="admin-actions">
                                <button onClick={() => handleDeleteProduct(product._id)} className="action-button delete-button">
                                    <FaTrash /> Delete
                                </button>
                                <button onClick={() => handleUpdateProduct(product)} className="action-button update-button">
                                    <FaEdit /> Update
                                </button>
                                <button onClick={() => handleViewProduct(product)} className="action-button view-button">
                                    <FaEye /> View
                                </button>
                            </div>
                        ) : (
                            <button onClick={() => handleAddToCart(product)} className="action-button add-to-cart-button">
                                <FaCartPlus /> Add to Cart
                            </button>
                        )}
                    </div>
                ))}
            </div>

<PaginationOutlined currentPage={currentPage} setCurrentPage={setCurrentPage} totalPage={totalPage} />
            
        </div>
    );
};

export default Dashboard;
