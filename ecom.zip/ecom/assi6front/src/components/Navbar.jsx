import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import Logout from '../reduxcomponent/Logout';
import './navbar.css';
import { handleSearch } from '../reduxcomponent/productSlice';

const Navbar = () => {
    const dispatch = useDispatch();
    const { productList, loading, error,search } = useSelector((state) => state.products);

    
    const handleLogout = () => {
        dispatch(Logout());
    };


    const handles = (e) => {
    dispatch(handleSearch(e.target.value))
        
    }

    return (
        <div className="navbar">
           <input 
    className="form-control" 
    name='search'
    value={search}
    placeholder="Search by product name" 
    onChange={(e)=>{
    dispatch(handleSearch(e.target.value))

    }}
    style={{
        width: '100%', // Adjust the width as needed
        padding: '10px', // Add padding for better spacing
        borderRadius: '5px', // Rounded corners
        border: '1px solid #ccc', // Light gray border
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)', // Subtle shadow
        fontSize: '16px', // Font size
        outline: 'none', // Remove outline on focus
    }}
/>
            <div className="logo">E-Shop</div>
            <ul className="nav-links">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/cart">Cart</Link></li>
                <li><Link to="/dashboard">Dashboard</Link></li>
            </ul>
            <div className="user-info">
                <button 
                    style={{ backgroundColor: "red", color: "white", padding: "4px", outline: "none" }} 
                    onClick={handleLogout}
                >
                    Logout
                </button>
                <span>Welcome, Admin</span>
            </div>
        </div>
    );
};

export default Navbar;