import Dashboard from "../components/dashboard";
import PrivateLayout from "../layout/PrivateLayout";
// import AddUser from "../constants/adduser";
import Cart from "../cartPages/cart";
import AddProduct from "../adminpages/addProductpage";
import UpdateProduct from "../adminpages/updateProduct";
import ViewProduct from "../adminpages/viewProduct";
import Orders from "../cartPages/Orders";

const PrivateRoutes = [
  {
    path: "/dashboard",
    element: (
      <PrivateLayout>
        <Dashboard />
      </PrivateLayout>
    ),
  },
  {
    path: "/Cart",
    element: (
      <PrivateLayout>
        <Cart />
      </PrivateLayout>
    ),
  },
  {
    path: "/add-product",
    element: (
      <PrivateLayout>
        <AddProduct />
      </PrivateLayout>
    ),
  },
  {
    path: "/update-product",
    element: (
      <PrivateLayout>
        <UpdateProduct />
      </PrivateLayout>
    ),
  },
  {
    path: "/view-product",
    element: (
      <PrivateLayout>
        <ViewProduct />
      </PrivateLayout>
    ),
  },
  {
    path: "/orders",
    element: (
      <PrivateLayout>
        <Orders/>
      </PrivateLayout>
    ),
  },
//   {
//     path:"/adduser",
//     element: (
//       <PrivateLayout>
//         <AddUser/>
//       </PrivateLayout>
//     ),
//   },
];
export default PrivateRoutes;