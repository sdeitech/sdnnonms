// ViewProduct.js
import React from 'react';
import { useSelector } from 'react-redux';
import './viewProduct.css'; // Assuming you create a CSS file for styles

const ViewProduct = () => {
    const product = useSelector((state) => state.products.selectedProduct); // Get the product from Redux

    if (!product) {
        return <p>Product not found</p>;
    }

    return (
        <div className="view-product-container">
            <h2 className="product-title">{product.name}</h2>
            
            <div className="product-details">
                <p className="product-price">Price: ${product.price}</p>
                <p className="product-description">Description: {product.description}</p>
                {product.image && (
                    <img
                        src={`http://localhost:3219/getimg/${product.image}`}
                        alt={product.name}
                        className="product-image"
                    />
                )}
            </div>
        </div>
    );
};

export default ViewProduct;
