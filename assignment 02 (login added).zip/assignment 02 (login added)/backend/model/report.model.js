/**
 * Importing Mongoose Package for creating Schema in Mongo
 */
const mongoose = require("mongoose");

/**
 * Report Schema body structure
 */
const reportDetailsSchema = new mongoose.Schema({
  FirstName: {
    type: String,
    required: true,
  },

  LastName: {
    type: String,
    required: true,
  },

  Email: {
    type: String,
    required: true,
    unique: true,
  },

  MarksInEnglish: {
    type: Number,
    required: true,
  },

  MarksInScience: {
    type: Number,
    required: true,
  },

  MarksInMaths: {
    type: Number,
    required: true,
  },

  AboutYou: {
    type: String,
  },
});

/*
 * Inserting the Schema related information in the userDetails collection.
 */
const report = mongoose.model("reportDetails", reportDetailsSchema);

/**
 * Exporting the Mongoose Schema into the User for reference in the other files
 */
module.exports = report;