const nodemailer=require('nodemailer')
const {MAIL_USER} = require("../config/constants")
const transporter=nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false, // True for 465, false for other ports
  auth: {
    user: MAIL_USER,
    pass: "xdkeyxydpjsiqqqx",
  },
})

const sendRegistrationEmail = (Email, FirstName, LastName) => {
  const mailOptions = {
    from: `"Student Registery" <${MAIL_USER}>`, // Sender address
    to: Email, // List of receivers
    subject: "Registration Successful", // Subject line
    text: `Hello ${FirstName} ${LastName},\n\nYour registration was successful.`, // Plain text body
  };

  return transporter.sendMail(mailOptions);
};

module.exports = { sendRegistrationEmail };