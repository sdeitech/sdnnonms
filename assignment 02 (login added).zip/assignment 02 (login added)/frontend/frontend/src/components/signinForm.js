import axios from "axios";
import { useState } from "react";
const Signup = () => {
  const [data, setData] = useState({
    name: "",
    username: "",
    password: "",
  });
  
  const changeHandle = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });//dynamic
  };


  const onSubmitHandle=async(req,res)=>{
    try{
        e.preventDefault();
      await axios.post(
        "http://localhost:4000/reportDetails/api",data
        
      );

    
    } catch (error) {
      console.log(error);
    }
    }


}
  {
    return (
    <>
      <div>
        <h2>Signup form</h2>
      </div>
      <div>
        <input text="text" placeholder="Enter name" name="name" />
        <input text="text" placeholder="Enter username" name="username" />
        <input
          text="password"
          placeholder="Enter the password"
          name="password"
        />
      </div>
      <button type="submit">Submit</button>
    </>
  );
}

export default Signup();
