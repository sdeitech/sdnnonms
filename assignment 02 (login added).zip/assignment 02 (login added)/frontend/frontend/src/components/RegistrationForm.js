// import Button from "react-bootstrap/Button";
// import { useState } from "react";
// import axios from "axios";

// function ReportForm() {
//   const [inputPara, setInputPara] = useState({
//     FirstName: "",
//     LastName: "",
//     Email: "",
//     MarksInEnglish: "",
//     MarksInScience: "",
//     MarksInMaths: "",
//   });

//   /**
//    * To accept value into the fields via user
//    */
//   const onChangeEventHandle = (e) => {
//     setInputPara({ ...inputPara, [e.target.name]: e.target.value });
//   };

//   /**
//    * Function to Submit or post to the Backend API
//    */
//   const onSubmitHandle = async (e) => {
//     console.log(e);
//     try {
//       e.preventDefault();
      
//       await axios.post(
//         "http://localhost:4000/reportDetails/api/report",
//         inputPara
//       );

//       /**
//        * Function to reload form after each addition of record
//        */
//       window.location.reload();
//     } catch (error) {
//       console.log(error);
//     }
//   };


//   return (
//     <div>
//       <form onSubmit={onSubmitHandle}>
//         <label>First Name</label>
//         <input
//         className="w3-input w3-border"
//           type="text"
//           name="FirstName"
//           placeholder="Enter your First Name"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>Last Name</label>
//         <input
//         className="w3-input w3-border"
//           type="text"
//           name="LastName"
//           placeholder="Enter your Last Name"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>Email</label>
//         <input
//         className="w3-input w3-border"
//           type="Email"
//           name="Email"
//           placeholder="Enter your Email"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>Marks English</label>
//         <input
//         className="w3-input w3-border"
//           type="number"
//           name="MarksInEnglish"
//           placeholder="Enter your Marks in English"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>Marks Science</label>
//         <input
//         className="w3-input w3-border"
//           type="number"
//           name="MarksInScience"
//           placeholder="Enter your Marks in Science"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>Marks Maths</label>
//         <input
//         className="w3-input w3-border"
//           type="number"
//           name="MarksInMath"
//           placeholder="Enter your Marks in Maths"
//           onChange={onChangeEventHandle}
//           required
//         />

//         <label>About</label>
//         <textarea
//         className="w3-input w3-border"
//           name="AboutYou"
//           placeholder="AboutYou"
//           onChange={onChangeEventHandle}
//         />
//         <Button type="submit" variant="success">
//           SUBMIT
//         </Button>
//       </form>
//     </div>
//   );
// }

// export default ReportForm;
