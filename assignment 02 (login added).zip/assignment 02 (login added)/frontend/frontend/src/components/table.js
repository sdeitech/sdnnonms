// import { Table, Button } from "react-bootstrap";
// import { useEffect, useState } from "react";
// import axios from "axios";

// function TableView() {
//   const [data, setData] = useState([]);
  
//   const recordHandle = async () => {
//     try {
//       const result = await axios.get(
//         "http://localhost:4000/reportDetails/api/report"
//       );
//       console.log(result.data,".....")
//         setData(result.data.item);
//     } catch (error) {
//       console.error(error);
//     }
    
//   };

//   useEffect(() => {
//     recordHandle();
//   }, []);

//   const viewHandle = (x) => {
//         const percentage = () => {
//           const subjectMarks = x.MarksInEnglish + x.MarksInScience + x.MarksInMath
//           const per = (subjectMarks / 300) * 100
//           return per
//         }
//         const grade = (per) => {
//           if (per >= 90 && per <= 100) {
//               return 'A'
//           } else if ( per >= 60 && per <= 90) {
//             return 'B'
//           } else {
//             return 'C'
//           }
//         }


// const per = percentage();
// const grd = grade(per)

//     alert(`First Name: ${x.FirstName}\nLast Name: ${x.LastName}\nEmail: ${x.Email}\nMarks English: ${x.MarksInEnglish}\nMarks Science: ${x.MarksInScience}\nMarks Maths: ${x.MarksInMath}} \nPercentage: ${per} \nGrade: ${grd}`);
//   };

//   console.log(data);
//   return (
//     <Table striped bordered hover variant="dark">
//       <thead>
//         <tr>
//           <th>First Name</th>
//           <th>Last Name</th>
//           <th>Email</th>
//           <th>Action</th>
//         </tr>
//       </thead>
//       <tbody>
//         {data?.map((x) => {
//           return (
//             <tr key={x._id}>
//               <td>{x.FirstName}</td>
//               <td>{x.LastName}</td>
//               <td>{x.Email}</td>  
//               <td>
//                 <Button variant="info" onClick={() => viewHandle(x)}>VIEW</Button>
//               </td>
//             </tr>
//           );
//         })}
//       </tbody>
//     </Table>
//   );      
// }

// export default TableView;

