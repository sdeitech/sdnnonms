import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import { deleteUser } from '../Reduxcomp/slice';


const Home = () => {
    const users = useSelector((state) => state.users);  //extracting or taking data from redux store for use in state
    // console.log(users);
    const dispatch = useDispatch();

    const handleDelete=(id)=>{
 dispatch(deleteUser({id:id}))
    }
    
    
    return (
        <div classsName="container">
            <h2>Crud App</h2>
            {/* create button which is link to page means when we click on that button new page will open with the help of link */}
            <Link to="/create" className='btn btn-success my-3'>Create +</Link> 
            <table className='table'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {/* mapping on userdata for listing in dashboard */}
                    {users.map((user,index)=>{
                        return(
                        <tr key={index}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>
                            <Link to={`/edit/${user.id}`}className='btn btn-sm btn-primary'>Edit</Link>
                            <button onClick={()=> handleDelete(user.id)} className='btn btn-sm btn-danger ms-2'>Delete</button>
                            </td>
                        </tr>
                        )
                    })}
                </tbody>
            </table>


        </div>
    )
}
export default Home;
