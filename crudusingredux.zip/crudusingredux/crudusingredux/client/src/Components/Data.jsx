//initially we are taking this array of object as static value in our project

export const userList = [
    {
        name: "Aryan",
        email: "ary@gmail.com",
        id: 1,
    },
    {
        name: "Rohti",
        email: "roh@gmail.com",
        id: 2,
    },
    {
        name: "altamash",
        email: "alt@gmail.com",
        id: 3,
    },

]