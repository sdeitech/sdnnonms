import React, { useState } from 'react'
import { addUser } from '../Reduxcomp/slice'
import { useDispatch,useSelector } from 'react-redux'
import {  useNavigate } from 'react-router-dom'


const Create = () => {
    const [name, setName] = useState('')  //state for holding name
    const [email, setEmail] = useState('')  //state for holding email

    const users = useSelector((state)=>state.users); // useSelector=>to extract data from the Redux store state for use in a React component

    //useDispatch=> sends an action to the Redux store, which then triggers a state change in your application. 
    // In simpler terms,  dispatch is a messenger that carries an action from your application to the Redux store,
    //  which then updates the state accordingly.

    const dispatch = useDispatch(); 


// used for taking one page to another page
    const navigate = useNavigate(); 

    const handleSubmit = (event)=>{
        event.preventDefault();

        //addUser me se name,email and id jayegi or id:users[users.length-1].id + 1 mtlb jo alreacy id he or user ke jo phle id he usme +1 kro and fhir usme or us id me data add kro
        dispatch(addUser({id:users[users.length-1].id + 1 , name ,email}))   

        //navigate to "/" path declared in app.js
        navigate("/")  
    }

    return (
        <div className='d-flex w-100 vh-100 justify-content-center align-items-center'>
            <div className='w-50 border bg-secondary text-white p-5'>
                <h3>Add new user</h3>
                {/* //handle submit for when we submit the form this function will call and apply action of definition written in that                     */}
                <form onSubmit={handleSubmit}> <div>

                        <label htmlFor='name'>Name:</label>
                        <input type='text' name='name' className='form-control' placeholder='enter name'
                            onChange={
                                e => setName(e.target.value)  //onChange hook for setting name from user input
                            } />
                    </div>
                    <div>
                        <label htmlFor='email'>Email:</label>
                        <input type='email' name='email' className='form-control' placeholder='enter email'
                          onChange={
                            e => setEmail(e.target.value)   //onChange hook for setting email from user input
                        }  />
                    </div>
                    <button className='btn btn-info'>Submit</button>
                </form>
            </div>

        </div>
    )
}

export default Create
