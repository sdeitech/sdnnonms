import { createSlice } from "@reduxjs/toolkit";
import { userList } from "../Components/Data";

const userSlice = createSlice({
    name:"users",
    initialState:userList,
    
    reducers:{
        addUser:(state,action)=>{
            // console.log(action)
            state.push(action.payload)
        },
        updateUser:(state,action)=>{
            const {id,name,email}=action.payload
           
            const uu = state.find(user => user.id === Number(id))
            console.log(uu,"uuuuua")
            if(uu){
                uu.name=name;
                uu.email=email;
            }
            else{
            state.push(action.payload)

            }
           
        },
        deleteUser:(state,action)=>{
            const {id}=action.payload
           
            const uu = state.find(user => user.id === Number(id))
            console.log(uu,"uuuuua")
            if(uu){
               return state.filter(f=>f.id !==id)
            }

        }

    }
})
export default userSlice.reducer;
export const {addUser , updateUser,deleteUser}=userSlice.actions