import { createSlice } from "@reduxjs/toolkit";
import { userList } from "../Components/Data";

const userSlice = createSlice({
    name:"users",
    initialState:userList,
    reducers:{
        addUser:(state,action)=>{
            // console.log(action)
            state.push(action.payload)
        }

    }
})
export default userSlice.reducer;
export const {addUser}=userSlice.actions