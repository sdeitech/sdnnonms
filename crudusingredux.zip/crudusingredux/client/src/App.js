import React from 'react';
import Home from "./Components/Home"
import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';

function App() {
  return (
  <Home/>
  );
}

export default App;
