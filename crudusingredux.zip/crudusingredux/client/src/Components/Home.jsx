import React from 'react'
import { useSelector } from 'react-redux'

export const Home = () => {
    const users = useSelector((state)=>state.users);
  return (
    <div classsName="container">
        <h2>Crud App</h2>
        <button className='btn btn-success my-3'>Create +</button>
        <table className='table'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
 

    </div>
  )
}
