export const userList=[
    {
    name:"Aryan",
    email:"ary@gmail.com",
    id:1,
},
{
    name:"Rohti",
    email:"roh@gmail.com",
    id:2,
},
{
    name:"altamash",
    email:"alt@gmail.com",
    id:3,
},

]