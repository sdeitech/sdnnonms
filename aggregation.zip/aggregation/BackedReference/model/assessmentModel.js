import mongoose from "mongoose";


const userSchema = mongoose.Schema(
  {
    question: {
      type: String,
    },
    type: {
      type: String,
      required: true,
    },
    options: [{ //[""] [{optionj: ""}]
      type: String,
    }],
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model("Assessment", userSchema);

module.exports = User;