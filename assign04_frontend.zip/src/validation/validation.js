const validation = (formData) => {
    let error = {}

    if (!formData.firstName) {
        error.firstName = "please enter first name"
    }

    if (!formData.lastName) {
        error.lastName = "please enter last name"
    }

    if (!formData.email) {
        error.email = "please enter email"
    }

    if (!formData.gender) {
        error.gender = "please select gender"
    }

    if (!formData.DOB) {
        error.DOB = "please select DOB"
    }

    if (!formData.password) {
        error.password = "Please enter password"
    }

    if (!formData.gender) {
        error.gender = "Please select gender "
    }


    if (!formData.profile) {
        error.gender = "Please upload profile "
    }

    return error
}

export default validation