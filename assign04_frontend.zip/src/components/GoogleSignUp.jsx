import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google"
import axios from "axios"
import { useContext } from "react"
import { useNavigate } from "react-router-dom"
import { userContext } from "../context/AppContext"

const clientId = process.env.REACT_APP_CLIENT_ID

const GoogleSignUp = () => {
    console.log(clientId)
    const { userId, setUserId } = useContext(userContext)


    const navigate = useNavigate()

    const handleSubmit = async (response) => {
        const { credential } = response
        console.log(response)
        try {
            const res = await axios.post("http://localhost:3002/api//google/auth", { token: credential })
            // console.log(res.data)
            localStorage.setItem("token", res.data.token)
            // toast.success(`You logged in successfully !`)
            localStorage.setItem("userId", res.data.id)
            setUserId(res.data.id)
            setTimeout(() => {
                navigate("/dashboard")
            }, 1000);



        } catch (error) {
            console.log(error.message)
        }
        console.log(credential)
    }

    const handleErrro = (error) => {
        console.log(error.message)

    }
    return (
        <div>
            <GoogleOAuthProvider clientId={clientId}>
                <GoogleLogin
                    onSuccess={handleSubmit}
                    onError={handleErrro} />
            </GoogleOAuthProvider>
        </div>
    )
}

export default GoogleSignUp