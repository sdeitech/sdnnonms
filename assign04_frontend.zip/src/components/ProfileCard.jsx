import React, { useContext } from 'react'
import toast from 'react-hot-toast'
import { Link, useNavigate } from 'react-router-dom'
import { userContext } from '../context/AppContext'
import useForm from '../customs/useForm'
import { putApi } from '../utils/apiUtils'
import axios from 'axios'


const ProfileCard = () => {

  const navigate = useNavigate()

  const { userData, userId, updateState,
    setUpdateState, } = useContext(userContext)
  console.log(userData, "from update")

  console.log(userId, "ipdate user is profile")
  // let fomatted_date = (userData.DOB).split("T")[0]
  // let fomatted_date = new Date(userData?.DOB).toDateString().split("T")[0]


  const updateProfile = {
    firstName: userData?.firstName || "",
    lastName: userData?.lastName || "",
    email: userData?.email || "",
    DOB: userData?.DOB?.split("T")[0] || "00-00-00",
    isMarried: userData?.isMarried,
    profile: userData?.profile,
    gender: userData?.gender,
  }


  const { formData, previewImg, handleChange } = useForm(updateProfile)
  console.log(formData)

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      // const res = await putApi(`/update/user/${userId}`, formData)
      // console.log(res.data)

      const res = await axios.put(`http://localhost:3002/api/update/${userId}`, formData, {
        headers: {
          Authorization: localStorage.getItem("token"),
          "Content-Type": "multipart/form-data"
        }
      })
      setTimeout(() => {
        navigate("/dashboard")
      }, 1000);
      setUpdateState(!updateState)
      console.log(res.data)
      toast.success("Profile updated")
    } catch (error) {
      toast.error("Cant update profile")
      // console.log(`error while updating user ${error.message}`)
    }
  }


  return (
    <div>
      <div>
        <p>Chnage profile</p>
      </div>
      <div>
        <form onSubmit={handleSubmit} className='form-inputs'>
          <div>
            {
              userData?.profile ? <img src={`${process.env.REACT_APP_IMAGE_URL}/${userData?.profile}`} alt="Profile" height={70} width={70} style={{ border: "1px solid gray" }} /> : <img src={`${userData?.google_img}`} alt="Profile" height={70} width={70} style={{ border: "1px solid gray" }} />
            }
          </div>
          <div>
            <input
              type="text"
              name='firstName'
              value={formData.firstName}
              placeholder='First name'
              onChange={handleChange}
            />
          </div>
          <div><input
            type="text"
            name='lastName'
            value={formData.lastName}
            placeholder='Last name'
            onChange={handleChange} /></div>
          <div> <input
            type="email"
            name='email'
            placeholder='Email'
            value={formData.email}
            onChange={handleChange} /></div>
          <div>
            <input
              type="date"
              name='DOB'
              value={formData.DOB}
              onChange={handleChange} />
          </div>

          <div>
            <label>Married</label>
            <input
              type="checkbox"
              name='isMarried'
              value={updateProfile.isMarried}
              checked={formData.isMarried}
              onChange={handleChange}
            />
          </div>

          <div className='gender-div'>
            <div>
              <label>Male</label>
              <input
                type="radio"
                name='gender'
                value="male"
                checked={formData.gender === "male"}
                onChange={handleChange} />
            </div>
            <div>
              <label>Female</label>
              <input
                type="radio"
                name='gender'
                value="female"
                checked={formData.gender === "female"}
                onChange={handleChange}
              />
            </div>
          </div>

          <div>
            <input
              type="file"
              id='profile'
              name='profile'
              onChange={handleChange}
            />
          </div>

          <div className='submit-btn'>
            <button type='submit' >Update</button>
          </div>
          <div>
            <Link to={"/dashboard"}><p>Back to dashboard</p></Link>
          </div>
        </form>
      </div>
    </div>
  )
}

export default ProfileCard