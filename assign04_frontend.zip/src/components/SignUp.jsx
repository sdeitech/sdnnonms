import React, { useState } from 'react'
import toast, { Toaster } from 'react-hot-toast'
import { CgProfile } from "react-icons/cg"
import { Link, useNavigate } from 'react-router-dom'
import "../css/SignUp.css"
import useForm from '../customs/useForm'
import { postApi } from '../utils/apiUtils'
import validation from '../validation/validation'

const SignUp = () => {
    const navigate = useNavigate()
    const [formErros, setFormError] = useState(null)

    const signUpForm = {
        firstName: "",
        lastName: "",
        email: "",
        DOB: "",
        password: "",
        isMarried: false,
        gender: "",
        profile: null
    }
    const { formData, previewImg, handleChange, resetForm } = useForm(signUpForm)
    console.log(previewImg, "blob")
    console.log(formData)


    const handleSubmit = async (e) => {
        e.preventDefault()

        const errors = validation(formData)
        console.log(errors)
        setFormError(errors)

        try {

            if (Object.keys(formErros) >= 0) {
                const res = await postApi("/signup", formData, true)
                resetForm()
                toast.success('user registered Successfully !')
                setTimeout(() => {
                    navigate("/login")
                }, 1000);
            }

        } catch (error) {
            toast.error('please enter valid details!')
            // console.log(`Error while signing up user ${error.message}`)

        }
    }


    return (
        <div className='form-container'>
            <h3>Sign Up</h3>

            <form onSubmit={handleSubmit} className='form-inputs'>
                <div>
                    {previewImg ? <div className='profile-container'> <img src={previewImg} alt="profile" height={60} width={50} /> </div> : <div className='profile-container' > <CgProfile size={50} /> </div>}
                </div>
                <div>
                    <input
                        type="text"
                        name='firstName'
                        placeholder='First name'
                        onChange={handleChange}
                    // required
                    />
                    {formErros?.firstName && <p style={{ color: "red" }}>{formErros.firstName}</p>}
                </div>


                <div><input
                    type="text"
                    name='lastName'
                    placeholder='Last name'
                    onChange={handleChange}
                // required
                />
                    {formErros?.lastName && <p style={{ color: "red" }}>{formErros.lastName}</p>}

                </div>
                <div>
                    <input
                        type="email"
                        name='email'
                        placeholder='Email'
                        onChange={handleChange}
                    // required
                    />
                    {formErros?.email && <p style={{ color: "red" }} >{formErros.email}</p>}

                </div>
                <div>
                    {/* <label>DOB</label> */}
                    <input
                        type="date"
                        name='DOB'
                        onChange={handleChange}
                    // required
                    />
                    {formErros?.DOB && <p style={{ color: "red" }}>{formErros.DOB}</p>}

                </div>
                <div>
                    <input
                        type="password"
                        name='password'
                        placeholder='password'
                        onChange={handleChange}
                    // required

                    />
                    {formErros?.password && <p style={{ color: "red" }}>{formErros.password}</p>}

                </div>
                <div>
                    <label>Married</label>
                    <input
                        type="checkbox"
                        name='isMarried'
                        checked={formData.isMarried}
                        onChange={handleChange}
                    />
                </div>

                <div className='gender-div'>
                    <div>
                        <label>Male</label>
                        <input
                            type="radio"
                            name='gender'
                            value="male"
                            checked={formData.gender === "male"}
                            onChange={handleChange} />
                    </div>
                    <div>
                        <label>Female</label>
                        <input
                            type="radio"
                            name='gender'
                            value="female"
                            checked={formData.gender === "female"}
                            onChange={handleChange}
                        />
                    </div>
                </div>
                {formErros?.gender && <p style={{ color: "red" }}>{formErros.gender}</p>}

                <div>
                    <label htmlFor="profile" style={{ backgroundColor: "rgb(131, 226, 255)", padding: "6px 15px", borderRadius: "4px" }}>Upload Profile</label>
                    <input
                        type="file"
                        id='profile'
                        name='profile'
                        placeholder=''
                        onChange={handleChange}
                        style={{ display: "none" }}
                    />
                </div>
                {formErros?.profile && <p style={{ color: "red" }}>{formErros.profile}</p>}


                <div className='submit-btn'>
                    <button type='submit' >submit</button>
                </div>
                <div>
                    <p>Already have an account ? <Link to={"/login"}><span>click here</span></Link></p>
                </div>

            </form >
            <Toaster />
        </div >
    )
}

export default SignUp