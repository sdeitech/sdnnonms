import React from 'react'
import PublicLayout from '../layout/PublicLayout'
import SignUp from '../components/SignUp'
import SignIn from '../components/SignIn'

const PublicRoutes = [
    {
        path: "/",
        element: <PublicLayout><SignUp /></PublicLayout>
    },
    {
        path: "/login",
        element: <PublicLayout> <SignIn /> </PublicLayout>
    }

]
export default PublicRoutes