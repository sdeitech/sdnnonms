import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './table.css';
function Viewuser() {

    const [userData, setUserData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await axios.get('http://localhost:4000/user/get');
                setUserData(res.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, []);
    return (
        <>
            <table>
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th>Actions </th>
                    </tr>
                </thead>
                <tbody>
                    {userData.map((userDat) => (
                        <tr key={userDat._id}>
                            <td>{userDat.name}</td>
                            <td>{userDat.email}</td>
                            <td>{userDat.message}</td>
                            <td>
                                <button onClick={''}>View Data</button>
                            </td>
                        </tr>
                    ))}

                </tbody>
            </table >
        </>
    );
}

export default Viewuser;




