import React, { useState } from 'react'; 
import axios from 'axios'; 
import Button from 'react-bootstrap/Button'; 
import Col from 'react-bootstrap/Col'; 
import Form from 'react-bootstrap/Form'; 
import Row from 'react-bootstrap/Row';

function AddForm() {
    const [user, setUser] = useState({
        name: '',
        email: '',
        message: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value,
        });
    };


    console.log(user);

    const handleSubmit = async (e) => {
        e.preventDefault();


        console.log(user, "user");
        try {
            const response = await axios.post(
                "http://localhost:4000/user/create",
                user
            );
            console.log("user data submitted:", response.data);
        } catch (err) {
            console.error("Error submitting Data:", err.message);
        }

    };

    const clearuser = () => {
        setUser({
            name: '',
            email: '',
            message:'',
        });
    };

    return (
        <Form onSubmit={handleSubmit}>
            <Row className="mb-3">
                <Form.Group as={Col}>
                    <Form.Label>Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter Name" name="name" onChange={handleChange} value={user.name} />
                </Form.Group>

                <Form.Group as={Col}>
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" name="email" onChange={handleChange} value={user.email} />
                </Form.Group>
            </Row>
            <Form.Group className="mb-3">
                <Form.Label>Message</Form.Label>
                <Form.Control type="text" name="message" onChange={handleChange} value={user.message} />
            </Form.Group>

            
            <Button variant="primary" type="submit">
                Submit
            </Button>
            <Button variant="secondary" onClick={clearuser} className="ms-2">
                Reset
            </Button>
        </Form>
    );
}

export default AddForm;