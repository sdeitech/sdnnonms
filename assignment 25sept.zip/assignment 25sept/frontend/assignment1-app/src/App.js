import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import AddForm from './component/Form';
import Viewuser from './component/List';


function App() {
  return (
    <>
      <Router>
        <Navbar expand="lg" className="bg-body-tertiary">
          <Container>
            <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link href="/components/Form">Add Details</Nav.Link>
                <Nav.Link href="/components/Viewdetails">View list</Nav.Link>
                <Routes>
                  <Route path="/components/Form" element={<AddForm />} />
                  <Route path="/components/Viewdetails" element={<Viewuser />} />
                </Routes>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </Router>
    </>
  );
}

export default App;
