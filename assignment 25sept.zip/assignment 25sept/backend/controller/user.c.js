const User = require('../model/user.m');
const sendEmail = require('../mail');

exports.createUser = async (req, res) => {
    const {name,email,message} = req.body;
    console.log(req.body)
    try {
        const newUser = new User({name,email,message});
        await newUser.save();

        await sendEmail(name,email,message);
        res.status(200).json({message: "Form submitted!"});
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.getUser = async (req, res) => {
    try {
        const Users = await User.find();
        res.send(Users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
