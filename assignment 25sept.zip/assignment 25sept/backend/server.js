const express = require('express');
const bodyParser =require('body-parser');
const UserRoute = require('./route/user.r');
const db = require('./db');
const cors = require('cors');

const app = express();
const PORT = 4000;

app.use(cors());
app.use(bodyParser.json());
app.use('/user', UserRoute );

app.listen(PORT, ()=>{
    console.log(`server is running on http://localhost:${PORT}`);
});