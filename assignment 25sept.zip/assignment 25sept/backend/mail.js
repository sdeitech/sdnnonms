const nodemailer = require("nodemailer");

// Function to send an email
const sendEmail = async (name, email, message) => {
  try {

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "mdayank7786@gmail.com", 
        pass: "mzdjumyutgcbbfsj"  
      }
    });

    // Define the email options
    const mailOptions = {
      from: "mdayank7786@gmail.com",
      to: email,
      subject: "Form Submission Received",
      text: `Hi ${name},\n\nThank you. I have received your message:\n"${message}"`
    };

    // Send the email
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully!");
  } catch (error) {
    console.error("Error sending email:", error);
  }
};

module.exports = sendEmail;
