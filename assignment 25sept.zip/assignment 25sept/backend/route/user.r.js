const express = require('express');
const router = express.Router();
const UserController = require('../controller/user.c');


router.post('/create', UserController.createUser); 
router.get('/get', UserController.getUser); 



module.exports = router;
