from django.shortcuts import render, redirect
from .models import Student 

# Create your views here.
# data = []
# def index(request):
#     return render(request, 'index.html')


def index(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        dob = request.POST.get('dob')
        salary = request.POST.get('salary')
        is_passed = request.POST.get('is_passed')
        if is_passed:
            newobj = Student (
            name = name,
            age = age,
            dob = dob,
            salary = salary,
            is_passed = True
            )
            newobj.save()
        else:
            Student.objects.create (
            name = name,
            age = age,
            dob = dob,
            salary = salary,
            is_passed = False
            )
        return redirect('/')
    else:
        obj = Student.objects.all()
        context = {'obj' : obj}
        return render(request, 'index.html', context)






















# # def about(request):
#     print(request.method)
#     if request.method == 'POST':
#         text1 = request.POST.get('text1')
#         text2 = int(request.POST.get('text2'))
#         text3 = request.POST.get('text3')
#         result = text1
#         obj = {'text':text1 , 'text2':text2 , 'text3':text3}
#         data.append(obj)
#         # print(data)
#         context = {"data":data}
#     else:
#         print("test--------------")
#         context = {'data': "None"}

    # context = {'result': result}

    # return render(request, 'about.html', context)


# def about(request):
    # data = []
    # text1 = request.POST.get('text1')
    # text2 = int(request.POST.get('text2'))
    # text3 = request.POST.get('text3')
    # result ={ text1, text2, text3}
    # data.append(result)
    # context = {'result' : data}
    # print(data)
    # return render(request, 'about.html', context)

