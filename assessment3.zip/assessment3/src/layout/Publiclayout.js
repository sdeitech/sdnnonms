import React from 'react'

const Publiclayout = ({children}) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default Publiclayout
