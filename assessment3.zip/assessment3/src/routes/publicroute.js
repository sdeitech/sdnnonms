import react from 'react';
import Publiclayout from '../layout/Publiclayout';
import Login from '../component/Login';
import Signup from '../component/Signup';

const publicroute=[
    {
        path:'/',
        element:<Publiclayout><Login/></Publiclayout>
    },
    {
        path:'/signup',
        element:<Publiclayout><Signup/></Publiclayout>
    }
]

export default publicroute;