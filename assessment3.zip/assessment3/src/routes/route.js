import react from 'react';
import publicroute from './publicroute';
import privateroute from './privateroute';
import { createBrowserRouter } from 'react-router-dom';
const route=createBrowserRouter([
    ...publicroute,
    ...privateroute
])

export default route;