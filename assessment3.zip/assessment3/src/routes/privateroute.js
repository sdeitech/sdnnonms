import react from 'react';
import Privatelayout from '../layout/Privatelayout';
import Dashboard from '../component/Dashboard';
const privateroute=[
    {
        path:'/dashboard',
        element:<Privatelayout><Dashboard/></Privatelayout>
    }
]

export default privateroute;