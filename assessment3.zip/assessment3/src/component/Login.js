import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';

const Login = () => {
  const [formData, setFormData] = useState({
    email:'',
    password:''
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    try {
        const result = await axios.post("http://localhost:5000/user/login",formData);
        console.log("login successfull !");
        localStorage.setItem("token",result.data.token);
        alert(`login successfull`);
        navigate("/dashboard");
        
    } catch (error) {
        alert(`User not found do register !!`);
        console.log("error while login !");
    }
  };
  return (
    <div className="container container-form">
      <h2>Welcome User</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email </label>
          <input
            name="email"
            type="email"
            placeholder="enter the email"
            value={formData.email}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Password </label>
          <input
            name="password"
            type="password"
            placeholder="enter the password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <div>
          <button variant="success"> Login </button>
        </div>
        <div>
          <h3>
            {" "}
            Don't have an Account!{" "}
            <span style={{color:"blue"}}
              onClick={() => {
                navigate("/signup");
              }}
            >Register Here</span>{" "}
          </h3>
        </div>
      </form>
    </div>
  );
};

export default Login;
