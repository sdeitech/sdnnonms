import React from 'react'

const View = ({user}) => {
  return (
    <div>
   
    <h4>ProductName:{user.productName}</h4>
    <h4>Price:{user.price}</h4>
    <h4>description:{user.description}</h4>

      
    </div>
  )
}

export default View
