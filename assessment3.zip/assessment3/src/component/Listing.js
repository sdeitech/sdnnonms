import React from 'react'

const Listing = ({data}) => {
  return (
    <table>
        <thead>
            <tr>
                <th>Sr.No</th>
                <th>ProductName</th>
                <th>Price</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            {data.map((value,index)=>(
                <tr key={index}>
                    <td>{index+1}</td>
                    <td>{value.productName}</td>
                    <td>{value.price}</td>
                    <td>{value.description}</td>
                </tr>
            ))}
        </tbody>
    </table>
  )
}

export default Listing;
