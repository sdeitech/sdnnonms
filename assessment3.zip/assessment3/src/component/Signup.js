import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Signup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/user/register", formData);
      alert(`thank you for registering`);
      navigate('/');
    } catch (error) {
      console.log("error while doing registration");
    }
  };
  return (
    <div className="container container-form">
      <h2>Regisstration form </h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name </label>
          <input
            name="name"
            type="text"
            placeholder="enter full name"
            value={formData.name}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Email </label>
          <input
            name="email"
            type="password"
            placeholder="enter email"
            value={formData.email}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Password </label>
          <input
            name="password"
            type="password"
            placeholder="enter the password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <div>
          <button type="submit" variant="success">
            Register
          </button>
        </div>
        <div>
          <h3>
            Already register! 
            <span
              onClick={() => {
                navigate("/");
              }}
            > click here </span>
          </h3>
        </div>
      </form>
    </div>
  );
};

export default Signup;
