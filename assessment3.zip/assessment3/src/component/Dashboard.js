import React, { useEffect, useState } from "react";
import axios from "axios";
import View from "./View";
const Dashboard = () => {
  const [data, setData] = useState([]);
  const [user, setUser] = useState(null);
  const [show, setShow] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    productName: "",
    price: "",
    description: "",
  });

  const pagination = async () => {
    try {
      const result = await axios.get("http://localhost:5000/product");
      console.log("result", result);
      setData(result.data.Product);
    } catch (error) {
      console.log("error while fetching data");
    }
  };
  useEffect(() => {
    pagination();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      [name]: value,
      ...prev,
    }));
  };

  const handleSubmit=async(e)=>
  {
    e.preventDefault();
    try {
        const result=await axios.post("http://localhost:5000/product",formData);
        setdata()
        
    } catch (error) {
        console.log("error while inserting product");
    }
  }
  return (
    <div>
      <h2>Product table</h2>
      <button onClick={() => setShowModal(!showModal)}> AddProduct</button>
      <table>
        <thead>
          <tr>
            <th>Sr.No</th>
            <th>ProductName</th>
            <th>Price</th>
            <th>Description</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((value, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{value.productName}</td>
              <td>{value.price}</td>
              <td>{value.description}</td>
              <td>
                <button
                  onClick={() => {
                    setShow(!show);
                    setUser(value);
                  }}
                >
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {show && <View user={user} />}
      {showModal && (
        <div>
          <form onSubmit={handleSubmit}>
            <div>
              <label>ProductName</label>
              <input
                name="productName"
                type="text"
                value={formData.productName}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>price</label>
              <input
                name="price"
                type="Number"
                value={formData.price}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>description</label>
              <input
                name="Description"
                type="text"
                value={formData.description}
                onChange={handleChange}
              />
            </div>
            <button type="submit">add</button>
            <button onClick={() => setShowModal(false)}>cancel</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
