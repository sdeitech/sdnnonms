import mongoose from 'mongoose'
mongoose.connect("mongodb://localhost:27017/userAuthentication")

const db =mongoose.connection;
db.on("error",console.error.bind(console,"error while connecting to db"))
db.once("open",()=>
{
    console.log("connected to database");
})

export default db;