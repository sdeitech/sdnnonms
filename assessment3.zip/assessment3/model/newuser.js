import mongoose from "mongoose";
const NewUserSchema= mongoose.Schema({
    username:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    profile:{
        type:String,
        required:true
    }
});
const newUser=mongoose.model("newUser",NewUserSchema);
export default newUser;