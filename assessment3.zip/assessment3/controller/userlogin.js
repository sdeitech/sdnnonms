import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../model/user.js'

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const newUser = await User.findOne({ email });
        if (!newUser) {
            res.status(400).json({ message: "email not matched" })
        }
        const ismatch = await bcrypt.compare(password, newUser.password);

        if (!ismatch) {
            res.status(400).json({ message: "Invalid credentials" });
        }
        const token = jwt.sign({ email: newUser.email, id: newUser._id }, "secret key", { expiresIn: "6hr" });
        newUser.tokens = [{ token }]
        await newUser.save();
        res.status(200).json({ message: "user login successfull", token, newUser });

    } catch (error) {
        res.send("user not found ");
    }
}

export default { loginUser };