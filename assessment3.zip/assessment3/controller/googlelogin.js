import { OAuth2Client } from "google-auth-library";
import newUser from "../model/newuser";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken'

const CLIENT_ID = "9377541509-72f7luegj1da5olu0uo0mcbi8g4vm11k.apps.googleusercontent.com";
const client = new OAuth2Client(CLIENT_ID);


export const googleLogin = async (req, res) => {
    const { token } = req.body;
    console.log("token", token)
    try {

        const ticket = await client.verifyIdToken({
            idToken: token,
            audience: CLIENT_ID
        });

        console.log("ticket", ticket)

        const payload = ticket.getPayload();
        // const { username, email, password } = payload;

        const googleId = payload['sub']; // Google user ID
        const email= payload['email'];

        const username = email.split('@')[0];

        let user = await newUser.findOne({email});
    // console.log(user,"user");
    
        if (!user) {
            user = new newUser({
                email,
                // googleId,
                username,
                password:googleId,
                profile
            })
            await user.save()
        }

        console.log("user", user)
        const jwttoken = jwt.sign({ userId: user._id }, "this is the secret key", { expiresIn: "6h" });
        res.json({ message: "login success", token: jwttoken })

    }
    catch (error) {
        console.log("error during login with google");
        res.json({ message: "invalid token" })
    }
}

//to get the user who login in the app
export const getuser = async (req, res) => {
    try {
        const user = await newUser.find({});
        res.json(user)

    } catch (error) {
        res.json({ message: "error while getting users" });
    }

}

///user registartion
export const userRegistration=async(req,res)=>
{
    try {
        const profile=req.file?.filename;
        const {username,email,password}=req.body;

        const hashedPassword=await bcrypt.hash(password,10);

        const newuser=new newUser({
            username,
            password:hashedPassword,
            email,
            profile:profile
        });

        await newuser.save();
        res.status(200).json(newuser);
        
    } catch (error) {
        res.status(500).json({message:" error while inserting new user "})
        
    }
}


export const userLogin=async (req,res)=>
{
    try {
        const {email,password}=req.body;
        const newuser= await newUser.findOne({email});
        if(!newuser){
            return res.status(400).json({message:"email not matched"});            
        }
        const ismatch= await bcrypt.compare(password,newuser.password)
        if(!ismatch)
        {
            return res.status(400).json({message:"invalid credentials"});
        }
        const token=jwt.sign({email:newuser.email,id:newuser._id},"your secret key",{expiresIn:"6h"});

        await newuser.save();
        res.status(200).json({message:"login successfull",newuser,token});
        
    } catch (error) {
        res.status(500).json({message:"error while login "})
        
    }
}