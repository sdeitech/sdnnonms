import axios from 'axios';

const base_url="http://localhost:6666";

const apiCall=axios.create({
    baseURL:base_url
})

export default apiCall;