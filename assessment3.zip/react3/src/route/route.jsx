import privateroute from "./privateroute";
import publicroute from "./publicroute";
import {createBrowserRouter} from 'react-router-dom';
const router=createBrowserRouter([
    ...publicroute,
    ...privateroute,
])

export default router;