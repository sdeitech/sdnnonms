import Publiclayout from "../layout/Publiclayout";
import Login from "../component/Login";
import Signup from "../component/Signup";
const publicroute =[
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Login/></Publiclayout>
    },
    {
        path:'/SignUp',
        exact:true,
        element:<Publiclayout><Signup/></Publiclayout>
    }
]

export default publicroute;