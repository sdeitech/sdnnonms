import Dashboard from "../component/dashboard";
import Privatelayout from "../layout/Privatelayout";
const privateroute=[
    {
        path:'/dashboard',
        exact:true,
        element:<Privatelayout><Dashboard/></Privatelayout>
    }
]

export default privateroute;