import React, { useState } from 'react';

const Dashboard = () => {
  const [showProfile, setShowProfile] = useState(false);

  // Retrieve data from local storage
  const data = localStorage.getItem("data");
  const profileData = JSON.parse(data);

  // Get the image URL or base64 string from localStorage (assuming it's saved as profileData.profileImage)
  const profileImage = profileData?.profile; // URL or base64 string

  console.log("profileData", profileData);
  console.log("Profile Image URL or Base64:", profileImage);  // Log profileImage to debug

  return (
    <div>
      <div>
        {/* Toggle profile visibility */}
        <span onClick={() => setShowProfile(true)}>Profile</span>
      </div>

      {showProfile && (
        <div>
          <p>First Name: {profileData?.firstName}</p>
          <p>Last Name: {profileData?.lastName}</p>

          {/* Display profile image */}
          {profileImage ? (
            <div>
              <p>Profile Image:</p>
              <img 
                src={profileImage} 
                alt="Profile" 
                style={{ width: '200px', height: '200px', objectFit: 'cover' }} 
              />
            </div>
          ) : (
            <p>No Profile Image Available</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
