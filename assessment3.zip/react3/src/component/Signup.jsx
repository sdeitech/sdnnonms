import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../style/signup.css";

const SignUp = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    dob: "",
    password: "",
    gender: "",
    image: null,
    married: false,
  });

  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const HandleImageChange = (e) => {
    const file = e.target.files[0];
    setFormData((prevData) => ({
      ...prevData,
      image: file,
    }));
  };

  const handlesubmit = async (e) => {
    e.preventDefault();

    const userData = new FormData();
    userData.append("firstName", formData.firstName);
    userData.append("lastName", formData.lastName);
    userData.append("email", formData.email);
    userData.append("dob", formData.dob);
    userData.append("password", formData.password);
    userData.append("gender", formData.gender);
    userData.append("married", formData.married);
    userData.append("image", formData.image); // Append the image file

    try {
        console.log("hhbbnjkjn")
        await axios.post(
        "http://localhost:4000/admin/register",
        userData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("Registration successful");
      alert("Registration successful");
      navigate("/");
    } catch (err) {
      setError("Error during registration. Please try again.");
      console.log("Registration failed", err);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value, 
    }));
  };

  return (
    <div>
      <div className="container login-container">
        <form className="login-form" onSubmit={handlesubmit}>
          {error && <p style={{ color: "red" }}>{error}</p>}
          <h2 className="text-center">Admin Registration</h2>
          <div className="form-group">
            <label htmlFor="firstName">First Name:</label>
            <input
              type="text"
              name="firstName"
              className="form-control"
              value={formData.firstName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="lastName">Last Name:</label>
            <input
              type="text"
              name="lastName"
              className="form-control"
              value={formData.lastName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="dob">Date of Birth:</label>
            <input
              type="date"
              name="dob"
              className="form-control"
              value={formData.dob}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="gender">Gender:</label>
            <select
              name="gender"
              className="form-control"
              value={formData.gender}
              onChange={handleChange}
            >
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label>Profile Image:</label>
            <input
              type="file"
              name="image"
              onChange={HandleImageChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="married">Married:</label>
            <input
              type="checkbox"
              name="married"
              checked={formData.married}
              onChange={handleChange}
            />
          </div>
          <br />
          <button
            type="submit"
            className="btn btn-primary btn-block"
            variant="success"
          >
            Register
          </button>
          &nbsp;
          <div>
            <span
              style={{ color: "red", cursor: "pointer" }}
              onClick={() => navigate("/")}
            >
              Back to Login
            </span>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
