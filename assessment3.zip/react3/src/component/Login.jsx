import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../style/login.css";

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();
  const [show, setShow] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(
        "http://localhost:4000/admin/login",
        formData
      );
      localStorage.setItem("token", result.data.token);

      localStorage.setItem("data", JSON.stringify(result.data.newemail));
      
      console.log("login successfull");
      navigate('/dashboard')
    } catch (error) {
      console.log("error occur while login");
      alert(`Invalid Credentials `);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSignUp = () => {
    setShow(true);
    navigate("/SignUp");
  };
  return (
    <div className="conatainer form-data">
      <div className="container login-container">
        <form className="login-form" onSubmit={handleSubmit}>
          <h3>Admin Login</h3>

          {Error && <p style={{ color: "red" }}>{Error}</p>}

          <div className="form-group">
            <label>Email:</label>
            <input
              className="form-control"
              type="email"
              name="email"
              onChange={handleChange}
              value={formData.email}
              required
            />
          </div>
          <br></br>

          <div className="form-group">
            <label>Password:</label>
            <input
              className="form-control"
              type="password"
              name="password"
              onChange={handleChange}
              value={formData.password}
              required
            />
          </div>
          <br></br>

          <div>
            <button
              type="submit"
              variant="success"
              className="btn btn-primary btn-block"
            >
              SignIn
            </button>{" "}
            &nbsp;
            <button
              variant="success"
              className="btn btn-primary btn-block"
              onClick={handleSignUp}
            >
              {show}SignUp
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
