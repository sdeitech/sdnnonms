import mongoose from "mongoose";
const Schema = mongoose.Schema;
const AdminSchema = new Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  DOB: {
    type: Date,
    required: true,
  },
  isMarried: {
    type: Boolean,
    default: false,
  },
  gender: {
    type: String,
    required: true,
  },
  profile: {
    type: String,
  },
  users: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  ],
  
});

const admin = mongoose.model("admin", AdminSchema);
export default admin;
