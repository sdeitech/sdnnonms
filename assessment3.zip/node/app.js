import express from "express";
import cors from 'cors';
import bodyParser from 'body-parser'
import path from 'path'
import router from './router/userRouter.js'
const app=express();

app.use(express.json())
app.use(bodyParser.urlencoded({limit:"50mb",extended:false}));
app.use(cors({origin:"*"}))
app.use('',router)

app.use('/',express.static(path.join('images')));
// app.use('',userRouter);

export default app;