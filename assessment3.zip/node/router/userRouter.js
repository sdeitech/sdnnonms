import express from 'express';
import {registerAdmin ,adminLogin ,getUsers} from '../controller/AdminController.js';
import { middlewareUpload } from '../middleware/multer.js';

const route=express.Router();

route.post("/admin/register",middlewareUpload.single('image'),registerAdmin);
route.post("/admin/login",adminLogin);

route.get("/users",getUsers);
export default route;