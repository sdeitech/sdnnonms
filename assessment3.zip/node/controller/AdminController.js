import admin from "../model/admin.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import path from "path";

export const registerAdmin = async (req, res) => {
  try {
    // const profile=req.file?.filename
    // console.log(req.body);
    const {
      firstName,
      lastName,
      email,
      password,
      DOB,
      isMarried,
      gender,
      profile,
    } = req.body;

    const hashedPass = await bcrypt.hashSync(password, 10);
    // console.log("hashpas", hashedPass);
    const newAdmin = new admin({
      firstName: firstName,
      lastName: lastName,
      email: email,
      password: hashedPass,
      DOB: DOB,
      isMarried: isMarried,
      gender: gender,
      profile: req.file.filename,
    });

    // console.log("hhhhhh")
    // console.log( Admin.firstName);
    await newAdmin.save();
    // console.log("saved", { saved });
    // console.log("hhhhhh5")
    res.status(200).json(newAdmin);
  } catch (error) {
    res.status(400).json({ message: "error while registering" });
  }
};

export const adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const newemail = await admin.findOne({ email });
    if (!newemail) {
      res.status(400).json({ message: "email not matched" });
    }
    const ismatch = await bcrypt.compare(password, newemail.password);

    if (!ismatch) {
      res.status(400).json({ message: "Invalid credentials" });
    }
    const token = jwt.sign(
      { email: newemail.email, id: newemail._id },
      "secret key",
      { expiresIn: "6hr" }
    );
    // newemail.tokens = [{ token }]
    await newemail.save();
    res
      .status(200)
      .json({ message: "user login successfull", token, newemail });
  } catch (error) {
    res.send("user not found ");
  }
};

export const getUsers = async (req, res) => {
  try {
    // const { searchText = "" } = req.query;
    const pageNo = parseInt(req.query.pageNo) || 1;
    const pageLimit = parseInt(req.query.pageLimit) || 10;
    const skip = (pageNo - 1) * pageLimit;

    // Fetch admin details and populate users based on search and pagination
    const userDetails = await admin.findById(req.params.id).populate({
      path: "user",
      // match: searchText.trim()
      //   ? {
      //       firstName: { $regex: searchText.trim(), $options: "i" },
      //     }
      //   : {},
      options: {
        skip: skip,
        limit: pageLimit, 
      },
    });

    const totalRecords = await admin.findById(req.params.id).select('user').countDocuments();
    const totalPages = Math.ceil(totalRecords / pageLimit);

    res.status(200).json({
      user: userDetails,
      totalPages: totalPages,
      pageNo: pageNo,
    });
  } catch (error) {
    console.error("Error while getting users:", error);
    res.status(500).json({ message: "error while getting users" });
  }
};
