import user from "../model/user.js";
import admin from "../model/admin.js";
import admin from "../model/admin.js";

export const addUser = async (req, res) => {
  try {
    const { firstName, lastName, email } = req.body;
    const { id } = req.params;

    const existadmin=await admin.findById(id)
    if(!existadmin){
        return res.status(400).json({message:"Not found"});
    }
    const newuser=new user({
        firstName,
        lastName,
        email
    });

    await newuser.save();
    const newAdmin=await admin.findByIdAndUpdate(id,{
        $push:{
            users:newuser
        }
    })

    res.status(200).json({message:"user added"});

  } catch (error) {}
};
