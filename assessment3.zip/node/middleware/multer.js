const multer = require("multer");
const path = require("path");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./images");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const filefilter = (req, file, cb) => {
  const filetype = ["image/jpg", "image/png", "image/jpeg"];
  if (!filetype.includes(file.mimetype)) {
    return cb(new Error("this file type not allow"));
  }
  cb(null, true);
};

const middlewareUpload = multer({
  storage: storage,
  fileFilter: filefilter,
  limit: { filesize: 5 * 1024 * 1024 },
});

module.exports={middlewareUpload};