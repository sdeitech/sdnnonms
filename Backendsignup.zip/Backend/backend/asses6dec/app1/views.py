from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_200_OK
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from .serializer import ProductSerializer
from .models import Products
from django.contrib.auth.hashers import make_password
from .models import CustomUser



# Create your views here.

class GetAllProduct(APIView):
    def get(self, request):
        try:
            products = Products.objects.all()
            serializer = ProductSerializer(products, many=True)
            return Response(serializer.data)
        except:
            context = {'error': 'No Data Found'}
            return Response(context, status=HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            data = request.data
            title = data.get('title')
            desc = data.get('desc')
            price = data.get('price')
            image = data.get('img')
            Products.objects.create(title=title, description=desc, price=price, image=image)
            context = {'msg': 'Product Added Successfully'}
            return Response(context, status=HTTP_200_OK)
        except:
            context = {'error': 'Error: Something Went Wrong'}
            return Response(context, status=HTTP_400_BAD_REQUEST)

class SignUp(APIView):
    def post(self, request):
        try:
            data = request.data
            email = data.get('email')
            first_name = data.get('first_name')
            last_name = data.get('last_name')
            address = data.get('address')
            postal_code = data.get('postal_code')
            contact_number = data.get('contact_number')
            password = data.get('password')

            # Validation
            if not email or not first_name or not last_name or not address or not postal_code or not contact_number or not password:
                return Response({'error': 'All fields are required'}, status=HTTP_400_BAD_REQUEST)

            if CustomUser.objects.filter(email=email).exists():
                return Response({'error': 'Email already exists'}, status=HTTP_400_BAD_REQUEST)

            # Hash the password before saving
            hashed_password = make_password(password)

            # Create new user without UserManager
            user = CustomUser.objects.create(
                email=email, first_name=first_name, last_name=last_name, 
                address=address, postal_code=postal_code, contact_number=contact_number, 
                password=hashed_password
            )

            return Response({'msg': 'User Registered Successfully'}, status=HTTP_200_OK)
        
        except Exception as e:
            return Response({'error': str(e)}, status=HTTP_400_BAD_REQUEST)


class Login(APIView):
    def post(self, request):
        try:
            data = request.data
            email = data.get('email')
            password = data.get('password')

            # Validation
            if not email or not password:
                return Response({'error': 'Email and Password are required'}, status=HTTP_400_BAD_REQUEST)

            # Authenticate user
            user = authenticate(username=email, password=password)
            print("success")
            print(user)
            if user is not None:
                print()
                return Response({'msg': 'Login Successful'}, status=HTTP_200_OK)
            else:
                return Response({'error': 'Invalid Credentials'}, status=HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=HTTP_400_BAD_REQUEST)
