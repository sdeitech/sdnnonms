from .views import *
from django.urls import path

urlpatterns = [
    path('products/',GetAllProduct.as_view(),name = 'getallproducts'),
    path('signup/', SignUp.as_view(), name='signup'),
    path('login/', Login.as_view(), name='login'),
]
