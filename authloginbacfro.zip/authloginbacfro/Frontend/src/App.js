//import logo from './logo.svg';
import './App.css';
import Form from './component/Form'
import Register from './component/RegisterForm';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import {Navbar} from './component/Navbar'



export default function App() {
  return (
    <BrowserRouter>
    <Navbar/>
      <Routes>
      {/* <Route path="/" element={<Home />} /> */}
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Form />} />
          {/* <Route path="*" element={<NoPage />} /> */}
        
      </Routes>
    </BrowserRouter>
  );
}



