import '../styles/Navbar.css'

import { Link } from "react-router-dom";


export const Navbar = () => {

    return (
        <>
            <div className='navbar'>
                <Link to="/"><h3 className='tab'>Home</h3></Link>
                <Link to="/register"><h3 className='tab'>Register</h3></Link>
                <Link to="/login"><h3 className='tab'>Login</h3></Link>
            </div>
        </>
    )
}

