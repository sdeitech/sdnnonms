const express = require ('express');
const { connectToMongo } = require("./database/db.js");
const router = express.Router();
const userroute = require ("./routes/userRoute.js")
const cors = require ('cors')
const bodyParser = require ('body-parser')

const app = express();
const PORT = 7365;

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

app.use(cors());


app.use(express.json());

app.use("/api", userroute);

// app.post("/register",(req,res){{}}
//     res.json({message:succced});
// })
// pp.post("/users", (req, res) => {
//     //app.push(req.body);
//     res.json({ message: "hi" })
// })

// app.post("/register",(req, res)=>{
//     res.json({message:"hi"})
// })



connectToMongo();
app.listen(PORT, ()=>{
    console.log(`Server is running on ${PORT}`);
})