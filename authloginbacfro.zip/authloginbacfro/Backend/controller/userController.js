const Users = require("../models/userModel");
const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken')

exports.createUser = async (req, res) => {
console.log("first",req.body)
  //taking username and password from db 
  const { Username, Password } = req.body
  try {
    console.log(Username)

    //checking the old user already exist or not 
    const olduser = await Users.findOne({ Username: Username })
    console.log(olduser)
    if (olduser) {
      return res.status(201).json({ msg: "user already exist" })
    }

    //if user not exist then it will create new user and save it

    const securepass = await bcrypt.hash(Password, 10);
    req.body.Password = securepass;
    const newUser = new Users(req.body);
    await newUser.save();
    return res.status(201).json({
      status: 201,
      message: "User created succedd",
      user: newUser,
    });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message, message: "failed to register" });
  }



  // const token = jwt.sign({userId:"66f403749b06362a6192bf0d"},'secret_key',{expiresIn:'2hr'});

  // jwt.verify(token, 'secret_key', (err, decodedToken) => {
  //   if (err) {
  //     console.error('Token verification failed');
  //   } else {
  //     console.log('Decoded token:', decodedToken);
  //   }
  // });

  // const token = jwt.sign(
  //   { newUser_id: newUser._id, Password },
  //   process.env.TOKEN_KEY,
  //   {
  //     expiresIn: "5h",
  //   }
  // );

  // // save user token
  // user.token = token;

  // // user
  // return res.status(200).json(user);
}

exports.loginUser = async (req, res) => {

  const { Username, Password } = req.body
  if (!Username && !Password) {
    return res.status(400).json({
      message: "all field are mandatory",
      status: 400
    })
  }
  try {
    const user = await Users.findOne({ Username: Username })
    console.log(user)
    if(!user){
      return res.status(400).json({message:"User not exist"})
    }

    const correct = await bcrypt.compare(Password ,user.Password)
    console.log(Password);
    console.log(user);
    
    

    if(correct){

      const token = jwt.sign({Username},"ykugfkjbtkufgkjhfkjv" ,{ expiresIn:'1hr'})

      return res.status(200).json({message:"token generated succed",token:token})
      
    }

  } catch (error) {

    res.status(400).json({message:"login Faild" , error : error.message})
  }


}


