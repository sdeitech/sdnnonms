const express = require('express');
const demo = express.Router();

const Info = require ("../controller/userController")

demo.post('/register',Info.createUser);
demo.post('/login',Info.loginUser)

module.exports = demo;