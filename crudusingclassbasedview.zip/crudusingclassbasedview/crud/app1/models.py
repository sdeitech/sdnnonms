
from django.db import models
from django.contrib.auth.hashers import check_password
# from django import forms

# Create your models here.
class crudUser(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    age = models.IntegerField(max_length=30)
    gender = models.CharField(max_length=30)
    
    
class Registration(models.Model):
    first_name=models.CharField(max_length=40)
    last_name=models.CharField(max_length=40)
    age = models.IntegerField()
    gender=models.CharField(max_length=10)
    email=models.EmailField(unique=True)
    password = models.CharField(max_length=255)# Store hashed password
    profile=models.FileField(default=0)
       
    
    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return f"{self.first_name} {self.last_name} "      