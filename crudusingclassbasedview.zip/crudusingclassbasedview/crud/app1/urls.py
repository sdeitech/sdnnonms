from django.urls import path
from . import views

urlpatterns = [

    path('', views.postGet.as_view(),name='create'),
    path('dashboard/', views.getdata.as_view(),name='dashboard'),
    path('delete/<int:id>', views.delete.as_view(),name='delete'),
    path('update/<int:id>', views.update.as_view(),name='update'),
    
    
    path('register/', views.register.as_view(),name='register'),
    
    
    
    

]
