from django.shortcuts import render,redirect
from django.views import View
from .models import crudUser,Registration
from django.contrib.auth.hashers import make_password,check_password


class postGet(View):
    def get(self, request):
        return render(request,'index.html')
    
    def post(self,request):
        data=request.POST
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        age=data.get('age')
        gender=data.get('gender')
        dob = request.POST.get('dob')
        is_passed = request.POST.get('is_passed')
     
        if is_passed == "on":
         is_passed = True
        else:
         is_passed = False
         
        newUser=crudUser.objects.create(
            first_name=first_name,
            last_name=last_name,
            age=age,
            gender=gender,  
            dob = dob,
            is_passed = is_passed
           
        )
        newUser.save()
        return redirect("/dashboard")
        
       
        
class getdata(View):
    def get(self,request):
        allUser=crudUser.objects.all()
        context = {"users" : allUser}
        return render(request,'dashboard.html',context)
        
         
    
    
class delete(View):
    def get(self,request,id):
        print("delete")
        crudUser.objects.get(id=id).delete()
        return redirect('/dashboard')
            
class update(View):
    def get(self,request,id):
        print("update")
        users = crudUser.objects.get(id=id)
        date = str(users.dob)
        print(date)
        return render(request,'update.html',{'update':users,'date':date})
    
    def post(self,request,id):
          data=request.POST
          first_name=data.get('first_name')
          last_name=data.get('last_name')
          age=data.get('age')
          gender=data.get('gender')
          dob = request.POST.get('dob')
          is_passed = request.POST.get('is_passed')
          
          newuser=crudUser.objects.get(id=id)
          
          
          newuser.first_name = first_name
          newuser.last_name = last_name
          newuser.age=age
          newuser.gender =gender
          newuser.dob =dob
          newuser.is_passed =is_passed
          if is_passed == "on":
            newuser.is_passed = True
          else:
             newuser.is_passed = False
      
          
          newuser.save()

          return redirect('/dashboard')    
          
        
class register(View):
    def get(self,request):
        allUser=Registration.objects.all()
        context = {"users" : allUser}
        return render(request,'register.html',context)
    
    
    def post(self,request):
        data=request.POST
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        age=data.get('age')
        gender=data.get('gender')
        email=data.get('email')
        password=data.get('password')
        profile=data.get('profile')
        
        newRegiter=Registration.objects.create(
            first_name=first_name,
            last_name=last_name,
            age=age,
            gender=gender,
            email=email,
            password=make_password(password),
            profile=profile
        )
        newRegiter.save()
        return redirect('login')
   
    

    
        
   
   
 
   
      
    
    

 
      
   
  
           
        
        
           
   