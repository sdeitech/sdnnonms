import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

const PrivateLayout = () => {
    const navigate = useNavigate()
    const token = localStorage.getItem("token")

    useEffect(() => {
        if (!token) {
            navigate("/")
        }
    })
    return (
        <div>PrivateLayout</div>
    )
}

export default PrivateLayout