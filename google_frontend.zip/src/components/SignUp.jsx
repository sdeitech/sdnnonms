import React from 'react'
import { useNavigate } from 'react-router-dom'

const SignUp = () => {

    const navigate = useNavigate()

    const handleSubmit = (e) => {
        navigate("login")
    }
    return (
        <div>
            <div>
                <form onSubmit={handleSubmit} >
                    <input type="text" />
                    <button type='submit'>submit</button>
                </form>
            </div>
            <div>

            </div>
        </div>
    )
}

export default SignUp