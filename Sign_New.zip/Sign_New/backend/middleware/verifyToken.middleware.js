/**
 * Importing essential packages
 */
const jwt = require("jsonwebtoken");
const {
  FORBIDDEN,
  ACCESS_DENIED,
  UNAUTHORIZED,
  NOT_FOUND,
} = require("../config/constants");

/**
 * To verify tokens
 */
const verifyToken = (req, res, next) => {
  try {
    const token = req.header("Authorization")?.split(" ")[1];

    if (!token) {
      return res.status(FORBIDDEN).json({ message: ACCESS_DENIED });
    }

    const verified = jwt.verify(token, "This_is_key : ");
    console.log(verified);

    if (!verified) {
      return res.status(NOT_FOUND).json({ msg: "Access Denied" });
    }
    next();
  } catch (error) {
    res.status(UNAUTHORIZED).json({ error: error.message });
  }
};

module.exports = verifyToken;
