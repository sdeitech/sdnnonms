const Header = () => {
  return (
    <>
      <header
        style={{ backgroundColor: "#282c34", padding: "10px", color: "white" }}
      >
        User Management
      </header>
    </>
  );
};

export default Header;
