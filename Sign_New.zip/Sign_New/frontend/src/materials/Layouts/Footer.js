const Footer = () => {
  return (
    <>
      <footer
        style={{
          backgroundColor: "#282c34",
          padding: "10px",
          color: "white",
          marginTop: "auto",
        }}
      >
        Footer
      </footer>
    </>
  );
};

export default Footer;
