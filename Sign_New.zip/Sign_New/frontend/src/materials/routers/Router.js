import { createBrowserRouter } from "react-router-dom";
import ProtectedRoute from "../routers/ProtectedRoute";
import SignUp from "../modules/SignUp/SignUp";
import Login from "../modules/SignIn/SignIn";
import TableView from "../../components/TableView";
import Layout from "../Layouts/Layout";

const routers = createBrowserRouter([
  {
    path: "/",
    exact: true,
    element: (
      <Layout>
        <Login />
      </Layout>
    ),
  },
  {
    path: "/signUp",
    exact: true,
    element: (
      <Layout>
        <SignUp />
      </Layout>
    ),
  },
  {
    path: "/table",
    exact: true,
    element: (
      <Layout>
        <ProtectedRoute>
          <TableView />
        </ProtectedRoute>
      </Layout>
    ),
  },
]);

export default routers;
