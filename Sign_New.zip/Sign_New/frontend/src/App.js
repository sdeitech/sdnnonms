import "./App.css";
// import SignIn from "./materials/modules/SignIn/SignIn";
import Routers from "../src/materials/routers/Router";
import { RouterProvider } from "react-router-dom";
// import SignUp from "./materials/modules/SignUp/SignUp";

function App() {
  return (
    <div className="App">
      <div>
        <RouterProvider router={Routers} />
        {/* <SignIn />
        <SignUp /> */}
      </div>
    </div>
  );
}

export default App;
