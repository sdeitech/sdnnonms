import mongoose from "mongoose";

const userDataSchema = mongoose.Schema(
    {
        firstname: {
            type: String,
            required: true,
          },
          lastname: {
            type: String,
            required: true,
          },
          email: {
            type: String,
            required: true,
            unique: true,
          },

    },
);

const userDataModel =mongoose.model("userData",userDataSchema);

module.exports=userDataModel;