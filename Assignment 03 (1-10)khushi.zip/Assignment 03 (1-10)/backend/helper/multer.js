import multer from "multer";
import path from "path";
import { messages } from "../config/constants"; // Adjust path as necessary

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./profile_picture"); // Ensure this directory exists
  },
  filename: function (req, file, cb) {
    console.log(file);
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = ["image/png", "image/jpeg", "image/jpg"];
  if (
    !allowedTypes.includes(file.mimetype) &&
    allowedTypes.length(5 * 1024 * 1024)
  ) {
    return cb(new Error(messages.imageType)); // Adjust error message as needed
  }
  cb(null, true);
};

export const uploadMiddleware = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // Optional: limit file size to 5MB
});