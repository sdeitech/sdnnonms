
import express from "express";
import userController from "../controller/userController.js";
import verifyToken from "../middleware/viewToken.middleware.js";
import { uploadimage } from "../controller/userController.js";
import { uploadMiddleware } from "../helper/multer.js";

const router = express.Router();



// For Creating, Reading, Updating, and Deleting (CRUD)
router.get("/api", userController.getUser);
router.get("/api/:id", verifyToken, userController.getUserById);
router.post("/api", userController.createUser);
router.put("/api/:id", verifyToken, userController.updateUser);
router.delete("/api/:id", verifyToken, userController.deleteUser);

//for creating new model
router.post("/api/useData/:id", userController.newUserStorage);

// For Login
router.post("/api/login", userController.loginUser);

// For Multer
router.post("/image", uploadMiddleware.single("image"), uploadimage);


export default router;
