import React, { useEffect } from "react";
import { useNavigate } from "react-router";

const PrivateLayout = ({ children }) => {

    return (
        <>
        <div className="layout">
            <div className="content">
                {children}
            </div>
        </div>
        
        </>
    );
};

export default PrivateLayout;