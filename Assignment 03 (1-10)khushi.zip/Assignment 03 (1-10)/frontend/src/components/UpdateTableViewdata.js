import { useState, useEffect } from "react";
import { Button, Form, Modal } from "react-bootstrap";
import axios from "axios";

// Main Function Components having props in it
function UpdateRecordModal({
  handleUpdateShow,
  handleUpdateClose,
  data,
  onUpdate,
}) {
  /**
   * Initialization of Props for editing
   */
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    
  });

  console.log(data);

  useEffect(() => {
    if (data) {
      // Pre-fill the form with current data when modal is opened
      setFormData({
        firstName: data?.firstName,
        lastName: data?.lastName,
        email: data?.email,
       
      });
    }
  }, [data]);

  // For Input Handler
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  /**
   * To submit Data after updation
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      // Send updated data to the backend
      await axios.put(
        `http://localhost:5000/user/api/${data?._id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`, 
          },
        }
      );
      // Call onUpdate to refresh the table data after successful update
      onUpdate();
      handleUpdateClose();
    } catch (error) {
      console.error("Error updating the record:", error);
    }
  };

  return (
    <>
      <Modal
        show={handleUpdateShow}
        onHide={handleUpdateClose}
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Update Record</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formFirstName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter First Name"
                name="firstName"
                value={formData?.firstname}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formlastname">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Last Name"
                name="lastName"
                value={formData?.lastname}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formemail">
              <Form.Label>email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter Email"
                name="email"
                value={formData?.email}
                onChange={handleInputChange}
              />
            
            </Form.Group>
            <Button variant="warning" type="submit">
              Update
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default UpdateRecordModal;