import React, { useState, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import axios from "axios";

const MyProfile = () => {
  const [ProfileData, setProfileData] = useState({});
  const [loading, setLoading] = useState(false);

  const initialState = {
    firstname: "",
    lastname: "",
    email: "",
    dob: "",
    marriedStatus: false,
    gender: "",
  };

  const [formData, setFormData] = useState(initialState);

  useEffect(() => {
    const fetchProfileData = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get("http://localhost:5000/user/api", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProfileData(response.data);
        setFormData(response.data);
      } catch (error) {
      } finally {
        setLoading(false);
      }
    };

    fetchProfileData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      await axios.get(`http://localhost:5000/user/api/getReport`, formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (error) {
      console.error("Failed to update profile.", error.message);
    } finally {
      setLoading(false);
    }
  };


  return (
    
      <Form onSubmit={handleProfileUpdate} encType="multipart/form-data">
        {Object.entries(formData).map(([key, value]) => (
          <Form.Group key={key} className="mb-3" controlId={`form${key.charAt(0).toUpperCase() + key.slice(1)}`}>
            <Form.Label>{key.charAt(0).toUpperCase() + key.slice(1)}</Form.Label>
            {key === "gender" ? (
              <Form.Control as="select" name={key} value={value} onChange={handleInputChange}>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </Form.Control>
            ) : (
              <Form.Control
                type={key === "dob" ? "date" : key === "email" ? "email" : "text"}
                placeholder={`Enter ${key.charAt(0).toUpperCase() + key.slice(1)}`}
                name={key}
                value={value}
                onChange={handleInputChange}
              />
            )}
          </Form.Group>
        ))}

        <Button variant="warning" type="submit" disabled={loading}>
          {loading ? "Updating..." : "Update"}
        </Button>
      </Form>
  );
};

export default MyProfile;
