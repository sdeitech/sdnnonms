import axios from "axios";
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "../App.css";


const SignUp = () => {
  const [data, setData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    DOB:"",
    gender: "",
    marriedStatus: "",
    password:""
  });
  const navigate =useNavigate();

  const changeHandle = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };
  // setdata((prevData) => ({
  //   ...prevData,
  //   [name]: type === "checkbox" ? checked : value,
  // }));

  const onSubmitHandle = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/user/api", data);

      localStorage.setItem("token", response.data.token);
      console.log(response.data.token)
      navigate("/dashbord");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div>
        <h2 className="App-header">Signup form</h2>
      </div>
      <form onSubmit={onSubmitHandle}>
        <div>
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter firstname"
            name="firstname"
            onChange={changeHandle}
          />
          <input
            className="w3-input w3-border"
            type="text"
            placeholder="Enter lastname"
            name="lastname"
            onChange={changeHandle}
          />
           <input
             className="w3-input w3-border"
            type="text"
            placeholder="Enter the email"
            name="email"
            onChange={changeHandle}
          />
           <input
             className="w3-input w3-border"
            type="text"
            placeholder="Enter the date of birth"
            name="DOB"
            onChange={changeHandle}
          />
           <input
             className="w3-input w3-border"
            type="checkbox"
            name="marriedStatus"
            checked={data.marriedStatus}
            onChange={changeHandle}
          />
             <label   className="w3-input w3-border"> Married</label>
          <br />
          <label>Male</label>
          <input
            className="w3-input w3-border"
            type="radio"
            name="gender"
            checked={data.gender === "Male"}
            onChange={changeHandle}
          />
          <label>Female</label>
          <input
            className="w3-input w3-border"
            type="radio"
            name="gender"
            checked={data.gender === "Female"}
            onChange={changeHandle}
          />

          <input
            className="w3-input w3-border"
            type="password"
            placeholder="Enter the password"
            name="password"
            onChange={changeHandle}
          />
         <div>
        <input type="radio" value="Male" name="gender" /> Male
        <input type="radio" value="Female" name="gender" /> Female
        <input type="radio" value="Other" name="gender" /> Other
        </div>
        </div>
        <button type="submit">Submit</button>
        <Link to="/">Already User?</Link>
      </form>
    </>
  );
};

export default SignUp;