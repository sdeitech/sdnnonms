import logo from './logo.svg';
import './App.css';
import ProductCrud from './Components/Product-Crud';

function App() {
  return (
    <div className="App">
      <ProductCrud></ProductCrud>
    </div>
  );
}

export default App;
