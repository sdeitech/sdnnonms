import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from 'axios'
import { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { TextField } from '@mui/material';

export default function ProductCrud() {

    const [data, setData] = useState([])
    const [error, setError] = useState(null)

    const [productInput, setProductInput] = useState({
        productName: '',
        productDesc: '',
        price: '',
        quantity: ''
    })

    const [products, setProduct] = useState([])
    const [isEditing, setIsEditing] = useState(false)
    const [editProductId, setEditProductId] = useState(null)
    const [editError, setEditError] = useState(null)

    const [deleteError, setDeleteError] = useState(null)

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:3007/api/product');
            console.log(response.data)
            setData(response.data);
            setError(null);
        } catch (error) {
            setData([]);
            setError('Failed to fetch data.');
        } finally {
        }
    };

    console.log("fetchData ----------", fetchData)

    useEffect(() => {
        fetchData();
    }, []);

    
    const handleSubmit = async (event) => {
        event.preventDefault();
        console.log('-----productInput-----', productInput);

        if (isEditing) {

            try {
                const response = await axios.put(`http://localhost:3007/api/product/${editProductId}`, productInput)
                setProduct(products.map(product => (product._id === editProductId ? response.data : product)))
                setIsEditing(false)
                setEditProductId(null)
                setProductInput({ productName: '', productDesc: '', price: '', quantity: '' })
            } catch (error) {
                setEditError('Failed to update data')
            }
        } else {
            event.preventDefault()
            console.log(productInput)

            axios({
                method: 'post',
                url: `http://localhost:3007/api/product`,
                data: productInput,
            }).then(function (response) {
                console.log(response)
                console.log("added Sucessfully")

            }).catch(function (error) {
                console.log(error)
            })
        }
    }

    const onDeleteHandler = async (deleteId) => {
        try {
            await axios.delete(`http://localhost:3007/api/product/${deleteId}`)
            setData(prevData => prevData.filter(item => item._id !== deleteId))
            setDeleteError(null)
        } catch (error) {
            setDeleteError('Failed to delete data')
        }
    }

    const onUpdateHandler = async (productId) => {
        try {
            setIsEditing(true)
            const response = await axios.get(`http://localhost:3007/api/product/${productId}`, )
            const productData = response.data
            setEditProductId(productData._id)
            setProductInput({
                productName: productData.productName,
                productDesc: productData.productDesc,
                price: productData.price,
                quantity: productData.quantity
            })
        } catch (error) {
            console.log('error fetching product details', error)
        }
    }

    console.log('----isEditing-----',isEditing)

    return (
        <>
            <h1>Product Management</h1>
            
            <br></br>
            <form onSubmit={handleSubmit}>

                <h1>Add Product Form</h1>
                <TextField
                    id="productName"
                    name='productName'
                    label="Product Name"
                    variant="outlined"
                    value={productInput.productName}
                    onChange={event => {setProductInput({ ...productInput, productName: event.target.value })}}
                    required
                />

                <TextField
                    id='productDesc'
                    name=''
                    label='Product Description'
                    value={productInput.productDesc}
                    onChange={event => {setProductInput({ ...productInput, productDesc: event.target.value })}}
                    required
                />

                <TextField
                    id='price'
                    label='Price'
                    value={productInput.price}
                    onChange={event => {setProductInput({ ...productInput, price: event.target.value })}}
                    required
                />

                <TextField
                    id='quantity'
                    label='Quantity'
                    value={productInput.quantity}
                    onChange={event => {setProductInput({ ...productInput, quantity: event.target.value }); }}
                    required
                />

                <Button variant='outlined' color='secondary' type='submit'>
                    {isEditing ? 'Edit Product' : "Add Product"}
                </Button>
            </form>
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Product Name</TableCell>
                            <TableCell align="right">Product Description</TableCell>
                            <TableCell align="right">Price&nbsp;</TableCell>
                            <TableCell align="right">Quantity&nbsp;</TableCell>
                            <TableCell align="right">Action&nbsp;</TableCell>

                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.map((row) => (
                            <TableRow
                                key={row._id}
                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                            >
                                <TableCell component="th" scope="row">
                                    {row.productName}
                                </TableCell>
                                <TableCell align="right">{row.productDesc}</TableCell>
                                <TableCell align="right">{row.price}</TableCell>
                                <TableCell align="right">{row.quantity}</TableCell>
                                <TableCell align="right">
                                    <Button onClick={(e) => onUpdateHandler(row._id)}>Edit</Button>
                                </TableCell>

                                <TableCell align="right">
                                    <Button onClick={(e) => onDeleteHandler(row._id)}>Delete</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </>
    );
}
