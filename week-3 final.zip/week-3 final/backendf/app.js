
const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const profileRouter = require('./routes/profileRoute')
const db = require('./config/db');
// import fileuploadroute from './routes/profileRoute';
const app = express();

app.use(cors({ origin: "*" }));

app.use(express.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }));


app.use("/getimg", express.static("profile_picture"));

app.use(bodyParser.json({ limit: "50mb" }));

app.use('/api', profileRouter);
// app.use('/api', fileuploadroute)

export default app;
