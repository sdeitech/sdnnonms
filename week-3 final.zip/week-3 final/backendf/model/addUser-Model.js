const mongoose = require('mongoose');


const addUserSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: {type: String, required: true},
    userId : {type : mongoose.Schema.Types.ObjectId, ref: 'User'}
});

const UserList = mongoose.model('UserList', addUserSchema);

module.exports = UserList;

