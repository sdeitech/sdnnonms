
const UserList = require('../model/addUser-Model')


const createUser = async (req, res) => {
    try {
        const { firstName, lastName, email} = req.body;
        const userId = req.user.userId

        console.log('userId',userId)
        const user = new UserList({
            firstName : firstName,
            lastName : lastName,
            email : email,
            userId : userId
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

const getUserById = async (req, res) => {
    try {
        const id  = req.params.id
        const user = await UserList.findById(id)
        console.log(user)
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}

const getUser = async (req, res) => {
    try {
        const { searchText } = req.query;
        const userId = req.user.userId
        let filter = {};

        filter.userId = userId;

        if (searchText) {
            filter = {
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        console.log(filter)

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 2;
        const skip = (page - 1) * limit;

        const users = await UserList.find(filter)
            .select('firstName lastName email password married dateofBirth gender userId')
            .skip(skip)
            .limit(limit);
        const totalCount = await UserList.countDocuments(filter);

        const response = {
            users: users,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: "Internal Server Error" });
    }
};


const deleteUser = async(req,res) => {
    try{
        const deletedUser = await UserList.findByIdAndDelete(req.params.id);
        if(!deletedUser) return res.status(404).json({message: 'user not found'});
            res.status(204).send();
            res.status(200).json(response);
    } catch(error){
        res.status(500).json({message: error.message});
    }
}

module.exports = { createUser, getUser, deleteUser, getUserById };