const User = require('../model/user-Model')
const bcrypt = require("bcryptjs");
import jwt from "jsonwebtoken";

const registerUser = async (req, res) => {
    try {
        const { firstName, email, password, lastName, married, gender, dateofBirth } = req.body;
        console.log(req.body);

        if (!firstName || !email || !password) {
            return res.status(400).json({ Error: "Missing required fields" });
        }

        const profile = req.file?.filename;
        let hashed;

        try {
            hashed = await bcrypt.hash(password, 10);
        } catch (hashError) {
            return res.status(500).json({ Error: "Password hashing failed" });
        }

        const user = new User({
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: hashed,
            dateofBirth: dateofBirth,
            married: married,
            gender: gender,
            photo: profile,
        });

        await user.save();
        res.status(200).json(user);
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (isMatch) {
            const token = jwt.sign({ email,  password, userId: user._id }, "an123idjk", { expiresIn: "8h" });

            return res.status(200).json({ message: "Logged In", token , 'userId' : user._id});
        } else {
            return res.status(401).json({ message: "Incorrect Credentials" });
        }
    } catch (error) {
        res.status(500).json({ Error: error.message });
    }
};

const getUserById = async (req, res) => {
    try {
        const id  = req.params.id
        const user = await User.findById(id)
        console.log(user)
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}


const updateUserById = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};


module.exports = { registerUser, loginUser ,getUserById, updateUserById};