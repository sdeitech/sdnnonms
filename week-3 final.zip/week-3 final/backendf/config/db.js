// import mongoose from "mongoose";
// import 'dotenv/config'
// const config = require("./config")
// const { DB } = config.config


// var options = {
//     user: DB.USERNAME,
//     pass: DB.PASSWORD,
// }
// /**
//  * @type {string}
//  */
// // const MONGOURI= `mongodb://${DB.HOST}:${DB.PORT}/${DB.DATABASE}`

// const MONGOURI = `mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false`


// export const initiateMongoConnection = async()=>{
//     try{
//         await mongoose.connect(MONGOURI,options);
//         console.log("Connected to Database");
//     } catch(e){
//         throw e
//     }
// }

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open',() => {
    console.log('connected successfully');
})
module.exports = db;