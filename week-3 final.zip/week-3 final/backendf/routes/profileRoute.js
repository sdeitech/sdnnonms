const express = require('express');
const router = express.Router();
import {fileMiddleware} from '../helper/fileUpload'

import profileController from  '../controller/profileController';
import profileDetailController from '../controller/profileDetailController';
import { verifyToken } from '../middleware/verifyToken';

router.post('/register',[fileMiddleware.single('photo')], profileController.registerUser)
router.post('/login', profileController.loginUser)
router.get('/getUser/:id', profileController.getUserById)
router.put('/updateUser/:id', profileController.updateUserById)


router.get('/user', verifyToken, profileDetailController.getUser);
router.post('/create',verifyToken, profileDetailController.createUser);
router.delete('/user/:id', profileDetailController.deleteUser);
router.get('/user/:id', profileDetailController.getUserById);



module.exports = router;