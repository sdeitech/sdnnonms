import React, {useEffect} from "react"
import { useNavigate } from "react-router-dom"

const PrivateLayout = ({children}) => {
    let token = "absdlkjsfdlkjlskdfj"
    let navigate = useNavigate();

    useEffect(() => {
        if(!token){
            navigate("/login");
        }
    }, [token,navigate]);

    return (
        <div>
            <div>
                {children}
            </div>
        </div>
    );
};
export default PrivateLayout;