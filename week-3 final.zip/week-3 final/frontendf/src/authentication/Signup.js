import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import FormControlLabel from '@mui/material/FormControlLabel';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import './signup.css';
import Checkbox from '@mui/material/Checkbox';  

export default function SignUp() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    dateofBirth: '',
    password: '',
    married: false,  
    gender: '',
    photo : ''
  });
  const [error, setError] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,  
    }));
    setFormErrors((prevErrors) => ({ ...prevErrors, [name]: null }));
  };

  const validateForm = () => {
    const errors = {};
    const { firstName, lastName, email, dateofBirth, password, married, gender } = formData;

    if (!firstName) {
      errors.firstName = 'First Name is required';
    }
    if (!lastName) {
      errors.lastName = 'Last Name is required';
    }
    if (!dateofBirth) {
      errors.dateofBirth = 'Date of Birth is required';
    }
    if (!gender) {
      errors.gender = 'Gender is required';
    }
    if (married === '') {
      errors.married = 'Marital status is required';
    }
    if (!email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email address is invalid';
    }
    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    return errors;
  };


  const handleFileChange = (e) => {
    const file = e.target.files[0]
    console.log(file , "fdkgvnsdjkl");
    
      setFormData((prevData) => ({
          ...prevData,
          photo : file
      }));
  };

  const handleSubmit = async () => {
    const data = new FormData();
        Object.keys(formData).forEach(key => {
          if (key === 'photo') {
            data.append(key, formData[key]);
          } else {
            data.append(key, formData[key]); 
          }
        });
         console.log(data , "data")
        console.log("formdatadata);", data)
        try {
            const response = await axios.post('http://localhost:5000/api/register', data);
            navigate('/');
            console.log('SignUp successful:');
        } catch (err) {
            setError('Login failed. Please check your credentials.');
        }
  }

  return (
    <form onSubmit={handleSubmit}> 
      <Box
        sx={{ '& .MuiTextField-root': { m: 1, width: '25ch' } }}
        noValidate
        autoComplete="off"
      >
        <h1>Sign Up</h1>

        <div>
          <TextField
            required
            label="First Name"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          {formErrors.firstName && <p style={{ color: 'red' }}>{formErrors.firstName}</p>}
        </div>

        <div>
          <TextField
            required
            label="Last Name"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          {formErrors.lastName && <p style={{ color: 'red' }}>{formErrors.lastName}</p>}
        </div>

        <div>
          <TextField
            required
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
          />
          {formErrors.email && <p style={{ color: 'red' }}>{formErrors.email}</p>}
        </div>

        <div>
          <TextField
            required
            name="dateofBirth"
            type="date"
            value={formData.dateofBirth}
            onChange={handleChange}
          />
          {formErrors.dateofBirth && <p style={{ color: 'red' }}>{formErrors.dateofBirth}</p>}
        </div>

        <div>
          <TextField
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
          />
          {formErrors.password && <p style={{ color: 'red' }}>{formErrors.password}</p>}
        </div>

        <div>
          <FormControl>
            <FormControlLabel
              control={<Checkbox name="married" checked={formData.married} onChange={handleChange} />}
              label="Married"
            />
            <hr />
            <FormLabel>Gender</FormLabel>
            <RadioGroup
              aria-labelledby="gender-label"
              name="gender"
              value={formData.gender}
              onChange={handleChange}
            >
              <FormControlLabel value="female" control={<Radio />} label="Female" />
              <FormControlLabel value="male" control={<Radio />} label="Male" />
              <FormControlLabel value="other" control={<Radio />} label="Other" />
            </RadioGroup>
          </FormControl>
        </div>

        <TextField
                    id="photo"
                    name="photo"
                    type="file"
                    // value={formData.photo}
                    onChange={handleFileChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    
                />

        <div className="container">
          <Stack spacing={5} direction="row" className="center">
            <Button type="submit" variant="contained">Sign Up</Button>
          </Stack>
        </div>

        <div className="text-center"> Have an account? <Link to="/login">Login</Link></div>
      </Box>
    </form>
  );
}