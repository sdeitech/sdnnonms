import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function ProfileDetail() {
  const params = useParams()
  const [data, setData] = useState([]);

  console.log(data)

  const fetchProfile = async (id) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/user/${id}`);
      console.log(response)
      setData(response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchProfile(params.id);
  }, [params.id]);


  return (
    <div>
      <h2>Profile Details</h2>
      <p><strong>First Name:</strong> {data.firstName}</p>
      <p><strong>Last Name:</strong> {data.lastName}</p>
      <p><strong>Email:</strong> {data.email}</p>
      
    </div>
  );
}

export default ProfileDetail;