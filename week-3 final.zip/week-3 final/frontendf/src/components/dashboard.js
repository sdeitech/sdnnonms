import React, { useState, useEffect } from 'react';
import { AppBar, Toolbar, Button, Box, TextField, Table, Pagination } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function Dashboard() {
  const [profile, setprofile] = useState([]);

  const user = localStorage.getItem('userId')
  console.log('user---------',user)

  const [editprofile, setEditprofile] = useState(null);
  const [searchText, setSearchText] = useState(""); 
  const [pagination, setPagination] = useState({
    total_record: 0,
    per_page: 8,
    current_page: 1,
    total_pages: 1,
  }); 

  const [error, setError] = useState(null);
  const navigate = useNavigate();

 
  const fetchUserData = async (page = 1) => {
    try {
      const token = localStorage.getItem('token'); 
      const response = await axios.get(
        `http://localhost:5000/api/user?page=${page}&searchText=${searchText}`,
        { headers: { Authorization: ` ${token}`,
        'Content-Type': 'application/json'
      } }
      );
      console.log(response.data);
      setprofile(response.data);
      setPagination({
        total_record: response.data.pagination.total_record,
        per_page: response.data.pagination.per_page,
        current_page: response.data.pagination.current_page,
        total_pages: response.data.pagination.total_pages,
      });
      setError(null);
    } catch (error) {
      setError('Failed to fetch data.');
    } 
  };
  
  useEffect(() => {
  
    fetchUserData(pagination.current_page);
  }, [pagination.current_page, searchText]);

  // Handle page 
  const handlePageChange = (event, value) => {
    setPagination((prevPagination) => ({
      ...prevPagination,
      current_page: value,
    }));
  };

  // Handle search 
  const handleSearch = () => {
    fetchUserData(1);
  };

  // Handle logout 
  const handleLogout = () => {
    localStorage.removeItem('token'); 
    navigate('/login'); 
  };

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    dateofBirth: '',
    married: false,  
    gender: '',
  });

  useEffect(() => {
    const fetchProfileData = async (user) => {
      try {
        const response = await axios.get(`http://localhost:5000/api/getUser/${user}`);
        console.log("Fetched profile data:", response.data); 
        setFormData(response.data);
      } catch (error) {
        setError("Failed to load profile data.");
        setFormData([])
      }
    };

    fetchProfileData([user]);
  }, [user]);

  return (
    <>
     <h3>Welcome {formData.firstName}</h3>

      <AppBar position="static">
        <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <h2 style={{ textAlign: 'center', flexGrow: 1 }}>Dashboard</h2>
          <Button color="inherit" onClick={() => navigate('/edit')}>
            My Profile
          </Button>
          <Button color="inherit" onClick={handleLogout}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>

     
      <Box sx={{ mt: 4, display: 'flex', justifyContent: 'space-between' }}>
      
        <Box sx={{ width: '25%', p: 1 }}>
          <TextField
            label="Search Users"
            variant="outlined"
            fullWidth
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            sx={{ mb: 2, ml: 1 }}
          />
          <Button  sx={{ mb: 2, mr: 40 }} variant="contained" color="primary" onClick={handleSearch}>
            Search
          </Button>
        </Box>

      
        <Box sx={{ width: '70%', p: 2 }}>
        
          <Link to="/add-user">
            <Button variant="contained" color="primary" sx={{ mb: 2, ml: 130 }}>
              Add User
            </Button>
          </Link>

          <div>
            <h2>Profile List</h2>
            <Table striped>
                <thead>
                    <tr>
                      <th>Sr. No. </th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {profile?.users?.length && profile?.users?.map((profile, index) => (
                        <tr key={profile.id}>
                            <td>{(pagination.current_page - 1) * pagination.per_page + index + 1}</td>
                            <td>{profile.firstName}</td>
                            <td>{profile.lastName}</td>
                            <td>{profile.email}</td>
                            <td>
                                <Link to={ `/detail/${profile._id}`}><Button className="me-2" >View </Button></Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
          </div>       
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Pagination
              count={pagination.total_pages}
              page={pagination.current_page}
              onChange={handlePageChange}
              color="primary"
            />
          </Box>
        </Box>
      </Box>
    </>
  );
}

export default Dashboard;