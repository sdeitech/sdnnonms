
import React, { useState } from 'react';
import axios from 'axios';

export default function FileUpload() {
    const [files, setFiles] = useState([]);
    const [uploadedFiles, setUploadedFiles] = useState([]);

    function handleMultipleChange(e) {
        setFiles([...e.target.files]);
    }

    async function handleMultipleSubmit(e) {
        e.preventDefault();
        const url = `http://localhost:5000/api/image`;
        const formData = new FormData();

        files.forEach((file, index) => {
            formData.append(`file${index}`, file);
        });

        const config = {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        };

        try {
            const response = await axios.post(url, formData, config);
            console.log(response.data);
            setUploadedFiles(response.data.files); 
        } catch (error) {
            console.error('Error uploading:', error);
        }
    }

    return (
        <div className="App">
            <form onSubmit={handleMultipleSubmit}>
                <h1>File Upload</h1>
                <input type="file" multiple onChange={handleMultipleChange} />
                <button type="submit">Upload</button>
            </form>
            <div>
                {uploadedFiles.map((file, index) => (
                    <img key={index} src={file} alt={`Uploaded content ${index}`} style={{ width: '100px', height: '100px' }} />
                ))}
            </div>
        </div>
    );
}
