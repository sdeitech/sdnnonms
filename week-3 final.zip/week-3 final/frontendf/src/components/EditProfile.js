import React, { useState, useEffect } from 'react';
import { Link, useParams, Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import FormControlLabel from '@mui/material/FormControlLabel';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Checkbox from '@mui/material/Checkbox';  

export default function EditProfile() {

  const user = localStorage.getItem('userId')
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    dateofBirth: '',
    married: false,  
    gender: '',
  });
  const [formErrors, setFormErrors] = useState({});
  const [error, setError] = useState(null); 

  useEffect(() => {
    const fetchProfileData = async (user) => {
      try {
        const response = await axios.get(`http://localhost:5000/api/getUser/${user}`);
        console.log("Fetched profile data:", response.data); 
        setFormData(response.data);
      } catch (error) {
        setError("Failed to load profile data.");
        setFormData([])
      }
    };

    fetchProfileData([user]);
  }, [user]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,  
    }));
    setFormErrors((prevErrors) => ({ ...prevErrors, [name]: null }));
  };

  const validateForm = () => {
    const errors = {};
    const { firstName, lastName, email, dateofBirth, married, gender } = formData;

    if (!firstName) {
      errors.firstName = 'First Name is required';
    }
    if (!lastName) {
      errors.lastName = 'Last Name is required';
    }
    if (!dateofBirth) {
      errors.dateofBirth = 'Date of Birth is required';
    }
    if (!gender) {
      errors.gender = 'Gender is required';
    }
    if (married === '') {
      errors.married = 'Marital status is required';
    }
    if (!email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email address is invalid';
    }
    
    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setFormErrors(validationErrors);
      return;
    }

    try {
      await axios.put(`http://localhost:5000/api/updateUser/${user}`, formData);
      navigate('/dashboard')
    } catch (error) {
      console.error('Error updating profile', error);
      setError("Failed to update profile.");
    }
  };

  return (
    <form onSubmit={handleSubmit}> 
      <Box
        sx={{ '& .MuiTextField-root': { m: 1, width: '25ch' } }}
        noValidate
        autoComplete="off"
      >
        <h1>Edit Profile Details</h1>
        {error && <p style={{ color: 'red' }}>{error}</p>} {/* Show error messages */}

<div className="profile">
                <p>Profile Pitcure</p>
                <img 
                    src={`http://localhost:5000/getimg/${formData.photo}`}
                    alt="photo"
                    height={100}
                    width={100}
                    
                />
            </div>

        <div>
          <TextField
            required
            label="First Name"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          {formErrors.firstName && <p style={{ color: 'red' }}>{formErrors.firstName}</p>}

          <TextField
            required
            label="Last Name"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          {formErrors.lastName && <p style={{ color: 'red' }}>{formErrors.lastName}</p>}
        </div>
        <div>
          <TextField
            required
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
          />
          {formErrors.email && <p style={{ color: 'red' }}>{formErrors.email}</p>}

          <TextField
            required
            name="dateofBirth"
            value={formData.dateofBirth}
            onChange={handleChange}
          />
          {formErrors.dateofBirth && <p style={{ color: 'red' }}>{formErrors.dateofBirth}</p>}
        </div>

        <div>
          <FormControl>
            <FormControlLabel
              control={<Checkbox name="married" checked={formData.married} onChange={handleChange} />}
              label="Married"
            />
            <hr />
            <FormLabel>Gender</FormLabel>
            <RadioGroup
              aria-labelledby="gender-label"
              name="gender"
              value={formData.gender}
              onChange={handleChange}
            >
              <FormControlLabel value="female" control={<Radio />} label="Female" />
              <FormControlLabel value="male" control={<Radio />} label="Male" />
              <FormControlLabel value="other" control={<Radio />} label="Other" />
            </RadioGroup>
          </FormControl>
        </div>

        <div className="container">
          <Stack spacing={5} direction="row" className="center">
            <Button type="submit" variant="contained">Edit</Button>
          </Stack>
        </div>
      </Box>
    </form>
  );
}
