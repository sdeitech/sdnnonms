import {React } from "react"
import PrivateLayout from "../layout/privateLayout"
import Dashboard from "../components/dashboard"
import AddUser from "../components/AddUser"
import ProfileDetail from "../components/ProfileDetail";
import EditProfile from "../components/EditProfile";
import FileUpload from "../components/fileUpload";

const privateRoutes = [
    {
        path: "/dashboard",
        exact: true,
        element: <PrivateLayout><Dashboard/></PrivateLayout>
    },
    {
        path: "/fileUpload",
        exact: true,
        element: <PrivateLayout><FileUpload/></PrivateLayout>
    },
    {
        path: "/detail/:id",
        exact: true,
        element: <PrivateLayout><ProfileDetail/></PrivateLayout>
    },
    {
        path: "/edit",
        exact: true,
        element: <PrivateLayout><EditProfile/></PrivateLayout>
    },

    
    {
        path: "/add-user",
        exact: true,
        element: <PrivateLayout> <AddUser/></PrivateLayout>
    },
];

export default privateRoutes;