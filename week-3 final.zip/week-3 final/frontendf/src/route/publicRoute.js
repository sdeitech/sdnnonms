import {React} from "react";
import PublicLayout from "../layout/publicLayout";
import Signup from '../authentication/Signup'
import Login from "../authentication/login";

const publicRoutes = [
    {
        path: "/login",
        exact: true,
        element: <PublicLayout><Login/></PublicLayout>
    },
    {
        path: "/",
        exact: true,
        element: <PublicLayout><Signup/></PublicLayout>
    }
];
export default publicRoutes;