import privateRoutes from "./privateRoute";
import publicRoutes from "./publicRoute";
import { createBrowserRouter } from "react-router-dom";

const routers = createBrowserRouter([
    ...publicRoutes,
    ...privateRoutes
]);
export default routers;