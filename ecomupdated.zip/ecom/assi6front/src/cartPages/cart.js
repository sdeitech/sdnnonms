import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { addToCart, removeFromCart } from '../reduxcomponent/slice';
import { FaTrash, FaPlus, FaMinus } from 'react-icons/fa'; // For icons
import { useNavigate } from 'react-router-dom';

const Cart = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate()
    const { userId, token } = useSelector((state) => state.users.authUser);
    const [cartItems, setCartItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    console.log(userId)

    useEffect(() => {
        const fetchCart = async () => {
            try {
                const response = await axios.get(`http://localhost:3219/api/cart/getcart`, {
                    params: { user: userId },
                    headers: { Authorization: token }
                });
                setCartItems(response.data.items);
            } catch (error) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchCart();
    }, [userId, token]);

    const handleIncreaseQuantity = async (productId) => {
        try {
            const item = cartItems.find(item => item.product._id === productId);
            const updatedQuantity = item.quantity + 1;

            await axios.put('http://localhost:3219/api/cart/updatecart', {
                user: userId,
                productId,
                quantity: updatedQuantity
            }, {
                headers: {
                    Authorization: token
                }
            });
            dispatch(addToCart({ productId, quantity: 1 }));
            setCartItems(cartItems.map(item => item.product._id === productId ? { ...item, quantity: updatedQuantity } : item));
        } catch (error) {
            console.error('Error increasing quantity:', error);
        }
    };

    const handleDecreaseQuantity = async (productId) => {
        try {
            const item = cartItems.find(item => item.product._id === productId);
            const updatedQuantity = item.quantity - 1;

            if (updatedQuantity > 0) {
                await axios.put('http://localhost:3219/api/cart/updatecart', {
                    user: userId,
                    productId,
                    quantity: updatedQuantity
                }, {
                    headers: {
                        Authorization: token
                    }
                });
                dispatch(addToCart({ productId, quantity: -1 }));
                setCartItems(cartItems.map(item => item.product._id === productId ? { ...item, quantity: updatedQuantity } : item));
            } else {
                handleRemoveItem(productId);
            }
        } catch (error) {
            console.error('Error decreasing quantity:', error);
        }
    };

    const handleRemoveItem = async (productId) => {
        try {
            await axios.delete(`http://localhost:3219/api/cart/deletecart/${productId}`, {
                data: { user: userId },
                headers: { Authorization: token }
            });
            dispatch(removeFromCart(productId));
            setCartItems(cartItems.filter(item => item.product._id !== productId));
        } catch (error) {
            console.error('Error removing item:', error);
        }
    };

    const calculateTotal = () => {
        return cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
    };

    const handleCheckout = async () => {
        try {
            const orderData = {
                user: userId,
                items: cartItems.map(item => ({
                    product: item.product._id,
                    quantity: item.quantity,
                    price: item.product.price,
                })),
                totalAmount: calculateTotal(),
            };
            
            const response = await axios.post('http://localhost:3219/api/order/create', orderData, {
                headers: {
                    Authorization: token,
                },
            });
            navigate("/orders")


            if (response.status === 200) {
                // Handle success (e.g., redirect to order confirmation page)
                alert('Order created successfully!');
                // Clear cart after order is created
                setCartItems([]);
                
            }
        } catch (error) {
            console.error('Error creating order:', error);
            alert('Error creating order. Please try again.');
        }
    };

    if (loading) return <p style={styles.loading}>Loading cart...</p>;
    if (error) return <p style={styles.error}>Error fetching cart: {error}</p>;

    return (
        <div style={styles.cartContainer}>
            <h1 style={styles.heading}>Your Cart</h1>
            
            <button onClick={handleCheckout} style={styles.checkoutButton}>Checkout</button>

            {cartItems.length === 0 ? (
                <p style={styles.emptyCart}>Your cart is empty.</p>
            ) : (
                <div style={styles.cartItems}>
                    {cartItems.map((item) => (
                        <div key={item.product._id} style={styles.cartItemCard}>
                            <div style={styles.itemDetails}>
                                <img src={`http://localhost:3219/getimg/${item.product.image}`} alt={item.product.name} style={styles.itemImage} />
                                <div style={styles.itemInfo}>
                                    <h3>{item.product.name}</h3>
                                    <p style={styles.price}>${item.product.price}</p>
                                </div>
                            </div>
                            <div style={styles.quantityActions}>
                                <button onClick={() => handleIncreaseQuantity(item.product._id)} style={styles.actionButton}>
                                    <FaPlus />
                                </button>
                                <span style={styles.quantity}>{item.quantity}</span>
                                <button onClick={() => handleDecreaseQuantity(item.product._id)} style={styles.actionButton}>
                                    <FaMinus />
                                </button>
                            </div>
                            <button onClick={() => handleRemoveItem(item.product._id)} style={styles.removeButton}>
                                <FaTrash />
                            </button>
                        </div>
                    ))}
                    <div style={styles.totalContainer}>
                        <h2>Total: ${calculateTotal()}</h2>
                    </div>
                </div>
            )}
            <button style={styles.backButton} onClick={() => window.location.href = '/dashboard'}>
                Back to Dashboard
            </button>
        </div>
    );
};

// Core CSS for the component
const styles = {
    cartContainer: {
        fontFamily: 'Arial, sans-serif',
        padding: '20px',
        maxWidth: '1100px',
        margin: '0 auto',
        backgroundColor: '#fff',
        borderRadius: '10px',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
    },
    heading: {
        textAlign: 'center',
        color: '#333',
        fontSize: '32px',
        fontWeight: '600',
        marginBottom: '20px',
    },
    emptyCart: {
        textAlign: 'center',
        color: '#888',
        fontSize: '20px',
        marginTop: '20px',
    },
    cartItems: {
        marginTop: '20px',
    },
    cartItemCard: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '20px',
        marginBottom: '15px',
        backgroundColor: '#fafafa',
        borderRadius: '8px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    itemDetails: {
        display: 'flex',
        alignItems: 'center',
    },
    itemImage: {
        width: '80px',
        height: '80px',
        objectFit: 'cover',
        borderRadius: '8px',
        marginRight: '20px',
    },
    itemInfo: {
        maxWidth: '200px',
    },
    price: {
        fontSize: '18px',
        fontWeight: 'bold',
        color: '#4CAF50',
    },
    quantityActions: {
        display: 'flex',
        alignItems: 'center',
    },
    actionButton: {
        backgroundColor: '#2196F3',
        color: 'white',
        border: 'none',
        padding: '8px 12px',
        margin: '0 10px',
        borderRadius: '4px',
        cursor: 'pointer',
        transition: 'background-color 0.3s ease',
        fontSize: '18px',
    },
    quantity: {
        fontSize: '20px',
        fontWeight: 'bold',
    },
    removeButton: {
        backgroundColor: '#e53935',
        color: 'white',
        border: 'none',
        padding: '8px 12px',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '18px',
        transition: 'background-color 0.3s ease',
    },
    totalContainer: {
        textAlign: 'right',
        marginTop: '20px',
    },
    backButton: {
        display: 'block',
        width: '100%',
        padding: '12px 0',
        backgroundColor: '#00796b',
        color: '#fff',
        border: 'none',
        fontSize: '20px',
        textAlign: 'center',
        borderRadius: '6px',
        cursor: 'pointer',
        marginTop: '30px',
    },
    checkoutButton: {
        width: '100%',
        padding: '14px 0',
        backgroundColor: '#ff9800',
        color: 'white',
        fontSize: '18px',
        fontWeight: '600',
        border: 'none',
        borderRadius: '8px',
        cursor: 'pointer',
        marginBottom: '20px',
    },
    loading: {
        textAlign: 'center',
        fontSize: '20px',
    },
    error: {
        color: 'red',
        fontSize: '18px',
    },
};

export default Cart;
