import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const Orders = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const { userId, token } = useSelector((state) => state.users.authUser);

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get(`http://localhost:3219/api/order/getorders/${userId}`, {
                    headers: { Authorization: `Bearer ${token}` } // Ensure token is sent for authentication
                });
                setOrders(response.data);
            } catch (err) {
                setError('Error fetching orders');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchOrders();
    }, [userId, token]);

    if (loading) {
        return <div style={styles.loading}>Loading...</div>;
    }

    if (error) {
        return <div style={styles.error}>{error}</div>;
    }

    return (
        <div style={styles.ordersContainer}>
            <h2>Your Orders</h2>
            <Link to={"/dashboard"}>
                <button>Dashboard</button></Link>

            {orders.length === 0 ? (
                <p>No orders found for this user.</p>
            ) : (
                <div style={styles.ordersList}>
                    {orders.map((order) => (
                        <div key={order._id} style={styles.orderCard}>
                            <h3 style={styles.orderId}>Order #{order._id}</h3>
                            <p style={styles.totalAmount}>Total: ${order.totalAmount}</p>
                            <ul style={styles.orderItems}>
                                {order.items.map((item) => (
                                    <li key={item.product._id} style={styles.orderItem}>
                                        <p style={styles.itemName}>{item.product.name}</p>
                                        <p style={styles.itemPrice}>Price: ${item.price}</p>
                                        <p style={styles.itemQuantity}>Quantity: {item.quantity}</p>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// Adding CSS as JavaScript object
const styles = {
    ordersContainer: {
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '20px',
        fontFamily: 'Arial, sans-serif',
    },
    loading: {
        textAlign: 'center',
        fontSize: '20px',
        marginTop: '50px',
    },
    error: {
        textAlign: 'center',
        fontSize: '20px',
        marginTop: '50px',
        color: 'red',
    },
    ordersList: {
        display: 'flex',
        flexDirection: 'column',
        gap: '20px',
    },
    orderCard: {
        padding: '20px',
        background: '#f9f9f9',
        border: '1px solid #ddd',
        borderRadius: '8px',
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
    },
    orderId: {
        fontSize: '18px',
        fontWeight: 'bold',
    },
    totalAmount: {
        fontSize: '16px',
        color: '#333',
    },
    orderItems: {
        listStyleType: 'none',
        padding: '0',
        marginTop: '10px',
    },
    orderItem: {
        padding: '10px 0',
        borderBottom: '1px solid #eee',
    },
    itemName: {
        fontSize: '16px',
        fontWeight: 'bold',
    },
    itemPrice: {
        fontSize: '14px',
        color: '#555',
    },
    itemQuantity: {
        fontSize: '14px',
        color: '#555',
    },
};

export default Orders;
