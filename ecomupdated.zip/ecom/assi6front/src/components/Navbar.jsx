import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import './navbar.css';
import Logout from '../reduxcomponent/Logout';

const Navbar = ({ onSearch, role}) => {
    const [searchInput, setSearchInput] = useState('');
    const dispatch = useDispatch()
    const handleLogout = () =>{
        dispatch(Logout())
    }


const handleSearch = (e) => {
        setSearchInput(e.target.value);
        onSearch(e.target.value);
    };

    
    return (
        
        <div className="navbar">
            <input 
                            className="form-control" 
                            type="search" 
                            placeholder="Search by product name" 
                            aria-label="Search" 
                            value={searchInput}
                            onChange={handleSearch}
                        />
            <div className="logo">E-Shop</div>
            <ul className="nav-links">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/cart">Cart</Link></li>
                <li><Link to="/dashboard">Dashboard</Link></li>
            </ul>
            
            <div className="user-info">
            <button style={{backgroundColor:"red",color:"white" ,padding:"4px", outline:"none" }} 
            onClick={handleLogout}
            >
                logout
            </button>
                <span>Welcome, Admin</span>
            </div>
        </div>
    );
};

export default Navbar;
