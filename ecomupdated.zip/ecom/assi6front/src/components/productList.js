// // src/components/ProductList.js
// import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { addToCart} from '../reduxcomponent/slice';
// import axios from 'axios';

// const ProductList = () => {
//   const dispatch = useDispatch();
//   const [products, setProducts] = React.useState([]);
//   const userId = useSelector((state) => state.users.authUser.userId); // Get user ID from Redux

//   useEffect(() => {
//     const fetchProducts = async () => {
//       try {
//         const response = await axios.get("http://localhost:3219/api/productadmin/getproduct"); // Replace with your products API
//         setProducts(response.data);
//       } catch (error) {
//         console.error("Failed to fetch products:", error);
//       }
//     };
    
//     fetchProducts();
//   }, []);

//   const handleAddToCart = async (productId) => {
//     await dispatch(addToCartAPI(userId, productId, 1)); // Add 1 quantity
//   };

//   return (
//     <div>
//       <h1>Product List</h1>
//       <div className="product-grid">
//         {products.map(product => (
//           <div key={product._id} className="product-card">
//             <h2>{product.name}</h2>
//             <p>Price: ${product.price}</p>
//             <button onClick={() => handleAddToCart(product._id)}>Add to Cart</button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default ProductList;
