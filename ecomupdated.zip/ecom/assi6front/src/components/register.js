import React, { useState, useEffect } from "react";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import { Link } from "react-router-dom";
// import validation from "../components/validation";
// import profile from "./profile.png";

const SignUp = () => {
    //const navigate = useNavigate();
    const [formData, setFormData] = useState({
        firstname: "",
        lastname: "",
        mobileno: "",
        email: "",
        password: "",
        role:""
    });
//  console.log(formData,"formdata")
    //   const [error, setError] = useState({});
    const [toastShown, setToastShown] = useState(false);
      const [imgUrl, setImgUrl] = useState(null);

    // console.log(formData);
    const handleChnage = (e) => {
        const { name, value, type, files, checked } = e.target;
        if (type === "file") {
            setFormData({
                ...formData,
                [name]: files[0],
            });
            setImgUrl(URL.createObjectURL(files[0]));
        // } else if (type === "checked") {
        //     setFormData({
        //         ...formData,
        //         [name]: checked,
        //     });
        // } else if (type === "checkbox") {
        //     setFormData({
        //         ...formData,
        //         [name]: checked,
        //     });
        } else {
            setFormData({
                ...formData,
                [name]: value,
            });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // console.log("submit");
        // console.log(",,,,,,,,,,,,,,,", formData);

        // const error = validation(formData);
        // setError(error);
        // console.log(error);
        // if (Object.keys(error).length === 0) {
        try {
            // const token = localStorage.getItem("token");
            const res = await axios.post(
                "http://localhost:3219/api/user/register",
                formData,
                // {
                //     headers: {
                //         // Authorization: `Bearer ${token}`,

                //         "Content-Type": "multipart/form-data",
                //     },
                // }
            );
            setToastShown(true);
            setTimeout(() => {
                // navigate("/dashboard");
            }, 1000);
            console.log(res.data);
        } catch (error) {
            console.log(error.message);
        }
    }
    //  else {
    // }


    useEffect(() => {
        if (toastShown) {
            toast.success("Registration successful!");
            setToastShown(false);
        }
    }, [toastShown]);

    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                minHeight: "100vh",
                background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
            }}
        >
            <div
                style={{
                    padding: "40px",
                    backgroundColor: "#fff",
                    borderRadius: "12px",
                    width: "400px",
                    boxShadow: "0 8px 16px rgba(0, 0, 0, 0.2)",
                    textAlign: "center",
                }}
            >
                <h1 style={{ fontSize: "28px", marginBottom: "20px", color: "#333" }}>
                    Sign Up
                </h1>
                <form
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        width: "100%",
                    }}
                    onSubmit={handleSubmit}
                    encType="multipart/form-data"
                >
                    <input
                        type="text"
                        name="firstname"
                        placeholder="First Name"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "15px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                        }}
                    />
                    {/* {error.firstname && <p style={{ color: "red" }}>{error.firstname}</p>} */}

                    <input
                        type="text"
                        name="lastname"
                        placeholder="Last Name"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "15px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                        }}
                    />
                    {/* {error.lastname && <p style={{ color: "red" }}>{error.lastname}</p>} */}

                    <input
                        type="tel"
                        name="mobileno"
                        placeholder="Mobile Number"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "15px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                        }}
                    />
                    {/* {error.mobileno && <p style={{ color: "red" }}>{error.mobileno}</p>} */}

                    <input
                        type="email"
                        name="email"
                        placeholder="Email Address"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "15px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                        }}
                    />
                    {/* {error.email && <p style={{ color: "red" }}>{error.email}</p>} */}

                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "20px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                        }}
                    />
                    {/* {error.password && <p style={{ color: "red" }}>{error.password}</p>} */}

                    <select
                        name="role"
                        onChange={handleChnage}
                        required
                        style={{
                            padding: "12px",
                            marginBottom: "20px",
                            borderRadius: "8px",
                            border: "1px solid #ddd",
                            fontSize: "16px",
                        }}
                    >
                        <option value="">Select Role</option>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                    {/* {error.role && <p style={{ color: "red" }}>{error.role}</p>} */}

                    <button
                        type="submit"
                        style={{
                            padding: "12px",
                            borderRadius: "8px",
                            backgroundColor: "#6a11cb",
                            color: "white",
                            fontSize: "16px",
                            border: "none",
                            cursor: "pointer",
                            marginBottom: "15px",
                            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.15)",
                        }}
                    >
                        Sign Up
                    </button>
                    {/* {error.submit && <p style={{ color: "red" }}>{error.submit}</p>} */}
                </form>
                <p style={{ marginTop: "15px", color: "#666" }}>
                    Already have an account?{" "}
                    <Link
                        to="/login"
                        style={{
                            color: "#2575fc",
                            textDecoration: "none",
                            fontWeight: "bold",
                        }}
                    >
                        Sign In
                    </Link>
                    <Toaster/>
                </p>
            </div>
        </div>
    )
};

export default SignUp;
