import SignIn from "../components/login";
import SignUp from "../components/register";
import PublicLayout from "../layout/PublicLayout";
// import Updateregistrationform from "../constants/updateregistrationform";
import Dashboard from "../components/dashboard";
// import ChangePassword  from "../components/ChangePassword";
// import ForgetPassword from "../components/ForgotPassword";
// import Cart from "../cartPages/cart";

const PublicRoutes = [
  {
    path: "/",
    element: (
      <PublicLayout>
        <SignUp />
       
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignIn />
      </PublicLayout>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicLayout>
        <SignUp />
      </PublicLayout>
    ),
  },
  // {
  //   path: "/Cart",
  //   element: (
  //     <PublicLayout>
  //       <Cart />
  //     </PublicLayout>
  //   ),
  // },
//   {
//     path: "/back",
//     element: (
//       <PublicLayout>
//         <Dashboard />
//       </PublicLayout>
//     ),
//   },
//   {
//     path: "/out",
//     element: (
//       <PublicLayout>
//         <SignIn />
//       </PublicLayout>
//     ),
//   },
//   {
//     path: "/register",
//     element: (
//       <PublicLayout>
//         <SignUp/>
//       </PublicLayout>
//     ),
//   },
//   {
//     path: "/change",
//     element: (
//       <PublicLayout>
//         <ChangePassword/>
//       </PublicLayout>
//     ),
//   },
//   {
//     path: "/forgot",
//     element: (
//       <PublicLayout>
//         <ForgetPassword/>
//       </PublicLayout>
//     ),
//   },
  

];
export default PublicRoutes;