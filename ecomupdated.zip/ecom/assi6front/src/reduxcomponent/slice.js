
import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "auth",
  initialState: {
    authUser: {
      token: null,
      userId: null,
      role:null,
    },
    cart: { // Ensure this is correctly defined
      items: [],
    },
  },
  reducers: {
    authUser: (state, action) => {
      state.authUser.token = action.payload.token;
      state.authUser.userId = action.payload.userId;
      state.authUser.role = action.payload.role;

    },
    logoutUser: (state) => {
      state.authUser.token = null;
      state.authUser.userId = null;
    },
    clearUsers: (state) => {
      state.authUser.token = null;
      state.authUser.userId = null;
    },
    setCart: (state, action) => {
      state.cart.items = action.payload; // Access cart.items properly
    },
    addToCart: (state, action) => {
      const { productId, quantity } = action.payload;
      const existingProduct = state.cart.items.find(item => item.product === productId);

      if (existingProduct) {
        existingProduct.quantity += quantity; // Update quantity if already in cart
      } else {
        state.cart.items.push({ product: productId, quantity }); // Add new product to cart
      }
    },
    removeFromCart: (state, action) => {
      const productId = action.payload;
      state.cart.items = state.cart.items.filter(item => item.product !== productId); // Remove product from cart
    },
  },
});

export default userSlice.reducer;
export const { authUser, logoutUser, clearUsers, addToCart, setCart,removeFromCart } = userSlice.actions;
