// routes/userRoutes.js
import express from 'express';
import { registerUser,userLogin}  from '../controllers/userController';
// import { verify } from 'jsonwebtoken';
import {verifyToken} from "../middleware/verifytoken"

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', userLogin);

export default router;