import express from 'express';
import { getCart, addToCart, updateCartItem, removeCartItem } from '../controllers/cartController.js';
import { verifyToken } from '../middleware/verifytoken.js';

const router = express.Router();

// Fetch cart - assumes user ID is extracted by verifyToken and passed as req.user.id
router.get('/getcart', verifyToken, getCart);

// Add item to cart
router.post('/addcart', verifyToken, addToCart);

// Update an item in the cart
router.put('/updatecart', verifyToken, updateCartItem);

// Remove an item from the cart by productId
router.delete('/deletecart/:productId', verifyToken, removeCartItem);

export default router;
