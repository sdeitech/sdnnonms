import express from 'express';
import { verifyToken } from "../middleware/verifytoken";
import { uploadMiddleware } from "../helper/multer";

import {
    createProduct,
    getProducts,
    getProductById,
    updateProduct,
    deleteProduct,
} from "../controllers/productController";

const productroute = express.Router();

// Create product (with image upload)
productroute.post("/createproduct",verifyToken, uploadMiddleware.single('image'), createProduct); // Ensure image is uploaded

// Get all products
productroute.get("/getproduct", getProducts);

// Get product by ID
productroute.get('/getproductbyid/:id', getProductById);

// Update product (if you need to update images, include the upload middleware)
productroute.put('/updateproduct/:id', uploadMiddleware.single('image'), updateProduct); // Ensure image can be updated

// Delete product
productroute.delete('/deleteproduct/:id', deleteProduct); // Ensure admin check in the controller

export default productroute;
