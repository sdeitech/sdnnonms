import SendmailTransport from 'nodemailer/lib/sendmail-transport/index.js';
import Order from '../models/orderModel.js';
export const createOrder = async (req, res) => {

try {
const {user, items, totalAmount} = req.body
const order = new Order({
  user: user,
  items:items,
  totalAmount:totalAmount

})
const createdOrder = await order.save()  
const snd = await SendmailTransport
res.json(createdOrder)
} catch (error) {
  res.json({message:error.message })
}
};

export const getOrder = async (req, res) => {
  const { userId } = req.params;

  try {
      const query = userId ? { user: userId } : {};
      const orders = await Order.find(query).populate('user', 'name email').populate('items.product', 'name price');
      console.log(orders, "orders");


      if (!orders || orders.length === 0) {
          return res.status(404).json({ message: 'No orders found' });
      }

      res.json(orders);
  } catch (error) {
      console.error("Error in getOrder:", error);
      res.status(500).json({ message: 'Error retrieving orders', error: error.message });
  }
};
