# from django.urls import path
# from . import views

# urlpatterns = [
#     # path('', views.login, name='login'),
#     path('', views.input, name='input'),
#     path('Display/', views.details, name='details'),
#     path('delete/<int:id>' ,views.delete, name='delete'),
#     path('update/<int:id>' ,views.update, name='update'),
#     path('view/<int:id>', views.view, name='view' )
# ]


from django.urls import path
from .views import EmployeeForm,EmployeeList,EmployeeDetails,EmployeeDelete,EmployeeUpdate

urlpatterns = [
    # path('', Input.as_view(), name='input'),
    # path("details/", Details.as_view(), name='details'),
    # path("update/<int:id>", Update.as_view(), name='update' ),
    # path("delete/<int:id>", Delete.as_view(), name='delete' ),
    # path("view/<int:id>", Person.as_view(), name='view')

    path('', EmployeeForm.as_view(), name='employee_form'),
    path('list/', EmployeeList.as_view(), name='employee_list'),
    path('delete/<int:id>', EmployeeDelete.as_view(), name='delete'),
    path('singledetails/<int:id>', EmployeeDetails.as_view(), name='view'),
    path('update/<int:id>', EmployeeUpdate.as_view(),name='update')
]

