from django.shortcuts import render, redirect
from . models import Employee
from django.views import View
from django.core.paginator import Paginator


#add employee info
class EmployeeForm(View):
    def get(self, request):
        return render(request, 'employee_form.html' )  

    def post(self, request):              
            employee_id = int(request.POST.get('employee_id'))
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            department = request.POST.get('department')
            position = request.POST.get('position')
            date_of_birth = request.POST.get('date_of_birth')
            date_joined = request.POST.get('date_joined')
            salary = int(request.POST.get('salary'))
            is_full_time = request.POST.get('is_full_time')
            email = request.POST.get('email')
            phone_number = request.POST.get('phone_number')
            address = request.POST.get('address')
            city = request.POST.get('city')
            state = request.POST.get('state')
            last_performance_review = request.POST.get('last_performance_review')

            if is_full_time:
                newObj = Employee(
                    employee_id = employee_id,
                    first_name = first_name,
                    last_name = last_name,
                    department = department,
                    position = position,
                    date_of_birth = date_of_birth,
                    date_joined = date_joined,
                    salary = salary,
                    email = email,
                    phone_number = phone_number,
                    address = address,
                    city = city,
                    state = state,
                    last_performance_review = last_performance_review ,  
                    is_full_time = True,
                )
                newObj.save()

            else:
                Employee.objects.create(
                    employee_id = employee_id,
                    first_name = first_name,
                    last_name = last_name,
                    department = department,
                    position = position,
                    date_of_birth = date_of_birth,
                    date_joined = date_joined,
                    salary = salary,
                    email = email,
                    phone_number = phone_number,
                    address = address,
                    city = city,
                    state = state,
                    last_performance_review = last_performance_review ,  
                    is_full_time = False
                )
            
            return redirect('list/')
    
#display table of employee data
class EmployeeList(View):
    def get(self, request):
        result = Employee.objects.all()
        paginator = Paginator(result, 2)
        pageno = request.GET.get('page')
        resultfinal = paginator.get_page(pageno)
        print(result, "result")
        print(resultfinal, "hfghf")

        context = {'result' : resultfinal}

        return render(request, 'employee_list.html', context)   
    
#update Employee daaata
class EmployeeUpdate(View):
    def get(self, request, id):
        result= Employee.objects.get(id = id)
        dateofbirth = result.date_of_birth.strftime('%Y-%m-%d')
        dateofjoin = result.date_joined.strftime('%Y-%m-%d')
        dateofreview = result.last_performance_review.strftime('%Y-%m-%d ,%I:%H %p')
        print(dateofreview)
        context = {'result': result, 'dateofbirth': dateofbirth, 'dateofjoin': dateofjoin, 'dateofreview':dateofreview}
        return render(request, 'update.html', context)
        
    def post(self, request, id):
        employee_id = int(request.POST.get('employee_id'))
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        department = request.POST.get('department')
        position = request.POST.get('position')
        date_of_birth = request.POST.get('date_of_birth')
        date_joined = request.POST.get('date_joined')
        salary = request.POST.get('salary')
        is_full_time = request.POST.get('is_full_time')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        last_performance_review = request.POST.get('last_performance_review')

        result = Employee.objects.get(id=id)

        if employee_id:
            result.employee_id  = employee_id
        
        if first_name:
            result.first_name  = first_name

        if last_name:
            result.last_name  = last_name

        if department:
            result.gender  = department

        if position:
            result.marritialstatus  = position

        if date_of_birth:
            result.date_of_birth  = date_of_birth

        if date_joined:
            result.date_joined  = date_joined

        if salary:
            result.salary  = salary

        if email:
            result.email  = email

        if phone_number:
            result.phone_number  = phone_number

        if address:
            result.address  = address

        if city:
            result.city  = city

        if state:
            result.state  = state

        if last_performance_review:
            result.last_performance_review  = last_performance_review

        if is_full_time == 'on':
            result.is_full_time  = True
        else:
            result.is_full_time = False
        
        result.save()
        return redirect('/list')
        

# delete employee data
class EmployeeDelete(View):
    def get(self, request, id):
        result = Employee.objects.get(id = id)
        result.delete()
        return redirect('/list')


#view single employee data
class EmployeeDetails(View):
    def get(self, request, id):
        result = Employee.objects.get(id=id)
        context = {'result': result}
        return render(request, 'employee_detail.html', context)
    