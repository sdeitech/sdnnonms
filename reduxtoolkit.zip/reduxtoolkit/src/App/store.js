import { configureStore } from "@reduxjs/toolkit";
import Userdetails from '../Features/Userdetails';

export const store = configureStore({
    reducer: {
        app: Userdetails
    }
});


