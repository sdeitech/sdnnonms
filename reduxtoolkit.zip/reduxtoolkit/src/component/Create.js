import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { createUser } from '../Features/Userdetails';
import { useNavigate } from 'react-router-dom';

export const Create = () => {
    const [userDetails, setUserDetails] = useState({});
    const navigate=useNavigate();
    const dispatch = useDispatch();
    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserDetails({ ...userDetails, [name]: value })
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(createUser(userDetails));
        navigate('/read')
    }
    return (
        <div>
            <h3> Post Userdetails</h3>
            <div className='w-50 mx-auto'>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <lable >Name:</lable>
                        <input
                            type="text"
                            name="name"
                            className="form-control"
                            placeholder="Enter Name"
                            onChange={handleChange}
                        />

                    </div>
                    <div className="form-group">
                        <label>Email: </label>
                        <input
                            type="email"
                            name="email"
                            className="form-control"
                            placeholder="Enter email"
                            onChange={handleChange}
                        />

                    </div>
                    <div className="form-group">
                        <label>Age</label>
                        <input
                            type="number"
                            name="age"
                            className="form-control"
                            placeholder="Enter Age"
                            onChange={handleChange}
                        />
                    </div>
                    <div>
                        <div className="mb-3">
                            <input
                                className="form-check-input"
                                type="radio"
                                name="gender"
                                value="male"
                                onChange={handleChange}
                            />
                            <label className="form-check-label" >
                                Male
                            </label>
                        </div>
                        <div className="mb-3">
                            <input
                                className="form-check-input"
                                type="radio"
                                name="gender"
                                value='female'
                                onChange={handleChange}
                            />
                            <label className="form-check-label" >
                                Female
                            </label>
                        </div>
                    </div>
                    <br />
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    )
}
