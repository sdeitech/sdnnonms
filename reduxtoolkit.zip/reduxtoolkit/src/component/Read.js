import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { readUser } from '../Features/Userdetails';
import '../styles/Read.css'
import { Navbar } from './Navbar';
const Read = () => {
    const [showModal, setShowModal] = useState(false);
    const [user, setUser] = useState({});
    const dispatch = useDispatch();
    const allUserdata = useSelector((state) => state.app.users);
    useEffect(() => {
        dispatch(readUser())
    })
    return (

        <div classNameName='container' >
            <h2>all user data</h2>
            {allUserdata && allUserdata.map((value) => (
                <div className="card text-center w-50 mx-auto my-2">
                    <div className="card-header">
                        {value.name}
                    </div>
                    <div className="card-body">
                        <h5 className="card-title">{value.email}</h5>
                        <p className="card-text">{value.gender} &nbsp;{value.age}</p>
                    </div>
                    <div>
                        <button
                            variant="success"
                            onClick={() => {
                                setShowModal(true)
                                
                            }}
                        >View</button>
                        {/* {showModal && (
                            <div
                                className="modal fade"
                                aria-labelledby="exampleModalLabel"
                                aria-hidden="true"
                            >
                                content
                            </div>
                        )
                        } */}
                        <button variant="success">delete</button>
                        <button variant="success">Update</button>
                    </div>

                    <hr></hr>
                </div>
            ))
            }

        </div>
    )
}

export default Read;