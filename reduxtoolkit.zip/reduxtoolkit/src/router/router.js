import { createBrowserRouter } from "react-router-dom";
import Privateroute from "./Privaterouter";
import Publicroute from "./Publicrouter";

const Router = createBrowserRouter([
    ...Publicroute,
    ...Privateroute
]);

export default Router;