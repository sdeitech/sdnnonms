import { Privatelayout } from "../layout/Privatelayout";

const Privateroute = [
    {
        path: "",
        element: <Privatelayout></Privatelayout>
    }
]

export default Privateroute;