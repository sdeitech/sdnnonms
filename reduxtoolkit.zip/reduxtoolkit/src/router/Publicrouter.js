import { Create } from "../component/Create";
import { Navbar } from "../component/Navbar";
import Read from "../component/Read";
import { Publiclayout } from "../layout/Publiclayout";
const Publicroute = [
    {
        path:'/',
        exact:true,
        element:<Publiclayout><Navbar /></Publiclayout>
    },
    {
        path: '/post',
        exact: true,
        element: <Publiclayout> <Create /></Publiclayout>
    },
    {
        path: '/read',
        exact: true,
        element: <Publiclayout> <Read /></Publiclayout>
    }
]
export default Publicroute;