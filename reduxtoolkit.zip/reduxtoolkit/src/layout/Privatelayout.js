import React, { Children, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export const Privatelayout = ({ Children }) => {
    const token = localStorage.getItem("token");
    const navigate = useNavigate();
    useEffect(() => {
        if (!token) {
            navigate('/');
        }
    }, [token, navigate]);
    return (
        <div>{Children}</div>
    )
}
