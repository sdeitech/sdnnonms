import React from 'react'

export const Publiclayout = ({ children }) => {
    return (
        <div>{children}</div>
    )
}
