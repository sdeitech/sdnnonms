import { useDispatch, useSelector } from 'react-redux';

import './App.css';
import { Navbar } from './component/Navbar';
import Router from './router/router';
import { RouterProvider } from 'react-router-dom';
function App() {
  return (
    <div className='App'>
     
      <RouterProvider router={Router} />
    </div>
  )
}

export default App;
