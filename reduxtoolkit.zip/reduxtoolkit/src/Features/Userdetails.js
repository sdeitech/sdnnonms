import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

///read action
export const readUser = createAsyncThunk("readUser", async () => {
    try {
        const response = await fetch("https://670608d7031fd46a8311bcf5.mockapi.io/crud", {
            method: "get",
            headers: {
                'Content-Type': 'Application/json'
            },
        });
        return response.json();
    } catch (error) {
        console.log("error while getting data");
    }
})

//create action
export const createUser = createAsyncThunk("createUser", async (data) => {
    try {
        const response = await fetch("https://670608d7031fd46a8311bcf5.mockapi.io/crud", {
            method: "POST",
            headers: {
                'Content-Type': 'Application/json'
            },
            body: JSON.stringify(data)
        })
        return response.json();
    } catch (error) {
        console.log("error while posting data");
    }
});


export const Userdetails = createSlice({
    name: "userDetails",
    initialState: {
        users: [],
        loading: false,
        error: false
    },
    extraReducers: (builder) => {

        ///for createuser
        builder.addCase(createUser.pending, (state) => {
            state.loading = true
        });
        builder.addCase(createUser.fulfilled, (state, action) => {
            state.loading = false;
            state.users.push(action.payload);
        });
        builder.addCase(createUser.rejected, (state, action) => {
            state.loading = false;
            state.users = (action.payload);
            state.error = true;
        });

        //for readUser
        builder.addCase(readUser.pending, (state) => {
            state.loading = true
        });
        builder.addCase(readUser.fulfilled, (state, action) => {
            state.loading = false;
            state.users = action.payload;
            state.error = false;
        });
        builder.addCase(readUser.rejected, (state) => {
            state.loading = false;
            state.error = true;
        })
    }
})

export default Userdetails.reducer;