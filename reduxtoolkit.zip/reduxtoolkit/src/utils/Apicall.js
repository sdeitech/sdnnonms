import axios from 'axios';

const base_url="https://670608d7031fd46a8311bcf5.mockapi.io/crud";

const apiCall= axios.create({
    baseURL:base_url,
    headers:{
        'Content-Type':'Application/json'
    }
})


export default apiCall;